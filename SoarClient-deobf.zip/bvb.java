/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class bvb
extends en {
    private static final fz[] f = new fz[]{fz.nc, fz.ec, fz.bc, fz.rc, fz.ic, fz.qc, fz.gc, fz.lc};
    private static final fz[] h = new fz[]{fz.mc, fz.xc};
    private final en z;
    private final tib l;
    private String b;
    private String c;
    private int v;
    private boolean d = false;

    public bvb(en a2, tib a3) {
        bvb a4;
        a4.z = a2;
        a4.l = a3;
    }

    @Override
    public void m() {
        bvb a2;
        Object object;
        int n2 = 0;
        a2.b = xab.a("options.stream.title", new Object[0]);
        a2.c = xab.a("options.stream.chat.title", new Object[0]);
        fz[] fzArray = f;
        int n3 = f.length;
        int n4 = 0;
        while (n4 < n3) {
            object = fzArray[n4];
            if (object.p()) {
                a2.r.add(new xvc(object.a(), n / 2 - 155 + n2 % 2 * 160, e / 6 + 24 * (n2 >> 1), (fz)((Object)object)));
            } else {
                a2.r.add(new mkb(object.a(), n / 2 - 155 + n2 % 2 * 160, e / 6 + 24 * (n2 >> 1), (fz)((Object)object), a2.l.p((fz)((Object)object))));
            }
            ++n2;
            ++n4;
        }
        if (n2 % 2 == 1) {
            ++n2;
        }
        a2.v = e / 6 + 24 * (n2 >> 1) + 6;
        n2 += 2;
        fzArray = h;
        n3 = h.length;
        n4 = 0;
        while (n4 < n3) {
            object = fzArray[n4];
            if (object.p()) {
                a2.r.add(new xvc(object.a(), n / 2 - 155 + n2 % 2 * 160, e / 6 + 24 * (n2 >> 1), (fz)((Object)object)));
            } else {
                a2.r.add(new mkb(object.a(), n / 2 - 155 + n2 % 2 * 160, e / 6 + 24 * (n2 >> 1), (fz)((Object)object), a2.l.p((fz)((Object)object))));
            }
            ++n2;
            ++n4;
        }
        a2.r.add(new ff(200, n / 2 - 155, e / 6 + 168, 150, 20, xab.a("gui.done", new Object[0])));
        object = new ff(201, n / 2 + 5, e / 6 + 168, 150, 20, xab.a("options.stream.ingestSelection", new Object[0]));
        ((ff)object).c = a2.w.a().h() && a2.w.a().a().length > 0 || a2.w.a().z();
        a2.r.add(object);
    }

    @Override
    protected void a(ff a2) throws IOException {
        if (a2.c) {
            bvb a3;
            if (a2.b < 100 && a2 instanceof mkb) {
                fz fz2 = ((mkb)a2).p();
                a3.l.p(fz2, 1);
                a2.l = a3.l.p(fz.a(a2.b));
                if (a3.w.a().x() && fz2 != fz.mc && fz2 != fz.xc) {
                    a3.d = true;
                }
            } else if (a2 instanceof xvc) {
                if (a2.b == fz.ic.a()) {
                    a3.w.a().m();
                } else if (a2.b == fz.qc.a()) {
                    a3.w.a().m();
                } else if (a3.w.a().x()) {
                    a3.d = true;
                }
            }
            if (a2.b == 200) {
                a3.w.jb.h();
                a3.w.a(a3.z);
            } else if (a2.b == 201) {
                a3.w.jb.h();
                a3.w.a(new hdb(a3));
            }
        }
    }

    @Override
    public void a(int a2, int a3, float a4) {
        bvb a5;
        a5.o();
        a5.p((gic)((Object)a5.z), a5.b, n / 2, 20, 0xFFFFFF);
        a5.p((gic)((Object)a5.z), a5.c, n / 2, a5.v, 0xFFFFFF);
        if (a5.d) {
            a5.p((gic)((Object)a5.z), (Object)((Object)yf.k) + xab.a("options.stream.changes", new Object[0]), n / 2, 20 + ((gic)((Object)a5.z)).u, 0xFFFFFF);
        }
        super.a(a2, a3, a4);
    }
}

