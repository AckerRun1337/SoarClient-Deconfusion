/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cma {
    private jfa b;
    private Class c;
    private int v;
    private fk[] d;

    public cma(jfa a2, Class a3, int a4) {
        cma a5;
        a5.b = a2;
        a5.c = a3;
        if (a2.a() && a3 != null) {
            a5.d = new fk[a4];
            int n2 = 0;
            while (n2 < a5.d.length) {
                a5.d[n2] = new fk(a2, a3, n2);
                ++n2;
            }
        }
    }

    public jfa a() {
        cma a2;
        return a2.b;
    }

    public Class a() {
        cma a2;
        return a2.c;
    }

    public int a() {
        cma a2;
        return a2.v;
    }

    public fk a(int a2) {
        cma a3;
        return a2 >= 0 && a2 < a3.d.length ? a3.d[a2] : null;
    }
}

