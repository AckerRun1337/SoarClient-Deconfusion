/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class beb
extends yd {
    public static final ewc l = ewc.a("north");
    public static final ewc b = ewc.a("east");
    public static final ewc c = ewc.a("south");
    public static final ewc v = ewc.a("west");
    private final boolean d;

    protected beb(dr a2, boolean a3) {
        super(a2);
        beb a4;
        a4.a(((lf)((Object)a4.c)).a().a(l, false).a(b, false).a(c, false).a(v, false));
        a4.d = a3;
        a4.a(md.k);
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        beb a5;
        return a2.a(l, a5.p(a3.a(a4.y()).a())).a(c, a5.p(a3.a(a4.o()).a())).a(v, a5.p(a3.a(a4.p()).a())).a(b, a5.p(a3.a(a4.a()).a()));
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        beb a5;
        return !a5.d ? null : super.a(a2, a3, a4);
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean p(cb a2, tp a3, hnd a4) {
        beb a5;
        return a2.a(a3).a() == a5 ? false : super.p(a2, a3, a4);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, tca a5, List<tca> a6, rj a7) {
        beb a8;
        boolean bl2 = a8.p(a2.a(a3.y()).a());
        boolean bl3 = a8.p(a2.a(a3.o()).a());
        boolean bl4 = a8.p(a2.a(a3.p()).a());
        boolean bl5 = a8.p(a2.a(a3.a()).a());
        if ((!bl4 || !bl5) && (bl4 || bl5 || bl2 || bl3)) {
            if (bl4) {
                a8.a(0.0f, 0.0f, 0.4375f, 0.5f, 1.0f, 0.5625f);
                super.a(a2, a3, a4, a5, a6, a7);
            } else if (bl5) {
                a8.a(0.5f, 0.0f, 0.4375f, 1.0f, 1.0f, 0.5625f);
                super.a(a2, a3, a4, a5, a6, a7);
            }
        } else {
            a8.a(0.0f, 0.0f, 0.4375f, 1.0f, 1.0f, 0.5625f);
            super.a(a2, a3, a4, a5, a6, a7);
        }
        if ((!bl2 || !bl3) && (bl4 || bl5 || bl2 || bl3)) {
            if (bl2) {
                a8.a(0.4375f, 0.0f, 0.0f, 0.5625f, 1.0f, 0.5f);
                super.a(a2, a3, a4, a5, a6, a7);
            } else if (bl3) {
                a8.a(0.4375f, 0.0f, 0.5f, 0.5625f, 1.0f, 1.0f);
                super.a(a2, a3, a4, a5, a6, a7);
            }
        } else {
            a8.a(0.4375f, 0.0f, 0.0f, 0.5625f, 1.0f, 1.0f);
            super.a(a2, a3, a4, a5, a6, a7);
        }
    }

    @Override
    public void p() {
        beb a2;
        a2.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }

    @Override
    public void a(cb a2, tp a3) {
        beb a4;
        float f2 = 0.4375f;
        float f3 = 0.5625f;
        float f4 = 0.4375f;
        float f5 = 0.5625f;
        boolean bl2 = a4.p(a2.a(a3.y()).a());
        boolean bl3 = a4.p(a2.a(a3.o()).a());
        boolean bl4 = a4.p(a2.a(a3.p()).a());
        boolean bl5 = a4.p(a2.a(a3.a()).a());
        if ((!bl4 || !bl5) && (bl4 || bl5 || bl2 || bl3)) {
            if (bl4) {
                f2 = 0.0f;
            } else if (bl5) {
                f3 = 1.0f;
            }
        } else {
            f2 = 0.0f;
            f3 = 1.0f;
        }
        if ((!bl2 || !bl3) && (bl4 || bl5 || bl2 || bl3)) {
            if (bl2) {
                f4 = 0.0f;
            } else if (bl3) {
                f5 = 1.0f;
            }
        } else {
            f4 = 0.0f;
            f5 = 1.0f;
        }
        a4.a(f2, 0.0f, f4, f3, 1.0f, f5);
    }

    public final boolean p(yd a2) {
        beb a3;
        return a2.n() || a2 == a3 || a2 == cl.om || a2 == cl.e || a2 == cl.r || a2 instanceof beb;
    }

    @Override
    protected boolean j() {
        return true;
    }

    @Override
    public hdc a() {
        return hdc.l;
    }

    @Override
    public int o(ba a2) {
        return 0;
    }

    @Override
    protected lf p() {
        beb a2;
        return new lf(a2, l, b, v, c);
    }
}

