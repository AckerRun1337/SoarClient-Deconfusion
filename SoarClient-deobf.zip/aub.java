/*
 * Decompiled with CFR 0.152.
 */
class aub
extends ie {
    aub() {
        aub a2;
    }

    @Override
    protected ca a(xga a2, ea a3) {
        return new tfb(a2, a3.o(), a3.p(), a3.a());
    }

    @Override
    protected float p() {
        aub a2;
        return super.p() * 0.5f;
    }

    @Override
    protected float a() {
        aub a2;
        return super.a() * 1.25f;
    }
}

