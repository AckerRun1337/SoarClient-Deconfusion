/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class ceb
implements Callable<String> {
    final /* synthetic */ mnb v;
    private final /* synthetic */ wfc d;

    ceb(mnb a2, wfc a3) {
        ceb a4;
        a4.v = a2;
        a4.d = a3;
    }

    public String a() throws Exception {
        ceb a2;
        return a2.d.a();
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        ceb a2;
        return a2.a();
    }
}

