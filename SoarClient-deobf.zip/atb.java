/*
 * Decompiled with CFR 0.152.
 */
import org.lwjgl.opengl.ARBShaderObjects;

public class atb
extends fw {
    private int[][] v;
    private static final int d = Integer.MIN_VALUE;

    public atb(String a2) {
        super(a2);
        atb a3;
        a3.p();
    }

    public void a(int a2, int a3) {
        atb a4;
        int n2 = a4.p();
        int[] nArray = a4.v[n2];
        if (nArray[0] != a2 || nArray[1] != a3) {
            nArray[0] = a2;
            nArray[1] = a3;
            int n3 = a4.a();
            if (n3 >= 0) {
                ARBShaderObjects.a(n3, a2, a3);
                a4.a();
            }
        }
    }

    public int[] a() {
        atb a2;
        int n2 = a2.p();
        int[] nArray = a2.v[n2];
        return nArray;
    }

    @Override
    protected void a(int a2) {
        atb a3;
        if (a2 >= a3.v.length) {
            int[][] nArray = a3.v;
            int[][] nArrayArray = new int[a2 + 10][];
            System.arraycopy(nArray, 0, nArrayArray, 0, nArray.length);
            a3.v = nArrayArray;
        }
        if (a3.v[a2] == null) {
            a3.v[a2] = new int[]{Integer.MIN_VALUE, Integer.MIN_VALUE};
        }
    }

    @Override
    protected void p() {
        a.v = new int[][]{{Integer.MIN_VALUE, Integer.MIN_VALUE}};
    }
}

