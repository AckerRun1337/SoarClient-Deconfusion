/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Splitter
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import SoarClientDeobf-ByAckerRun.gda;
import SoarClientDeobf-ByAckerRun.hka;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dha {
    private static final Splitter c = Splitter.on((char)'\u0000').limit(6);
    private static final Logger v = LogManager.getLogger();
    private final List<joc> d = Collections.synchronizedList(Lists.newArrayList());

    public dha() {
        dha a2;
    }

    public void p(zmc a2) throws UnknownHostException {
        dha a3;
        gvb gvb2 = gvb.a(a2.n);
        joc joc2 = joc.a(InetAddress.getByName(gvb2.a()), gvb2.a(), false);
        a3.d.add(joc2);
        a2.r = "Pinging...";
        a2.f = -1L;
        a2.b = null;
        joc2.a(new rad(a3, joc2, a2));
        try {
            joc2.a(new lec(47, gvb2.a(), gvb2.a(), bs.r));
            joc2.a(new eaa());
        }
        catch (Throwable throwable) {
            v.error((Object)throwable);
        }
    }

    private /* synthetic */ void a(zmc a2) {
        dha a3;
        gvb gvb2 = gvb.a(a2.n);
        ((hka)((hka)((hka)new hka().a(joc.w.p())).a(new zec(a3, gvb2, a2))).a(gda.class)).p(gvb2.a(), gvb2.a());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void p() {
        dha a2;
        List<joc> list = a2.d;
        synchronized (list) {
            Iterator<joc> iterator = a2.d.iterator();
            while (iterator.hasNext()) {
                joc joc2 = iterator.next();
                if (joc2.o()) {
                    joc2.o();
                    continue;
                }
                iterator.remove();
                joc2.a();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a() {
        dha a2;
        List<joc> list = a2.d;
        synchronized (list) {
            Iterator<joc> iterator = a2.d.iterator();
            while (iterator.hasNext()) {
                joc joc2 = iterator.next();
                if (!joc2.o()) continue;
                iterator.remove();
                joc2.a(new gkb("Cancelled"));
            }
        }
    }

    static /* synthetic */ Logger a() {
        return v;
    }

    static /* synthetic */ void a(dha a2, zmc a3) {
        a2.a(a3);
    }

    static /* synthetic */ Splitter a() {
        return c;
    }
}

