/*
 * Decompiled with CFR 0.152.
 */
public class dad
extends dl {
    public /* synthetic */ wfc c;
    public /* synthetic */ float v;
    public /* synthetic */ float d;

    public dad(wfc a2, float a3, float a4) {
        dad a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }
}

