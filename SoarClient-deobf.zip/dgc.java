/*
 * Decompiled with CFR 0.152.
 */
class dgc
extends fea {
    private gm d;

    public dgc(gm a2) {
        super(a2);
        dgc a3;
        a3.d = a2;
    }

    @Override
    public void a() {
        dgc a2;
        if (a2.d.aa && !a2.d.na()) {
            a2.d.a(0.0);
        }
        super.a();
    }
}

