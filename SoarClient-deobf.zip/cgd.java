/*
 * Decompiled with CFR 0.152.
 */
public class cgd
implements fc {
    public cgd() {
        cgd a2;
    }

    @Override
    public ucc a(xga a2, qda a3, tp a4, int a5) {
        return new byb(a2, a3, a4, a5);
    }
}

