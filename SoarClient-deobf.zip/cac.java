/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cac
extends gba {
    private zb v;
    private int d;

    public cac(zb a2, zb a3, pm a4) {
        int n2;
        cac a5;
        a5.v = a3;
        a5.d = a3.o() / 9;
        a3.p(a4);
        int n3 = (a5.d - 4) * 18;
        int n4 = 0;
        while (n4 < a5.d) {
            n2 = 0;
            while (n2 < 9) {
                a5.a(new se(a3, n2 + n4 * 9, 8 + n2 * 18, 18 + n4 * 18));
                ++n2;
            }
            ++n4;
        }
        n4 = 0;
        while (n4 < 3) {
            n2 = 0;
            while (n2 < 9) {
                a5.a(new se(a2, n2 + n4 * 9 + 9, 8 + n2 * 18, 103 + n4 * 18 + n3));
                ++n2;
            }
            ++n4;
        }
        n4 = 0;
        while (n4 < 9) {
            a5.a(new se(a2, n4, 8 + n4 * 18, 161 + n3));
            ++n4;
        }
    }

    @Override
    public boolean a(pm a2) {
        cac a3;
        return a3.v.a(a2);
    }

    @Override
    public wfc a(pm a2, int a3) {
        cac a4;
        wfc wfc2 = null;
        se se2 = (se)a4.f.get(a3);
        if (se2 != null && se2.p()) {
            wfc wfc3 = se2.a();
            wfc2 = wfc3.a();
            if (a3 < a4.d * 9 ? !a4.a(wfc3, a4.d * 9, a4.f.size(), true) : !a4.a(wfc3, 0, a4.d * 9, false)) {
                return null;
            }
            if (wfc3.e == 0) {
                se2.a((wfc)null);
            } else {
                se2.a();
            }
        }
        return wfc2;
    }

    @Override
    public void a(pm a2) {
        cac a3;
        super.a(a2);
        a3.v.a(a2);
    }

    public zb a() {
        cac a2;
        return a2.v;
    }
}

