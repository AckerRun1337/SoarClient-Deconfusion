/*
 * Decompiled with CFR 0.152.
 */
public class ay
implements va<bid> {
    private static final wmc c = new wmc("textures/entity/pig/pig_saddle.png");
    private final cic v;
    private final voa d = new voa(0.5f);

    public ay(cic a2) {
        ay a3;
        a3.v = a2;
    }

    @Override
    public void a(bid a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9) {
        if (a2.la()) {
            ay a10;
            a10.v.p(c);
            a10.d.a(a10.v.a());
            a10.d.a(a2, a3, a4, a6, a7, a8, a9);
        }
    }

    @Override
    public boolean a() {
        return false;
    }
}

