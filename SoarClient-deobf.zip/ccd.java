/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 */
import com.google.common.collect.ImmutableSet;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ccd
implements pa {
    public static final Set<String> v = ImmutableSet.of((Object)"minecraft", (Object)"realms");
    private final Map<String, File> d;

    public ccd(Map<String, File> a2) {
        ccd a3;
        a3.d = a2;
    }

    @Override
    public InputStream a(wmc a2) throws IOException {
        ccd a3;
        InputStream inputStream = a3.p(a2);
        if (inputStream != null) {
            return inputStream;
        }
        InputStream inputStream2 = a3.o(a2);
        if (inputStream2 != null) {
            return inputStream2;
        }
        throw new FileNotFoundException(a2.p());
    }

    public InputStream o(wmc a2) throws IOException, FileNotFoundException {
        ccd a3;
        File file = a3.d.get(a2.toString());
        return file != null && file.isFile() ? new FileInputStream(file) : null;
    }

    private /* synthetic */ InputStream p(wmc a2) {
        String string = "/assets/" + a2.a() + "/" + a2.p();
        InputStream inputStream = tbb.a(string);
        return inputStream != null ? inputStream : ccd.class.getResourceAsStream(string);
    }

    @Override
    public boolean a(wmc a2) {
        ccd a3;
        return a3.p(a2) != null || a3.d.containsKey(a2.toString());
    }

    @Override
    public Set<String> a() {
        return v;
    }

    @Override
    public <T extends v> T a(gn a2, String a3) throws IOException {
        try {
            ccd a4;
            FileInputStream fileInputStream = new FileInputStream(a4.d.get("pack.mcmeta"));
            return qq.a(a2, fileInputStream, a3);
        }
        catch (RuntimeException runtimeException) {
            return null;
        }
        catch (FileNotFoundException fileNotFoundException) {
            return null;
        }
    }

    @Override
    public BufferedImage a() throws IOException {
        return zjc.a(ccd.class.getResourceAsStream("/" + new wmc("pack.png").p()));
    }

    @Override
    public String a() {
        return "Default";
    }
}

