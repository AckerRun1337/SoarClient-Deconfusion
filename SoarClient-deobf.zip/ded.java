/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;

public class ded
extends bh {
    public ded() {
        super("ClickGUI", 54, gk.v);
        ded a2;
    }

    @Override
    public void y() {
        ded a2;
        ArrayList<String> arrayList = new ArrayList<String>();
        ArrayList<String> arrayList2 = new ArrayList<String>();
        ArrayList<String> arrayList3 = new ArrayList<String>();
        arrayList.add("Color");
        arrayList.add("Classic");
        arrayList.add("Clear");
        arrayList.add("Normal");
        arrayList.add("Rainbow");
        arrayList.add("Outline");
        arrayList.add("Outline2");
        arrayList2.add("Vanilla");
        arrayList2.add("Custom");
        arrayList3.add("Hide");
        arrayList3.add("Normal");
        arrayList3.add("Color");
        gsc.t.w.a(new egd("Blur", a2, true));
        gsc.t.w.a(new egd("Opacity", a2, 1.0, 0.0, 1.0, false));
        gsc.t.w.a(new egd("Radius", a2, 6.0, 0.0, 10.0, true));
        gsc.t.w.a(new egd("Blur Radius", a2, 20.0, 1.0, 30.0, true));
        gsc.t.w.a(new egd("Design", a2, "Color", arrayList));
        gsc.t.w.a(new egd("Font", a2, "Custom", arrayList2));
        gsc.t.w.a(new egd("Shadow", a2, "Normal", arrayList3));
        gsc.t.w.a(new egd("Volume", a2, 1.0, 0.0, 1.0, false));
        gsc.t.w.a(new egd("Random", a2, false));
        gsc.t.w.a(new egd("Loop", a2, false));
        a2.p(true);
    }

    @Override
    public void o() {
        ded a2;
        super.o();
        a2.g.a(gsc.t.e);
        a2.y(false);
    }
}

