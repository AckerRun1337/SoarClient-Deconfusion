/*
 * Decompiled with CFR 0.152.
 */
public class ckd
extends tf {
    private static final wmc b = new wmc("textures/particle/footprint.png");
    private int c;
    private int v;
    private ov d;

    protected ckd(ov a2, xga a3, double a4, double a5, double a6) {
        super(a3, a4, a5, a6, 0.0, 0.0, 0.0);
        ckd a7;
        a7.d = a2;
        a7.wb = 0.0;
        a7.gb = 0.0;
        a7.mb = 0.0;
        a7.v = 200;
    }

    @Override
    public void a(krb a2, rj a3, float a4, float a5, float a6, float a7, float a8, float a9) {
        float f2;
        ckd a10;
        float f3 = ((float)a10.c + a4) / (float)a10.v;
        if ((f2 = 2.0f - (f3 *= f3) * 2.0f) > 1.0f) {
            f2 = 1.0f;
        }
        f2 *= 0.2f;
        ewa.ka();
        float f4 = 0.125f;
        float f5 = (float)(a10.fb - c);
        float f6 = (float)(a10.zb - v);
        float f7 = (float)(a10.db - d);
        float f8 = a10.ib.a(new tp(a10));
        a10.d.p(b);
        ewa.w();
        ewa.y(770, 771);
        a2.a(7, ybd.e);
        a2.a((double)(f5 - 0.125f), (double)f6, (double)(f7 + 0.125f)).a(0.0, 1.0).a(f8, f8, f8, f2).z();
        a2.a((double)(f5 + 0.125f), (double)f6, (double)(f7 + 0.125f)).a(1.0, 1.0).a(f8, f8, f8, f2).z();
        a2.a((double)(f5 + 0.125f), (double)f6, (double)(f7 - 0.125f)).a(1.0, 0.0).a(f8, f8, f8, f2).z();
        a2.a((double)(f5 - 0.125f), (double)f6, (double)(f7 - 0.125f)).a(0.0, 0.0).a(f8, f8, f8, f2).z();
        xlb.a().a();
        ewa.b();
        ewa.ra();
    }

    @Override
    public void n() {
        ckd a2;
        ++a2.c;
        if (a2.c == a2.v) {
            a2.g();
        }
    }

    @Override
    public int a() {
        return 3;
    }
}

