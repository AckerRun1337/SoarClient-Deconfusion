/*
 * Decompiled with CFR 0.152.
 */
public class brb {
    private ypb c = new ypb();
    private fwc[] v = new fwc[32];
    private wqa d;

    public brb(wqa a2) {
        brb a3;
        a3.d = a2;
    }

    public zjb a(cb a2, rj a3, rj a4, float a5) {
        brb a6;
        return a6.a(a2, a3, a4.fb, a4.a().l, a4.db, a5);
    }

    public zjb a(cb a2, rj a3, tp a4, float a5) {
        brb a6;
        return a6.a(a2, a3, (float)a4.o() + 0.5f, (float)a4.p() + 0.5f, (float)a4.a() + 0.5f, a5);
    }

    private /* synthetic */ zjb a(cb a2, rj a3, double a4, double a5, double a6, float a7) {
        brb a8;
        a8.c.a();
        a8.d.a(a2, a3);
        fwc fwc2 = a8.d.a(a3);
        fwc fwc3 = a8.d.a(a3, a4, a5, a6);
        zjb zjb2 = a8.a(a3, fwc2, fwc3, a7);
        a8.d.a();
        return zjb2;
    }

    private /* synthetic */ zjb a(rj a2, fwc a3, fwc a4, float a5) {
        brb a6;
        a3.l = 0.0f;
        a3.c = a3.b = a3.a(a4);
        a6.c.a();
        a6.c.a(a3);
        fwc fwc2 = a3;
        while (!a6.c.a()) {
            fwc fwc3 = a6.c.a();
            if (fwc3.equals(a4)) {
                return a6.a(a3, a4);
            }
            if (fwc3.a(a4) < fwc2.a(a4)) {
                fwc2 = fwc3;
            }
            fwc3.d = true;
            int n2 = a6.d.a(a6.v, a2, fwc3, a4, a5);
            int n3 = 0;
            while (n3 < n2) {
                fwc fwc4 = a6.v[n3];
                float f2 = fwc3.l + fwc3.a(fwc4);
                if (f2 < a5 * 2.0f && (!fwc4.a() || f2 < fwc4.l)) {
                    fwc4.v = fwc3;
                    fwc4.l = f2;
                    fwc4.b = fwc4.a(a4);
                    if (fwc4.a()) {
                        a6.c.a(fwc4, fwc4.l + fwc4.b);
                    } else {
                        fwc4.c = fwc4.l + fwc4.b;
                        a6.c.a(fwc4);
                    }
                }
                ++n3;
            }
        }
        if (fwc2 == a3) {
            return null;
        }
        return a6.a(a3, fwc2);
    }

    private /* synthetic */ zjb a(fwc a2, fwc a3) {
        int n2 = 1;
        fwc[] fwcArray = a3;
        while (fwcArray.v != null) {
            ++n2;
            fwcArray = fwcArray.v;
        }
        fwcArray = new fwc[n2];
        Object object = a3;
        fwcArray[--n2] = a3;
        while (object.v != null) {
            object = object.v;
            fwcArray[--n2] = object;
        }
        return new zjb(fwcArray);
    }
}

