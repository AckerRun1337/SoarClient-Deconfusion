/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class as
implements Serializable,
Cloneable {
    static final long c = -3555701650170169638L;
    public int v;
    public int d;

    public as(int a2, int a3) {
        as a4;
        a4.v = a2;
        a4.d = a3;
    }

    public as(int[] a2) {
        as a3;
        a3.v = a2[0];
        a3.d = a2[1];
    }

    public as(as a2) {
        as a3;
        a3.v = a2.v;
        a3.d = a2.d;
    }

    public as() {
        as a2;
        a2.v = 0;
        a2.d = 0;
    }

    public final void p(int a2, int a3) {
        a.v = a2;
        a.d = a3;
    }

    public final void p(int[] a2) {
        a.v = a2[0];
        a.d = a2[1];
    }

    public final void j(as a2) {
        a.v = a2.v;
        a.d = a2.d;
    }

    public final void a(int[] a2) {
        as a3;
        a2[0] = a3.v;
        a2[1] = a3.d;
    }

    public final void z(as a2) {
        as a3;
        a2.v = a3.v;
        a2.d = a3.d;
    }

    public final void p(as a2, as a3) {
        a.v = a2.v + a3.v;
        a.d = a2.d + a3.d;
    }

    public final void y(as a2) {
        a.v += a2.v;
        a.d += a2.d;
    }

    public final void a(as a2, as a3) {
        a.v = a2.v - a3.v;
        a.d = a2.d - a3.d;
    }

    public final void o(as a2) {
        a.v -= a2.v;
        a.d -= a2.d;
    }

    public final void p(as a2) {
        a.v = -a2.v;
        a.d = -a2.d;
    }

    public final void p() {
        as a2;
        a2.v = -a2.v;
        a2.d = -a2.d;
    }

    public final void y(int a2, as a3) {
        a.v = a2 * a3.v;
        a.d = a2 * a3.d;
    }

    public final void z(int a2) {
        a.v *= a2;
        a.d *= a2;
    }

    public final void a(int a2, as a3, as a4) {
        a.v = a2 * a3.v + a4.v;
        a.d = a2 * a3.d + a4.d;
    }

    public final void o(int a2, as a3) {
        as a4;
        a4.v = a2 * a4.v + a3.v;
        a4.d = a2 * a4.d + a3.d;
    }

    public String toString() {
        as a2;
        return "(" + a2.v + ", " + a2.d + ")";
    }

    public boolean equals(Object a2) {
        try {
            as a3;
            as as2 = (as)a2;
            return a3.v == as2.v && a3.d == as2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
        catch (ClassCastException classCastException) {
            return false;
        }
    }

    public int hashCode() {
        as a2;
        long l2 = 1L;
        l2 = 31L * l2 + (long)a2.v;
        l2 = 31L * l2 + (long)a2.d;
        return (int)(l2 ^ l2 >> 32);
    }

    public final void a(int a2, int a3, as a4) {
        a.v = a4.v > a3 ? a3 : (a4.v < a2 ? a2 : a4.v);
        a.d = a4.d > a3 ? a3 : (a4.d < a2 ? a2 : a4.d);
    }

    public final void p(int a2, as a3) {
        a.v = a3.v < a2 ? a2 : a3.v;
        a.d = a3.d < a2 ? a2 : a3.d;
    }

    public final void a(int a2, as a3) {
        a.v = a3.v > a2 ? a2 : a3.v;
        a.d = a3.d > a2 ? a2 : a3.d;
    }

    public final void a(as a2) {
        a.v = Math.abs(a2.v);
        a.d = Math.abs(a2.d);
    }

    public final void a(int a2, int a3) {
        as a4;
        if (a4.v > a3) {
            a4.v = a3;
        } else if (a4.v < a2) {
            a4.v = a2;
        }
        if (a4.d > a3) {
            a4.d = a3;
        } else if (a4.d < a2) {
            a4.d = a2;
        }
    }

    public final void y(int a2) {
        as a3;
        if (a3.v < a2) {
            a3.v = a2;
        }
        if (a3.d < a2) {
            a3.d = a2;
        }
    }

    public final void o(int a2) {
        as a3;
        if (a3.v > a2) {
            a3.v = a2;
        }
        if (a3.d > a2) {
            a3.d = a2;
        }
    }

    public final void a() {
        as a2;
        a2.v = Math.abs(a2.v);
        a2.d = Math.abs(a2.d);
    }

    public Object clone() {
        try {
            as a2;
            return super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
    }

    public final int p() {
        as a2;
        return a2.v;
    }

    public final void p(int a2) {
        a.v = a2;
    }

    public final int a() {
        as a2;
        return a2.d;
    }

    public final void a(int a2) {
        a.d = a2;
    }
}

