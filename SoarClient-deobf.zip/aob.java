/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Charsets
 *  com.google.common.collect.Maps
 *  com.google.common.io.Files
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.base.Charsets;
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class aob {
    private static final Logger v = LogManager.getLogger();
    private final Map<String, File> d;

    public aob(File a2, String a3) {
        block9: {
            aob a4;
            a4.d = Maps.newHashMap();
            if (a3 != null) {
                File file = new File(a2, "objects");
                File file2 = new File(a2, "indexes/" + a3 + ".json");
                BufferedReader bufferedReader = null;
                try {
                    bufferedReader = Files.newReader((File)file2, (Charset)Charsets.UTF_8);
                    JsonElement jsonElement = new JsonParser().a(bufferedReader).a();
                    JsonObject jsonObject = px.a((JsonObject)jsonElement, "objects", null);
                    if (jsonObject != null) {
                        for (Map.Entry<String, JsonElement> entry : jsonObject.p()) {
                            JsonObject jsonObject2 = (JsonObject)entry.getValue();
                            String string = entry.getKey();
                            String[] stringArray = string.split("/", 2);
                            String string2 = stringArray.length == 1 ? stringArray[0] : String.valueOf(stringArray[0]) + ":" + stringArray[1];
                            String string3 = px.a(jsonObject2, "hash");
                            File file3 = new File(file, String.valueOf(string3.substring(0, 2)) + "/" + string3);
                            a4.d.put(string2, file3);
                        }
                    }
                }
                catch (JsonParseException jsonParseException) {
                    v.error("Unable to parse resource index file: " + file2);
                    IOUtils.closeQuietly((Reader)bufferedReader);
                    break block9;
                }
                catch (FileNotFoundException fileNotFoundException) {
                    try {
                        v.error("Can't find the resource index file: " + file2);
                    }
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(bufferedReader);
                        throw throwable;
                    }
                    IOUtils.closeQuietly((Reader)bufferedReader);
                    break block9;
                }
                IOUtils.closeQuietly((Reader)bufferedReader);
            }
        }
    }

    public Map<String, File> a() {
        aob a2;
        return a2.d;
    }
}

