/*
 * Decompiled with CFR 0.152.
 */
public abstract class bkc
extends ej {
    public bkc() {
        bkc a2;
    }

    protected bkc(moa a2, int a3) {
        super(a2, a3);
        bkc a4;
    }
}

