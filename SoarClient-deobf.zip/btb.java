/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 */
import com.google.common.base.Predicate;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class btb
extends an {
    private vfb l;
    private vfb b;
    private vfb c;
    private vfb v;
    private static final Predicate<ba> d = a2 -> a2 != null && (a2.a() == cl.cc || a2.a() == cl.sc);

    protected btb() {
        super(dr.s, rpb.m);
        btb a2;
        a2.a(((lf)((Object)a2.c)).a().a(d, hnd.x));
        a2.a(true);
        a2.a(md.g);
    }

    @Override
    public void p(xga a2, tp a3, ba a4) {
        btb a5;
        super.p(a2, a3, a4);
        a5.p(a2, a3);
    }

    public boolean o(xga a2, tp a3) {
        btb a4;
        return a4.y().a(a2, a3) != null || a4.p().a(a2, a3) != null;
    }

    private /* synthetic */ void p(xga a2, tp a3) {
        block9: {
            clc clc2;
            btb a4;
            block8: {
                Object object;
                clc2 = a4.o().a(a2, a3);
                if (clc2 == null) break block8;
                int n2 = 0;
                while (n2 < a4.o().p()) {
                    object = clc2.a(0, n2, 0);
                    a2.a(((rfa)object).a(), cl.cd.a(), 2);
                    ++n2;
                }
                sbd sbd2 = new sbd(a2);
                object = clc2.a(0, 2, 0).a();
                sbd2.p((double)((vx)object).o() + 0.5, (double)((vx)object).p() + 0.05, (double)((vx)object).a() + 0.5, 0.0f, 0.0f);
                a2.a(sbd2);
                int n3 = 0;
                while (n3 < 120) {
                    a2.a(wra.x, (double)((vx)object).o() + a2.q.nextDouble(), (double)((vx)object).p() + a2.q.nextDouble() * 2.5, (double)((vx)object).a() + a2.q.nextDouble(), 0.0, 0.0, 0.0, new int[0]);
                    ++n3;
                }
                n3 = 0;
                while (n3 < a4.o().p()) {
                    rfa rfa2 = clc2.a(0, n3, 0);
                    a2.y(rfa2.a(), cl.cd);
                    ++n3;
                }
                break block9;
            }
            clc2 = a4.a().a(a2, a3);
            if (clc2 == null) break block9;
            int n4 = 0;
            while (n4 < a4.a().a()) {
                int n5 = 0;
                while (n5 < a4.a().p()) {
                    a2.a(clc2.a(n4, n5, 0).a(), cl.cd.a(), 2);
                    ++n5;
                }
                ++n4;
            }
            tp tp2 = clc2.a(1, 2, 0).a();
            fda fda2 = new fda(a2);
            fda2.q(true);
            fda2.p((double)tp2.o() + 0.5, (double)tp2.p() + 0.05, (double)tp2.a() + 0.5, 0.0f, 0.0f);
            a2.a(fda2);
            int n6 = 0;
            while (n6 < 120) {
                a2.a(wra.k, (double)tp2.o() + a2.q.nextDouble(), (double)tp2.p() + a2.q.nextDouble() * 3.9, (double)tp2.a() + a2.q.nextDouble(), 0.0, 0.0, 0.0, new int[0]);
                ++n6;
            }
            n6 = 0;
            while (n6 < a4.a().a()) {
                int n7 = 0;
                while (n7 < a4.a().p()) {
                    rfa rfa3 = clc2.a(n6, n7, 0);
                    a2.y(rfa3.a(), cl.cd);
                    ++n7;
                }
                ++n6;
            }
        }
    }

    @Override
    public boolean a(xga a2, tp a3) {
        return a2.a((tp)a3).a().z.o() && xga.a(a2, a3.z());
    }

    @Override
    public ba a(xga a2, tp a3, hnd a4, float a5, float a6, float a7, int a8, xi a9) {
        btb a10;
        return a10.a().a(d, a9.a().z());
    }

    @Override
    public ba a(int a2) {
        btb a3;
        return a3.a().a(d, hnd.a(a2));
    }

    @Override
    public int o(ba a2) {
        return ((hnd)((Object)a2.a(d))).y();
    }

    @Override
    protected lf p() {
        btb a2;
        return new lf(a2, new gb[]{d});
    }

    protected vfb y() {
        btb a2;
        if (a2.l == null) {
            a2.l = zrc.a().a(" ", "#", "#").a('#', rfa.a(nkc.a(cl.kn))).a();
        }
        return a2.l;
    }

    protected vfb o() {
        btb a2;
        if (a2.b == null) {
            a2.b = zrc.a().a("^", "#", "#").a('^', rfa.a(d)).a('#', rfa.a(nkc.a(cl.kn))).a();
        }
        return a2.b;
    }

    protected vfb p() {
        btb a2;
        if (a2.c == null) {
            a2.c = zrc.a().a("~ ~", "###", "~#~").a('#', rfa.a(nkc.a(cl.do))).a('~', rfa.a(nkc.a(cl.cd))).a();
        }
        return a2.c;
    }

    protected vfb a() {
        btb a2;
        if (a2.v == null) {
            a2.v = zrc.a().a("~^~", "###", "~#~").a('^', rfa.a(d)).a('#', rfa.a(nkc.a(cl.do))).a('~', rfa.a(nkc.a(cl.cd))).a();
        }
        return a2.v;
    }
}

