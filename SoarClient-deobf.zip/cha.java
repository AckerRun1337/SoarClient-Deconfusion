/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class cha
implements o<vi> {
    private ga v;
    private ga d;

    public cha() {
        cha a2;
    }

    public cha(ga a2) {
        cha a3;
        a3.v = a2;
    }

    @Override
    public void p(io a2) throws IOException {
        a.v = a2.a();
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        cha a3;
        a2.a(a3.v);
        a2.a(a3.d);
    }

    @Override
    public void a(vi a2) {
        cha a3;
        a2.a(a3);
    }

    public ga p() {
        cha a2;
        return a2.v;
    }

    public ga a() {
        cha a2;
        return a2.d;
    }
}

