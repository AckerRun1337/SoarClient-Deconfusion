/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class bw {
    int z;
    bw[] l = new bw[6];
    boolean[] b = new boolean[6];
    boolean c;
    boolean v;
    int d;

    public bw(int a2) {
        bw a3;
        a3.z = a2;
    }

    public void a(hnd a2, bw a3) {
        bw a4;
        a4.l[a2.z()] = a3;
        a3.l[a2.z().z()] = a4;
    }

    public void a() {
        int n2 = 0;
        while (n2 < 6) {
            bw a2;
            a2.b[n2] = a2.l[n2] != null;
            ++n2;
        }
    }

    public boolean a(int a2) {
        bw a3;
        if (a3.v) {
            return true;
        }
        a3.d = a2;
        int n2 = 0;
        while (n2 < 6) {
            if (a3.l[n2] != null && a3.b[n2] && a3.l[n2].d != a2 && a3.l[n2].a(a2)) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    public boolean a() {
        bw a2;
        return a2.z >= 75;
    }

    public int a() {
        int n2 = 0;
        int n3 = 0;
        while (n3 < 6) {
            bw a2;
            if (a2.b[n3]) {
                ++n2;
            }
            ++n3;
        }
        return n2;
    }
}

