/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aib {
    private static final Logger l = LogManager.getLogger();
    private final svb b;
    private final sga c;
    private int v;
    private int d;

    public aib(int a2, svb a3, sga a4, int a5) {
        aib a6;
        if (!a6.a(a2, a4)) {
            l.warn("Multiple vertex elements of the same type other than UVs are not supported. Forcing type to UV.");
            a6.c = sga.z;
        } else {
            a6.c = a4;
        }
        a6.b = a3;
        a6.v = a2;
        a6.d = a5;
    }

    private final /* synthetic */ boolean a(int a2, sga a3) {
        return a2 == 0 || a3 == sga.z;
    }

    public final svb a() {
        aib a2;
        return a2.b;
    }

    public final sga a() {
        aib a2;
        return a2.c;
    }

    public final int o() {
        aib a2;
        return a2.d;
    }

    public final int p() {
        aib a2;
        return a2.v;
    }

    public String toString() {
        aib a2;
        return String.valueOf(a2.d) + "," + a2.c.a() + "," + a2.b.a();
    }

    public final int a() {
        aib a2;
        return a2.b.p() * a2.d;
    }

    public final boolean a() {
        aib a2;
        return a2.c == sga.r;
    }

    public boolean equals(Object a2) {
        aib a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 != null && a3.getClass() == a2.getClass()) {
            aib aib2 = (aib)a2;
            return a3.d != aib2.d ? false : (a3.v != aib2.v ? false : (a3.b != aib2.b ? false : a3.c == aib2.c));
        }
        return false;
    }

    public int hashCode() {
        aib a2;
        int n2 = a2.b.hashCode();
        n2 = 31 * n2 + a2.c.hashCode();
        n2 = 31 * n2 + a2.v;
        n2 = 31 * n2 + a2.d;
        return n2;
    }
}

