/*
 * Decompiled with CFR 0.152.
 */
public class bd
extends wg {
    public bd(long a2, wg a3) {
        super(a2);
        bd a4;
        a4.c = a3;
    }

    @Override
    public int[] a(int a2, int a3, int a4, int a5) {
        bd a6;
        int n2 = a2 - 1;
        int n3 = a3 - 1;
        int n4 = a4 + 2;
        int n5 = a5 + 2;
        int[] nArray = a6.c.a(n2, n3, n4, n5);
        int[] nArray2 = xeb.a(a4 * a5);
        int n6 = 0;
        while (n6 < a5) {
            int n7 = 0;
            while (n7 < a4) {
                int n8 = nArray[n7 + 0 + (n6 + 0) * n4];
                int n9 = nArray[n7 + 2 + (n6 + 0) * n4];
                int n10 = nArray[n7 + 0 + (n6 + 2) * n4];
                int n11 = nArray[n7 + 2 + (n6 + 2) * n4];
                int n12 = nArray[n7 + 1 + (n6 + 1) * n4];
                a6.a((long)(n7 + a2), (long)(n6 + a3));
                if (n12 != 0 || n8 == 0 && n9 == 0 && n10 == 0 && n11 == 0) {
                    nArray2[n7 + n6 * a4] = n12 > 0 && (n8 == 0 || n9 == 0 || n10 == 0 || n11 == 0) ? (a6.a(5) == 0 ? (n12 == 4 ? 4 : 0) : n12) : n12;
                } else {
                    int n13 = 1;
                    int n14 = 1;
                    if (n8 != 0 && a6.a(n13++) == 0) {
                        n14 = n8;
                    }
                    if (n9 != 0 && a6.a(n13++) == 0) {
                        n14 = n9;
                    }
                    if (n10 != 0 && a6.a(n13++) == 0) {
                        n14 = n10;
                    }
                    if (n11 != 0 && a6.a(n13++) == 0) {
                        n14 = n11;
                    }
                    nArray2[n7 + n6 * a4] = a6.a(3) == 0 ? n14 : (n14 == 4 ? 4 : 0);
                }
                ++n7;
            }
            ++n6;
        }
        return nArray2;
    }
}

