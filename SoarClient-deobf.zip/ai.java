/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ai
extends yd {
    public static final afa d = afa.a("age", 0, 15);

    protected ai() {
        super(dr.t);
        ai a2;
        a2.a(a2.c.a().a(d, 0));
        a2.a(true);
        a2.a(md.k);
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        tp tp2 = a3.j();
        if (a2.a(tp2)) {
            ai a6;
            int n2 = 1;
            while (a2.a(a3.z(n2)).a() == a6) {
                ++n2;
            }
            if (n2 < 3) {
                int n3 = a4.a(d);
                if (n3 == 15) {
                    a2.a(tp2, a6.a());
                    ba ba2 = a4.a(d, 0);
                    a2.a(a3, ba2, 4);
                    a6.a(a2, tp2, ba2, a6);
                } else {
                    a2.a(a3, a4.a(d, n3 + 1), 4);
                }
            }
        }
    }

    @Override
    public tca a(xga a2, tp a3, ba a4) {
        float f2 = 0.0625f;
        return new tca((float)a3.o() + f2, a3.p(), (float)a3.a() + f2, (float)(a3.o() + 1) - f2, (float)(a3.p() + 1) - f2, (float)(a3.a() + 1) - f2);
    }

    @Override
    public tca a(xga a2, tp a3) {
        float f2 = 0.0625f;
        return new tca((float)a3.o() + f2, a3.p(), (float)a3.a() + f2, (float)(a3.o() + 1) - f2, a3.p() + 1, (float)(a3.a() + 1) - f2);
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        ai a4;
        return super.a(a2, a3) ? a4.o(a2, a3) : false;
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        ai a6;
        if (!a6.o(a2, a3)) {
            a2.y(a3, true);
        }
    }

    public boolean o(xga a2, tp a3) {
        Object object2;
        for (Object object2 : wta.b) {
            if (!a2.a(a3.a((hnd)object2)).a().a().x()) continue;
            return false;
        }
        object2 = a2.a(a3.z()).a();
        return object2 == cl.fd || object2 == cl.bg;
    }

    @Override
    public void a(xga a2, tp a3, ba a4, rj a5) {
        a5.a(sy.k, 1.0f);
    }

    @Override
    public hdc a() {
        return hdc.b;
    }

    @Override
    public ba a(int a2) {
        ai a3;
        return a3.a().a(d, a2);
    }

    @Override
    public int o(ba a2) {
        return a2.a(d);
    }

    @Override
    protected lf p() {
        ai a2;
        return new lf(a2, d);
    }
}

