/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

class dea
extends URLConnection {
    final /* synthetic */ lyb v;
    private final /* synthetic */ wmc d;

    dea(lyb a2, URL a3, wmc a4) {
        dea a5;
        a5.v = a2;
        a5.d = a4;
        super(a3);
    }

    @Override
    public void connect() throws IOException {
    }

    @Override
    public InputStream getInputStream() throws IOException {
        dea a2;
        return oj.a().a().a(a2.d).a();
    }
}

