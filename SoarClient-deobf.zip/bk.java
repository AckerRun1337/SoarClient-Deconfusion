/*
 * Decompiled with CFR 0.152.
 */
public class bk
extends nd {
    private yd v;
    private yd d;

    public bk(int a2, float a3, yd a4, yd a5) {
        super(a2, a3, false);
        bk a6;
        a6.v = a4;
        a6.d = a5;
    }

    @Override
    public boolean a(wfc a2, pm a3, xga a4, tp a5, hnd a6, float a7, float a8, float a9) {
        bk a10;
        if (a6 != hnd.k) {
            return false;
        }
        if (!a3.a(a5.a(a6), a6, a2)) {
            return false;
        }
        if (a4.a(a5).a() == a10.d && a4.a(a5.j())) {
            a4.a(a5.j(), a10.v.a());
            --a2.e;
            return true;
        }
        return false;
    }
}

