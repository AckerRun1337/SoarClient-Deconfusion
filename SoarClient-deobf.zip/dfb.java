/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dfb
extends yd {
    public static final iab b = iab.a("facing");
    public static final kcb<aoa> c = kcb.a("type", aoa.class);
    public static final ewc v = ewc.a("short");
    private static volatile /* synthetic */ int[] d;

    public dfb() {
        super(dr.r);
        dfb a2;
        a2.a(((lf)((Object)a2.c)).a().a(b, hnd.x).a(c, aoa.b).a(v, false));
        a2.a(ja);
        a2.a(0.5f);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, pm a5) {
        dfb a6;
        tp tp2;
        yd yd2;
        hnd hnd2;
        if (a5.y.b && (hnd2 = a4.a(b)) != null && ((yd2 = a2.a(tp2 = a3.a(hnd2.z())).a()) == cl.yk || yd2 == cl.ci)) {
            a2.r(tp2);
        }
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(xga a2, tp a3, ba a4) {
        dfb a5;
        super.a(a2, a3, a4);
        hnd hnd2 = a4.a(b).z();
        a3 = a3.a(hnd2);
        ba ba2 = a2.a(a3);
        if ((ba2.a() == cl.yk || ba2.a() == cl.ci) && ba2.a(sjb.c).booleanValue()) {
            ba2.a().a(a2, a3, ba2, 0);
            a2.r(a3);
        }
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        return false;
    }

    @Override
    public boolean a(xga a2, tp a3, hnd a4) {
        return false;
    }

    @Override
    public int a(Random a2) {
        return 0;
    }

    @Override
    public void a(xga a2, tp a3, ba a4, tca a5, List<tca> a6, rj a7) {
        dfb a8;
        a8.p(a4);
        super.a(a2, a3, a4, a5, a6, a7);
        a8.o(a4);
        super.a(a2, a3, a4, a5, a6, a7);
        a8.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }

    private /* synthetic */ void o(ba a2) {
        switch (dfb.a()[a2.a(b).ordinal()]) {
            case 1: {
                dfb a3;
                a3.a(0.375f, 0.25f, 0.375f, 0.625f, 1.0f, 0.625f);
                break;
            }
            case 2: {
                dfb a3;
                a3.a(0.375f, 0.0f, 0.375f, 0.625f, 0.75f, 0.625f);
                break;
            }
            case 3: {
                dfb a3;
                a3.a(0.25f, 0.375f, 0.25f, 0.75f, 0.625f, 1.0f);
                break;
            }
            case 4: {
                dfb a3;
                a3.a(0.25f, 0.375f, 0.0f, 0.75f, 0.625f, 0.75f);
                break;
            }
            case 5: {
                dfb a3;
                a3.a(0.375f, 0.25f, 0.25f, 0.625f, 0.75f, 1.0f);
                break;
            }
            case 6: {
                dfb a3;
                a3.a(0.0f, 0.375f, 0.25f, 0.75f, 0.625f, 0.75f);
            }
        }
    }

    @Override
    public void a(cb a2, tp a3) {
        dfb a4;
        a4.p(a2.a(a3));
    }

    public void p(ba a2) {
        hnd hnd2 = a2.a(b);
        if (hnd2 != null) {
            switch (dfb.a()[hnd2.ordinal()]) {
                case 1: {
                    dfb a3;
                    a3.a(0.0f, 0.0f, 0.0f, 1.0f, 0.25f, 1.0f);
                    break;
                }
                case 2: {
                    dfb a3;
                    a3.a(0.0f, 0.75f, 0.0f, 1.0f, 1.0f, 1.0f);
                    break;
                }
                case 3: {
                    dfb a3;
                    a3.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.25f);
                    break;
                }
                case 4: {
                    dfb a3;
                    a3.a(0.0f, 0.0f, 0.75f, 1.0f, 1.0f, 1.0f);
                    break;
                }
                case 5: {
                    dfb a3;
                    a3.a(0.0f, 0.0f, 0.0f, 0.25f, 1.0f, 1.0f);
                    break;
                }
                case 6: {
                    dfb a3;
                    a3.a(0.75f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                }
            }
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        hnd hnd2 = a4.a(b);
        tp tp2 = a3.a(hnd2.z());
        ba ba2 = a2.a(tp2);
        if (ba2.a() != cl.yk && ba2.a() != cl.ci) {
            a2.r(a3);
        } else {
            ba2.a().a(a2, tp2, ba2, a5);
        }
    }

    @Override
    public boolean p(cb a2, tp a3, hnd a4) {
        return true;
    }

    public static hnd a(int a2) {
        int n2 = a2 & 7;
        return n2 > 5 ? null : hnd.p(n2);
    }

    @Override
    public ge a(xga a2, tp a3) {
        return a2.a(a3).a(c) == aoa.c ? ge.a(cl.ci) : ge.a(cl.yk);
    }

    @Override
    public ba a(int a2) {
        dfb a3;
        return a3.a().a(b, dfb.a(a2)).a(c, (a2 & 8) > 0 ? aoa.c : aoa.b);
    }

    @Override
    public int o(ba a2) {
        int n2 = 0;
        n2 |= a2.a(b).z();
        if (a2.a(c) == aoa.c) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    protected lf p() {
        dfb a2;
        return new lf(a2, b, c, v);
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[hnd.values().length];
        try {
            nArray[hnd.g.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.s.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.x.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.t.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.k.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.p.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

