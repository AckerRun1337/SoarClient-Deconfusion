/*
 * Decompiled with CFR 0.152.
 */
public class bob
extends ge {
    public bob() {
        bob a2;
        a2.a(md.e);
    }

    @Override
    public wfc p(wfc a2, xga a3, pm a4) {
        bob a5;
        lwa lwa2 = a5.a(a3, a4, true);
        if (lwa2 == null) {
            return a2;
        }
        if (lwa2.b == qgb.c) {
            tp tp2 = lwa2.a();
            if (!a3.a(a4, tp2)) {
                return a2;
            }
            if (!a4.a(tp2.a(lwa2.c), lwa2.c, a2)) {
                return a2;
            }
            if (a3.a(tp2).a().a() == dr.ca) {
                --a2.e;
                a4.p(hca.v[ge.a(a5)]);
                if (a2.e <= 0) {
                    return new wfc(sxa.gb);
                }
                if (!a4.ob.p(new wfc(sxa.gb))) {
                    a4.a(new wfc(sxa.gb, 1, 0), false);
                }
            }
        }
        return a2;
    }
}

