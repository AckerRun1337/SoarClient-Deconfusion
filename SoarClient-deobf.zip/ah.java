/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class ah
implements o<vi> {
    private ga d;

    public ah() {
        ah a2;
    }

    public ah(ga a2) {
        ah a3;
        a3.d = a2;
    }

    @Override
    public void p(io a2) throws IOException {
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        ah a3;
        a2.a(a3.d);
    }

    @Override
    public void a(vi a2) {
        ah a3;
        a2.a(a3);
    }

    public ga a() {
        ah a2;
        return a2.d;
    }
}

