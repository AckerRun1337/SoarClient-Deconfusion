/*
 * Decompiled with CFR 0.152.
 */
public enum crb implements s
{
    h("straight"),
    z("inner_left"),
    l("inner_right"),
    b("outer_left"),
    c("outer_right");

    private final String v;

    private /* synthetic */ crb(String a2, int a3, String a4) {
        crb a5;
        a5.v = a4;
    }

    public String toString() {
        crb a2;
        return a2.v;
    }

    @Override
    public String zpa() {
        crb a2;
        return a2.v;
    }
}

