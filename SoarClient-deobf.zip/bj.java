/*
 * Decompiled with CFR 0.152.
 */
public interface bj {
}

