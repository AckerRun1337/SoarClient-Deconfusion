/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class co {
    private /* synthetic */ au z;
    private /* synthetic */ String l;
    private /* synthetic */ String b;
    private /* synthetic */ oi c;
    private /* synthetic */ kk v;
    private /* synthetic */ boolean d;

    public co() {
        co a2;
        a2.v = new kk();
        a2.d = false;
    }

    public void a(au a2, String a3, String a4) {
        a.z = a2;
        a.l = a3;
        a.b = a4;
    }

    public void p() {
        co a2;
        a2.c = new qxb(300, rxb.o.a(a2.b) + 12.0);
        a2.v.a();
    }

    public boolean a() {
        co a2;
        return !a2.c.a(fl.v);
    }

    public void a() {
        co a2;
        if (gsc.t.i != null && !a2.d) {
            a2.d = true;
            gsc.t.i.p(a2);
        }
        int n2 = 120;
        double d2 = a2.c.p();
        int n3 = trc.a();
        int n4 = 255;
        Color color = new Color(0, 0, 0, 220);
        if (a2.v.a(3000L)) {
            a2.c.a(fl.v);
        }
        if (a2.z == au.b) {
            Color color2 = new Color(0, 26, 169);
        } else if (a2.z == au.c) {
            Color color3 = new Color(204, 193, 0);
        } else {
            Color color4 = new Color(204, 0, 18);
            int n5 = Math.max(0, Math.min(255, (int)(Math.sin(1.0) * 255.0 / 2.0 + 127.5)));
            color = new Color(n5, 0, 0, 220);
        }
        gic gic2 = oj.a().vb;
        frc.a((float)((double)en.n - d2), en.e - 40, (float)(rxb.o.a(a2.b) + 1.0), 29.0f, 6.0f, trc.a(0, n3), trc.a(90, n3), trc.a(180, n3), trc.a(270, n3));
        rxb.y.a(a2.l, (double)en.n - d2 + 3.0, (double)(en.e - 38), new Color(255, 255, 255, n4).getRGB());
        rxb.ba.a(a2.b, (double)en.n - d2 + 3.0, (double)(en.e - 22), new Color(255, 255, 255, n4).getRGB());
    }

    @fo
    public void a(iw a2) {
        co a3;
        if (a3.c != null) {
            double d2 = a3.c.p();
            frc.p((float)((double)en.n - d2), en.e - 40, (float)(rxb.o.a(a3.b) + 1.0), 29.0f, 6.0f, new Color(0, 0, 0));
        }
    }
}

