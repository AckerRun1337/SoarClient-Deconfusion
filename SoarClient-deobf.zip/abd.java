/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 */
import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class abd
extends dsc {
    public abd(xga a2, int a3, int a4) {
        super(a2, a3, a4);
        abd a5;
    }

    @Override
    public boolean o(int a2, int a3) {
        abd a4;
        return a2 == a4.p && a3 == a4.s;
    }

    @Override
    public int a(int a2, int a3) {
        return 0;
    }

    @Override
    public void m() {
    }

    @Override
    public void h() {
    }

    @Override
    public yd a(tp a2) {
        return cl.cd;
    }

    @Override
    public int p(tp a2) {
        return 255;
    }

    @Override
    public int a(tp a2) {
        return 0;
    }

    @Override
    public int a(yec a2, tp a3) {
        return a2.v;
    }

    @Override
    public void a(yec a2, tp a3, int a4) {
    }

    @Override
    public int a(tp a2, int a3) {
        return 0;
    }

    @Override
    public void p(rj a2) {
    }

    @Override
    public void a(rj a2) {
    }

    @Override
    public void a(rj a2, int a3) {
    }

    @Override
    public boolean a(tp a2) {
        return false;
    }

    @Override
    public kv a(tp a2, upc a3) {
        return null;
    }

    @Override
    public void a(kv a2) {
    }

    @Override
    public void a(tp a2, kv a3) {
    }

    @Override
    public void a(tp a2) {
    }

    @Override
    public void x() {
    }

    @Override
    public void j() {
    }

    @Override
    public void z() {
    }

    @Override
    public void a(rj a2, tca a3, List<rj> a4, Predicate<? super rj> a5) {
    }

    @Override
    public <T extends rj> void a(Class<? extends T> a2, tca a3, List<T> a4, Predicate<? super T> a5) {
    }

    @Override
    public boolean a(boolean a2) {
        return false;
    }

    @Override
    public Random a(long a2) {
        abd a3;
        return new Random(a3.a().o() + (long)(a3.p * a3.p * 4987142) + (long)(a3.p * 5947611) + (long)(a3.s * a3.s) * 4392871L + (long)(a3.s * 389711) ^ a2);
    }

    @Override
    public boolean z() {
        return true;
    }

    @Override
    public boolean p(int a2, int a3) {
        return true;
    }
}

