/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bl {
    private final owc d;

    public bl(int a2, int a3, int a4, int a5, int a6) {
        bl a7;
        a7.d = new owc(a7, a2, a3, a4, a5, a6);
    }

    public void a(int a2, int a3, float a4) {
        bl a5;
        a5.d.a(a2, a3, a4);
    }

    public int x() {
        bl a2;
        return a2.d.d();
    }

    public int j() {
        bl a2;
        return a2.d.m();
    }

    public int z() {
        bl a2;
        return a2.d.h();
    }

    protected void a(int a2, int a3, int a4, int a5, yxb a6, int a7, int a8) {
    }

    public void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        bl a8;
        a8.a(a2, a3, a4, a5, yxb.d, a6, a7);
    }

    public int y() {
        return 0;
    }

    public void a(int a2, boolean a3, int a4, int a5) {
    }

    public boolean a(int a2) {
        return false;
    }

    public void p() {
    }

    public int o() {
        return 0;
    }

    public int p() {
        bl a2;
        return a2.d.d() / 2 + 124;
    }

    public void a() {
        bl a2;
        a2.d.a();
    }

    public void a(int a2, int a3, int a4, float a5, int a6) {
    }

    public void p(int a2) {
        bl a3;
        a3.d.p(a2);
    }

    public int a() {
        bl a2;
        return a2.d.y();
    }

    protected void a(int a2, int a3, int a4, int a5) {
    }

    public void a(int a2, int a3, int a4, int a5, int a6) {
    }

    public void a(int a2, int a3, int a4, yxb a5) {
    }

    public void a(int a2) {
        bl a3;
        a3.d.a(a2);
    }
}

