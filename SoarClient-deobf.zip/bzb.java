/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bzb
implements o<vi> {
    private int c;
    private int v;
    private wfc d;

    public bzb() {
        bzb a2;
    }

    public bzb(int a2, int a3, wfc a4) {
        bzb a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4 == null ? null : a4.a();
    }

    @Override
    public void a(vi a2) {
        bzb a3;
        a2.a(a3);
    }

    @Override
    public void p(io a2) throws IOException {
        a.c = a2.a();
        a.v = a2.a();
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        bzb a3;
        a2.x(a3.c);
        a2.j(a3.v);
        a2.a(a3.d);
    }

    public int p() {
        bzb a2;
        return a2.c;
    }

    public int a() {
        bzb a2;
        return a2.v;
    }

    public wfc a() {
        bzb a2;
        return a2.d;
    }
}

