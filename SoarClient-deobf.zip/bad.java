/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bad
extends gba {
    private static final Logger r = LogManager.getLogger();
    private zb f = new vqb();
    private zb h;
    private xga z;
    private tp l;
    public int b;
    private int c;
    private String v;
    private final pm d;

    public bad(mnb a2, xga a3, pm a4) {
        a5(a2, a3, tp.r, a4);
        bad a5;
    }

    public bad(mnb a2, xga a3, tp a4, pm a5) {
        bad a6;
        a6.h = new ddc(a6, "Repair", true, 2);
        a6.l = a4;
        a6.z = a3;
        a6.d = a5;
        a6.a(new se(a6.h, 0, 27, 47));
        a6.a(new se(a6.h, 1, 76, 47));
        a6.a(new hda(a6, a6.f, 2, 134, 47, a3, a4));
        int n2 = 0;
        while (n2 < 3) {
            int n3 = 0;
            while (n3 < 9) {
                a6.a(new se(a2, n3 + n2 * 9 + 9, 8 + n3 * 18, 84 + n2 * 18));
                ++n3;
            }
            ++n2;
        }
        n2 = 0;
        while (n2 < 9) {
            a6.a(new se(a2, n2, 8 + n2 * 18, 142));
            ++n2;
        }
    }

    @Override
    public void a(zb a2) {
        bad a3;
        super.a(a2);
        if (a2 == a3.h) {
            a3.o();
        }
    }

    public void o() {
        bad a2;
        boolean bl2 = false;
        boolean bl3 = true;
        boolean bl4 = true;
        boolean bl5 = true;
        int n2 = 2;
        boolean bl6 = true;
        boolean bl7 = true;
        wfc wfc2 = a2.h.p(0);
        a2.b = 1;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        if (wfc2 == null) {
            a2.f.a(0, null);
            a2.b = 0;
        } else {
            wfc wfc3 = wfc2.a();
            wfc wfc4 = a2.h.p(1);
            Map<Integer, Integer> map = fi.a(wfc3);
            boolean bl8 = false;
            n4 = n4 + wfc2.a() + (wfc4 == null ? 0 : wfc4.a());
            a2.c = 0;
            if (wfc4 != null) {
                boolean bl9 = bl8 = wfc4.a() == sxa.ba && sxa.ba.a(wfc4).p() > 0;
                if (wfc3.d() && wfc3.a().a(wfc2, wfc4)) {
                    int n6 = Math.min(wfc3.z(), wfc3.o() / 4);
                    if (n6 <= 0) {
                        a2.f.a(0, null);
                        a2.b = 0;
                        return;
                    }
                    int n7 = 0;
                    while (n6 > 0 && n7 < wfc4.e) {
                        int n8 = wfc3.z() - n6;
                        wfc3.p(n8);
                        ++n3;
                        n6 = Math.min(wfc3.z(), wfc3.o() / 4);
                        ++n7;
                    }
                    a2.c = n7;
                } else {
                    int n9;
                    if (!(bl8 || wfc3.a() == wfc4.a() && wfc3.d())) {
                        a2.f.a(0, null);
                        a2.b = 0;
                        return;
                    }
                    if (wfc3.d() && !bl8) {
                        int n10 = wfc2.o() - wfc2.z();
                        int n11 = wfc4.o() - wfc4.z();
                        int n12 = n11 + wfc3.o() * 12 / 100;
                        int n13 = n10 + n12;
                        n9 = wfc3.o() - n13;
                        if (n9 < 0) {
                            n9 = 0;
                        }
                        if (n9 < wfc3.y()) {
                            wfc3.p(n9);
                            n3 += 2;
                        }
                    }
                    Map<Integer, Integer> map2 = fi.a(wfc4);
                    for (int n12 : map2.keySet()) {
                        int n142;
                        zk zk2 = zk.a(n12);
                        if (zk2 == null) continue;
                        n9 = map.containsKey(n12) ? map.get(n12) : 0;
                        int n15 = map2.get(n12);
                        int n16 = n9 == n15 ? ++n15 : Math.max(n15, n9);
                        n15 = n16;
                        boolean bl10 = zk2.a(wfc2);
                        if (a2.d.y.b || wfc2.a() == sxa.ba) {
                            bl10 = true;
                        }
                        for (int n142 : map.keySet()) {
                            if (n142 == n12 || zk2.a(zk.a(n142))) continue;
                            bl10 = false;
                            ++n3;
                        }
                        if (!bl10) continue;
                        if (n15 > zk2.a()) {
                            n15 = zk2.a();
                        }
                        map.put(n12, n15);
                        n142 = 0;
                        switch (zk2.o()) {
                            case 1: {
                                n142 = 8;
                                break;
                            }
                            case 2: {
                                n142 = 4;
                            }
                            default: {
                                break;
                            }
                            case 5: {
                                n142 = 2;
                                break;
                            }
                            case 10: {
                                n142 = 1;
                            }
                        }
                        if (bl8) {
                            n142 = Math.max(1, n142 / 2);
                        }
                        n3 += n142 * n15;
                    }
                }
            }
            if (StringUtils.isBlank((CharSequence)a2.v)) {
                if (wfc2.j()) {
                    n5 = 1;
                    n3 += n5;
                    wfc3.a();
                }
            } else if (!a2.v.equals(wfc2.a())) {
                n5 = 1;
                n3 += n5;
                wfc3.a(a2.v);
            }
            a2.b = n4 + n3;
            if (n3 <= 0) {
                wfc3 = null;
            }
            if (n5 == n3 && n5 > 0 && a2.b >= 40) {
                a2.b = 39;
            }
            if (a2.b >= 40 && !a2.d.y.b) {
                wfc3 = null;
            }
            if (wfc3 != null) {
                int n17 = wfc3.a();
                if (wfc4 != null && n17 < wfc4.a()) {
                    n17 = wfc4.a();
                }
                n17 = n17 * 2 + 1;
                wfc3.a(n17);
                fi.a(map, wfc3);
            }
            a2.f.a(0, wfc3);
            a2.p();
        }
    }

    @Override
    public void p(d a2) {
        bad a3;
        super.p(a2);
        a2.a((gba)a3, 0, a3.b);
    }

    @Override
    public void a(int a2, int a3) {
        if (a2 == 0) {
            a.b = a3;
        }
    }

    @Override
    public void a(pm a2) {
        bad a3;
        super.a(a2);
        if (!a3.z.f) {
            int n2 = 0;
            while (n2 < a3.h.o()) {
                wfc wfc2 = a3.h.a(n2);
                if (wfc2 != null) {
                    a2.a(wfc2, false);
                }
                ++n2;
            }
        }
    }

    @Override
    public boolean a(pm a2) {
        bad a3;
        return a3.z.a(a3.l).a() != cl.ha ? false : a2.p((double)a3.l.o() + 0.5, (double)a3.l.p() + 0.5, (double)a3.l.a() + 0.5) <= 64.0;
    }

    @Override
    public wfc a(pm a2, int a3) {
        bad a4;
        wfc wfc2 = null;
        se se2 = (se)a4.f.get(a3);
        if (se2 != null && se2.p()) {
            wfc wfc3 = se2.a();
            wfc2 = wfc3.a();
            if (a3 == 2) {
                if (!a4.a(wfc3, 3, 39, true)) {
                    return null;
                }
                se2.a(wfc3, wfc2);
            } else if (a3 != 0 && a3 != 1 ? a3 >= 3 && a3 < 39 && !a4.a(wfc3, 0, 2, false) : !a4.a(wfc3, 3, 39, false)) {
                return null;
            }
            if (wfc3.e == 0) {
                se2.a((wfc)null);
            } else {
                se2.a();
            }
            if (wfc3.e == wfc2.e) {
                return null;
            }
            se2.a(a2, wfc3);
        }
        return wfc2;
    }

    public void a(String a2) {
        bad a3;
        a3.v = a2;
        if (a3.a(2).p()) {
            wfc wfc2 = a3.a(2).a();
            if (StringUtils.isBlank((CharSequence)a2)) {
                wfc2.a();
            } else {
                wfc2.a(a3.v);
            }
        }
        a3.o();
    }

    static /* synthetic */ zb a(bad a2) {
        return a2.h;
    }

    static /* synthetic */ int a(bad a2) {
        return a2.c;
    }
}

