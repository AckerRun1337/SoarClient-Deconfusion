/*
 * Decompiled with CFR 0.152.
 */
public class aaa
extends bm {
    public aaa() {
        super(dr.p, false, rpb.ha);
        aaa a2;
        a2.a(md.k);
        a2.b = 0.8f;
    }

    @Override
    public hdc a() {
        return hdc.c;
    }

    @Override
    public void a(xga a2, tp a3, rj a4, float a5) {
        if (a4.c()) {
            aaa a6;
            super.a(a2, a3, a4, a5);
        } else {
            a4.a(a5, 0.0f);
        }
    }

    @Override
    public void a(xga a2, rj a3) {
        if (a3.c()) {
            aaa a4;
            super.a(a2, a3);
        } else if (a3.gb < 0.0) {
            a3.gb = -a3.gb;
        }
    }

    @Override
    public void a(xga a2, tp a3, rj a4) {
        aaa a5;
        if (Math.abs(a4.gb) < 0.1 && !a4.c()) {
            double d2 = 0.4 + Math.abs(a4.gb) * 0.2;
            a4.mb *= d2;
            a4.wb *= d2;
        }
        super.a(a2, a3, a4);
    }
}

