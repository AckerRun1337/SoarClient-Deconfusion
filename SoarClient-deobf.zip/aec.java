/*
 * Decompiled with CFR 0.152.
 */
public class aec
extends wg {
    public aec(long a2, wg a3) {
        super(a2);
        aec a4;
        a4.c = a3;
    }

    @Override
    public int[] a(int a2, int a3, int a4, int a5) {
        aec a6;
        int n2 = a2 - 1;
        int n3 = a3 - 1;
        int n4 = a4 + 2;
        int n5 = a5 + 2;
        int[] nArray = a6.c.a(n2, n3, n4, n5);
        int[] nArray2 = xeb.a(a4 * a5);
        int n6 = 0;
        while (n6 < a5) {
            int n7 = 0;
            while (n7 < a4) {
                int n8 = nArray[n7 + 1 + (n6 + 1) * n4];
                a6.a((long)(n7 + a2), (long)(n6 + a3));
                if (n8 == 0) {
                    nArray2[n7 + n6 * a4] = 0;
                } else {
                    int n9 = a6.a(6);
                    n9 = n9 == 0 ? 4 : (n9 <= 1 ? 3 : 1);
                    nArray2[n7 + n6 * a4] = n9;
                }
                ++n7;
            }
            ++n6;
        }
        return nArray2;
    }
}

