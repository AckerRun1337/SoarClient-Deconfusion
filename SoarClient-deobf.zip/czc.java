/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.FutureCallback
 *  com.google.common.util.concurrent.SettableFuture
 */
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.SettableFuture;
import java.io.File;

class czc
implements FutureCallback<Object> {
    final /* synthetic */ ayc c;
    private final /* synthetic */ File v;
    private final /* synthetic */ SettableFuture d;

    czc(ayc a2, File a3, SettableFuture a4) {
        czc a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    public void onSuccess(Object a2) {
        czc a3;
        a3.c.a(a3.v);
        a3.d.set(null);
    }

    public void onFailure(Throwable a2) {
        czc a3;
        a3.d.setException(a2);
    }
}

