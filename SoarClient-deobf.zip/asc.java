/*
 * Decompiled with CFR 0.152.
 */
public class asc
extends bh {
    public asc() {
        super("NoHurtCam", 0, gk.b);
        asc a2;
    }
}

