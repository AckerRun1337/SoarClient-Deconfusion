/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bqb
extends tp {
    private int z;
    private int l;
    private int b;
    private int c;
    private bqb[] v;
    private boolean d;

    public bqb(int a2, int a3, int a4) {
        a5(a2, a3, a4, 0);
        bqb a5;
    }

    public bqb(double a2, double a3, double a4) {
        a5(smb.o(a2), smb.o(a3), smb.o(a4));
        bqb a5;
    }

    public bqb(int a2, int a3, int a4, int a5) {
        super(0, 0, 0);
        bqb a6;
        a6.z = a2;
        a6.l = a3;
        a6.b = a4;
        a6.c = a5;
    }

    @Override
    public int o() {
        bqb a2;
        return a2.z;
    }

    @Override
    public int p() {
        bqb a2;
        return a2.l;
    }

    @Override
    public int a() {
        bqb a2;
        return a2.b;
    }

    public void a(int a2, int a3, int a4) {
        a.z = a2;
        a.l = a3;
        a.b = a4;
        a.d = true;
    }

    public void a(double a2, double a3, double a4) {
        bqb a5;
        a5.a(smb.o(a2), smb.o(a3), smb.o(a4));
    }

    @Override
    public bqb a(vx a2) {
        bqb a3;
        a3.a(a2.o(), a2.p(), a2.a());
        return a3;
    }

    @Override
    public bqb a(int a2, int a3, int a4) {
        bqb a5;
        a5.a(a2, a3, a4);
        return a5;
    }

    public tp p(hnd a2) {
        bqb a3;
        return a3.a(a2);
    }

    @Override
    public tp a(hnd a2) {
        int n2;
        bqb bqb2;
        bqb a3;
        if (a3.c <= 0) {
            return super.a(a2, 1);
        }
        if (a3.v == null) {
            a3.v = new bqb[hnd.z.length];
        }
        if (a3.d) {
            a3.a();
        }
        if ((bqb2 = a3.v[n2 = a2.z()]) == null) {
            int n3 = a3.z + a2.o();
            int n4 = a3.l + a2.p();
            int n5 = a3.b + a2.a();
            a3.v[n2] = bqb2 = new bqb(n3, n4, n5, a3.c - 1);
        }
        return bqb2;
    }

    @Override
    public tp a(hnd a2, int a3) {
        bqb a4;
        return a3 == 1 ? a4.a(a2) : super.a(a2, a3);
    }

    private /* synthetic */ void a() {
        int n2 = 0;
        while (n2 < 6) {
            bqb a2;
            bqb bqb2 = a2.v[n2];
            if (bqb2 != null) {
                hnd hnd2 = hnd.z[n2];
                int n3 = a2.z + hnd2.o();
                int n4 = a2.l + hnd2.p();
                int n5 = a2.b + hnd2.a();
                bqb2.a(n3, n4, n5);
            }
            ++n2;
        }
        a2.d = false;
    }

    public tp x() {
        bqb a2;
        return new tp(a2.z, a2.l, a2.b);
    }

    public static Iterable o(tp a2, tp a3) {
        tp tp2 = new tp(Math.min(a2.o(), a3.o()), Math.min(a2.p(), a3.p()), Math.min(a2.a(), a3.a()));
        tp tp3 = new tp(Math.max(a2.o(), a3.o()), Math.max(a2.p(), a3.p()), Math.max(a2.a(), a3.a()));
        return new btc(tp2, tp3);
    }
}

