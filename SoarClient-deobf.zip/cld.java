/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

public class cld
extends ldd
implements Serializable {
    static final long d = 6149289077348153921L;

    public cld(int a2, int a3, int a4) {
        super(a2, a3, a4);
        cld a5;
    }

    public cld(int[] a2) {
        super(a2);
        cld a3;
    }

    public cld(ldd a2) {
        super(a2);
        cld a3;
    }

    public cld() {
        cld a2;
    }
}

