/*
 * Decompiled with CFR 0.152.
 */
enum bxa {
    h,
    z,
    l,
    b,
    c,
    v;


    private /* synthetic */ bxa(String a2, int a3) {
        bxa a4;
    }
}

