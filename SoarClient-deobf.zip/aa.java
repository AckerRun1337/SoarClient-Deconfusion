/*
 * Decompiled with CFR 0.152.
 */
interface aa {
    public void a(zk var1, int var2);
}

