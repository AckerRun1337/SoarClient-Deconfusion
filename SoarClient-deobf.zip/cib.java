/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class cib
implements o<ib> {
    private String v;
    private axc d;

    public cib() {
        cib a2;
    }

    public cib(String a2, axc a3) {
        cib a4;
        if (a2.length() > 40) {
            a2 = a2.substring(0, 40);
        }
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public void p(io a2) throws IOException {
        a.v = a2.a(40);
        a.d = a2.a(axc.class);
    }

    @Override
    public void a(io a2) throws IOException {
        cib a3;
        a2.a(a3.v);
        a2.a(a3.d);
    }

    @Override
    public void a(ib a2) {
        cib a3;
        a2.a(a3);
    }
}

