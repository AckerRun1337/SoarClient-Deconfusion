/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cwb
extends mi {
    xga n;
    protected sj e;
    int r;
    double f;
    boolean h;
    zjb z;
    Class<? extends rj> l;
    private int b;
    private double c;
    private double v;
    private double d;

    public cwb(sj a2, Class<? extends rj> a3, double a4, boolean a5) {
        a6(a2, a4, a5);
        cwb a6;
        a6.l = a3;
    }

    public cwb(sj a2, double a3, boolean a4) {
        cwb a5;
        a5.e = a2;
        a5.n = a2.ib;
        a5.f = a3;
        a5.h = a4;
        a5.a(3);
    }

    @Override
    public boolean o() {
        cwb a2;
        xi xi2 = a2.e.y();
        if (xi2 == null) {
            return false;
        }
        if (!xi2.g()) {
            return false;
        }
        if (a2.l != null && !a2.l.isAssignableFrom(xi2.getClass())) {
            return false;
        }
        a2.z = a2.e.a().a(xi2);
        return a2.z != null;
    }

    @Override
    public boolean p() {
        cwb a2;
        xi xi2 = a2.e.y();
        return xi2 == null ? false : (!xi2.g() ? false : (!a2.h ? !a2.e.a().o() : a2.e.a(new tp(xi2))));
    }

    @Override
    public void o() {
        cwb a2;
        a2.e.a().a(a2.z, a2.f);
        a2.b = 0;
    }

    @Override
    public void p() {
        cwb a2;
        a2.e.a().p();
    }

    @Override
    public void a() {
        cwb a2;
        xi xi2 = a2.e.y();
        a2.e.a().a(xi2, 30.0f, 30.0f);
        double d2 = a2.e.p(xi2.fb, xi2.a().l, xi2.db);
        double d3 = a2.a(xi2);
        --a2.b;
        if ((a2.h || a2.e.a().a(xi2)) && a2.b <= 0 && (a2.c == 0.0 && a2.v == 0.0 && a2.d == 0.0 || xi2.p(a2.c, a2.v, a2.d) >= 1.0 || a2.e.a().nextFloat() < 0.05f)) {
            a2.c = xi2.fb;
            a2.v = xi2.a().l;
            a2.d = xi2.db;
            a2.b = 4 + a2.e.a().nextInt(7);
            if (d2 > 1024.0) {
                a2.b += 10;
            } else if (d2 > 256.0) {
                a2.b += 5;
            }
            if (!a2.e.a().a(xi2, a2.f)) {
                a2.b += 15;
            }
        }
        a2.r = Math.max(a2.r - 1, 0);
        if (d2 <= d3 && a2.r <= 0) {
            a2.r = 20;
            if (a2.e.a() != null) {
                a2.e.xa();
            }
            a2.e.y(xi2);
        }
    }

    protected double a(xi a2) {
        cwb a3;
        return a3.e.xa * 2.0f * a3.e.xa * 2.0f + a2.xa;
    }
}

