/*
 * Decompiled with CFR 0.152.
 */
public interface bb {
    public int a(ba var1, cb var2, tp var3);

    public boolean a();
}

