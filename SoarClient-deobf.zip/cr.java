/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cr
implements o<vi> {
    private int l;
    private byte b;
    private byte c;
    private int v;
    private byte d;

    public cr() {
        cr a2;
    }

    public cr(int a2, ihd a3) {
        cr a4;
        a4.l = a2;
        a4.b = (byte)(a3.y() & 0xFF);
        a4.c = (byte)(a3.p() & 0xFF);
        a4.v = a3.o() > Short.MAX_VALUE ? Short.MAX_VALUE : a3.o();
        a4.d = (byte)(a3.p() ? 1 : 0);
    }

    @Override
    public void p(io a2) throws IOException {
        a.l = a2.c();
        a.b = a2.a();
        a.c = a2.a();
        a.v = a2.c();
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        cr a3;
        a2.a(a3.l);
        a2.x(a3.b);
        a2.x(a3.c);
        a2.a(a3.v);
        a2.x(a3.d);
    }

    public boolean p() {
        cr a2;
        return a2.v == Short.MAX_VALUE;
    }

    @Override
    public void a(vi a2) {
        cr a3;
        a2.a(a3);
    }

    public int p() {
        cr a2;
        return a2.l;
    }

    public byte p() {
        cr a2;
        return a2.b;
    }

    public byte a() {
        cr a2;
        return a2.c;
    }

    public int a() {
        cr a2;
        return a2.v;
    }

    public boolean a() {
        cr a2;
        return a2.d != 0;
    }
}

