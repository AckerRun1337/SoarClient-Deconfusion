/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  tv.twitch.ErrorCode
 */
import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import tv.twitch.ErrorCode;

public class agc
extends en {
    private static final Logger r = LogManager.getLogger();
    private final ga f = new klb("stream.unavailable.title", new Object[0]);
    private final en h;
    private final ak z;
    private final List<klb> l;
    private final List<String> b = Lists.newArrayList();
    private static volatile /* synthetic */ int[] d;

    public agc(en a2, ak a3) {
        a4(a2, a3, null);
        agc a4;
    }

    public agc(en a2, ak a3, List<klb> a4) {
        agc a5;
        a5.h = a2;
        a5.z = a3;
        a5.l = a4;
    }

    @Override
    public void m() {
        agc a2;
        if (a2.b.isEmpty()) {
            a2.b.addAll(((gic)((Object)a2.z)).a(a2.z.p().a(), (int)((float)n * 0.75f)));
            if (a2.l != null) {
                a2.b.add("");
                for (klb klb2 : a2.l) {
                    a2.b.add(klb2.o());
                }
            }
        }
        if (a2.z.a() != null) {
            a2.r.add(new ff(0, n / 2 - 155, e - 50, 150, 20, xab.a("gui.cancel", new Object[0])));
            a2.r.add(new ff(1, n / 2 - 155 + 160, e - 50, 150, 20, xab.a(a2.z.a().a(), new Object[0])));
        } else {
            a2.r.add(new ff(0, n / 2 - 75, e - 50, 150, 20, xab.a("gui.cancel", new Object[0])));
        }
    }

    @Override
    public void y() {
    }

    @Override
    public void a(int a2, int a3, float a4) {
        agc a5;
        a5.o();
        int n2 = Math.max((int)((double)e * 0.85 / 2.0 - (double)((float)(a5.b.size() * ((gic)((Object)a5.z)).u) / 2.0f)), 50);
        a5.p((gic)((Object)a5.z), a5.f.a(), n / 2, n2 - ((gic)((Object)a5.z)).u * 2, 0xFFFFFF);
        for (String string : a5.b) {
            a5.p((gic)((Object)a5.z), string, n / 2, n2, 0xA0A0A0);
            n2 += ((gic)((Object)a5.z)).u;
        }
        super.a(a2, a3, a4);
    }

    @Override
    protected void a(ff a2) throws IOException {
        if (a2.c) {
            agc a3;
            if (a2.b == 1) {
                switch (a3.z) {
                    case f: 
                    case h: {
                        a3.a("https://account.mojang.com/me/settings");
                        break;
                    }
                    case r: {
                        a3.a("https://account.mojang.com/migrate");
                        break;
                    }
                    case n: {
                        a3.a("http://www.apple.com/osx/");
                        break;
                    }
                    case w: 
                    case l: 
                    case b: {
                        a3.a("http://bugs.mojang.com/browse/MC");
                    }
                }
            }
            a3.w.a(a3.h);
        }
    }

    private /* synthetic */ void a(String a2) {
        try {
            Class<?> clazz = Class.forName("java.awt.Desktop");
            Object object = clazz.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
            clazz.getMethod("browse", URI.class).invoke(object, new URI(a2));
        }
        catch (Throwable throwable) {
            r.error("Couldn't open link", throwable);
        }
    }

    public static void a(en a2) {
        oj oj2 = oj.a();
        oc oc2 = oj2.a();
        if (!nla.za) {
            ArrayList arrayList = Lists.newArrayList();
            arrayList.add(new klb("stream.unavailable.no_fbo.version", GL11.a(7938)));
            arrayList.add(new klb("stream.unavailable.no_fbo.blend", GLContext.o().bfc));
            arrayList.add(new klb("stream.unavailable.no_fbo.arb", GLContext.o().hoc));
            arrayList.add(new klb("stream.unavailable.no_fbo.ext", GLContext.o().gwb));
            oj2.a(new agc(a2, ak.p, arrayList));
        } else if (oc2 instanceof ehd) {
            if (((ehd)oc2).a().getMessage().contains("Can't load AMD 64-bit .dll on a IA 32-bit platform")) {
                oj2.a(new agc(a2, ak.s));
            } else {
                oj2.a(new agc(a2, ak.w));
            }
        } else if (!oc2.o() && oc2.a() == ErrorCode.TTV_EC_OS_TOO_OLD) {
            switch (pdc.a()) {
                case b: {
                    oj2.a(new agc(a2, ak.i));
                    break;
                }
                case c: {
                    oj2.a(new agc(a2, ak.n));
                    break;
                }
                default: {
                    oj2.a(new agc(a2, ak.e));
                    break;
                }
            }
        } else if (!oj2.p().containsKey((Object)"twitch_access_token")) {
            if (oj2.a().a() == upa.l) {
                oj2.a(new agc(a2, ak.r));
            } else {
                oj2.a(new agc(a2, ak.f));
            }
        } else if (!oc2.p()) {
            switch (agc.a()[oc2.a().ordinal()]) {
                case 2: {
                    oj2.a(new agc(a2, ak.h));
                    break;
                }
                default: {
                    oj2.a(new agc(a2, ak.z));
                    break;
                }
            }
        } else if (oc2.a() != null) {
            List<klb> list = Arrays.asList(new klb("stream.unavailable.initialization_failure.extra", ErrorCode.getString((ErrorCode)oc2.a())));
            oj2.a(new agc(a2, ak.l, list));
        } else {
            oj2.a(new agc(a2, ak.b));
        }
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[tnd.values().length];
        try {
            nArray[tnd.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[tnd.v.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

