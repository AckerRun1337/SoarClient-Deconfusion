/*
 * Decompiled with CFR 0.152.
 */
class bkb
implements sb {
    final /* synthetic */ kp d;

    bkb(kp a2) {
        bkb a3;
        a3.d = a2;
    }

    @Override
    public yjc a(wfc a2) {
        return new yjc("spawn_egg", "inventory");
    }
}

