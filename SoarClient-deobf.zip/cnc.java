/*
 * Decompiled with CFR 0.152.
 */
public enum cnc {
    z,
    l,
    b,
    c,
    v;


    private /* synthetic */ cnc(String a2, int a3) {
        cnc a4;
    }
}

