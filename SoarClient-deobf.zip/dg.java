/*
 * Decompiled with CFR 0.152.
 */
public class dg
extends ui {
    private final cla d;

    public dg(cla a2) {
        super(a2.i);
        dg a3;
        a3.d = a2;
    }
}

