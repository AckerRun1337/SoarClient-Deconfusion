/*
 * Decompiled with CFR 0.152.
 */
public class bia {
    public boolean h;
    public boolean z;
    public boolean l;
    public boolean b;
    public boolean c = true;
    private float v = 0.05f;
    private float d = 0.1f;

    public bia() {
        bia a2;
    }

    public void p(dgb a2) {
        bia a3;
        dgb dgb2 = new dgb();
        dgb2.a("invulnerable", a3.h);
        dgb2.a("flying", a3.z);
        dgb2.a("mayfly", a3.l);
        dgb2.a("instabuild", a3.b);
        dgb2.a("mayBuild", a3.c);
        dgb2.a("flySpeed", a3.v);
        dgb2.a("walkSpeed", a3.d);
        a2.a("abilities", dgb2);
    }

    public void a(dgb a2) {
        if (a2.a("abilities", 10)) {
            ml ml2 = a2.a("abilities");
            a.h = ((dgb)ml2).a("invulnerable");
            a.z = ((dgb)ml2).a("flying");
            a.l = ((dgb)ml2).a("mayfly");
            a.b = ((dgb)ml2).a("instabuild");
            if (((dgb)ml2).a("flySpeed", 99)) {
                a.v = ((dgb)ml2).a("flySpeed");
                a.d = ((dgb)ml2).a("walkSpeed");
            }
            if (((dgb)ml2).a("mayBuild", 1)) {
                a.c = ((dgb)ml2).a("mayBuild");
            }
        }
    }

    public float p() {
        bia a2;
        return a2.v;
    }

    public void p(float a2) {
        a.v = a2;
    }

    public float a() {
        bia a2;
        return a2.d;
    }

    public void a(float a2) {
        a.d = a2;
    }
}

