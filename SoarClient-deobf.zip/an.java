/*
 * Decompiled with CFR 0.152.
 */
public abstract class an
extends yd {
    public static final iab d = iab.a("facing", wta.b);

    protected an(dr a2) {
        super(a2);
        an a3;
    }

    protected an(dr a2, rpb a3) {
        super(a2, a3);
        an a4;
    }
}

