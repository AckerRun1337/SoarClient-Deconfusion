/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cpa
implements fb {
    private final oj d = oj.a();

    public cpa() {
        cpa a2;
    }

    @Override
    public void a(int a2, int a3, int a4, int a5, int a6, int a7, int a8, boolean a9) {
        String string;
        cpa a10;
        int n2 = a4 + a6 / 2 - a10.d.vb.u / 2;
        en cfr_ignored_0 = a10.d.sb;
        a10.d.vb.a(xab.a("lanServer.scanning", new Object[0]), en.n / 2 - a10.d.vb.a(xab.a("lanServer.scanning", new Object[0])) / 2, n2, 0xFFFFFF);
        switch ((int)(oj.a() / 300L % 4L)) {
            default: {
                string = "O o o";
                break;
            }
            case 1: 
            case 3: {
                string = "o O o";
                break;
            }
            case 2: {
                string = "o o O";
            }
        }
        en cfr_ignored_1 = a10.d.sb;
        a10.d.vb.a(string, en.n / 2 - a10.d.vb.a(string) / 2, n2 + a10.d.vb.u, 0x808080);
    }

    @Override
    public void a(int a2, int a3, int a4) {
    }

    @Override
    public boolean a(int a2, int a3, int a4, int a5, int a6, int a7) {
        return false;
    }

    @Override
    public void a(int a2, int a3, int a4, int a5, int a6, int a7) {
    }
}

