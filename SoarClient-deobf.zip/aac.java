/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.HashMultiset
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Multiset
 *  com.google.common.collect.Multisets
 */
import com.google.common.collect.HashMultiset;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multisets;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aac
extends myb {
    protected aac() {
        aac a2;
        a2.a(true);
    }

    public static vfa a(int a2, xga a3) {
        String string = "map_" + a2;
        vfa vfa2 = (vfa)a3.a(vfa.class, string);
        if (vfa2 == null) {
            vfa2 = new vfa(string);
            a3.a(string, vfa2);
        }
        return vfa2;
    }

    public vfa a(wfc a2, xga a3) {
        String string = "map_" + a2.y();
        vfa vfa2 = (vfa)a3.a(vfa.class, string);
        if (vfa2 == null && !a3.f) {
            a2.p(a3.a("map"));
            string = "map_" + a2.y();
            vfa2 = new vfa(string);
            vfa2.l = (byte)3;
            vfa2.a(a3.a().m(), a3.a().x(), vfa2.l);
            vfa2.z = (byte)a3.g.a();
            vfa2.a();
            a3.a(string, vfa2);
        }
        return vfa2;
    }

    public void a(xga a2, rj a3, vfa a4) {
        if (a2.g.a() == a4.z && a3 instanceof pm) {
            int n2 = 1 << a4.l;
            int n3 = a4.f;
            int n4 = a4.h;
            int n5 = smb.o(a3.fb - (double)n3) / n2 + 64;
            int n6 = smb.o(a3.db - (double)n4) / n2 + 64;
            int n7 = 128 / n2;
            if (a2.g.a()) {
                n7 /= 2;
            }
            epb epb2 = a4.a((pm)a3);
            ++epb2.v;
            boolean bl2 = false;
            int n8 = n5 - n7 + 1;
            while (n8 < n5 + n7) {
                if ((n8 & 0xF) == (epb2.v & 0xF) || bl2) {
                    bl2 = false;
                    double d2 = 0.0;
                    int n9 = n6 - n7 - 1;
                    while (n9 < n6 + n7) {
                        if (n8 >= 0 && n9 >= -1 && n8 < 128 && n9 < 128) {
                            int n10 = n8 - n5;
                            int n11 = n9 - n6;
                            boolean bl3 = n10 * n10 + n11 * n11 > (n7 - 2) * (n7 - 2);
                            int n12 = (n3 / n2 + n8 - 64) * n2;
                            int n13 = (n4 / n2 + n9 - 64) * n2;
                            HashMultiset hashMultiset = HashMultiset.create();
                            dsc dsc2 = a2.a(new tp(n12, 0, n13));
                            if (!dsc2.z()) {
                                byte by2;
                                rpb rpb2;
                                int n14;
                                int n15;
                                int n16 = n12 & 0xF;
                                int n17 = n13 & 0xF;
                                int n18 = 0;
                                double d3 = 0.0;
                                if (a2.g.a()) {
                                    int n19 = n12 + n13 * 231871;
                                    if (((n19 = n19 * n19 * 31287121 + n19 * 11) >> 20 & 1) == 0) {
                                        hashMultiset.add((Object)cl.zk.a(cl.zk.a().a(teb.v, kd.r)), 10);
                                    } else {
                                        hashMultiset.add((Object)cl.gj.a(cl.gj.a().a(uca.d, nsa.w)), 100);
                                    }
                                    d3 = 100.0;
                                } else {
                                    qt qt2 = new qt();
                                    int n20 = 0;
                                    while (n20 < n2) {
                                        n15 = 0;
                                        while (n15 < n2) {
                                            int n21 = dsc2.a(n20 + n16, n15 + n17) + 1;
                                            ba ba2 = cl.cd.a();
                                            if (n21 > 1) {
                                                while ((ba2 = dsc2.a(qt2.a(n20 + n16, --n21, n15 + n17))).a().a(ba2) == rpb.ka && n21 > 0) {
                                                }
                                                if (n21 > 0 && ba2.a().a().h()) {
                                                    yd yd2;
                                                    n14 = n21 - 1;
                                                    do {
                                                        yd2 = dsc2.a(n20 + n16, n14--, n15 + n17);
                                                        ++n18;
                                                    } while (n14 > 0 && yd2.a().h());
                                                }
                                            }
                                            d3 += (double)n21 / (double)(n2 * n2);
                                            hashMultiset.add((Object)ba2.a().a(ba2));
                                            ++n15;
                                        }
                                        ++n20;
                                    }
                                }
                                n18 /= n2 * n2;
                                double d4 = (d3 - d2) * 4.0 / (double)(n2 + 4) + ((double)(n8 + n9 & 1) - 0.5) * 0.4;
                                n15 = 1;
                                if (d4 > 0.6) {
                                    n15 = 2;
                                }
                                if (d4 < -0.6) {
                                    n15 = 0;
                                }
                                if ((rpb2 = (rpb)Iterables.getFirst((Iterable)Multisets.copyHighestCountFirst((Multiset)hashMultiset), (Object)rpb.ka)) == rpb.u) {
                                    d4 = (double)n18 * 0.1 + (double)(n8 + n9 & 1) * 0.2;
                                    n15 = 1;
                                    if (d4 < 0.5) {
                                        n15 = 2;
                                    }
                                    if (d4 > 0.9) {
                                        n15 = 0;
                                    }
                                }
                                d2 = d3;
                                if (!(n9 < 0 || n10 * n10 + n11 * n11 >= n7 * n7 || bl3 && (n8 + n9 & 1) == 0 || (by2 = a4.b[n8 + n9 * 128]) == (n14 = (int)((byte)(rpb2.d * 4 + n15))))) {
                                    a4.b[n8 + n9 * 128] = n14;
                                    a4.a(n8, n9);
                                    bl2 = true;
                                }
                            }
                        }
                        ++n9;
                    }
                }
                ++n8;
            }
        }
    }

    @Override
    public void a(wfc a2, xga a3, rj a4, int a5, boolean a6) {
        if (!a3.f) {
            aac a7;
            vfa vfa2 = a7.a(a2, a3);
            if (a4 instanceof pm) {
                pm pm2 = (pm)a4;
                vfa2.a(pm2, a2);
            }
            if (a6) {
                a7.a(a3, a4, vfa2);
            }
        }
    }

    @Override
    public o a(wfc a2, xga a3, pm a4) {
        aac a5;
        return a5.a(a2, a3).a(a2, a3, a4);
    }

    @Override
    public void a(wfc a2, xga a3, pm a4) {
        if (a2.x() && a2.a().a("map_is_scaling")) {
            vfa vfa2 = sxa.tc.a(a2, a3);
            a2.p(a3.a("map"));
            vfa vfa3 = new vfa("map_" + a2.y());
            vfa3.l = (byte)(vfa2.l + 1);
            if (vfa3.l > 4) {
                vfa3.l = (byte)4;
            }
            vfa3.a(vfa2.f, vfa2.h, vfa3.l);
            vfa3.z = vfa2.z;
            vfa3.a();
            a3.a("map_" + a2.y(), vfa3);
        }
    }

    @Override
    public void a(wfc a2, pm a3, List<String> a4, boolean a5) {
        aac a6;
        vfa vfa2 = a6.a(a2, a3.ib);
        if (a5) {
            if (vfa2 == null) {
                a4.add("Unknown map");
            } else {
                a4.add("Scaling at 1:" + (1 << vfa2.l));
                a4.add("(Level " + vfa2.l + "/" + 4 + ")");
            }
        }
    }
}

