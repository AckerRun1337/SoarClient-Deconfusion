/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public interface db
extends fa {
    public void a(List<pa> var1);

    public void a(xa var1);
}

