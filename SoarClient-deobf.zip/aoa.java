/*
 * Decompiled with CFR 0.152.
 */
public enum aoa implements s
{
    b("normal"),
    c("sticky");

    private final String v;

    private /* synthetic */ aoa(String a2, int a3, String a4) {
        aoa a5;
        a5.v = a4;
    }

    public String toString() {
        aoa a2;
        return a2.v;
    }

    @Override
    public String zpa() {
        aoa a2;
        return a2.v;
    }
}

