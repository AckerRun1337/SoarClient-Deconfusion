/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

class cvb
extends ch {
    private final List<rm> v;
    final /* synthetic */ rra d;

    public cvb(rra a2, oj a3) {
        cvb a4;
        a4.d = a2;
        super(a3, rra.n, rra.e, 32, rra.e - 64, rra.a((rra)a2).u * 4);
        a4.v = Lists.newArrayList();
        a4.p(false);
        for (rm rm2 : pvb.d.values()) {
            if (rra.a(a2).a(rm2.v) <= 0 && rra.a(a2).a(rm2.d) <= 0) continue;
            a4.v.add(rm2);
        }
    }

    @Override
    protected int x() {
        cvb a2;
        return a2.v.size();
    }

    @Override
    protected void a(int a2, boolean a3, int a4, int a5) {
    }

    @Override
    protected boolean p(int a2) {
        return false;
    }

    @Override
    protected int j() {
        cvb a2;
        return a2.x() * rra.a((rra)a2.d).u * 4;
    }

    @Override
    protected void o() {
        cvb a2;
        a2.d.o();
    }

    @Override
    protected void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        cvb a8;
        rm rm2 = a8.v.get(a2);
        String string = xab.a("entity." + pvb.a(rm2.l) + ".name", new Object[0]);
        int n2 = rra.a(a8.d).a(rm2.v);
        int n3 = rra.a(a8.d).a(rm2.d);
        String string2 = xab.a("stat.entityKills", n2, string);
        String string3 = xab.a("stat.entityKilledBy", string, n3);
        if (n2 == 0) {
            string2 = xab.a("stat.entityKills.none", string);
        }
        if (n3 == 0) {
            string3 = xab.a("stat.entityKilledBy.none", string);
        }
        a8.d.a(rra.a(a8.d), string, a3 + 2 - 10, a4 + 1, 0xFFFFFF);
        a8.d.a(rra.a(a8.d), string2, a3 + 2, a4 + 1 + rra.a((rra)a8.d).u, n2 == 0 ? 0x606060 : 0x909090);
        a8.d.a(rra.a(a8.d), string3, a3 + 2, a4 + 1 + rra.a((rra)a8.d).u * 2, n3 == 0 ? 0x606060 : 0x909090);
    }
}

