/*
 * Decompiled with CFR 0.152.
 */
public class cmb
extends qtb {
    public cmb(long a2, wg a3) {
        super(a2, a3);
        cmb a4;
    }

    @Override
    protected int a(int a2, int a3, int a4, int a5) {
        cmb a6;
        return a6.a(new int[]{a2, a3, a4, a5});
    }
}

