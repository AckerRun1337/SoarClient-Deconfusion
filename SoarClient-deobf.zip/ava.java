/*
 * Decompiled with CFR 0.152.
 */
public enum ava {
    b("file"),
    c("event");

    private final String v;

    private /* synthetic */ ava(String a2, int a3, String a4) {
        ava a5;
        a5.v = a4;
    }

    public static ava a(String a2) {
        ava[] avaArray = ava.values();
        int n2 = avaArray.length;
        int n3 = 0;
        while (n3 < n2) {
            ava ava2 = avaArray[n3];
            if (ava2.v.equals(a2)) {
                return ava2;
            }
            ++n3;
        }
        return null;
    }
}

