/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cbd {
    private static final Logger l = LogManager.getLogger();
    private final oeb b;
    private Set<qga> c = Sets.newHashSet();
    private ct<qga> v = new ct();
    private int d;

    public cbd(oeb a2) {
        cbd a3;
        a3.b = a2;
        a3.d = a2.a().a().y();
    }

    public void p(rj a2) {
        cbd a3;
        if (a2 instanceof xj) {
            a3.a(a2, 512, 2);
            xj xj2 = (xj)a2;
            for (qga qga2 : a3.c) {
                if (qga2.o == xj2) continue;
                qga2.p(xj2);
            }
        } else if (a2 instanceof isb) {
            a3.a(a2, 64, 5, true);
        } else if (a2 instanceof iwc) {
            a3.a(a2, 64, 20, false);
        } else if (a2 instanceof nja) {
            a3.a(a2, 64, 10, false);
        } else if (a2 instanceof te) {
            a3.a(a2, 64, 10, false);
        } else if (a2 instanceof poa) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof mdb) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof vra) {
            a3.a(a2, 64, 4, true);
        } else if (a2 instanceof sz) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof fub) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof tfb) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof oed) {
            a3.a(a2, 64, 10, true);
        } else if (a2 instanceof xsc) {
            a3.a(a2, 64, 20, true);
        } else if (a2 instanceof dz) {
            a3.a(a2, 80, 3, true);
        } else if (a2 instanceof fcd) {
            a3.a(a2, 80, 3, true);
        } else if (a2 instanceof oh) {
            a3.a(a2, 64, 3, true);
        } else if (a2 instanceof qcd) {
            a3.a(a2, 80, 3, false);
        } else if (a2 instanceof gra) {
            a3.a(a2, 80, 3, false);
        } else if (a2 instanceof oic) {
            a3.a(a2, 160, 3, true);
        } else if (a2 instanceof m) {
            a3.a(a2, 80, 3, true);
        } else if (a2 instanceof pgb) {
            a3.a(a2, 160, 10, true);
        } else if (a2 instanceof isa) {
            a3.a(a2, 160, 20, true);
        } else if (a2 instanceof kzb) {
            a3.a(a2, 160, Integer.MAX_VALUE, false);
        } else if (a2 instanceof ioa) {
            a3.a(a2, 160, 3, true);
        } else if (a2 instanceof wn) {
            a3.a(a2, 160, 20, true);
        } else if (a2 instanceof xla) {
            a3.a(a2, 256, Integer.MAX_VALUE, false);
        }
    }

    public void a(rj a2, int a3, int a4) {
        cbd a5;
        a5.a(a2, a3, a4, false);
    }

    public void a(rj a2, int a3, int a4, boolean a5) {
        cbd a6;
        if (a3 > a6.d) {
            a3 = a6.d;
        }
        try {
            if (a6.v.a(a2.h())) {
                throw new IllegalStateException("Entity is already tracked!");
            }
            qga qga2 = new qga(a2, a3, a4, a5);
            a6.c.add(qga2);
            a6.v.a(a2.h(), qga2);
            qga2.a(a6.b.ia);
        }
        catch (Throwable throwable) {
            hna hna2 = hna.a(throwable, "Adding entity to track");
            cya cya2 = hna2.a("Entity To Track");
            cya2.a("Tracking range", String.valueOf(a3) + " blocks");
            cya2.a("Update interval", new bab(a6, a4));
            a2.a(cya2);
            cya cya3 = hna2.a("Entity That Is Already Tracked");
            a6.v.p((int)a2.h()).o.a(cya3);
            try {
                throw new yja(hna2);
            }
            catch (yja yja2) {
                l.error("\"Silently\" catching entity tracking error.", (Throwable)yja2);
            }
        }
    }

    public void a(rj a2) {
        cbd a3;
        Object object;
        if (a2 instanceof xj) {
            object = (xj)a2;
            for (qga qga2 : a3.c) {
                qga2.o((xj)object);
            }
        }
        if ((object = a3.v.a(a2.h())) != null) {
            a3.c.remove(object);
            ((qga)object).a();
        }
    }

    public void a() {
        cbd a2;
        ArrayList arrayList = Lists.newArrayList();
        for (qga qga2 : a2.c) {
            qga2.p(a2.b.ia);
            if (!qga2.v || !(qga2.o instanceof xj)) continue;
            arrayList.add((xj)qga2.o);
        }
        int n2 = 0;
        while (n2 < arrayList.size()) {
            xj xj2 = (xj)arrayList.get(n2);
            for (qga qga3 : a2.c) {
                if (qga3.o == xj2) continue;
                qga3.p(xj2);
            }
            ++n2;
        }
    }

    public void p(xj a2) {
        cbd a3;
        for (qga qga2 : a3.c) {
            if (qga2.o == a2) {
                qga2.a(a3.b.ia);
                continue;
            }
            qga2.p(a2);
        }
    }

    public void p(rj a2, o a3) {
        cbd a4;
        qga qga2 = a4.v.p(a2.h());
        if (qga2 != null) {
            qga2.p(a3);
        }
    }

    public void a(rj a2, o a3) {
        cbd a4;
        qga qga2 = a4.v.p(a2.h());
        if (qga2 != null) {
            qga2.a(a3);
        }
    }

    public void a(xj a2) {
        cbd a3;
        for (qga qga2 : a3.c) {
            qga2.a(a2);
        }
    }

    public void a(xj a2, dsc a3) {
        cbd a4;
        for (qga qga2 : a4.c) {
            if (qga2.o == a2 || qga2.o.k != a3.p || qga2.o.t != a3.s) continue;
            qga2.p(a2);
        }
    }
}

