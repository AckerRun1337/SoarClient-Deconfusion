/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class acc
extends jj {
    public acc() {
        acc a2;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4) {
        acc a5;
        int n2;
        while (a2.a(a4) && a4.p() > 2) {
            a4 = a4.z();
        }
        if (a2.a(a4).a() != cl.kn) {
            return false;
        }
        a4 = a4.j(a3.nextInt(4));
        int n3 = a3.nextInt(4) + 7;
        int n4 = n3 / 4 + a3.nextInt(2);
        if (n4 > 1 && a3.nextInt(60) == 0) {
            a4 = a4.j(10 + a3.nextInt(30));
        }
        int n5 = 0;
        while (n5 < n3) {
            float f2 = (1.0f - (float)n5 / (float)n3) * (float)n4;
            n2 = smb.a(f2);
            int n6 = -n2;
            while (n6 <= n2) {
                float f3 = (float)smb.y(n6) - 0.25f;
                int n7 = -n2;
                while (n7 <= n2) {
                    float f4 = (float)smb.y(n7) - 0.25f;
                    if ((n6 == 0 && n7 == 0 || f3 * f3 + f4 * f4 <= f2 * f2) && (n6 != -n2 && n6 != n2 && n7 != -n2 && n7 != n2 || a3.nextFloat() <= 0.75f)) {
                        yd yd2 = a2.a(a4.a(n6, n5, n7)).a();
                        if (yd2.a() == dr.ua || yd2 == cl.zk || yd2 == cl.kn || yd2 == cl.mn) {
                            a5.a(a2, a4.a(n6, n5, n7), cl.p.a());
                        }
                        if (n5 != 0 && n2 > 1 && ((yd2 = a2.a(a4.a(n6, -n5, n7)).a()).a() == dr.ua || yd2 == cl.zk || yd2 == cl.kn || yd2 == cl.mn)) {
                            a5.a(a2, a4.a(n6, -n5, n7), cl.p.a());
                        }
                    }
                    ++n7;
                }
                ++n6;
            }
            ++n5;
        }
        n5 = n4 - 1;
        if (n5 < 0) {
            n5 = 0;
        } else if (n5 > 1) {
            n5 = 1;
        }
        int n8 = -n5;
        while (n8 <= n5) {
            n2 = -n5;
            while (n2 <= n5) {
                tp tp2 = a4.a(n8, -1, n2);
                int n9 = 50;
                if (Math.abs(n8) == 1 && Math.abs(n2) == 1) {
                    n9 = a3.nextInt(5);
                }
                while (tp2.p() > 50) {
                    yd yd3 = a2.a(tp2).a();
                    if (yd3.a() != dr.ua && yd3 != cl.zk && yd3 != cl.kn && yd3 != cl.mn && yd3 != cl.p) break;
                    a5.a(a2, tp2, cl.p.a());
                    tp2 = tp2.z();
                    if (--n9 > 0) continue;
                    tp2 = tp2.z(a3.nextInt(5) + 1);
                    n9 = a3.nextInt(5);
                }
                ++n2;
            }
            ++n8;
        }
        return true;
    }
}

