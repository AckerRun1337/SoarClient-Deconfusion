/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.mojang.authlib.GameProfile;
import java.util.List;

public class axb
extends ge {
    private static final String[] d = new String[]{"skeleton", "wither", "zombie", "char", "creeper"};

    public axb() {
        axb a2;
        a2.a(md.k);
        a2.a(0);
        a2.a(true);
    }

    @Override
    public boolean a(wfc a2, pm a3, xga a4, tp a5, hnd a6, float a7, float a8, float a9) {
        if (a6 == hnd.g) {
            return false;
        }
        ba ba2 = a4.a(a5);
        yd yd2 = ba2.a();
        boolean bl2 = yd2.p(a4, a5);
        if (!bl2) {
            if (!a4.a(a5).a().a().x()) {
                return false;
            }
            a5 = a5.a(a6);
        }
        if (!a3.a(a5, a6, a2)) {
            return false;
        }
        if (!cl.ka.a(a4, a5)) {
            return false;
        }
        if (!a4.f) {
            kv kv2;
            a4.a(a5, cl.ka.a().a(jaa.z, a6), 3);
            int n2 = 0;
            if (a6 == hnd.k) {
                n2 = smb.o((double)(a3.nb * 16.0f / 360.0f) + 0.5) & 0xF;
            }
            if ((kv2 = a4.a(a5)) instanceof csc) {
                csc csc2 = (csc)kv2;
                if (a2.y() == 3) {
                    GameProfile gameProfile = null;
                    if (a2.x()) {
                        dgb dgb2 = a2.a();
                        if (dgb2.a("SkullOwner", 10)) {
                            gameProfile = nvb.a((dgb)dgb2.a("SkullOwner"));
                        } else if (dgb2.a("SkullOwner", 8) && dgb2.a("SkullOwner").length() > 0) {
                            gameProfile = new GameProfile(null, dgb2.a("SkullOwner"));
                        }
                    }
                    csc2.a(gameProfile);
                } else {
                    csc2.p(a2.y());
                }
                csc2.a(n2);
                cl.ka.a(a4, a5, csc2);
            }
            --a2.e;
        }
        return true;
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        int n2 = 0;
        while (n2 < d.length) {
            a4.add(new wfc(a2, 1, n2));
            ++n2;
        }
    }

    @Override
    public int a(int a2) {
        return a2;
    }

    @Override
    public String o(wfc a2) {
        axb a3;
        int n2 = a2.y();
        if (n2 < 0 || n2 >= d.length) {
            n2 = 0;
        }
        return String.valueOf(super.a()) + "." + d[n2];
    }

    @Override
    public String a(wfc a2) {
        axb a3;
        if (a2.y() == 3 && a2.x()) {
            ml ml2;
            if (a2.a().a("SkullOwner", 8)) {
                return bwa.a("item.skull.player.name", a2.a().a("SkullOwner"));
            }
            if (a2.a().a("SkullOwner", 10) && ((dgb)(ml2 = a2.a().a("SkullOwner"))).a("Name", 8)) {
                return bwa.a("item.skull.player.name", ((dgb)ml2).a("Name"));
            }
        }
        return super.a(a2);
    }

    @Override
    public boolean a(dgb a2) {
        axb a3;
        super.a(a2);
        if (a2.a("SkullOwner", 8) && a2.a("SkullOwner").length() > 0) {
            GameProfile gameProfile = new GameProfile(null, a2.a("SkullOwner"));
            gameProfile = csc.a(gameProfile);
            a2.a("SkullOwner", nvb.a(new dgb(), gameProfile));
            return true;
        }
        return false;
    }
}

