/*
 * Decompiled with CFR 0.152.
 */
public enum cdb {
    b,
    c,
    v;


    private /* synthetic */ cdb(String a2, int a3) {
        cdb a4;
    }
}

