/*
 * Decompiled with CFR 0.152.
 */
public class aba
extends ff {
    private boolean b;
    private String v;
    private final nl d;

    public aba(nl a2, int a3, int a4, int a5, String a6, boolean a7) {
        super(a3, a4, a5, 150, 20, "");
        aba a8;
        a8.v = a6;
        a8.b = a7;
        a8.l = a8.a();
        a8.d = a2;
    }

    private /* synthetic */ String a() {
        aba a2;
        return String.valueOf(xab.a(a2.v, new Object[0])) + ": " + (a2.b ? xab.a("gui.yes", new Object[0]) : xab.a("gui.no", new Object[0]));
    }

    public void a(boolean a2) {
        aba a3;
        a3.b = a2;
        a3.l = a3.a();
        a3.d.a(a3.b ? 1 : 0, a2);
    }

    @Override
    public boolean a(oj a2, int a3, int a4) {
        aba a5;
        if (super.a(a2, a3, a4)) {
            a5.b = !a5.b;
            a5.l = a5.a();
            a5.d.a(a5.b ? 1 : 0, a5.b);
            return true;
        }
        return false;
    }
}

