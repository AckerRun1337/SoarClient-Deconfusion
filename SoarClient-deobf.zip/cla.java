/*
 * Decompiled with CFR 0.152.
 */
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cla {
    public final String i;
    private final ga n;
    public boolean e;
    private final yc r;
    private final q f;
    private Class<? extends ec> h;
    private static NumberFormat z = NumberFormat.getIntegerInstance(Locale.US);
    public static yc l = new rac();
    private static DecimalFormat b = new DecimalFormat("########0.00");
    public static yc c = new mlb();
    public static yc v = new qwc();
    public static yc d = new cjb();

    public cla(String a2, ga a3, yc a4) {
        cla a5;
        a5.i = a2;
        a5.n = a3;
        a5.r = a4;
        a5.f = new dg(a5);
        q.r.put(a5.f.a(), a5.f);
    }

    public cla(String a2, ga a3) {
        a4(a2, a3, l);
        cla a4;
    }

    public cla p() {
        cla a2;
        a2.e = true;
        return a2;
    }

    public cla a() {
        cla a2;
        if (hca.wb.containsKey(a2.i)) {
            throw new RuntimeException("Duplicate stat id: \"" + hca.wb.get((Object)a2.i).n + "\" and \"" + a2.n + "\" at id " + a2.i);
        }
        hca.nb.add(a2);
        hca.wb.put(a2.i, a2);
        return a2;
    }

    public boolean a() {
        return false;
    }

    public String a(int a2) {
        cla a3;
        return a3.r.a(a2);
    }

    public ga p() {
        cla a2;
        ga ga2 = a2.n.a();
        ga2.a().a(yf.m);
        ga2.a().a(new sqc(bwb.h, new gkb(a2.i)));
        return ga2;
    }

    public ga a() {
        cla a2;
        ga ga2 = a2.p();
        ga ga3 = new gkb("[").a(ga2).a("]");
        ga3.a(ga2.a());
        return ga3;
    }

    public boolean equals(Object a2) {
        cla a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 != null && a3.getClass() == a2.getClass()) {
            cla cla2 = (cla)a2;
            return a3.i.equals(cla2.i);
        }
        return false;
    }

    public int hashCode() {
        cla a2;
        return a2.i.hashCode();
    }

    public String toString() {
        cla a2;
        return "Stat{id=" + a2.i + ", nameId=" + a2.n + ", awardLocallyOnly=" + a2.e + ", formatter=" + a2.r + ", objectiveCriteria=" + a2.f + '}';
    }

    public q a() {
        cla a2;
        return a2.f;
    }

    public Class<? extends ec> a() {
        cla a2;
        return a2.h;
    }

    public cla a(Class<? extends ec> a2) {
        cla a3;
        a3.h = a2;
        return a3;
    }

    static /* synthetic */ NumberFormat a() {
        return z;
    }

    static /* synthetic */ DecimalFormat a() {
        return b;
    }
}

