/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum bwb {
    f("show_text", true),
    h("show_achievement", true),
    z("show_item", true),
    l("show_entity", true);

    private static final Map<String, bwb> b;
    private final boolean c;
    private final String v;

    static {
        b = Maps.newHashMap();
        bwb[] bwbArray = bwb.values();
        int n2 = bwbArray.length;
        int n3 = 0;
        while (n3 < n2) {
            bwb bwb2 = bwbArray[n3];
            b.put(bwb2.a(), bwb2);
            ++n3;
        }
    }

    private /* synthetic */ bwb(String a2, int a3, String a4, boolean a5) {
        bwb a6;
        a6.v = a4;
        a6.c = a5;
    }

    public boolean a() {
        bwb a2;
        return a2.c;
    }

    public String a() {
        bwb a2;
        return a2.v;
    }

    public static bwb a(String a2) {
        return b.get(a2);
    }
}

