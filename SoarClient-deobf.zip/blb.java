/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class blb
extends bh {
    private /* synthetic */ Color c;
    private /* synthetic */ Color v;
    private /* synthetic */ Color d;

    public blb() {
        super("Hitbox", 0, gk.b);
        blb a2;
        a2.c = Color.WHITE;
        a2.v = Color.RED;
        a2.d = Color.BLUE;
    }

    @Override
    public void y() {
        blb a2;
        gsc.t.w.a(new egd("BoundingBox", a2, true));
        gsc.t.w.a(new egd("EyeHeight", a2, true));
        gsc.t.w.a(new egd("LookVector", a2, true));
        gsc.t.w.a(new egd("Width", a2, 1.0, 1.0, 10.0, true));
    }

    @Override
    public void o() {
        blb a2;
        super.o();
        if (a2.g.a() != null) {
            a2.g.a().p(true);
        }
    }

    @Override
    public void p() {
        blb a2;
        super.p();
        if (a2.g.a() != null) {
            a2.g.a().p(false);
        }
    }

    @fo
    public void a(jyc a2) {
        Object object;
        Object object2;
        blb a3;
        int n2 = (int)gsc.t.w.a(a3, "Width").o();
        boolean bl2 = gsc.t.w.a(a3, "BoundingBox").z();
        boolean bl3 = gsc.t.w.a(a3, "EyeHeight").z();
        boolean bl4 = gsc.t.w.a(a3, "LookVector").z();
        float f2 = a2.z.xa / 2.0f;
        ewa.p(false);
        ewa.c();
        ewa.ka();
        ewa.v();
        ewa.w();
        GL11.y((float)n2);
        if (bl2) {
            object2 = a2.z.a();
            object = new tca(((tca)object2).z - a2.z.fb + a2.l, ((tca)object2).l - a2.z.zb + a2.b, ((tca)object2).b - a2.z.db + a2.c, ((tca)object2).c - a2.z.fb + a2.l, ((tca)object2).v - a2.z.zb + a2.b, ((tca)object2).d - a2.z.db + a2.c);
            qda.a((tca)object, a3.c.getRed(), a3.c.getGreen(), a3.c.getBlue(), a3.c.getAlpha());
        }
        if (bl3 && a2.z instanceof xi) {
            qda.a(new tca(a2.l - (double)f2, a2.b + (double)a2.z.o() - (double)0.01f, a2.c - (double)f2, a2.l + (double)f2, a2.b + (double)a2.z.o() + (double)0.01f, a2.c + (double)f2), a3.v.getRed(), a3.v.getGreen(), a3.v.getBlue(), a3.v.getAlpha());
        }
        object2 = xlb.a();
        object = ((xlb)object2).a();
        if (bl4) {
            tta tta2 = a2.z.p(a2.d);
            ((krb)object).a(3, ybd.w);
            ((krb)object).a(a2.l, a2.b + (double)a2.z.o(), a2.c).a(0, 0, 255, 255).z();
            ((krb)object).a(a2.l + tta2.c * 2.0, a2.b + (double)a2.z.o() + tta2.v * 2.0, a2.c + tta2.d * 2.0).a(a3.d.getRed(), a3.d.getGreen(), a3.d.getBlue(), a3.d.getAlpha()).z();
            ((xlb)object2).a();
        }
        ewa.e();
        ewa.ra();
        ewa.t();
        ewa.b();
        ewa.p(true);
        GL11.y(1.0f);
    }
}

