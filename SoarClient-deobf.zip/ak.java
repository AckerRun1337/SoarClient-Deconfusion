/*
 * Decompiled with CFR 0.152.
 */
public enum ak {
    p(new klb("stream.unavailable.no_fbo", new Object[0])),
    s(new klb("stream.unavailable.library_arch_mismatch", new Object[0])),
    w(new klb("stream.unavailable.library_failure", new Object[0]), new klb("stream.unavailable.report_to_mojang", new Object[0])),
    i(new klb("stream.unavailable.not_supported.windows", new Object[0])),
    n(new klb("stream.unavailable.not_supported.mac", new Object[0]), new klb("stream.unavailable.not_supported.mac.okay", new Object[0])),
    e(new klb("stream.unavailable.not_supported.other", new Object[0])),
    r(new klb("stream.unavailable.account_not_migrated", new Object[0]), new klb("stream.unavailable.account_not_migrated.okay", new Object[0])),
    f(new klb("stream.unavailable.account_not_bound", new Object[0]), new klb("stream.unavailable.account_not_bound.okay", new Object[0])),
    h(new klb("stream.unavailable.failed_auth", new Object[0]), new klb("stream.unavailable.failed_auth.okay", new Object[0])),
    z(new klb("stream.unavailable.failed_auth_error", new Object[0])),
    l(new klb("stream.unavailable.initialization_failure", new Object[0]), new klb("stream.unavailable.report_to_mojang", new Object[0])),
    b(new klb("stream.unavailable.unknown", new Object[0]), new klb("stream.unavailable.report_to_mojang", new Object[0]));

    private final ga c;
    private final ga v;

    private /* synthetic */ ak(String a2, int a3, ga a4) {
        a5(a2, a3, a4, null);
        ak a5;
    }

    private /* synthetic */ ak(String a2, int a3, ga a4, ga a5) {
        ak a6;
        a6.c = a4;
        a6.v = a5;
    }

    public ga p() {
        ak a2;
        return a2.c;
    }

    public ga a() {
        ak a2;
        return a2.v;
    }
}

