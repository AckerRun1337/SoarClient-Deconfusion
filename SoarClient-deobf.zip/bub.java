/*
 * Decompiled with CFR 0.152.
 */
public enum bub implements s
{
    c,
    v;


    private /* synthetic */ bub(String a2, int a3) {
        bub a4;
    }

    public String toString() {
        bub a2;
        return a2.zpa();
    }

    @Override
    public String zpa() {
        bub a2;
        return a2 == c ? "left" : "right";
    }
}

