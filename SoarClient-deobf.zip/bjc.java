/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class bjc
extends smc {
    private final ba v;
    private final ba d;

    public bjc(ba a2, ba a3) {
        super(false);
        bjc a4;
        a4.d = a2;
        a4.v = a3;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4) {
        yd yd2;
        while (((yd2 = a2.a(a4).a()).a() == dr.ua || yd2.a() == dr.ja) && a4.p() > 0) {
            a4 = a4.z();
        }
        yd yd3 = a2.a(a4).a();
        if (yd3 == cl.zk || yd3 == cl.ik) {
            bjc a5;
            a4 = a4.j();
            a5.a(a2, a4, a5.d);
            int n2 = a4.p();
            while (n2 <= a4.p() + 2) {
                int n3 = n2 - a4.p();
                int n4 = 2 - n3;
                int n5 = a4.o() - n4;
                while (n5 <= a4.o() + n4) {
                    int n6 = n5 - a4.o();
                    int n7 = a4.a() - n4;
                    while (n7 <= a4.a() + n4) {
                        tp tp2;
                        int n8 = n7 - a4.a();
                        if (!(Math.abs(n6) == n4 && Math.abs(n8) == n4 && a3.nextInt(2) == 0 || a2.a(tp2 = new tp(n5, n2, n7)).a().n())) {
                            a5.a(a2, tp2, a5.v);
                        }
                        ++n7;
                    }
                    ++n5;
                }
                ++n2;
            }
        }
        return true;
    }
}

