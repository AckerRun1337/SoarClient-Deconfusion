/*
 * Decompiled with CFR 0.152.
 */
import org.lwjgl.util.vector.Vector3f;

public class df {
    public final Vector3f b;
    public final mh c;
    public final float v;
    public final boolean d;

    public df(Vector3f a2, mh a3, float a4, boolean a5) {
        df a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }
}

