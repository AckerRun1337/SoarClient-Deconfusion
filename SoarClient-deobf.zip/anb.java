/*
 * Decompiled with CFR 0.152.
 */
public class anb
implements va<rva> {
    private final ymc v;
    private final qm d = new dic(0);

    public anb(ymc a2) {
        anb a3;
        a3.v = a2;
    }

    @Override
    public void a(rva a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9) {
        if (!a2.l()) {
            anb a10;
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            ewa.f();
            ewa.w();
            ewa.y(770, 771);
            a10.d.a(a10.v.a());
            a10.d.a(a2, a3, a4, a6, a7, a8, a9);
            ewa.b();
            ewa.l();
        }
    }

    @Override
    public boolean a() {
        return true;
    }
}

