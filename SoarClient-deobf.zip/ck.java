/*
 * Decompiled with CFR 0.152.
 */
public class ck
implements e {
    public ck() {
        ck a2;
    }

    @Override
    public final wfc a(kb a2, wfc a3) {
        ck a4;
        wfc wfc2 = a4.p(a2, a3);
        a4.a(a2);
        a4.a(a2, kkb.a(a2.a()));
        return wfc2;
    }

    protected wfc p(kb a2, wfc a3) {
        hnd hnd2 = kkb.a(a2.a());
        ea ea2 = kkb.a(a2);
        wfc wfc2 = a3.a(1);
        ck.a(a2.a(), wfc2, 6, hnd2, ea2);
        return a3;
    }

    public static void a(xga a2, wfc a3, int a4, hnd a5, ea a6) {
        double d2 = a6.o();
        double d3 = a6.p();
        double d4 = a6.a();
        d3 = a5.a() == mh.z ? (d3 -= 0.125) : (d3 -= 0.15625);
        xsc xsc2 = new xsc(a2, d2, d3, d4, a3);
        double d5 = a2.q.nextDouble() * 0.1 + 0.2;
        xsc2.mb = (double)a5.o() * d5;
        xsc2.gb = 0.2f;
        xsc2.wb = (double)a5.a() * d5;
        xsc2.mb += a2.q.nextGaussian() * (double)0.0075f * (double)a4;
        xsc2.gb += a2.q.nextGaussian() * (double)0.0075f * (double)a4;
        xsc2.wb += a2.q.nextGaussian() * (double)0.0075f * (double)a4;
        a2.a(xsc2);
    }

    protected void a(kb a2) {
        ((xga)a2.a()).p(1000, a2.a(), 0);
    }

    protected void a(kb a2, hnd a3) {
        ck a4;
        ((xga)a2.a()).p(2000, a2.a(), a4.a(a3));
    }

    private /* synthetic */ int a(hnd a2) {
        return a2.o() + 1 + (a2.a() + 1) * 3;
    }
}

