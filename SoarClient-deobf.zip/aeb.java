/*
 * Decompiled with CFR 0.152.
 */
public class aeb
extends gya {
    protected jj d = new xp(cl.zb);

    public aeb() {
        aeb a2;
    }

    @Override
    protected void a(nk a2) {
        aeb a3;
        a3.a();
        if (a3.ha.nextInt(5) == 0) {
            int n2 = a3.ha.nextInt(16) + 8;
            int n3 = a3.ha.nextInt(16) + 8;
            a3.d.a(a3.ka, a3.ha, a3.ka.a(a3.ya.a(n2, 0, n3)));
        }
        if (a3.ya.o() == 0 && a3.ya.a() == 0) {
            oic oic2 = new oic(a3.ka);
            oic2.p(0.0, 128.0, 0.0, a3.ha.nextFloat() * 360.0f, 0.0f);
            a3.ka.a(oic2);
        }
    }
}

