/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class cm
implements Serializable,
Cloneable {
    static final long c = 9011180388985266884L;
    public float v;
    public float d;

    public cm(float a2, float a3) {
        cm a4;
        a4.v = a2;
        a4.d = a3;
    }

    public cm(float[] a2) {
        cm a3;
        a3.v = a2[0];
        a3.d = a2[1];
    }

    public cm(cm a2) {
        cm a3;
        a3.v = a2.v;
        a3.d = a2.d;
    }

    public cm(hu a2) {
        cm a3;
        a3.v = (float)a2.v;
        a3.d = (float)a2.d;
    }

    public cm() {
        cm a2;
        a2.v = 0.0f;
        a2.d = 0.0f;
    }

    public final void p(float a2, float a3) {
        a.v = a2;
        a.d = a3;
    }

    public final void p(float[] a2) {
        a.v = a2[0];
        a.d = a2[1];
    }

    public final void z(cm a2) {
        a.v = a2.v;
        a.d = a2.d;
    }

    public final void a(hu a2) {
        a.v = (float)a2.v;
        a.d = (float)a2.d;
    }

    public final void a(float[] a2) {
        cm a3;
        a2[0] = a3.v;
        a2[1] = a3.d;
    }

    public final void p(cm a2, cm a3) {
        a.v = a2.v + a3.v;
        a.d = a2.d + a3.d;
    }

    public final void y(cm a2) {
        a.v += a2.v;
        a.d += a2.d;
    }

    public final void a(cm a2, cm a3) {
        a.v = a2.v - a3.v;
        a.d = a2.d - a3.d;
    }

    public final void o(cm a2) {
        a.v -= a2.v;
        a.d -= a2.d;
    }

    public final void p(cm a2) {
        a.v = -a2.v;
        a.d = -a2.d;
    }

    public final void p() {
        cm a2;
        a2.v = -a2.v;
        a2.d = -a2.d;
    }

    public final void y(float a2, cm a3) {
        a.v = a2 * a3.v;
        a.d = a2 * a3.d;
    }

    public final void z(float a2) {
        a.v *= a2;
        a.d *= a2;
    }

    public final void a(float a2, cm a3, cm a4) {
        a.v = a2 * a3.v + a4.v;
        a.d = a2 * a3.d + a4.d;
    }

    public final void o(float a2, cm a3) {
        cm a4;
        a4.v = a2 * a4.v + a3.v;
        a4.d = a2 * a4.d + a3.d;
    }

    public int hashCode() {
        cm a2;
        long l2 = 1L;
        l2 = kbd.a(l2, a2.v);
        l2 = kbd.a(l2, a2.d);
        return kbd.a(l2);
    }

    public boolean a(cm a2) {
        try {
            cm a3;
            return a3.v == a2.v && a3.d == a2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean equals(Object a2) {
        try {
            cm a3;
            cm cm2 = (cm)a2;
            return a3.v == cm2.v && a3.d == cm2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
        catch (ClassCastException classCastException) {
            return false;
        }
    }

    public boolean a(cm a2, float a3) {
        cm a4;
        float f2 = a4.v - a2.v;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f3 = f2 < 0.0f ? -f2 : f2;
        if (f3 > a3) {
            return false;
        }
        f2 = a4.d - a2.d;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f4 = f2 < 0.0f ? -f2 : f2;
        return !(f4 > a3);
    }

    public String toString() {
        cm a2;
        return "(" + a2.v + ", " + a2.d + ")";
    }

    public final void a(float a2, float a3, cm a4) {
        a.v = a4.v > a3 ? a3 : (a4.v < a2 ? a2 : a4.v);
        a.d = a4.d > a3 ? a3 : (a4.d < a2 ? a2 : a4.d);
    }

    public final void p(float a2, cm a3) {
        a.v = a3.v < a2 ? a2 : a3.v;
        a.d = a3.d < a2 ? a2 : a3.d;
    }

    public final void a(float a2, cm a3) {
        a.v = a3.v > a2 ? a2 : a3.v;
        a.d = a3.d > a2 ? a2 : a3.d;
    }

    public final void a(cm a2) {
        a.v = Math.abs(a2.v);
        a.d = Math.abs(a2.d);
    }

    public final void a(float a2, float a3) {
        cm a4;
        if (a4.v > a3) {
            a4.v = a3;
        } else if (a4.v < a2) {
            a4.v = a2;
        }
        if (a4.d > a3) {
            a4.d = a3;
        } else if (a4.d < a2) {
            a4.d = a2;
        }
    }

    public final void y(float a2) {
        cm a3;
        if (a3.v < a2) {
            a3.v = a2;
        }
        if (a3.d < a2) {
            a3.d = a2;
        }
    }

    public final void o(float a2) {
        cm a3;
        if (a3.v > a2) {
            a3.v = a2;
        }
        if (a3.d > a2) {
            a3.d = a2;
        }
    }

    public final void a() {
        cm a2;
        a2.v = Math.abs(a2.v);
        a2.d = Math.abs(a2.d);
    }

    public final void a(cm a2, cm a3, float a4) {
        a.v = (1.0f - a4) * a2.v + a4 * a3.v;
        a.d = (1.0f - a4) * a2.d + a4 * a3.d;
    }

    public final void a(cm a2, float a3) {
        cm a4;
        a4.v = (1.0f - a3) * a4.v + a3 * a2.v;
        a4.d = (1.0f - a3) * a4.d + a3 * a2.d;
    }

    public Object clone() {
        try {
            cm a2;
            return super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
    }

    public final float p() {
        cm a2;
        return a2.v;
    }

    public final void p(float a2) {
        a.v = a2;
    }

    public final float a() {
        cm a2;
        return a2.d;
    }

    public final void a(float a2) {
        a.d = a2;
    }
}

