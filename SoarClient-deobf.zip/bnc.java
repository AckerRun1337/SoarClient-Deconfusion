/*
 * Decompiled with CFR 0.152.
 */
public enum bnc implements s
{
    b("compare"),
    c("subtract");

    private final String v;

    private /* synthetic */ bnc(String a2, int a3, String a4) {
        bnc a5;
        a5.v = a4;
    }

    public String toString() {
        bnc a2;
        return a2.v;
    }

    @Override
    public String zpa() {
        bnc a2;
        return a2.v;
    }
}

