/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;

public class bv
extends zh {
    private xga l;
    private final List<tp> b = Lists.newArrayList();
    private final List<rsa> c = Lists.newArrayList();
    private final List<ao> v = Lists.newArrayList();
    private int d;

    public bv(String a2) {
        super(a2);
        bv a3;
    }

    public bv(xga a2) {
        super(bv.a(a2.g));
        bv a3;
        a3.l = a2;
        a3.a();
    }

    public void a(xga a2) {
        bv a3;
        a3.l = a2;
        for (ao ao2 : a3.v) {
            ao2.a(a2);
        }
    }

    public void o(tp a2) {
        bv a3;
        if (a3.b.size() <= 64 && !a3.p(a2)) {
            a3.b.add(a2);
        }
    }

    public void z() {
        bv a2;
        ++a2.d;
        for (ao ao2 : a2.v) {
            ao2.p(a2.d);
        }
        a2.y();
        a2.o();
        a2.p();
        if (a2.d % 400 == 0) {
            a2.a();
        }
    }

    private /* synthetic */ void y() {
        bv a2;
        Iterator<ao> iterator = a2.v.iterator();
        while (iterator.hasNext()) {
            ao ao2 = iterator.next();
            if (!ao2.p()) continue;
            iterator.remove();
            a2.a();
        }
    }

    public List<ao> a() {
        bv a2;
        return a2.v;
    }

    public ao a(tp a2, int a3) {
        bv a4;
        ao ao2 = null;
        double d2 = 3.4028234663852886E38;
        for (ao ao3 : a4.v) {
            float f2;
            double d3 = ao3.a().a(a2);
            if (!(d3 < d2) || !(d3 <= (double)((f2 = (float)(a3 + ao3.y())) * f2))) continue;
            ao2 = ao3;
            d2 = d3;
        }
        return ao2;
    }

    private /* synthetic */ void o() {
        bv a2;
        if (!a2.b.isEmpty()) {
            a2.p(a2.b.remove(0));
        }
    }

    private /* synthetic */ void p() {
        bv a2;
        int n2 = 0;
        while (n2 < a2.c.size()) {
            rsa rsa2 = a2.c.get(n2);
            ao ao2 = a2.a(rsa2.p(), 32);
            if (ao2 == null) {
                ao2 = new ao(a2.l);
                a2.v.add(ao2);
                a2.a();
            }
            ao2.a(rsa2);
            ++n2;
        }
        a2.c.clear();
    }

    private /* synthetic */ void p(tp a2) {
        int n2 = 16;
        int n3 = 4;
        int n4 = 16;
        int n5 = -n2;
        while (n5 < n2) {
            int n6 = -n3;
            while (n6 < n3) {
                int n7 = -n4;
                while (n7 < n4) {
                    bv a3;
                    tp tp2 = a2.a(n5, n6, n7);
                    if (a3.a(tp2)) {
                        rsa rsa2 = a3.a(tp2);
                        if (rsa2 == null) {
                            a3.a(tp2);
                        } else {
                            rsa2.a(a3.d);
                        }
                    }
                    ++n7;
                }
                ++n6;
            }
            ++n5;
        }
    }

    private /* synthetic */ rsa a(tp a2) {
        bv a3;
        for (rsa object : a3.c) {
            if (object.p().o() != a2.o() || object.p().a() != a2.a() || Math.abs(object.p().p() - a2.p()) > 1) continue;
            return object;
        }
        for (ao ao2 : a3.v) {
            rsa rsa2 = ao2.a(a2);
            if (rsa2 == null) continue;
            return rsa2;
        }
        return null;
    }

    private /* synthetic */ void a(tp a2) {
        int n2;
        bv a3;
        hnd hnd2 = ccc.a(a3.l, a2);
        hnd hnd3 = hnd2.z();
        int n3 = a3.a(a2, hnd2, 5);
        if (n3 != (n2 = a3.a(a2, hnd3, n3 + 1))) {
            a3.c.add(new rsa(a2, n3 < n2 ? hnd2 : hnd3, a3.d));
        }
    }

    private /* synthetic */ int a(tp a2, hnd a3, int a4) {
        int n2 = 0;
        int n3 = 1;
        while (n3 <= 5) {
            bv a5;
            if (a5.l.q(a2.a(a3, n3)) && ++n2 >= a4) {
                return n2;
            }
            ++n3;
        }
        return n2;
    }

    private /* synthetic */ boolean p(tp a2) {
        bv a3;
        for (tp tp2 : a3.b) {
            if (!tp2.equals(a2)) continue;
            return true;
        }
        return false;
    }

    private /* synthetic */ boolean a(tp a2) {
        bv a3;
        yd yd2 = a3.l.a(a2).a();
        return yd2 instanceof ccc ? yd2.a() == dr.na : false;
    }

    @Override
    public void p(dgb a2) {
        a3.d = a2.a("Tick");
        mxb mxb2 = a2.a("Villages", 10);
        int n2 = 0;
        while (n2 < mxb2.p()) {
            bv a3;
            dgb dgb2 = mxb2.a(n2);
            ao ao2 = new ao();
            ao2.p(dgb2);
            a3.v.add(ao2);
            ++n2;
        }
    }

    @Override
    public void a(dgb a2) {
        bv a3;
        a2.a("Tick", a3.d);
        mxb mxb2 = new mxb();
        for (ao ao2 : a3.v) {
            dgb dgb2 = new dgb();
            ao2.a(dgb2);
            mxb2.a(dgb2);
        }
        a2.a("Villages", mxb2);
    }

    public static String a(wma a2) {
        return "villages" + a2.a();
    }
}

