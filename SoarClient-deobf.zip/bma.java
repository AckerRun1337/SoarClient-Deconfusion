/*
 * Decompiled with CFR 0.152.
 */
public enum bma {
    c,
    v;


    private /* synthetic */ bma(String a2, int a3) {
        bma a4;
    }
}

