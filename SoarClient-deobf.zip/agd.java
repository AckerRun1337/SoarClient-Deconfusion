/*
 * Decompiled with CFR 0.152.
 */
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class agd {
    public agd() {
        agd a2;
    }

    public static String a(InputStream a2) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            String string;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(a2));
            while ((string = bufferedReader.readLine()) != null) {
                stringBuilder.append(string).append('\n');
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return String.valueOf(stringBuilder);
    }
}

