/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;
import net.optifine.shaders.\u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80;
import net.optifine.shaders.\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class adb
extends hya {
    private zsa[] h = null;
    private hya[] z = null;
    private static final String l = "<profile>";
    private static final String b = "<custom>";

    public adb(zsa[] a2, hya[] a3) {
        super(l, "", adb.a(a2, a3, false), adb.a(a2), adb.a(a2, a3, true), null);
        adb a4;
        a4.h = a2;
        a4.z = a3;
    }

    @Override
    public void p() {
        adb a2;
        super.p();
        if (a2.y().equals(b)) {
            super.p();
        }
        a2.y();
    }

    public void z() {
        adb a2;
        zsa zsa2 = a2.a(a2.y());
        if (zsa2 == null || !\u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a(zsa2, a2.z, false)) {
            String string = adb.a(a2.h, a2.z, false);
            a2.y(string);
        }
    }

    private /* synthetic */ void y() {
        adb a2;
        zsa zsa2 = a2.a(a2.y());
        if (zsa2 != null) {
            String[] stringArray = zsa2.a();
            int n2 = 0;
            while (n2 < stringArray.length) {
                String string = stringArray[n2];
                hya hya2 = a2.a(string);
                if (hya2 != null) {
                    String string2 = zsa2.a(string);
                    hya2.y(string2);
                }
                ++n2;
            }
        }
    }

    private /* synthetic */ hya a(String a2) {
        adb a3;
        int n2 = 0;
        while (n2 < a3.z.length) {
            hya hya2 = a3.z[n2];
            if (hya2.x().equals(a2)) {
                return hya2;
            }
            ++n2;
        }
        return null;
    }

    private /* synthetic */ zsa a(String a2) {
        adb a3;
        int n2 = 0;
        while (n2 < a3.h.length) {
            zsa zsa2 = a3.h[n2];
            if (zsa2.a().equals(a2)) {
                return zsa2;
            }
            ++n2;
        }
        return null;
    }

    @Override
    public String p() {
        return hic.a("of.shaders.profile");
    }

    @Override
    public String p(String a2) {
        return a2.equals(b) ? hic.a("of.general.custom", b) : \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a("profile." + a2, a2);
    }

    @Override
    public String a(String a2) {
        return a2.equals(b) ? "\u00a7c" : "\u00a7a";
    }

    @Override
    public String z() {
        adb a2;
        String string = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a("profile.comment", null);
        if (string != null) {
            return string;
        }
        StringBuffer stringBuffer = new StringBuffer();
        int n2 = 0;
        while (n2 < a2.h.length) {
            String string2;
            String string3 = a2.h[n2].a();
            if (string3 != null && (string2 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a("profile." + string3 + ".comment", null)) != null) {
                stringBuffer.append(string2);
                if (!string2.endsWith(". ")) {
                    stringBuffer.append(". ");
                }
            }
            ++n2;
        }
        return stringBuffer.toString();
    }

    private static /* synthetic */ String a(zsa[] a2, hya[] a3, boolean a4) {
        zsa zsa2 = \u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a(a2, a3, a4);
        return zsa2 == null ? b : zsa2.a();
    }

    private static /* synthetic */ String[] a(zsa[] a2) {
        ArrayList<String> arrayList = new ArrayList<String>();
        int n2 = 0;
        while (n2 < a2.length) {
            zsa zsa2 = a2[n2];
            arrayList.add(zsa2.a());
            ++n2;
        }
        arrayList.add(b);
        String[] stringArray = arrayList.toArray(new String[arrayList.size()]);
        return stringArray;
    }
}

