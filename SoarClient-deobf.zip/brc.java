/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class brc {
    private /* synthetic */ String l;
    private /* synthetic */ String b;
    private /* synthetic */ String c;
    private /* synthetic */ String v;
    private /* synthetic */ kk d;

    public brc(String a2, String a3, String a4) {
        brc a5;
        a5.l = a2;
        a5.b = a3;
        a5.c = a4;
        a5.v = "";
        a5.d = new kk();
    }

    public String y() {
        brc a2;
        return a2.l;
    }

    public String o() {
        brc a2;
        return a2.b;
    }

    public String p() {
        brc a2;
        return a2.c;
    }

    public void y(String a2) {
        a.l = a2;
    }

    public void o(String a2) {
        a.b = a2;
    }

    public void p(String a2) {
        a.c = a2;
    }

    public String a() {
        brc a2;
        return a2.v;
    }

    public void a(String a2) {
        a.v = a2;
    }

    public kk a() {
        brc a2;
        return a2.d;
    }
}

