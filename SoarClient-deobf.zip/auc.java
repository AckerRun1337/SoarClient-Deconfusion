/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class auc
implements Callable<String> {
    final /* synthetic */ oj d;

    auc(oj a2) {
        auc a3;
        a3.d = a2;
    }

    public String a() {
        auc a2;
        return a2.d.jb.kd ? "Yes" : "No";
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        auc a2;
        return a2.a();
    }
}

