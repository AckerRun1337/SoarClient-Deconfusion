/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.authlib.GameProfile
 */
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.UUID;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ao {
    private xga i;
    private final List<rsa> n;
    private tp e;
    private tp r;
    private int f;
    private int h;
    private int z;
    private int l;
    private int b;
    private TreeMap<String, Integer> c;
    private List<tob> v;
    private int d;

    public ao() {
        ao a2;
        a2.n = Lists.newArrayList();
        a2.e = tp.r;
        a2.r = tp.r;
        a2.c = new TreeMap();
        a2.v = Lists.newArrayList();
    }

    public ao(xga a2) {
        ao a3;
        a3.n = Lists.newArrayList();
        a3.e = tp.r;
        a3.r = tp.r;
        a3.c = new TreeMap();
        a3.v = Lists.newArrayList();
        a3.i = a2;
    }

    public void a(xga a2) {
        a.i = a2;
    }

    public void p(int a2) {
        tta tta2;
        int n2;
        ao a3;
        a3.z = a2;
        a3.o();
        a3.y();
        if (a2 % 20 == 0) {
            a3.z();
        }
        if (a2 % 30 == 0) {
            a3.j();
        }
        if (a3.d < (n2 = a3.l / 10) && a3.n.size() > 20 && a3.i.q.nextInt(7000) == 0 && (tta2 = a3.a(a3.r, 2, 4, 2)) != null) {
            fda fda2 = new fda(a3.i);
            fda2.z(tta2.c, tta2.v, tta2.d);
            a3.i.a(fda2);
            ++a3.d;
        }
    }

    private /* synthetic */ tta a(tp a2, int a3, int a4, int a5) {
        int n2 = 0;
        while (n2 < 10) {
            ao a6;
            tp tp2 = a2.a(a6.i.q.nextInt(16) - 8, a6.i.q.nextInt(6) - 3, a6.i.q.nextInt(16) - 8);
            if (a6.p(tp2) && a6.a(new tp(a3, a4, a5), tp2)) {
                return new tta(tp2.o(), tp2.p(), tp2.a());
            }
            ++n2;
        }
        return null;
    }

    private /* synthetic */ boolean a(tp a2, tp a3) {
        ao a4;
        if (!xga.a(a4.i, a3.z())) {
            return false;
        }
        int n2 = a3.o() - a2.o() / 2;
        int n3 = a3.a() - a2.a() / 2;
        int n4 = n2;
        while (n4 < n2 + a2.o()) {
            int n5 = a3.p();
            while (n5 < a3.p() + a2.p()) {
                int n6 = n3;
                while (n6 < n3 + a2.a()) {
                    if (a4.i.a(new tp(n4, n5, n6)).a().f()) {
                        return false;
                    }
                    ++n6;
                }
                ++n5;
            }
            ++n4;
        }
        return true;
    }

    private /* synthetic */ void j() {
        ao a2;
        List<fda> list = a2.i.a(fda.class, new tca(a2.r.o() - a2.f, a2.r.p() - 4, a2.r.a() - a2.f, a2.r.o() + a2.f, a2.r.p() + 4, a2.r.a() + a2.f));
        a2.d = list.size();
    }

    private /* synthetic */ void z() {
        ao a2;
        List<tfa> list = a2.i.a(tfa.class, new tca(a2.r.o() - a2.f, a2.r.p() - 4, a2.r.a() - a2.f, a2.r.o() + a2.f, a2.r.p() + 4, a2.r.a() + a2.f));
        a2.l = list.size();
        if (a2.l == 0) {
            a2.c.clear();
        }
    }

    public tp a() {
        ao a2;
        return a2.r;
    }

    public int y() {
        ao a2;
        return a2.f;
    }

    public int o() {
        ao a2;
        return a2.n.size();
    }

    public int p() {
        ao a2;
        return a2.z - a2.h;
    }

    public int a() {
        ao a2;
        return a2.l;
    }

    public boolean p(tp a2) {
        ao a3;
        return a3.r.a(a2) < (double)(a3.f * a3.f);
    }

    public List<rsa> a() {
        ao a2;
        return a2.n;
    }

    public rsa o(tp a2) {
        ao a3;
        rsa rsa2 = null;
        int n2 = Integer.MAX_VALUE;
        for (rsa rsa3 : a3.n) {
            int n3 = rsa3.p(a2);
            if (n3 >= n2) continue;
            rsa2 = rsa3;
            n2 = n3;
        }
        return rsa2;
    }

    public rsa p(tp a2) {
        ao a3;
        rsa rsa2 = null;
        int n2 = Integer.MAX_VALUE;
        for (rsa rsa3 : a3.n) {
            int n3 = rsa3.p(a2);
            n3 = n3 > 256 ? (n3 *= 1000) : rsa3.y();
            if (n3 >= n2) continue;
            rsa2 = rsa3;
            n2 = n3;
        }
        return rsa2;
    }

    public rsa a(tp a2) {
        ao a3;
        if (a3.r.a(a2) > (double)(a3.f * a3.f)) {
            return null;
        }
        for (rsa rsa2 : a3.n) {
            if (rsa2.p().o() != a2.o() || rsa2.p().a() != a2.a() || Math.abs(rsa2.p().p() - a2.p()) > 1) continue;
            return rsa2;
        }
        return null;
    }

    public void a(rsa a2) {
        ao a3;
        a3.n.add(a2);
        a3.e = a3.e.o(a2.p());
        a3.p();
        a3.h = a2.a();
    }

    public boolean p() {
        ao a2;
        return a2.n.isEmpty();
    }

    public void a(xi a2) {
        ao a3;
        for (tob tob2 : a3.v) {
            if (tob2.c != a2) continue;
            tob2.v = a3.z;
            return;
        }
        a3.v.add(new tob(a3, a2, a3.z));
    }

    public xi a(xi a2) {
        ao a3;
        double d2 = Double.MAX_VALUE;
        tob tob2 = null;
        int n2 = 0;
        while (n2 < a3.v.size()) {
            tob tob3 = a3.v.get(n2);
            double d3 = tob3.c.a((rj)a2);
            if (d3 <= d2) {
                tob2 = tob3;
                d2 = d3;
            }
            ++n2;
        }
        return tob2 != null ? tob2.c : null;
    }

    public pm a(xi a2) {
        ao a3;
        double d2 = Double.MAX_VALUE;
        pm pm2 = null;
        for (String string : a3.c.keySet()) {
            double d3;
            pm pm3;
            if (!a3.a(string) || (pm3 = a3.i.a(string)) == null || !((d3 = pm3.a((rj)a2)) <= d2)) continue;
            pm2 = pm3;
            d2 = d3;
        }
        return pm2;
    }

    private /* synthetic */ void y() {
        ao a2;
        Iterator<tob> iterator = a2.v.iterator();
        while (iterator.hasNext()) {
            tob tob2 = iterator.next();
            if (tob2.c.g() && Math.abs(a2.z - tob2.v) <= 300) continue;
            iterator.remove();
        }
    }

    private /* synthetic */ void o() {
        ao a2;
        boolean bl2 = false;
        boolean bl3 = a2.i.q.nextInt(50) == 0;
        Iterator<rsa> iterator = a2.n.iterator();
        while (iterator.hasNext()) {
            rsa rsa2 = iterator.next();
            if (bl3) {
                rsa2.p();
            }
            if (a2.a(rsa2.p()) && Math.abs(a2.z - rsa2.a()) <= 1200) continue;
            a2.e = a2.e.p(rsa2.p());
            bl2 = true;
            rsa2.a(true);
            iterator.remove();
        }
        if (bl2) {
            a2.p();
        }
    }

    private /* synthetic */ boolean a(tp a2) {
        ao a3;
        yd yd2 = a3.i.a(a2).a();
        return yd2 instanceof ccc ? yd2.a() == dr.na : false;
    }

    private /* synthetic */ void p() {
        ao a2;
        int n2 = a2.n.size();
        if (n2 == 0) {
            a2.r = new tp(0, 0, 0);
            a2.f = 0;
        } else {
            a2.r = new tp(a2.e.o() / n2, a2.e.p() / n2, a2.e.a() / n2);
            int n3 = 0;
            for (rsa rsa2 : a2.n) {
                n3 = Math.max(rsa2.p(a2.r), n3);
            }
            a2.f = Math.max(32, (int)Math.sqrt(n3) + 1);
        }
    }

    public int a(String a2) {
        ao a3;
        Integer n2 = a3.c.get(a2);
        return n2 != null ? n2 : 0;
    }

    public int a(String a2, int a3) {
        ao a4;
        int n2 = a4.a(a2);
        int n3 = smb.p(n2 + a3, -30, 10);
        a4.c.put(a2, n3);
        return n3;
    }

    public boolean a(String a2) {
        ao a3;
        return a3.a(a2) <= -15;
    }

    public void p(dgb a2) {
        ao a3;
        Object object;
        a3.l = a2.a("PopSize");
        a3.f = a2.a("Radius");
        a3.d = a2.a("Golems");
        a3.h = a2.a("Stable");
        a3.z = a2.a("Tick");
        a3.b = a2.a("MTick");
        a3.r = new tp(a2.a("CX"), a2.a("CY"), a2.a("CZ"));
        a3.e = new tp(a2.a("ACX"), a2.a("ACY"), a2.a("ACZ"));
        mxb mxb2 = a2.a("Doors", 10);
        int n2 = 0;
        while (n2 < mxb2.p()) {
            dgb dgb2 = mxb2.a(n2);
            object = new rsa(new tp(dgb2.a("X"), dgb2.a("Y"), dgb2.a("Z")), dgb2.a("IDX"), dgb2.a("IDZ"), dgb2.a("TS"));
            a3.n.add((rsa)object);
            ++n2;
        }
        mxb mxb3 = a2.a("Players", 10);
        int n3 = 0;
        while (n3 < mxb3.p()) {
            object = mxb3.a(n3);
            if (((dgb)object).p("UUID")) {
                sm sm2 = ccb.a().a();
                GameProfile gameProfile = sm2.a(UUID.fromString(((dgb)object).a("UUID")));
                if (gameProfile != null) {
                    a3.c.put(gameProfile.getName(), ((dgb)object).a("S"));
                }
            } else {
                a3.c.put(((dgb)object).a("Name"), ((dgb)object).a("S"));
            }
            ++n3;
        }
    }

    public void a(dgb a2) {
        ao a3;
        a2.a("PopSize", a3.l);
        a2.a("Radius", a3.f);
        a2.a("Golems", a3.d);
        a2.a("Stable", a3.h);
        a2.a("Tick", a3.z);
        a2.a("MTick", a3.b);
        a2.a("CX", a3.r.o());
        a2.a("CY", a3.r.p());
        a2.a("CZ", a3.r.a());
        a2.a("ACX", a3.e.o());
        a2.a("ACY", a3.e.p());
        a2.a("ACZ", a3.e.a());
        mxb mxb2 = new mxb();
        for (rsa rsa2 : a3.n) {
            dgb dgb2 = new dgb();
            dgb2.a("X", rsa2.p().o());
            dgb2.a("Y", rsa2.p().p());
            dgb2.a("Z", rsa2.p().a());
            dgb2.a("IDX", rsa2.o());
            dgb2.a("IDZ", rsa2.p());
            dgb2.a("TS", rsa2.a());
            mxb2.a(dgb2);
        }
        a2.a("Doors", mxb2);
        mxb mxb3 = new mxb();
        for (String string : a3.c.keySet()) {
            dgb dgb3 = new dgb();
            sm sm2 = ccb.a().a();
            GameProfile gameProfile = sm2.a(string);
            if (gameProfile == null) continue;
            dgb3.a("UUID", gameProfile.getId().toString());
            dgb3.a("S", a3.c.get(string));
            mxb3.a(dgb3);
        }
        a2.a("Players", mxb3);
    }

    public void a() {
        ao a2;
        a2.b = a2.z;
    }

    public boolean a() {
        ao a2;
        return a2.b == 0 || a2.z - a2.b >= 3600;
    }

    public void a(int a2) {
        ao a3;
        for (String string : a3.c.keySet()) {
            a3.a(string, a2);
        }
    }
}

