/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 *  com.google.common.collect.Lists
 */
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bgb {
    private static final ya e = new myc(null);
    private static final ya r = new jlc(-1, true);
    private static final ya f = new jlc(1, true);
    private static final ya h = new jlc(1, false);
    public static final ya z = new vid();
    private final vc l;
    private final List<cbb> b = Lists.newArrayList();
    private sa c = new yma();
    private int v = -1;
    private int d;

    public bgb(vc a2) {
        bgb a3;
        a3.l = a2;
    }

    public ya a(int a2) {
        bgb a3;
        int n2 = a2 + a3.d * 6;
        return a3.d > 0 && a2 == 0 ? r : (a2 == 7 ? (n2 < a3.c.a().size() ? f : h) : (a2 == 8 ? e : (n2 >= 0 && n2 < a3.c.a().size() ? (ya)Objects.firstNonNull((Object)a3.c.a().get(n2), (Object)z) : z)));
    }

    public List<ya> a() {
        ArrayList arrayList = Lists.newArrayList();
        int n2 = 0;
        while (n2 <= 8) {
            bgb a2;
            arrayList.add(a2.a(n2));
            ++n2;
        }
        return arrayList;
    }

    public ya a() {
        bgb a2;
        return a2.a(a2.v);
    }

    public sa a() {
        bgb a2;
        return a2.c;
    }

    public void a(int a2) {
        bgb a3;
        ya ya2 = a3.a(a2);
        if (ya2 != z) {
            if (a3.v == a2 && ya2.a()) {
                ya2.a(a3);
            } else {
                a3.v = a2;
            }
        }
    }

    public void a() {
        bgb a2;
        a2.l.a(a2);
    }

    public int a() {
        bgb a2;
        return a2.v;
    }

    public void a(sa a2) {
        bgb a3;
        a3.b.add(a3.a());
        a3.c = a2;
        a3.v = -1;
        a3.d = 0;
    }

    public cbb a() {
        bgb a2;
        return new cbb(a2.c, a2.a(), a2.v);
    }

    static /* synthetic */ void a(bgb a2, int a3) {
        a2.d = a3;
    }
}

