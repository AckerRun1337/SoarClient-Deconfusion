/*
 * Decompiled with CFR 0.152.
 */
class aj
extends ch {
    public int v;
    final /* synthetic */ nya d;

    public aj(nya a2) {
        aj a3;
        a3.d = a2;
        super(a2.w, nya.n, nya.e, 43, nya.e - 60, 24);
        a3.v = -1;
    }

    private /* synthetic */ void a(int a2, int a3, wfc a4) {
        aj a5;
        a5.y(a2 + 1, a3 + 1);
        ewa.r();
        if (a4 != null && a4.a() != null) {
            rcc.a();
            a5.d.i.p(a4, a2 + 2, a3 + 2);
            rcc.o();
        }
        ewa.q();
    }

    private /* synthetic */ void y(int a2, int a3) {
        aj a4;
        a4.y(a2, a3, 0, 0);
    }

    private /* synthetic */ void y(int a2, int a3, int a4, int a5) {
        aj a6;
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        a6.o.a().p(xf.c);
        float f2 = 0.0078125f;
        float f3 = 0.0078125f;
        int n2 = 18;
        int n3 = 18;
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        krb2.a(7, ybd.i);
        krb2.a((double)(a2 + 0), (double)(a3 + 18), (double)a6.d.d).a((float)(a4 + 0) * 0.0078125f, (float)(a5 + 18) * 0.0078125f).z();
        krb2.a((double)(a2 + 18), (double)(a3 + 18), (double)a6.d.d).a((float)(a4 + 18) * 0.0078125f, (float)(a5 + 18) * 0.0078125f).z();
        krb2.a((double)(a2 + 18), (double)(a3 + 0), (double)a6.d.d).a((float)(a4 + 18) * 0.0078125f, (float)(a5 + 0) * 0.0078125f).z();
        krb2.a((double)(a2 + 0), (double)(a3 + 0), (double)a6.d.d).a((float)(a4 + 0) * 0.0078125f, (float)(a5 + 0) * 0.0078125f).z();
        xlb2.a();
    }

    @Override
    protected int x() {
        aj a2;
        return nya.a(a2.d).a().size();
    }

    @Override
    protected void a(int a2, boolean a3, int a4, int a5) {
        aj a6;
        a6.v = a2;
        a6.d.a();
    }

    @Override
    protected boolean p(int a2) {
        aj a3;
        return a2 == a3.v;
    }

    @Override
    protected void o() {
    }

    @Override
    protected void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        String string;
        aj a8;
        bcc bcc2 = nya.a(a8.d).a().get(nya.a(a8.d).a().size() - a2 - 1);
        ba ba2 = bcc2.a();
        yd yd2 = ba2.a();
        ge ge2 = ge.a(yd2);
        wfc wfc2 = yd2 != cl.cd && ge2 != null ? new wfc(ge2, 1, yd2.o(ba2)) : null;
        String string2 = string = wfc2 == null ? "Air" : ge2.a(wfc2);
        if (ge2 == null) {
            if (yd2 != cl.nl && yd2 != cl.ek) {
                if (yd2 == cl.vi || yd2 == cl.ff) {
                    ge2 = sxa.kn;
                }
            } else {
                ge2 = sxa.mn;
            }
            if (ge2 != null) {
                wfc2 = new wfc(ge2, 1, yd2.o(ba2));
                string = yd2.p();
            }
        }
        a8.a(a3, a4, wfc2);
        ((gic)((Object)a8.d.z)).a(string, a3 + 18 + 5, a4 + 3, 0xFFFFFF);
        String string3 = a2 == 0 ? xab.a("createWorld.customize.flat.layer.top", bcc2.o()) : (a2 == nya.a(a8.d).a().size() - 1 ? xab.a("createWorld.customize.flat.layer.bottom", bcc2.o()) : xab.a("createWorld.customize.flat.layer", bcc2.o()));
        ((gic)((Object)a8.d.z)).a(string3, a3 + 2 + 213 - ((gic)((Object)a8.d.z)).a(string3), a4 + 3, 0xFFFFFF);
    }

    @Override
    protected int p() {
        aj a2;
        return a2.m - 70;
    }
}

