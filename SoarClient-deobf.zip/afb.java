/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class afb
extends mi {
    private rva v;
    private int d;

    public afb(rva a2) {
        afb a3;
        a3.v = a2;
        a3.a(2);
    }

    @Override
    public boolean o() {
        afb a2;
        xi xi2 = a2.v.y();
        return xi2 == null ? false : (!xi2.g() ? false : !(xi2 instanceof pm) || !((pm)xi2).y.h);
    }

    @Override
    public void o() {
        afb a2;
        a2.d = 300;
        super.o();
    }

    @Override
    public boolean p() {
        afb a2;
        xi xi2 = a2.v.y();
        return xi2 == null ? false : (!xi2.g() ? false : (xi2 instanceof pm && ((pm)xi2).y.h ? false : --a2.d > 0));
    }

    @Override
    public void a() {
        afb a2;
        a2.v.a(a2.v.y(), 10.0f, 10.0f);
        ((mzc)a2.v.a()).a(a2.v.nb, a2.v.aa());
    }
}

