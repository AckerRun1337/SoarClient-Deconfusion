/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface cb {
    public kv a(tp var1);

    public int a(tp var1, int var2);

    public ba a(tp var1);

    public boolean a(tp var1);

    public nk a(tp var1);

    public boolean a();

    public int a(tp var1, hnd var2);

    public rkb a();
}

