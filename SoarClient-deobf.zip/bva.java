/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class bva
implements Callable<String> {
    final /* synthetic */ pi v;
    private final /* synthetic */ int d;

    bva(pi a2, int a3) {
        bva a4;
        a4.v = a2;
        a4.d = a3;
    }

    public String a() throws Exception {
        bva a2;
        return a2.d == 0 ? "MISC_TEXTURE" : (a2.d == 1 ? "TERRAIN_TEXTURE" : (a2.d == 3 ? "ENTITY_PARTICLE_TEXTURE" : "Unknown - " + a2.d));
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        bva a2;
        return a2.a();
    }
}

