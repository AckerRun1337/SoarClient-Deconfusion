/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cx
extends yd {
    public static final ewc b = ewc.a("north");
    public static final ewc c = ewc.a("east");
    public static final ewc v = ewc.a("south");
    public static final ewc d = ewc.a("west");

    public cx(dr a2) {
        a3(a2, a2.a());
        cx a3;
    }

    public cx(dr a2, rpb a3) {
        super(a2, a3);
        cx a4;
        a4.a(((lf)((Object)a4.c)).a().a(b, false).a(c, false).a(v, false).a(d, false));
        a4.a(md.k);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, tca a5, List<tca> a6, rj a7) {
        float f2;
        cx a8;
        boolean bl2 = a8.p((cb)a2, a3.y());
        boolean bl3 = a8.p((cb)a2, a3.o());
        boolean bl4 = a8.p((cb)a2, a3.p());
        boolean bl5 = a8.p((cb)a2, a3.a());
        float f3 = 0.375f;
        float f4 = 0.625f;
        float f5 = bl2 ? 0.0f : 0.375f;
        float f6 = f2 = bl3 ? 1.0f : 0.625f;
        if (bl2 || bl3) {
            a8.a(f3, 0.0f, f5, f4, 1.5f, f2);
            super.a(a2, a3, a4, a5, a6, a7);
        }
        f5 = 0.375f;
        f2 = 0.625f;
        if (bl4) {
            f3 = 0.0f;
        }
        if (bl5) {
            f4 = 1.0f;
        }
        if (bl4 || bl5 || !bl2 && !bl3) {
            a8.a(f3, 0.0f, f5, f4, 1.5f, f2);
            super.a(a2, a3, a4, a5, a6, a7);
        }
        if (bl2) {
            f5 = 0.0f;
        }
        if (bl3) {
            f2 = 1.0f;
        }
        a8.a(f3, 0.0f, f5, f4, 1.0f, f2);
    }

    @Override
    public void a(cb a2, tp a3) {
        cx a4;
        boolean bl2 = a4.p(a2, a3.y());
        boolean bl3 = a4.p(a2, a3.o());
        boolean bl4 = a4.p(a2, a3.p());
        boolean bl5 = a4.p(a2, a3.a());
        float f2 = bl4 ? 0.0f : 0.375f;
        float f3 = bl5 ? 1.0f : 0.625f;
        float f4 = bl2 ? 0.0f : 0.375f;
        float f5 = bl3 ? 1.0f : 0.625f;
        a4.a(f2, 0.0f, f4, f3, 1.0f, f5);
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean a(cb a2, tp a3) {
        return false;
    }

    public boolean p(cb a2, tp a3) {
        cx a4;
        yd yd2 = a2.a(a3).a();
        return yd2 == cl.a ? false : (!(yd2 instanceof cx && yd2.z == a4.z || yd2 instanceof zpc) ? (yd2.z.p() && yd2.r() ? yd2.z != dr.s : false) : true);
    }

    @Override
    public boolean p(cb a2, tp a3, hnd a4) {
        return true;
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, pm a5, hnd a6, float a7, float a8, float a9) {
        return a2.f ? true : bg.a(a5, a2, a3);
    }

    @Override
    public int o(ba a2) {
        return 0;
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        cx a5;
        return a2.a(b, a5.p(a3, a4.y())).a(c, a5.p(a3, a4.a())).a(v, a5.p(a3, a4.o())).a(d, a5.p(a3, a4.p()));
    }

    @Override
    protected lf p() {
        cx a2;
        return new lf(a2, b, c, d, v);
    }
}

