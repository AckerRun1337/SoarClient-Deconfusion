/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum cfd implements s
{
    i(0, "oak", rpb.j),
    n(1, "spruce", rpb.b),
    e(2, "birch", rpb.ya),
    r(3, "jungle", rpb.ba),
    f(4, "acacia", rpb.m),
    h(5, "dark_oak", "big_oak", rpb.i);

    private static final cfd[] z;
    private final int l;
    private final String b;
    private final String c;
    private final rpb v;

    static {
        z = new cfd[cfd.values().length];
        cfd[] cfdArray = cfd.values();
        int n2 = cfdArray.length;
        int n3 = 0;
        while (n3 < n2) {
            cfd cfd2;
            cfd.z[cfd2.a()] = cfd2 = cfdArray[n3];
            ++n3;
        }
    }

    private /* synthetic */ cfd(String a2, int a3, int a4, String a5, rpb a6) {
        a7(a2, a3, a4, a5, a5, a6);
        cfd a7;
    }

    private /* synthetic */ cfd(String a2, int a3, int a4, String a5, String a6, rpb a7) {
        cfd a8;
        a8.l = a4;
        a8.b = a5;
        a8.c = a6;
        a8.v = a7;
    }

    public int a() {
        cfd a2;
        return a2.l;
    }

    public rpb a() {
        cfd a2;
        return a2.v;
    }

    public String toString() {
        cfd a2;
        return a2.b;
    }

    public static cfd a(int a2) {
        if (a2 < 0 || a2 >= z.length) {
            a2 = 0;
        }
        return z[a2];
    }

    @Override
    public String zpa() {
        cfd a2;
        return a2.b;
    }

    public String a() {
        cfd a2;
        return a2.c;
    }
}

