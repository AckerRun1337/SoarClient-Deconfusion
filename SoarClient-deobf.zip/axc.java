/*
 * Decompiled with CFR 0.152.
 */
public enum axc {
    l,
    b,
    c,
    v;


    private /* synthetic */ axc(String a2, int a3) {
        axc a4;
    }
}

