/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.util.UUIDTypeAdapter
 */
import com.mojang.authlib.GameProfile;
import com.mojang.util.UUIDTypeAdapter;
import java.util.UUID;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dba {
    private final String b;
    private final String c;
    private final String v;
    private final upa d;

    public dba(String a2, String a3, String a4, String a5) {
        dba a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = upa.a(a5);
    }

    public String y() {
        dba a2;
        return "token:" + a2.v + ":" + a2.c;
    }

    public String o() {
        dba a2;
        return a2.c;
    }

    public String p() {
        dba a2;
        return a2.b;
    }

    public String a() {
        dba a2;
        return a2.v;
    }

    public GameProfile a() {
        dba a2;
        try {
            UUID uUID = UUIDTypeAdapter.fromString((String)a2.o());
            return new GameProfile(uUID, a2.p());
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return new GameProfile(null, a2.p());
        }
    }

    public upa a() {
        dba a2;
        return a2.d;
    }
}

