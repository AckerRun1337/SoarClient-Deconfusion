/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.optifine.util.\u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94;

public class dbd
extends src {
    public dbd() {
        dbd a2;
    }

    @Override
    public String[] a(ff a2, int a3) {
        dbd a4;
        if (!(a2 instanceof zxa)) {
            return null;
        }
        zxa zxa2 = (zxa)a2;
        hya hya2 = zxa2.a();
        String[] stringArray = a4.a(hya2, a3);
        return stringArray;
    }

    private /* synthetic */ String[] a(hya a2, int a3) {
        Object object;
        dbd a4;
        String string = a2.p();
        String string2 = xfc.p(a2.z()).trim();
        String[] stringArray = a4.p(string2);
        tib tib2 = xfc.a();
        String string3 = null;
        if (!string.equals(a2.x()) && tib2.ui) {
            string3 = "\u00a78" + hic.a("of.general.id") + ": " + a2.x();
        }
        String string4 = null;
        if (a2.p() != null && tib2.ui) {
            string4 = "\u00a78" + hic.a("of.general.from") + ": " + xfc.a(a2.p());
        }
        String string5 = null;
        if (a2.o() != null && tib2.ui) {
            object = a2.y() ? a2.p(a2.o()) : hic.a("of.general.ambiguous");
            string5 = "\u00a78" + hic.a() + ": " + (String)object;
        }
        object = new ArrayList<String>();
        object.add(string);
        object.addAll(Arrays.asList(stringArray));
        if (string3 != null) {
            object.add(string3);
        }
        if (string4 != null) {
            object.add(string4);
        }
        if (string5 != null) {
            object.add(string5);
        }
        String[] stringArray2 = a4.a(a3, (List<String>)object);
        return stringArray2;
    }

    private /* synthetic */ String[] p(String a2) {
        if (a2.length() <= 0) {
            return new String[0];
        }
        a2 = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.x(a2, "//");
        String[] stringArray = a2.split("\\. ");
        int n2 = 0;
        while (n2 < stringArray.length) {
            stringArray[n2] = "- " + stringArray[n2].trim();
            stringArray[n2] = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.j(stringArray[n2], ".");
            ++n2;
        }
        return stringArray;
    }

    private /* synthetic */ String[] a(int a2, List<String> a3) {
        gic gic2 = xfc.a().vb;
        ArrayList<String> arrayList = new ArrayList<String>();
        int n2 = 0;
        while (n2 < a3.size()) {
            String string = a3.get(n2);
            if (string != null && string.length() > 0) {
                for (String string2 : gic2.a(string, a2)) {
                    arrayList.add(string2);
                }
            }
            ++n2;
        }
        String[] stringArray = arrayList.toArray(new String[arrayList.size()]);
        return stringArray;
    }
}

