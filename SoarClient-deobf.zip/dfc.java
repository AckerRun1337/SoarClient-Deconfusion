/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class dfc
extends bh {
    public dfc() {
        super("ReachCircles", 0, gk.b);
        dfc a2;
    }

    @Override
    public void y() {
        dfc a2;
        gsc.t.w.a(new egd("AccentColor", a2, true));
        gsc.t.w.a(new egd("Width", a2, 1.0, 1.0, 10.0, true));
    }

    @fo
    public void a(fx a2) {
        dfc a3;
        GL11.y();
        a3.g.bb.h();
        GL11.f(3553);
        GL11.c(3042);
        GL11.f(770, 771);
        GL11.f(2929);
        GL11.c(2848);
        GL11.a(false);
        for (Object e2 : a3.g.ab.ka) {
            rj rj2 = (rj)e2;
            if (!(rj2 instanceof xi) || rj2.l() || rj2.c() || rj2 == a3.g.ob || !((xi)rj2).o((rj)a3.g.ob) || rj2.l() || !(rj2 instanceof pm)) continue;
            double d2 = rj2.ya + (rj2.fb - rj2.ya) * (double)a2.d - a3.g.a().h;
            double d3 = rj2.ca + (rj2.zb - rj2.ca) * (double)a2.d - a3.g.a().z;
            double d4 = rj2.ga + (rj2.db - rj2.ga) * (double)a2.d - a3.g.a().l;
            a3.a(d2, d3, d4, a3.g.lc.z() ? 4.7 : 3.4);
        }
        GL11.a(true);
        GL11.f(2848);
        GL11.c(2929);
        GL11.f(3042);
        GL11.c(3553);
        a3.g.bb.x();
        GL11.o();
    }

    private /* synthetic */ void a(double a2, double a3, double a4, double a5) {
        dfc a6;
        GL11.y();
        double d2 = Math.PI * 2;
        double d3 = 45.0;
        Color color = gsc.t.w.a(a6, "AccentColor").z() ? trc.a(0) : new Color(255, 255, 255);
        GL11.y((float)gsc.t.w.a(a6, "Width").o());
        trc.a(color.getRGB());
        GL11.s(1);
        int n2 = 0;
        while (n2 <= 90) {
            trc.a(color.getRGB(), 40.0f);
            GL11.o(a2 + a5 * Math.cos((double)n2 * (Math.PI * 2) / 45.0), a3, a4 + a5 * Math.sin((double)n2 * (Math.PI * 2) / 45.0));
            ++n2;
        }
        GL11.q();
        GL11.o();
    }
}

