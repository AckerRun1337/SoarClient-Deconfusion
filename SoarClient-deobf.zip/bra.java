/*
 * Decompiled with CFR 0.152.
 */
public class bra
extends cla {
    private final ge d;

    public bra(String a2, String a3, ga a4, ge a5) {
        super(String.valueOf(a2) + a3, a4);
        bra a6;
        a6.d = a5;
        int n2 = ge.a(a5);
        if (n2 != 0) {
            q.r.put(String.valueOf(a2) + n2, a6.a());
        }
    }

    public ge a() {
        bra a2;
        return a2.d;
    }
}

