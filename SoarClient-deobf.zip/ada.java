/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringEscapeUtils
 */
import java.util.Arrays;
import java.util.regex.Pattern;
import net.optifine.util.\u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94;
import org.apache.commons.lang3.StringEscapeUtils;

public class ada {
    private String[] g = null;
    private String k = null;
    private boolean x = false;
    private int t = 0;
    private String p = null;
    private int s = 0;
    private static final int w = 0;
    private static final int i = 1;
    private static final int n = 2;
    private static final int e = 3;
    private static final int r = 4;
    private static final String f = "pattern:";
    private static final String h = "ipattern:";
    private static final String z = "regex:";
    private static final String l = "iregex:";
    private static final int b = 0;
    private static final int c = 1;
    private static final String v = "#";
    private static final Pattern d = Pattern.compile("^#[0-9a-f]{6}+$");

    public ada(String a2, String a3) {
        ada a4;
        String[] stringArray = xfc.a(a2, ".");
        a4.g = Arrays.copyOfRange(stringArray, 0, stringArray.length - 1);
        a4.k = stringArray[stringArray.length - 1];
        if (a3.startsWith("!")) {
            a4.x = true;
            a3 = a3.substring(1);
        }
        if (a3.startsWith(f)) {
            a4.t = 1;
            a3 = a3.substring(f.length());
        } else if (a3.startsWith(h)) {
            a4.t = 2;
            a3 = a3.substring(h.length()).toLowerCase();
        } else if (a3.startsWith(z)) {
            a4.t = 3;
            a3 = a3.substring(z.length());
        } else if (a3.startsWith(l)) {
            a4.t = 4;
            a3 = a3.substring(l.length()).toLowerCase();
        } else {
            a4.t = 0;
        }
        a3 = StringEscapeUtils.unescapeJava((String)a3);
        if (a4.t == 0 && d.matcher(a3).matches()) {
            a4.s = 1;
        }
        a4.p = a3;
    }

    public boolean p(dgb a2) {
        ada a3;
        return a3.x ? !a3.a(a2) : a3.a(a2);
    }

    public boolean a(dgb a2) {
        ada a3;
        if (a2 == null) {
            return false;
        }
        ml ml2 = a2;
        int n2 = 0;
        while (n2 < a3.g.length) {
            String string = a3.g[n2];
            if ((ml2 = ada.a(ml2, string)) == null) {
                return false;
            }
            ++n2;
        }
        if (a3.k.equals("*")) {
            return a3.p(ml2);
        }
        if ((ml2 = ada.a(ml2, a3.k)) == null) {
            return false;
        }
        return a3.a(ml2);
    }

    private /* synthetic */ boolean p(ml a2) {
        block4: {
            ada a3;
            block3: {
                if (!(a2 instanceof dgb)) break block3;
                dgb dgb2 = (dgb)a2;
                for (String string : dgb2.a()) {
                    ml ml2 = dgb2.a(string);
                    if (!a3.a(ml2)) continue;
                    return true;
                }
                break block4;
            }
            if (!(a2 instanceof mxb)) break block4;
            mxb mxb2 = (mxb)a2;
            int n2 = mxb2.p();
            int n3 = 0;
            while (n3 < n2) {
                if (a3.a(mxb2.a(n3))) {
                    return true;
                }
                ++n3;
            }
        }
        return false;
    }

    private static /* synthetic */ ml a(ml a2, String a3) {
        if (a2 instanceof dgb) {
            dgb dgb2 = (dgb)a2;
            return dgb2.a(a3);
        }
        if (a2 instanceof mxb) {
            mxb mxb2 = (mxb)a2;
            if (a3.equals("count")) {
                return new enc(mxb2.p());
            }
            int n2 = xfc.a(a3, -1);
            return n2 >= 0 && n2 < mxb2.p() ? mxb2.a(n2) : null;
        }
        return null;
    }

    public boolean a(ml a2) {
        ada a3;
        if (a2 == null) {
            return false;
        }
        String string = ada.a(a2, a3.s);
        return a3.a(string);
    }

    public boolean a(String a2) {
        ada a3;
        if (a2 == null) {
            return false;
        }
        switch (a3.t) {
            case 0: {
                return a2.equals(a3.p);
            }
            case 1: {
                return a3.p(a2, a3.p);
            }
            case 2: {
                return a3.p(a2.toLowerCase(), a3.p);
            }
            case 3: {
                return a3.a(a2, a3.p);
            }
            case 4: {
                return a3.a(a2.toLowerCase(), a3.p);
            }
        }
        throw new IllegalArgumentException("Unknown NbtTagValue type: " + a3.t);
    }

    private /* synthetic */ boolean p(String a2, String a3) {
        return \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.a(a2, a3, '*', '?');
    }

    private /* synthetic */ boolean a(String a2, String a3) {
        return a2.matches(a3);
    }

    private static /* synthetic */ String a(ml a2, int a3) {
        if (a2 == null) {
            return null;
        }
        if (a2 instanceof ep) {
            ep ep2 = (ep)a2;
            return ep2.a();
        }
        if (a2 instanceof enc) {
            enc enc2 = (enc)a2;
            return a3 == 1 ? v + \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.p(Integer.toHexString(enc2.a()), 6, '0') : Integer.toString(enc2.a());
        }
        if (a2 instanceof jcb) {
            jcb jcb2 = (jcb)a2;
            return Byte.toString(jcb2.p());
        }
        if (a2 instanceof txb) {
            txb txb2 = (txb)a2;
            return Short.toString(txb2.a());
        }
        if (a2 instanceof tra) {
            tra tra2 = (tra)a2;
            return Long.toString(tra2.a());
        }
        if (a2 instanceof idb) {
            idb idb2 = (idb)a2;
            return Float.toString(idb2.a());
        }
        if (a2 instanceof qp) {
            qp qp2 = (qp)a2;
            return Double.toString(qp2.a());
        }
        return a2.toString();
    }

    public String toString() {
        ada a2;
        StringBuffer stringBuffer = new StringBuffer();
        int n2 = 0;
        while (n2 < a2.g.length) {
            String string = a2.g[n2];
            if (n2 > 0) {
                stringBuffer.append(".");
            }
            stringBuffer.append(string);
            ++n2;
        }
        if (stringBuffer.length() > 0) {
            stringBuffer.append(".");
        }
        stringBuffer.append(a2.k);
        stringBuffer.append(" = ");
        stringBuffer.append(a2.p);
        return stringBuffer.toString();
    }
}

