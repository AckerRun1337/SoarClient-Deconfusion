/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

public class cad
extends ji {
    private int d;

    public cad() {
        cad a2;
    }

    public cad(int a2, Random a3, uxc a4, hnd a5) {
        super(a2);
        cad a6;
        a6.c = a5;
        a6.b = a4;
        a6.d = a3.nextInt();
    }

    public static cad a(List<ae> a2, Random a3, int a4, int a5, int a6, hnd a7, int a8) {
        uxc uxc2 = uxc.a(a4, a5, a6, -1, -3, 0, 5, 10, 8, a7);
        return cad.a(uxc2) && ae.a(a2, uxc2) == null ? new cad(a8, a3, uxc2, a7) : null;
    }

    @Override
    protected void a(dgb a2) {
        cad a3;
        super.a(a2);
        a3.d = a2.a("Seed");
    }

    @Override
    protected void p(dgb a2) {
        cad a3;
        super.p(a2);
        a2.a("Seed", a3.d);
    }

    @Override
    public boolean a(xga a2, Random a3, uxc a4) {
        int n2;
        int n3;
        cad a5;
        Random random = new Random(a5.d);
        int n4 = 0;
        while (n4 <= 4) {
            n3 = 3;
            while (n3 <= 4) {
                n2 = random.nextInt(8);
                a5.a(a2, a4, n4, n3, 0, n4, n3, n2, cl.pb.a(), cl.pb.a(), false);
                ++n3;
            }
            ++n4;
        }
        n4 = random.nextInt(8);
        a5.a(a2, a4, 0, 5, 0, 0, 5, n4, cl.pb.a(), cl.pb.a(), false);
        n4 = random.nextInt(8);
        a5.a(a2, a4, 4, 5, 0, 4, 5, n4, cl.pb.a(), cl.pb.a(), false);
        n4 = 0;
        while (n4 <= 4) {
            n3 = random.nextInt(5);
            a5.a(a2, a4, n4, 2, 0, n4, 2, n3, cl.pb.a(), cl.pb.a(), false);
            ++n4;
        }
        n4 = 0;
        while (n4 <= 4) {
            n3 = 0;
            while (n3 <= 1) {
                n2 = random.nextInt(3);
                a5.a(a2, a4, n4, n3, 0, n4, n3, n2, cl.pb.a(), cl.pb.a(), false);
                ++n3;
            }
            ++n4;
        }
        return true;
    }
}

