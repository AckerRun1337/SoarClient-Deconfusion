/*
 * Decompiled with CFR 0.152.
 */
import java.awt.image.BufferedImage;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class akc
extends bqc {
    private fca c;
    private wmc v;
    private boolean d;

    public akc(fca a2, wmc a3) {
        akc a4;
        a4.c = a2;
        a4.v = a3;
    }

    @Override
    public BufferedImage a(BufferedImage a2) {
        BufferedImage bufferedImage = ssa.a(a2);
        a.d = ssa.a(a2, bufferedImage);
        return bufferedImage;
    }

    @Override
    public void a() {
        akc a2;
        if (a2.c != null) {
            a2.c.a(a2.v);
            a2.c.d(a2.d);
        }
        a2.p();
    }

    public void p() {
        a.c = null;
    }

    public boolean a() {
        akc a2;
        return a2.d;
    }
}

