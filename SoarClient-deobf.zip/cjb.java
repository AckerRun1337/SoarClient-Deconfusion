/*
 * Decompiled with CFR 0.152.
 */
class cjb
implements yc {
    cjb() {
        cjb a2;
    }

    @Override
    public String a(int a2) {
        return cla.a().format((double)a2 * 0.1);
    }
}

