/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public interface d {
    public void a(gba var1, List<wfc> var2);

    public void a(gba var1, int var2, wfc var3);

    public void a(gba var1, int var2, int var3);

    public void a(gba var1, zb var2);
}

