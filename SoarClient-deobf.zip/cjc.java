/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cjc {
    public static final /* synthetic */ cjc z;
    private static final /* synthetic */ wmc l;
    private static final /* synthetic */ Logger b;
    private /* synthetic */ oj c;
    private /* synthetic */ zab v;
    private /* synthetic */ float d;

    static {
        z = new cjc();
        l = new wmc("minecraft:shaders/post/motion_blur.json");
        b = LogManager.getLogger();
    }

    public cjc() {
        cjc a2;
        a2.c = oj.a();
    }

    public float a() {
        return (float)gsc.t.w.a(gsc.t.n.a("MotionBlur"), "Amount").o();
    }

    public zab a() {
        cjc a3;
        if (a3.v == null) {
            a3.d = Float.NaN;
            try {
                a3.v = new zab(a3.c.a(), a3.c.a(), a3.c.a(), l);
                a3.v.a(a3.c.wc, a3.c.pc);
            }
            catch (JsonSyntaxException | IOException exception) {
                b.error("Could not load motion blur shader", (Throwable)exception);
                return null;
            }
        }
        if (a3.d != a3.a()) {
            a3.v.a().forEach(a2 -> {
                jva jva2 = a2.a().p("BlurFactor");
                if (jva2 != null) {
                    cjc a3;
                    jva2.a(a3.a());
                }
            });
            a3.d = a3.a();
        }
        return a3.v;
    }
}

