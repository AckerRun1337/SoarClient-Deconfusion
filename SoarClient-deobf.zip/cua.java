/*
 * Decompiled with CFR 0.152.
 */
class cua {
    public mi c;
    public int v;
    final /* synthetic */ gna d;

    public cua(gna a2, int a3, mi a4) {
        cua a5;
        a5.d = a2;
        a5.v = a3;
        a5.c = a4;
    }
}

