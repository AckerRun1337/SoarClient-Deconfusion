/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public class cxb
extends qec {
    public static final kcb<eha> d = kcb.a("variant", eha.class);

    public cxb() {
        cxb a2;
        a2.a(a2.c.a().a(d, eha.f));
    }

    @Override
    public int p(ba a2) {
        return a2.a(d).a();
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        eha[] ehaArray = eha.values();
        int n2 = ehaArray.length;
        int n3 = 0;
        while (n3 < n2) {
            eha eha2 = ehaArray[n3];
            a4.add(new wfc(a2, 1, eha2.a()));
            ++n3;
        }
    }

    @Override
    public rpb a(ba a2) {
        return a2.a(d).a();
    }

    @Override
    public ba a(int a2) {
        cxb a3;
        return a3.a().a(d, eha.a(a2));
    }

    @Override
    public int o(ba a2) {
        return a2.a(d).a();
    }

    @Override
    protected lf p() {
        cxb a2;
        return new lf(a2, d);
    }
}

