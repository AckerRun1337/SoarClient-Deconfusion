/*
 * Decompiled with CFR 0.152.
 */
public class bda
extends cla {
    public bda(String a2, ga a3, yc a4) {
        super(a2, a3, a4);
        bda a5;
    }

    public bda(String a2, ga a3) {
        super(a2, a3);
        bda a4;
    }

    @Override
    public cla a() {
        bda a2;
        super.a();
        hca.rb.add(a2);
        return a2;
    }
}

