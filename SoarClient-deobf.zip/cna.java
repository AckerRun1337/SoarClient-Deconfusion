/*
 * Decompiled with CFR 0.152.
 */
public class cna
extends qm {
    private sfc na;
    private sfc ka;
    private sfc ha;
    private sfc ya;
    private sfc ca;
    private sfc ga;
    private sfc ja;
    private sfc ia;
    private sfc ta;
    private sfc oa;
    private sfc pa;
    private sfc ba;
    private sfc la;
    private sfc u;
    private sfc j;
    private sfc o;
    private sfc m;
    private sfc y;
    private sfc a;
    private sfc q;
    private sfc g;
    private sfc k;
    private sfc x;
    private sfc t;
    private sfc p;
    private sfc s;
    private sfc w;
    private sfc i;
    private sfc n;
    private sfc e;
    private sfc r;
    private sfc f;
    private sfc h;
    private sfc z;
    private sfc l;
    private sfc b;
    private sfc c;
    private sfc v = (sfc)128;
    private sfc d = (sfc)128;

    public cna() {
        cna a2;
        a2.pa = new sfc(a2, 0, 34);
        a2.pa.a(-5.0f, -8.0f, -19.0f, 10, 10, 24);
        a2.pa.a(0.0f, 11.0f, 9.0f);
        a2.ba = new sfc(a2, 44, 0);
        a2.ba.a(-1.0f, -1.0f, 0.0f, 2, 2, 3);
        a2.ba.a(0.0f, 3.0f, 14.0f);
        a2.a(a2.ba, -1.134464f, 0.0f, 0.0f);
        a2.la = new sfc(a2, 38, 7);
        a2.la.a(-1.5f, -2.0f, 3.0f, 3, 4, 7);
        a2.la.a(0.0f, 3.0f, 14.0f);
        a2.a(a2.la, -1.134464f, 0.0f, 0.0f);
        a2.u = new sfc(a2, 24, 3);
        a2.u.a(-1.5f, -4.5f, 9.0f, 3, 4, 7);
        a2.u.a(0.0f, 3.0f, 14.0f);
        a2.a(a2.u, -1.40215f, 0.0f, 0.0f);
        a2.j = new sfc(a2, 78, 29);
        a2.j.a(-2.5f, -2.0f, -2.5f, 4, 9, 5);
        a2.j.a(4.0f, 9.0f, 11.0f);
        a2.o = new sfc(a2, 78, 43);
        a2.o.a(-2.0f, 0.0f, -1.5f, 3, 5, 3);
        a2.o.a(4.0f, 16.0f, 11.0f);
        a2.m = new sfc(a2, 78, 51);
        a2.m.a(-2.5f, 5.1f, -2.0f, 4, 3, 4);
        a2.m.a(4.0f, 16.0f, 11.0f);
        a2.y = new sfc(a2, 96, 29);
        a2.y.a(-1.5f, -2.0f, -2.5f, 4, 9, 5);
        a2.y.a(-4.0f, 9.0f, 11.0f);
        a2.a = new sfc(a2, 96, 43);
        a2.a.a(-1.0f, 0.0f, -1.5f, 3, 5, 3);
        a2.a.a(-4.0f, 16.0f, 11.0f);
        a2.q = new sfc(a2, 96, 51);
        a2.q.a(-1.5f, 5.1f, -2.0f, 4, 3, 4);
        a2.q.a(-4.0f, 16.0f, 11.0f);
        a2.g = new sfc(a2, 44, 29);
        a2.g.a(-1.9f, -1.0f, -2.1f, 3, 8, 4);
        a2.g.a(4.0f, 9.0f, -8.0f);
        a2.k = new sfc(a2, 44, 41);
        a2.k.a(-1.9f, 0.0f, -1.6f, 3, 5, 3);
        a2.k.a(4.0f, 16.0f, -8.0f);
        a2.x = new sfc(a2, 44, 51);
        a2.x.a(-2.4f, 5.1f, -2.1f, 4, 3, 4);
        a2.x.a(4.0f, 16.0f, -8.0f);
        a2.t = new sfc(a2, 60, 29);
        a2.t.a(-1.1f, -1.0f, -2.1f, 3, 8, 4);
        a2.t.a(-4.0f, 9.0f, -8.0f);
        a2.p = new sfc(a2, 60, 41);
        a2.p.a(-1.1f, 0.0f, -1.6f, 3, 5, 3);
        a2.p.a(-4.0f, 16.0f, -8.0f);
        a2.s = new sfc(a2, 60, 51);
        a2.s.a(-1.6f, 5.1f, -2.1f, 4, 3, 4);
        a2.s.a(-4.0f, 16.0f, -8.0f);
        a2.na = new sfc(a2, 0, 0);
        a2.na.a(-2.5f, -10.0f, -1.5f, 5, 5, 7);
        a2.na.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.na, 0.5235988f, 0.0f, 0.0f);
        a2.ka = new sfc(a2, 24, 18);
        a2.ka.a(-2.0f, -10.0f, -7.0f, 4, 3, 6);
        a2.ka.a(0.0f, 3.95f, -10.0f);
        a2.a(a2.ka, 0.5235988f, 0.0f, 0.0f);
        a2.ha = new sfc(a2, 24, 27);
        a2.ha.a(-2.0f, -7.0f, -6.5f, 4, 2, 5);
        a2.ha.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ha, 0.5235988f, 0.0f, 0.0f);
        a2.na.a(a2.ka);
        a2.na.a(a2.ha);
        a2.ya = new sfc(a2, 0, 0);
        a2.ya.a(0.45f, -12.0f, 4.0f, 2, 3, 1);
        a2.ya.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ya, 0.5235988f, 0.0f, 0.0f);
        a2.ca = new sfc(a2, 0, 0);
        a2.ca.a(-2.45f, -12.0f, 4.0f, 2, 3, 1);
        a2.ca.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ca, 0.5235988f, 0.0f, 0.0f);
        a2.ga = new sfc(a2, 0, 12);
        a2.ga.a(-2.0f, -16.0f, 4.0f, 2, 7, 1);
        a2.ga.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ga, 0.5235988f, 0.0f, 0.2617994f);
        a2.ja = new sfc(a2, 0, 12);
        a2.ja.a(0.0f, -16.0f, 4.0f, 2, 7, 1);
        a2.ja.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ja, 0.5235988f, 0.0f, -0.2617994f);
        a2.ia = new sfc(a2, 0, 12);
        a2.ia.a(-2.05f, -9.8f, -2.0f, 4, 14, 8);
        a2.ia.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ia, 0.5235988f, 0.0f, 0.0f);
        a2.w = new sfc(a2, 0, 34);
        a2.w.a(-3.0f, 0.0f, 0.0f, 8, 8, 3);
        a2.w.a(-7.5f, 3.0f, 10.0f);
        a2.a(a2.w, 0.0f, 1.5707964f, 0.0f);
        a2.i = new sfc(a2, 0, 47);
        a2.i.a(-3.0f, 0.0f, 0.0f, 8, 8, 3);
        a2.i.a(4.5f, 3.0f, 10.0f);
        a2.a(a2.i, 0.0f, 1.5707964f, 0.0f);
        a2.n = new sfc(a2, 80, 0);
        a2.n.a(-5.0f, 0.0f, -3.0f, 10, 1, 8);
        a2.n.a(0.0f, 2.0f, 2.0f);
        a2.e = new sfc(a2, 106, 9);
        a2.e.a(-1.5f, -1.0f, -3.0f, 3, 1, 2);
        a2.e.a(0.0f, 2.0f, 2.0f);
        a2.r = new sfc(a2, 80, 9);
        a2.r.a(-4.0f, -1.0f, 3.0f, 8, 1, 2);
        a2.r.a(0.0f, 2.0f, 2.0f);
        a2.h = new sfc(a2, 74, 0);
        a2.h.a(-0.5f, 6.0f, -1.0f, 1, 2, 2);
        a2.h.a(5.0f, 3.0f, 2.0f);
        a2.f = new sfc(a2, 70, 0);
        a2.f.a(-0.5f, 0.0f, -0.5f, 1, 6, 1);
        a2.f.a(5.0f, 3.0f, 2.0f);
        a2.l = new sfc(a2, 74, 4);
        a2.l.a(-0.5f, 6.0f, -1.0f, 1, 2, 2);
        a2.l.a(-5.0f, 3.0f, 2.0f);
        a2.z = new sfc(a2, 80, 0);
        a2.z.a(-0.5f, 0.0f, -0.5f, 1, 6, 1);
        a2.z.a(-5.0f, 3.0f, 2.0f);
        a2.b = new sfc(a2, 74, 13);
        a2.b.a(1.5f, -8.0f, -4.0f, 1, 2, 2);
        a2.b.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.b, 0.5235988f, 0.0f, 0.0f);
        a2.c = new sfc(a2, 74, 13);
        a2.c.a(-2.5f, -8.0f, -4.0f, 1, 2, 2);
        a2.c.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.c, 0.5235988f, 0.0f, 0.0f);
        a2.v = new sfc(a2, 44, 10);
        a2.v.a(2.6f, -6.0f, -6.0f, 0, 3, 16);
        a2.v.a(0.0f, 4.0f, -10.0f);
        a2.d = new sfc(a2, 44, 5);
        a2.d.a(-2.6f, -6.0f, -6.0f, 0, 3, 16);
        a2.d.a(0.0f, 4.0f, -10.0f);
        a2.oa = new sfc(a2, 58, 0);
        a2.oa.a(-1.0f, -11.5f, 5.0f, 2, 16, 4);
        a2.oa.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.oa, 0.5235988f, 0.0f, 0.0f);
        a2.ta = new sfc(a2, 80, 12);
        a2.ta.p(-2.5f, -10.1f, -7.0f, 5, 5, 12, 0.2f);
        a2.ta.a(0.0f, 4.0f, -10.0f);
        a2.a(a2.ta, 0.5235988f, 0.0f, 0.0f);
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        cna a9;
        boolean bl2;
        obb obb2 = (obb)a2;
        int n2 = obb2.v();
        float f2 = obb2.z(0.0f);
        boolean bl3 = obb2.gb();
        boolean bl4 = bl3 && obb2.eb();
        boolean bl5 = bl3 && obb2.rb();
        boolean bl6 = n2 == 1 || n2 == 2;
        float f3 = obb2.f();
        boolean bl7 = bl2 = obb2.lb != null;
        if (bl4) {
            a9.ta.y(a8);
            a9.n.y(a8);
            a9.e.y(a8);
            a9.r.y(a8);
            a9.f.y(a8);
            a9.h.y(a8);
            a9.z.y(a8);
            a9.l.y(a8);
            a9.b.y(a8);
            a9.c.y(a8);
            if (bl2) {
                a9.v.y(a8);
                a9.d.y(a8);
            }
        }
        if (!bl3) {
            ewa.m();
            ewa.o(f3, 0.5f + f3 * 0.5f, f3);
            ewa.p(0.0f, 0.95f * (1.0f - f3), 0.0f);
        }
        a9.j.y(a8);
        a9.o.y(a8);
        a9.m.y(a8);
        a9.y.y(a8);
        a9.a.y(a8);
        a9.q.y(a8);
        a9.g.y(a8);
        a9.k.y(a8);
        a9.x.y(a8);
        a9.t.y(a8);
        a9.p.y(a8);
        a9.s.y(a8);
        if (!bl3) {
            ewa.h();
            ewa.m();
            ewa.o(f3, f3, f3);
            ewa.p(0.0f, 1.35f * (1.0f - f3), 0.0f);
        }
        a9.pa.y(a8);
        a9.ba.y(a8);
        a9.la.y(a8);
        a9.u.y(a8);
        a9.ia.y(a8);
        a9.oa.y(a8);
        if (!bl3) {
            ewa.h();
            ewa.m();
            float f4 = 0.5f + f3 * f3 * 0.5f;
            ewa.o(f4, f4, f4);
            if (f2 <= 0.0f) {
                ewa.p(0.0f, 1.35f * (1.0f - f3), 0.0f);
            } else {
                ewa.p(0.0f, 0.9f * (1.0f - f3) * f2 + 1.35f * (1.0f - f3) * (1.0f - f2), 0.15f * (1.0f - f3) * f2);
            }
        }
        if (bl6) {
            a9.ga.y(a8);
            a9.ja.y(a8);
        } else {
            a9.ya.y(a8);
            a9.ca.y(a8);
        }
        a9.na.y(a8);
        if (!bl3) {
            ewa.h();
        }
        if (bl5) {
            a9.w.y(a8);
            a9.i.y(a8);
        }
    }

    private /* synthetic */ void a(sfc a2, float a3, float a4, float a5) {
        a2.j = a3;
        a2.o = a4;
        a2.m = a5;
    }

    private /* synthetic */ float a(float a2, float a3, float a4) {
        float f2 = a3 - a2;
        while (f2 < -180.0f) {
            f2 += 360.0f;
        }
        while (f2 >= 180.0f) {
            f2 -= 360.0f;
        }
        return a2 + a4 * f2;
    }

    @Override
    public void a(xi a2, float a3, float a4, float a5) {
        cna a6;
        super.a(a2, a3, a4, a5);
        float f2 = a6.a(a2.va, a2.wa, a5);
        float f3 = a6.a(a2.ea, a2.sa, a5);
        int n2 = a2.hb + (a2.rb - a2.hb) * a5;
        float f4 = f3 - f2;
        int n3 = n2 / 57.295776f;
        if (f4 > 20.0f) {
            f4 = 20.0f;
        }
        if (f4 < -20.0f) {
            f4 = -20.0f;
        }
        if (a4 > 0.2f) {
            n3 += smb.y(a3 * 0.4f) * 0.15f * a4;
        }
        obb obb2 = (obb)a2;
        float f5 = obb2.z(a5);
        float f6 = obb2.y(a5);
        float f7 = 1.0f - f6;
        float f8 = obb2.o(a5);
        boolean bl2 = obb2.ta != 0;
        boolean bl3 = obb2.eb();
        boolean bl4 = obb2.lb != null;
        float f9 = (float)a2.pa + a5;
        float f10 = smb.y(a3 * 0.6662f + (float)Math.PI);
        float f11 = f10 * 0.8f * a4;
        a6.na.la = 4.0f;
        a6.na.u = -10.0f;
        a6.ba.la = 3.0f;
        a6.la.u = 14.0f;
        a6.i.la = 3.0f;
        a6.i.u = 10.0f;
        a6.pa.j = 0.0f;
        a6.na.j = 0.5235988f + n3;
        a6.na.o = f4 / 57.295776f;
        a6.na.j = f6 * (0.2617994f + n3) + f5 * 2.18166f + (1.0f - Math.max(f6, f5)) * a6.na.j;
        a6.na.o = f6 * f4 / 57.295776f + (1.0f - Math.max(f6, f5)) * a6.na.o;
        a6.na.la = f6 * -6.0f + f5 * 11.0f + (1.0f - Math.max(f6, f5)) * a6.na.la;
        a6.na.u = f6 * -1.0f + f5 * -10.0f + (1.0f - Math.max(f6, f5)) * a6.na.u;
        a6.ba.la = f6 * 9.0f + f7 * a6.ba.la;
        a6.la.u = f6 * 18.0f + f7 * a6.la.u;
        a6.i.la = f6 * 5.5f + f7 * a6.i.la;
        a6.i.u = f6 * 15.0f + f7 * a6.i.u;
        a6.pa.j = f6 * -45.0f / 57.295776f + f7 * a6.pa.j;
        a6.ya.la = a6.na.la;
        a6.ca.la = a6.na.la;
        a6.ga.la = a6.na.la;
        a6.ja.la = a6.na.la;
        a6.ia.la = a6.na.la;
        a6.ka.la = 0.02f;
        a6.ha.la = 0.0f;
        a6.oa.la = a6.na.la;
        a6.ya.u = a6.na.u;
        a6.ca.u = a6.na.u;
        a6.ga.u = a6.na.u;
        a6.ja.u = a6.na.u;
        a6.ia.u = a6.na.u;
        a6.ka.u = 0.02f - f8 * 1.0f;
        a6.ha.u = 0.0f + f8 * 1.0f;
        a6.oa.u = a6.na.u;
        a6.ya.j = a6.na.j;
        a6.ca.j = a6.na.j;
        a6.ga.j = a6.na.j;
        a6.ja.j = a6.na.j;
        a6.ia.j = a6.na.j;
        a6.ka.j = 0.0f - 0.09424778f * f8;
        a6.ha.j = 0.0f + 0.15707964f * f8;
        a6.oa.j = a6.na.j;
        a6.ya.o = a6.na.o;
        a6.ca.o = a6.na.o;
        a6.ga.o = a6.na.o;
        a6.ja.o = a6.na.o;
        a6.ia.o = a6.na.o;
        a6.ka.o = 0.0f;
        a6.ha.o = 0.0f;
        a6.oa.o = a6.na.o;
        a6.w.j = f11 / 5.0f;
        a6.i.j = -f11 / 5.0f;
        float f12 = 1.5707964f;
        float f13 = 4.712389f;
        float f14 = -1.0471976f;
        float f15 = 0.2617994f * f6;
        float f16 = smb.y(f9 * 0.6f + (float)Math.PI);
        a6.g.la = -2.0f * f6 + 9.0f * f7;
        a6.g.u = -2.0f * f6 + -8.0f * f7;
        a6.t.la = a6.g.la;
        a6.t.u = a6.g.u;
        a6.o.la = a6.j.la + smb.z(1.5707964f + f15 + f7 * -f10 * 0.5f * a4) * 7.0f;
        a6.o.u = a6.j.u + smb.y(4.712389f + f15 + f7 * -f10 * 0.5f * a4) * 7.0f;
        a6.a.la = a6.y.la + smb.z(1.5707964f + f15 + f7 * f10 * 0.5f * a4) * 7.0f;
        a6.a.u = a6.y.u + smb.y(4.712389f + f15 + f7 * f10 * 0.5f * a4) * 7.0f;
        float f17 = (-1.0471976f + f16) * f6 + f11 * f7;
        float f18 = (-1.0471976f + -f16) * f6 + -f11 * f7;
        a6.k.la = a6.g.la + smb.z(1.5707964f + f17) * 7.0f;
        a6.k.u = a6.g.u + smb.y(4.712389f + f17) * 7.0f;
        a6.p.la = a6.t.la + smb.z(1.5707964f + f18) * 7.0f;
        a6.p.u = a6.t.u + smb.y(4.712389f + f18) * 7.0f;
        a6.j.j = f15 + -f10 * 0.5f * a4 * f7;
        a6.m.j = a6.o.j = -0.08726646f * f6 + (-f10 * 0.5f * a4 - Math.max(0.0f, f10 * 0.5f * a4)) * f7;
        a6.y.j = f15 + f10 * 0.5f * a4 * f7;
        a6.q.j = a6.a.j = -0.08726646f * f6 + (f10 * 0.5f * a4 - Math.max(0.0f, -f10 * 0.5f * a4)) * f7;
        a6.g.j = f17;
        a6.x.j = a6.k.j = (a6.g.j + (float)Math.PI * Math.max(0.0f, 0.2f + f16 * 0.2f)) * f6 + (f11 + Math.max(0.0f, f10 * 0.5f * a4)) * f7;
        a6.t.j = f18;
        a6.s.j = a6.p.j = (a6.t.j + (float)Math.PI * Math.max(0.0f, 0.2f - f16 * 0.2f)) * f6 + (-f11 + Math.max(0.0f, -f10 * 0.5f * a4)) * f7;
        a6.m.la = a6.o.la;
        a6.m.u = a6.o.u;
        a6.q.la = a6.a.la;
        a6.q.u = a6.a.u;
        a6.x.la = a6.k.la;
        a6.x.u = a6.k.u;
        a6.s.la = a6.p.la;
        a6.s.u = a6.p.u;
        if (bl3) {
            a6.n.la = f6 * 0.5f + f7 * 2.0f;
            a6.n.u = f6 * 11.0f + f7 * 2.0f;
            a6.e.la = a6.n.la;
            a6.r.la = a6.n.la;
            a6.f.la = a6.n.la;
            a6.z.la = a6.n.la;
            a6.h.la = a6.n.la;
            a6.l.la = a6.n.la;
            a6.w.la = a6.i.la;
            a6.e.u = a6.n.u;
            a6.r.u = a6.n.u;
            a6.f.u = a6.n.u;
            a6.z.u = a6.n.u;
            a6.h.u = a6.n.u;
            a6.l.u = a6.n.u;
            a6.w.u = a6.i.u;
            a6.n.j = a6.pa.j;
            a6.e.j = a6.pa.j;
            a6.r.j = a6.pa.j;
            a6.v.la = a6.na.la;
            a6.d.la = a6.na.la;
            a6.ta.la = a6.na.la;
            a6.b.la = a6.na.la;
            a6.c.la = a6.na.la;
            a6.v.u = a6.na.u;
            a6.d.u = a6.na.u;
            a6.ta.u = a6.na.u;
            a6.b.u = a6.na.u;
            a6.c.u = a6.na.u;
            a6.v.j = n3;
            a6.d.j = n3;
            a6.ta.j = a6.na.j;
            a6.b.j = a6.na.j;
            a6.c.j = a6.na.j;
            a6.ta.o = a6.na.o;
            a6.b.o = a6.na.o;
            a6.v.o = a6.na.o;
            a6.c.o = a6.na.o;
            a6.d.o = a6.na.o;
            if (bl4) {
                a6.f.j = -1.0471976f;
                a6.h.j = -1.0471976f;
                a6.z.j = -1.0471976f;
                a6.l.j = -1.0471976f;
                a6.f.m = 0.0f;
                a6.h.m = 0.0f;
                a6.z.m = 0.0f;
                a6.l.m = 0.0f;
            } else {
                a6.f.j = f11 / 3.0f;
                a6.h.j = f11 / 3.0f;
                a6.z.j = f11 / 3.0f;
                a6.l.j = f11 / 3.0f;
                a6.f.m = f11 / 5.0f;
                a6.h.m = f11 / 5.0f;
                a6.z.m = -f11 / 5.0f;
                a6.l.m = -f11 / 5.0f;
            }
        }
        if ((f12 = -1.3089f + a4 * 1.5f) > 0.0f) {
            f12 = 0.0f;
        }
        if (bl2) {
            a6.ba.o = smb.y(f9 * 0.7f);
            f12 = 0.0f;
        } else {
            a6.ba.o = 0.0f;
        }
        a6.la.o = a6.ba.o;
        a6.u.o = a6.ba.o;
        a6.la.la = a6.ba.la;
        a6.u.la = a6.ba.la;
        a6.la.u = a6.ba.u;
        a6.u.u = a6.ba.u;
        a6.ba.j = f12;
        a6.la.j = f12;
        a6.u.j = -0.2618f + f12;
    }
}

