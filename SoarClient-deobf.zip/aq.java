/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class aq
extends xk<gea> {
    public aq(gub a2) {
        super(a2);
        aq a3;
    }

    @Override
    public void a(gea a2, double a3, double a4, double a5, float a6, float a7) {
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        ewa.c();
        ewa.ka();
        ewa.w();
        ewa.y(770, 1);
        double[] dArray = new double[8];
        double[] dArray2 = new double[8];
        double d2 = 0.0;
        double d3 = 0.0;
        Random random = new Random(a2.v);
        int n2 = 7;
        while (n2 >= 0) {
            dArray[n2] = d2;
            dArray2[n2] = d3;
            d2 += (double)(random.nextInt(11) - 5);
            d3 += (double)(random.nextInt(11) - 5);
            --n2;
        }
        n2 = 0;
        while (n2 < 4) {
            Random random2 = new Random(a2.v);
            int n3 = 0;
            while (n3 < 3) {
                int n4 = 7;
                int n5 = 0;
                if (n3 > 0) {
                    n4 = 7 - n3;
                }
                if (n3 > 0) {
                    n5 = n4 - 2;
                }
                double d4 = dArray[n4] - d2;
                double d5 = dArray2[n4] - d3;
                int n6 = n4;
                while (n6 >= n5) {
                    double d6 = d4;
                    double d7 = d5;
                    if (n3 == 0) {
                        d4 += (double)(random2.nextInt(11) - 5);
                        d5 += (double)(random2.nextInt(11) - 5);
                    } else {
                        d4 += (double)(random2.nextInt(31) - 15);
                        d5 += (double)(random2.nextInt(31) - 15);
                    }
                    krb2.a(5, ybd.w);
                    float f2 = 0.5f;
                    float f3 = 0.45f;
                    float f4 = 0.45f;
                    float f5 = 0.5f;
                    double d8 = 0.1 + (double)n2 * 0.2;
                    if (n3 == 0) {
                        d8 *= (double)n6 * 0.1 + 1.0;
                    }
                    double d9 = 0.1 + (double)n2 * 0.2;
                    if (n3 == 0) {
                        d9 *= (double)(n6 - 1) * 0.1 + 1.0;
                    }
                    int n7 = 0;
                    while (n7 < 5) {
                        double d10 = a3 + 0.5 - d8;
                        double d11 = a5 + 0.5 - d8;
                        if (n7 == 1 || n7 == 2) {
                            d10 += d8 * 2.0;
                        }
                        if (n7 == 2 || n7 == 3) {
                            d11 += d8 * 2.0;
                        }
                        double d12 = a3 + 0.5 - d9;
                        double d13 = a5 + 0.5 - d9;
                        if (n7 == 1 || n7 == 2) {
                            d12 += d9 * 2.0;
                        }
                        if (n7 == 2 || n7 == 3) {
                            d13 += d9 * 2.0;
                        }
                        krb2.a(d12 + d4, a4 + (double)(n6 * 16), d13 + d5).a(0.45f, 0.45f, 0.5f, 0.3f).z();
                        krb2.a(d10 + d6, a4 + (double)((n6 + 1) * 16), d11 + d7).a(0.45f, 0.45f, 0.5f, 0.3f).z();
                        ++n7;
                    }
                    xlb2.a();
                    --n6;
                }
                ++n3;
            }
            ++n2;
        }
        ewa.b();
        ewa.ra();
        ewa.e();
    }

    @Override
    protected wmc a(gea a2) {
        return null;
    }
}

