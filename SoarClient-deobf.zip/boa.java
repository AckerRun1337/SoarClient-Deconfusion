/*
 * Decompiled with CFR 0.152.
 */
public class boa<T extends rj>
extends xk<T> {
    protected final ge v;
    private final kp d;

    public boa(gub a2, ge a3, kp a4) {
        super(a2);
        boa a5;
        a5.v = a3;
        a5.d = a4;
    }

    @Override
    public void y(T a2, double a3, double a4, double a5, float a6, float a7) {
        boa a8;
        ewa.m();
        ewa.p((float)a3, (float)a4, (float)a5);
        ewa.r();
        ewa.o(0.5f, 0.5f, 0.5f);
        ewa.p(-a8.l.e, 0.0f, 1.0f, 0.0f);
        ewa.p(a8.l.r, 1.0f, 0.0f, 0.0f);
        a8.p(yeb.q);
        a8.d.a(a8.a(a2), unc.c);
        ewa.q();
        ewa.h();
        super.y(a2, a3, a4, a5, a6, a7);
    }

    public wfc a(T a2) {
        boa a3;
        return new wfc(a3.v, 1, 0);
    }

    @Override
    protected wmc a(rj a2) {
        return yeb.q;
    }
}

