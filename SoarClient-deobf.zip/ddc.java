/*
 * Decompiled with CFR 0.152.
 */
class ddc
extends fsa {
    final /* synthetic */ bad d;

    ddc(bad a2, String a3, boolean a4, int a5) {
        ddc a6;
        a6.d = a2;
        super(a3, a4, a5);
    }

    @Override
    public void o() {
        ddc a2;
        super.o();
        a2.d.a(a2);
    }
}

