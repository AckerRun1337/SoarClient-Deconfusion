/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cgc
implements o<vi> {
    private tp c;
    private int v;
    private dgb d;

    public cgc() {
        cgc a2;
    }

    public cgc(tp a2, int a3, dgb a4) {
        cgc a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    @Override
    public void p(io a2) throws IOException {
        a.c = a2.a();
        a.v = a2.p();
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        cgc a3;
        a2.a(a3.c);
        a2.x((byte)a3.v);
        a2.a(a3.d);
    }

    @Override
    public void a(vi a2) {
        cgc a3;
        a2.a(a3);
    }

    public tp a() {
        cgc a2;
        return a2.c;
    }

    public int a() {
        cgc a2;
        return a2.v;
    }

    public dgb a() {
        cgc a2;
        return a2.d;
    }
}

