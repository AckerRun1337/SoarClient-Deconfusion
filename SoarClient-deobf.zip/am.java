/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class am {
    private Class b;
    private String c;
    private float v;
    private String[] d;

    public am(Class a2, String a3, float a4) {
        am a5;
        a5.b = a2;
        a5.c = a3;
        a5.v = a4;
    }

    public am(Class a2, String a3, float a4, String[] a5) {
        am a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    public Class a() {
        am a2;
        return a2.b;
    }

    public String a() {
        am a2;
        return a2.c;
    }

    public String[] p() {
        am a2;
        return a2.d;
    }

    public float a() {
        am a2;
        return a2.v;
    }

    public abstract qm a();

    public abstract sfc a(qm var1, String var2);

    public abstract String[] a();

    public abstract h a(qm var1, float var2);

    public sfc[] a(qm a2) {
        am a3;
        String[] stringArray = a3.a();
        ArrayList<sfc> arrayList = new ArrayList<sfc>();
        int n2 = 0;
        while (n2 < stringArray.length) {
            String string = stringArray[n2];
            sfc sfc2 = a3.a(a2, string);
            if (sfc2 != null) {
                arrayList.add(sfc2);
            }
            ++n2;
        }
        sfc[] sfcArray = arrayList.toArray(new sfc[arrayList.size()]);
        return sfcArray;
    }
}

