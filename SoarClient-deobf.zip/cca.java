/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

class cca
extends ica {
    protected List<ica> d = Lists.newArrayList();

    public cca(String a2) {
        cca a3;
        a3.d = a2;
    }

    @Override
    public ml a() throws rl {
        cca a2;
        dgb dgb2 = new dgb();
        for (ica ica2 : a2.d) {
            dgb2.a(ica2.d, ica2.a());
        }
        return dgb2;
    }
}

