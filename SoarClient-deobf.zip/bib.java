/*
 * Decompiled with CFR 0.152.
 */
public class bib
extends dk {
    public bib() {
        a2(0.0f);
        bib a2;
    }

    public bib(float a2) {
        a3(a2, 64, 32);
        bib a3;
    }

    protected bib(float a2, int a3, int a4) {
        super(a2, 0.0f, a3, a4);
        bib a5;
    }

    @Override
    public void a(float a2, float a3, float a4, float a5, float a6, float a7, rj a8) {
        if (a8 instanceof ioa) {
            bib a9;
            ioa ioa2 = (ioa)a8;
            a9.n.j = (float)Math.PI / 180 * ioa2.j().o();
            a9.n.o = (float)Math.PI / 180 * ioa2.j().p();
            a9.n.m = (float)Math.PI / 180 * ioa2.j().a();
            a9.n.a(0.0f, 1.0f, 0.0f);
            a9.r.j = (float)Math.PI / 180 * ioa2.z().o();
            a9.r.o = (float)Math.PI / 180 * ioa2.z().p();
            a9.r.m = (float)Math.PI / 180 * ioa2.z().a();
            a9.h.j = (float)Math.PI / 180 * ioa2.y().o();
            a9.h.o = (float)Math.PI / 180 * ioa2.y().p();
            a9.h.m = (float)Math.PI / 180 * ioa2.y().a();
            a9.f.j = (float)Math.PI / 180 * ioa2.o().o();
            a9.f.o = (float)Math.PI / 180 * ioa2.o().p();
            a9.f.m = (float)Math.PI / 180 * ioa2.o().a();
            a9.l.j = (float)Math.PI / 180 * ioa2.p().o();
            a9.l.o = (float)Math.PI / 180 * ioa2.p().p();
            a9.l.m = (float)Math.PI / 180 * ioa2.p().a();
            a9.l.a(1.9f, 11.0f, 0.0f);
            a9.z.j = (float)Math.PI / 180 * ioa2.a().o();
            a9.z.o = (float)Math.PI / 180 * ioa2.a().p();
            a9.z.m = (float)Math.PI / 180 * ioa2.a().a();
            a9.z.a(-1.9f, 11.0f, 0.0f);
            bib.a(a9.n, a9.e);
        }
    }
}

