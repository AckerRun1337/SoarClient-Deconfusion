/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class azb
extends hf {
    public azb() {
        azb a2;
    }

    @Override
    public String a() {
        return "say";
    }

    @Override
    public int a() {
        return 1;
    }

    @Override
    public String a(j a2) {
        return "commands.say.usage";
    }

    @Override
    public void a(j a2, String[] a3) throws tqa {
        if (a3.length <= 0 || a3[0].length() <= 0) {
            throw new xvb("commands.say.usage", new Object[0]);
        }
        ga ga2 = azb.a(a2, a3, 0, true);
        ccb.a().a().a(new klb("chat.type.announcement", a2.a(), ga2));
    }

    @Override
    public List<String> a(j a2, String[] a3, tp a4) {
        return a3.length >= 1 ? azb.a(a3, ccb.a().a()) : null;
    }
}

