/*
 * Decompiled with CFR 0.152.
 */
class cyb {
    public ud c;
    public int v;
    public int d = -1;

    public cyb(int a2, int a3) {
        cyb a4;
        a4.v = a2;
        a4.c = new ud(a3);
    }
}

