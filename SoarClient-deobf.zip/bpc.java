/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

public class bpc
extends es {
    private static final List<String> d = Lists.newArrayList((Object[])new String[]{"harp", "bd", "snare", "hat", "bassattack"});

    public bpc() {
        super(dr.na);
        bpc a2;
        a2.a(md.x);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        boolean bl2 = a2.y(a3);
        kv kv2 = a2.a(a3);
        if (kv2 instanceof pxc) {
            pxc pxc2 = (pxc)kv2;
            if (pxc2.d != bl2) {
                if (bl2) {
                    pxc2.a(a2, a3);
                }
                pxc2.d = bl2;
            }
        }
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, pm a5, hnd a6, float a7, float a8, float a9) {
        if (a2.f) {
            return true;
        }
        kv kv2 = a2.a(a3);
        if (kv2 instanceof pxc) {
            pxc pxc2 = (pxc)kv2;
            pxc2.a();
            pxc2.a(a2, a3);
            a5.p(hca.w);
        }
        return true;
    }

    @Override
    public void a(xga a2, tp a3, pm a4) {
        kv kv2;
        if (!a2.f && (kv2 = a2.a(a3)) instanceof pxc) {
            ((pxc)kv2).a(a2, a3);
            a4.p(hca.s);
        }
    }

    @Override
    public kv a(xga a2, int a3) {
        return new pxc();
    }

    private /* synthetic */ String a(int a2) {
        if (a2 < 0 || a2 >= d.size()) {
            a2 = 0;
        }
        return d.get(a2);
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, int a5, int a6) {
        bpc a7;
        float f2 = (float)Math.pow(2.0, (double)(a6 - 12) / 12.0);
        a2.a((double)a3.o() + 0.5, (double)a3.p() + 0.5, (double)a3.a() + 0.5, "note." + a7.a(a5), 3.0f, f2);
        a2.a(wra.u, (double)a3.o() + 0.5, (double)a3.p() + 1.2, (double)a3.a() + 0.5, (double)a6 / 24.0, 0.0, 0.0, 0);
        return true;
    }

    @Override
    public int o() {
        return 3;
    }
}

