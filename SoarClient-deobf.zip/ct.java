/*
 * Decompiled with CFR 0.152.
 */
public class ct<V> {
    private transient ohb<V>[] b = new ohb[16];
    private transient int c;
    private int v = 12;
    private final float d = 0.75f;

    public ct() {
        ct a2;
    }

    private static /* synthetic */ int p(int a2) {
        a2 = a2 ^ a2 >>> 20 ^ a2 >>> 12;
        return a2 ^ a2 >>> 7 ^ a2 >>> 4;
    }

    private static /* synthetic */ int a(int a2, int a3) {
        return a2 & a3 - 1;
    }

    public V p(int a2) {
        ct a3;
        int n2 = ct.p(a2);
        ohb<V> ohb2 = a3.b[ct.a(n2, a3.b.length)];
        while (ohb2 != null) {
            if (ohb2.b == a2) {
                return ohb2.c;
            }
            ohb2 = ohb2.v;
        }
        return null;
    }

    public boolean a(int a2) {
        ct a3;
        return a3.p(a2) != null;
    }

    final ohb<V> p(int a2) {
        ct a3;
        int n2 = ct.p(a2);
        ohb<V> ohb2 = a3.b[ct.a(n2, a3.b.length)];
        while (ohb2 != null) {
            if (ohb2.b == a2) {
                return ohb2;
            }
            ohb2 = ohb2.v;
        }
        return null;
    }

    public void a(int a2, V a3) {
        ct a4;
        int n2 = ct.p(a2);
        int n3 = ct.a(n2, a4.b.length);
        ohb<V> ohb2 = a4.b[n3];
        while (ohb2 != null) {
            if (ohb2.b == a2) {
                ohb2.c = a3;
                return;
            }
            ohb2 = ohb2.v;
        }
        a4.a(n2, a2, a3, n3);
    }

    private /* synthetic */ void a(int a2) {
        ct a3;
        ohb<V>[] ohbArray = a3.b;
        int n2 = ohbArray.length;
        if (n2 == 0x40000000) {
            a3.v = Integer.MAX_VALUE;
        } else {
            ohb[] ohbArray2 = new ohb[a2];
            a3.a(ohbArray2);
            a3.b = ohbArray2;
            a3.v = (int)((float)a2 * 0.75f);
        }
    }

    private /* synthetic */ void a(ohb<V>[] a2) {
        ct a3;
        ohb<V>[] ohbArray = a3.b;
        int n2 = a2.length;
        int n3 = 0;
        while (n3 < ohbArray.length) {
            ohb<V> ohb2 = ohbArray[n3];
            if (ohb2 != null) {
                ohb ohb3;
                ohbArray[n3] = null;
                do {
                    ohb3 = ohb2.v;
                    int n4 = ct.a(ohb2.d, n2);
                    ohb2.v = a2[n4];
                    a2[n4] = ohb2;
                    ohb2 = ohb3;
                } while (ohb3 != null);
            }
            ++n3;
        }
    }

    public V a(int a2) {
        ct a3;
        ohb<V> ohb2 = a3.a(a2);
        return ohb2 == null ? null : (V)ohb2.c;
    }

    final ohb<V> a(int a2) {
        ohb<V> ohb2;
        ct a3;
        int n2 = ct.p(a2);
        int n3 = ct.a(n2, a3.b.length);
        ohb<V> ohb3 = ohb2 = a3.b[n3];
        while (ohb3 != null) {
            ohb ohb4 = ohb3.v;
            if (ohb3.b == a2) {
                --a3.c;
                if (ohb2 == ohb3) {
                    a3.b[n3] = ohb4;
                } else {
                    ohb2.v = ohb4;
                }
                return ohb3;
            }
            ohb2 = ohb3;
            ohb3 = ohb4;
        }
        return ohb3;
    }

    public void a() {
        ct a2;
        ohb<V>[] ohbArray = a2.b;
        int n2 = 0;
        while (n2 < ohbArray.length) {
            ohbArray[n2] = null;
            ++n2;
        }
        a2.c = 0;
    }

    private /* synthetic */ void a(int a2, int a3, V a4, int a5) {
        ct a6;
        ohb<V> ohb2 = a6.b[a5];
        a6.b[a5] = new ohb<V>(a2, a3, a4, ohb2);
        if (a6.c++ >= a6.v) {
            a6.a(2 * a6.b.length);
        }
    }

    static /* synthetic */ int a(int a2) {
        return ct.p(a2);
    }
}

