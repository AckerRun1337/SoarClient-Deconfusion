/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.lwjgl.util.vector.Vector3f;

public class azc {
    public static final List<String> v = Lists.newArrayList((Object[])new String[]{"layer0", "layer1", "layer2", "layer3", "layer4"});
    private static volatile /* synthetic */ int[] d;

    public azc() {
        azc a2;
    }

    public ela a(yeb a2, ela a3) {
        HashMap hashMap = Maps.newHashMap();
        ArrayList arrayList = Lists.newArrayList();
        int n2 = 0;
        while (n2 < v.size()) {
            azc a4;
            String string = v.get(n2);
            if (!a3.p(string)) break;
            String string2 = a3.a(string);
            hashMap.put(string, string2);
            jqa jqa2 = a2.o(new wmc(string2).toString());
            arrayList.addAll(a4.a(n2, string, jqa2));
            ++n2;
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        hashMap.put("particle", a3.p("particle") ? a3.a("particle") : (String)hashMap.get("layer0"));
        return new ela(arrayList, (Map<String, String>)hashMap, false, false, a3.a());
    }

    private /* synthetic */ List<yzb> a(int a2, String a3, jqa a4) {
        azc a5;
        HashMap hashMap = Maps.newHashMap();
        hashMap.put(hnd.t, new zvc(null, a2, a3, new sf(new float[]{0.0f, 0.0f, 16.0f, 16.0f}, 0)));
        hashMap.put(hnd.x, new zvc(null, a2, a3, new sf(new float[]{16.0f, 0.0f, 0.0f, 16.0f}, 0)));
        ArrayList arrayList = Lists.newArrayList();
        arrayList.add(new yzb(new Vector3f(0.0f, 0.0f, 7.5f), new Vector3f(16.0f, 16.0f, 8.5f), hashMap, null, true));
        arrayList.addAll(a5.a(a4, a3, a2));
        return arrayList;
    }

    private /* synthetic */ List<yzb> a(jqa a2, String a3, int a4) {
        azc a5;
        float f2 = a2.z();
        float f3 = a2.y();
        ArrayList arrayList = Lists.newArrayList();
        for (cqc cqc2 : a5.a(a2)) {
            float f4 = 0.0f;
            float f5 = 0.0f;
            float f6 = 0.0f;
            float f7 = 0.0f;
            float f8 = 0.0f;
            float f9 = 0.0f;
            float f10 = 0.0f;
            float f11 = 0.0f;
            float f12 = 0.0f;
            float f13 = 0.0f;
            float f14 = cqc2.o();
            float f15 = cqc2.p();
            float f16 = cqc2.a();
            wgc wgc2 = cqc2.a();
            switch (azc.a()[wgc2.ordinal()]) {
                case 1: {
                    f8 = f14;
                    f4 = f14;
                    f6 = f9 = f15 + 1.0f;
                    f10 = f16;
                    f5 = f16;
                    f11 = f16;
                    f7 = f16;
                    f12 = 16.0f / f2;
                    f13 = 16.0f / (f3 - 1.0f);
                    break;
                }
                case 2: {
                    f11 = f16;
                    f10 = f16;
                    f8 = f14;
                    f4 = f14;
                    f6 = f9 = f15 + 1.0f;
                    f5 = f16 + 1.0f;
                    f7 = f16 + 1.0f;
                    f12 = 16.0f / f2;
                    f13 = 16.0f / (f3 - 1.0f);
                    break;
                }
                case 3: {
                    f8 = f16;
                    f4 = f16;
                    f9 = f16;
                    f6 = f16;
                    f11 = f14;
                    f5 = f14;
                    f7 = f10 = f15 + 1.0f;
                    f12 = 16.0f / (f2 - 1.0f);
                    f13 = 16.0f / f3;
                    break;
                }
                case 4: {
                    f9 = f16;
                    f8 = f16;
                    f4 = f16 + 1.0f;
                    f6 = f16 + 1.0f;
                    f11 = f14;
                    f5 = f14;
                    f7 = f10 = f15 + 1.0f;
                    f12 = 16.0f / (f2 - 1.0f);
                    f13 = 16.0f / f3;
                }
            }
            float f17 = 16.0f / f2;
            float f18 = 16.0f / f3;
            f4 *= f17;
            f6 *= f17;
            f5 *= f18;
            f7 *= f18;
            f5 = 16.0f - f5;
            f7 = 16.0f - f7;
            HashMap hashMap = Maps.newHashMap();
            hashMap.put(wgc2.a(), new zvc(null, a4, a3, new sf(new float[]{f8 *= f12, f10 *= f13, f9 *= f12, f11 *= f13}, 0)));
            switch (azc.a()[wgc2.ordinal()]) {
                case 1: {
                    arrayList.add(new yzb(new Vector3f(f4, f5, 7.5f), new Vector3f(f6, f5, 8.5f), hashMap, null, true));
                    break;
                }
                case 2: {
                    arrayList.add(new yzb(new Vector3f(f4, f7, 7.5f), new Vector3f(f6, f7, 8.5f), hashMap, null, true));
                    break;
                }
                case 3: {
                    arrayList.add(new yzb(new Vector3f(f4, f5, 7.5f), new Vector3f(f4, f7, 8.5f), hashMap, null, true));
                    break;
                }
                case 4: {
                    arrayList.add(new yzb(new Vector3f(f6, f5, 7.5f), new Vector3f(f6, f7, 8.5f), hashMap, null, true));
                }
            }
        }
        return arrayList;
    }

    private /* synthetic */ List<cqc> a(jqa a2) {
        int n2 = a2.z();
        int n3 = a2.y();
        ArrayList arrayList = Lists.newArrayList();
        int n4 = 0;
        while (n4 < a2.o()) {
            int[] nArray = a2.a(n4)[0];
            int n5 = 0;
            while (n5 < n3) {
                int n6 = 0;
                while (n6 < n2) {
                    azc a3;
                    boolean bl2 = !a3.a(nArray, n6, n5, n2, n3);
                    a3.a(wgc.f, arrayList, nArray, n6, n5, n2, n3, bl2);
                    a3.a(wgc.h, arrayList, nArray, n6, n5, n2, n3, bl2);
                    a3.a(wgc.z, arrayList, nArray, n6, n5, n2, n3, bl2);
                    a3.a(wgc.l, arrayList, nArray, n6, n5, n2, n3, bl2);
                    ++n6;
                }
                ++n5;
            }
            ++n4;
        }
        return arrayList;
    }

    private /* synthetic */ void a(wgc a2, List<cqc> a3, int[] a4, int a5, int a6, int a7, int a8, boolean a9) {
        azc a10;
        boolean bl2;
        boolean bl3 = bl2 = a10.a(a4, a5 + a2.p(), a6 + a2.a(), a7, a8) && a9;
        if (bl2) {
            a10.a(a3, a2, a5, a6);
        }
    }

    private /* synthetic */ void a(List<cqc> a2, wgc a3, int a4, int a5) {
        int n2;
        cqc cqc2 = null;
        for (cqc cqc3 : a2) {
            int n3;
            if (cqc3.a() != a3) continue;
            int n4 = n3 = wgc.a(a3) ? a5 : a4;
            if (cqc3.a() != n3) continue;
            cqc2 = cqc3;
            break;
        }
        int n5 = wgc.a(a3) ? a5 : a4;
        int n6 = n2 = wgc.a(a3) ? a4 : a5;
        if (cqc2 == null) {
            a2.add(new cqc(a3, n2, n5));
        } else {
            cqc2.a(n2);
        }
    }

    private /* synthetic */ boolean a(int[] a2, int a3, int a4, int a5, int a6) {
        return a3 >= 0 && a4 >= 0 && a3 < a5 && a4 < a6 ? (a2[a4 * a5 + a3] >> 24 & 0xFF) == 0 : true;
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[wgc.values().length];
        try {
            nArray[wgc.h.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[wgc.z.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[wgc.l.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[wgc.f.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

