/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class coa
extends eu
implements eb {
    protected coa() {
        coa a2;
        a2.a(0.3f, 0.0f, 0.3f, 0.7f, 0.4f, 0.7f);
        a2.a(true);
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        if (a5.nextInt(25) == 0) {
            void var7_11;
            coa a6;
            int n2 = 5;
            int n3 = 4;
            for (tp tp22 : tp.a(a3.a(-4, -1, -4), a3.a(4, 1, 4))) {
                if (a2.a(tp22).a() != a6 || --n2 > 0) continue;
                return;
            }
            tp tp2 = a3.a(a5.nextInt(3) - 1, a5.nextInt(2) - a5.nextInt(2), a5.nextInt(3) - 1);
            int n4 = 0;
            while (n4 < 4) {
                if (a2.a((tp)var7_11) && a6.a(a2, (tp)var7_11, a6.a())) {
                    a3 = var7_11;
                }
                tp tp3 = a3.a(a5.nextInt(3) - 1, a5.nextInt(2) - a5.nextInt(2), a5.nextInt(3) - 1);
                ++n4;
            }
            if (a2.a((tp)var7_11) && a6.a(a2, (tp)var7_11, a6.a())) {
                a2.a((tp)var7_11, a6.a(), 2);
            }
        }
    }

    @Override
    public boolean a(xga a2, tp a3) {
        coa a4;
        return super.a(a2, a3) && a4.a(a2, a3, a4.a());
    }

    @Override
    protected boolean p(yd a2) {
        return a2.n();
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4) {
        if (a3.p() >= 0 && a3.p() < 256) {
            coa a5;
            ba ba2 = a2.a(a3.z());
            return ba2.a() == cl.yb ? true : (ba2.a() == cl.zk && ba2.a(teb.v) == kd.h ? true : a2.y(a3) < 13 && a5.p(ba2.a()));
        }
        return false;
    }

    public boolean a(xga a2, tp a3, ba a4, Random a5) {
        coa a6;
        a2.r(a3);
        wed wed2 = null;
        if (a6 == cl.uj) {
            wed2 = new wed(cl.lc);
        } else if (a6 == cl.vk) {
            wed2 = new wed(cl.rc);
        }
        if (wed2 != null && ((jj)wed2).a(a2, a5, a3)) {
            return true;
        }
        a2.a(a3, a4, 3);
        return false;
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, boolean a5) {
        return true;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4, ba a5) {
        return (double)a3.nextFloat() < 0.4;
    }

    @Override
    public void a(xga a2, Random a3, tp a4, ba a5) {
        coa a6;
        a6.a(a2, a4, a5, a3);
    }
}

