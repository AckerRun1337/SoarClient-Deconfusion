/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ana
extends hf {
    public static final Pattern d = Pattern.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

    public ana() {
        ana a2;
    }

    @Override
    public String a() {
        return "ban-ip";
    }

    @Override
    public int a() {
        return 3;
    }

    @Override
    public boolean a(j a2) {
        ana a3;
        return ccb.a().a().a().a() && super.a(a2);
    }

    @Override
    public String a(j a2) {
        return "commands.banip.usage";
    }

    @Override
    public void a(j a2, String[] a3) throws tqa {
        if (a3.length >= 1 && a3[0].length() > 1) {
            ana a4;
            ga ga2 = a3.length >= 2 ? ana.a(a2, a3, 1) : null;
            Matcher matcher = d.matcher(a3[0]);
            if (matcher.matches()) {
                a4.a(a2, a3[0], ga2 == null ? null : ga2.p());
            } else {
                xj xj2 = ccb.a().a().a(a3[0]);
                if (xj2 == null) {
                    throw new vua("commands.banip.invalid", new Object[0]);
                }
                a4.a(a2, xj2.o(), ga2 == null ? null : ga2.p());
            }
        } else {
            throw new xvb("commands.banip.usage", new Object[0]);
        }
    }

    @Override
    public List<String> a(j a2, String[] a3, tp a4) {
        return a3.length == 1 ? ana.a(a3, ccb.a().a()) : null;
    }

    protected void a(j a2, String a3, String a4) {
        ana a5;
        klc klc2 = new klc(a3, null, a2.a(), null, a4);
        ccb.a().a().a().a(klc2);
        List<xj> list = ccb.a().a().a(a3);
        Object[] objectArray = new String[list.size()];
        int n2 = 0;
        for (xj xj2 : list) {
            xj2.ia.p("You have been IP banned.");
            objectArray[n2++] = xj2.a();
        }
        if (list.isEmpty()) {
            ana.a(a2, (w)a5, "commands.banip.success", a3);
        } else {
            ana.a(a2, (w)a5, "commands.banip.success.players", a3, ana.a(objectArray));
        }
    }
}

