/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cfb
extends kv
implements ab,
t {
    public int i;
    public float n;
    public float e;
    public float r;
    public float f;
    public float h;
    public float z;
    public float l;
    public float b;
    public float c;
    private static Random v = new Random();
    private String d;

    public cfb() {
        cfb a2;
    }

    @Override
    public void a(dgb a2) {
        cfb a3;
        super.a(a2);
        if (a3.p()) {
            a2.a("CustomName", a3.d);
        }
    }

    @Override
    public void p(dgb a2) {
        cfb a3;
        super.p(a2);
        if (a2.a("CustomName", 8)) {
            a3.d = a2.a("CustomName");
        }
    }

    @Override
    public void a() {
        cfb a2;
        a2.z = a2.h;
        a2.b = a2.l;
        pm pm2 = a2.l.a((float)a2.b.o() + 0.5f, (float)a2.b.p() + 0.5f, (double)((float)a2.b.a() + 0.5f), 3.0);
        if (pm2 != null) {
            float f2 = pm2.fb - (double)((float)a2.b.o() + 0.5f);
            double d2 = pm2.db - (double)((float)a2.b.a() + 0.5f);
            a2.c = (float)smb.a(d2, (double)f2);
            a2.h += 0.1f;
            if (a2.h < 0.5f || v.nextInt(40) == 0) {
                float f3 = a2.r;
                do {
                    a2.r += (float)(v.nextInt(4) - v.nextInt(4));
                } while (f3 == a2.r);
            }
        } else {
            a2.c += 0.02f;
            a2.h -= 0.1f;
        }
        while (a2.l >= (float)Math.PI) {
            a2.l -= (float)Math.PI * 2;
        }
        while (a2.l < (float)(-Math.PI)) {
            a2.l += (float)Math.PI * 2;
        }
        while (a2.c >= (float)Math.PI) {
            a2.c -= (float)Math.PI * 2;
        }
        while (a2.c < (float)(-Math.PI)) {
            a2.c += (float)Math.PI * 2;
        }
        float f4 = a2.c - a2.l;
        while (f4 >= (float)Math.PI) {
            f4 -= (float)Math.PI * 2;
        }
        while (f4 < (float)(-Math.PI)) {
            f4 += (float)Math.PI * 2;
        }
        a2.l += f4 * 0.4f;
        a2.h = smb.a(a2.h, 0.0f, 1.0f);
        ++a2.i;
        a2.e = a2.n;
        float f5 = (a2.r - a2.n) * 0.4f;
        float f6 = 0.2f;
        f5 = smb.a(f5, -f6, f6);
        a2.f += (f5 - a2.f) * 0.9f;
        a2.n += a2.f;
    }

    @Override
    public String a() {
        cfb a2;
        return a2.p() ? a2.d : "container.enchant";
    }

    @Override
    public boolean p() {
        cfb a2;
        return a2.d != null && a2.d.length() > 0;
    }

    public void a(String a2) {
        a.d = a2;
    }

    @Override
    public ga a() {
        cfb a2;
        return a2.p() ? new gkb(a2.a()) : new klb(a2.a(), new Object[0]);
    }

    @Override
    public gba a(mnb a2, pm a3) {
        cfb a4;
        return new akd(a2, (xga)a4.l, (tp)a4.b);
    }

    @Override
    public String p() {
        return "minecraft:enchanting_table";
    }
}

