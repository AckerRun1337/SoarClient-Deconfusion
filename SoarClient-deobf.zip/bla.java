/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bla {
    private String l = null;
    private String b = null;
    private wmc c = null;
    private dmb[] v = null;
    private float d = 0.0f;

    public bla(String a2, String a3, wmc a4, dmb[] a5, float a6) {
        bla a7;
        a7.l = a2;
        a7.b = a3;
        a7.c = a4;
        a7.v = a5;
        a7.d = a6;
    }

    public String p() {
        bla a2;
        return a2.l;
    }

    public String a() {
        bla a2;
        return a2.b;
    }

    public wmc a() {
        bla a2;
        return a2.c;
    }

    public dmb[] a() {
        bla a2;
        return a2.v;
    }

    public float a() {
        bla a2;
        return a2.d;
    }
}

