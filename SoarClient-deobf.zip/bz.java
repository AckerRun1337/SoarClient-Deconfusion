/*
 * Decompiled with CFR 0.152.
 */
public class bz
extends kx {
    public Class<? extends dj> b;
    public int c;
    public int v;

    public bz(Class<? extends dj> a2, int a3, int a4, int a5) {
        super(a3);
        bz a6;
        a6.b = a2;
        a6.c = a4;
        a6.v = a5;
    }

    public String toString() {
        bz a2;
        return String.valueOf(a2.b.getSimpleName()) + "*(" + a2.c + "-" + a2.v + "):" + a2.d;
    }
}

