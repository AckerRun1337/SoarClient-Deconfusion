/*
 * Decompiled with CFR 0.152.
 */
public class cxa
extends bib {
    public sfc b;
    public sfc c;
    public sfc v;
    public sfc d;

    public cxa() {
        a2(0.0f);
        cxa a2;
    }

    public cxa(float a2) {
        super(a2, 64, 64);
        cxa a3;
        a3.n = new sfc(a3, 0, 0);
        a3.n.p(-1.0f, -7.0f, -1.0f, 2, 7, 2, a2);
        a3.n.a(0.0f, 0.0f, 0.0f);
        a3.r = new sfc(a3, 0, 26);
        a3.r.p(-6.0f, 0.0f, -1.5f, 12, 3, 3, a2);
        a3.r.a(0.0f, 0.0f, 0.0f);
        a3.f = new sfc(a3, 24, 0);
        a3.f.p(-2.0f, -2.0f, -1.0f, 2, 12, 2, a2);
        a3.f.a(-5.0f, 2.0f, 0.0f);
        a3.h = new sfc(a3, 32, 16);
        a3.h.q = true;
        a3.h.p(0.0f, -2.0f, -1.0f, 2, 12, 2, a2);
        a3.h.a(5.0f, 2.0f, 0.0f);
        a3.z = new sfc(a3, 8, 0);
        a3.z.p(-1.0f, 0.0f, -1.0f, 2, 11, 2, a2);
        a3.z.a(-1.9f, 12.0f, 0.0f);
        a3.l = new sfc(a3, 40, 16);
        a3.l.q = true;
        a3.l.p(-1.0f, 0.0f, -1.0f, 2, 11, 2, a2);
        a3.l.a(1.9f, 12.0f, 0.0f);
        a3.b = new sfc(a3, 16, 0);
        a3.b.p(-3.0f, 3.0f, -1.0f, 2, 7, 2, a2);
        a3.b.a(0.0f, 0.0f, 0.0f);
        a3.b.g = true;
        a3.c = new sfc(a3, 48, 16);
        a3.c.p(1.0f, 3.0f, -1.0f, 2, 7, 2, a2);
        a3.c.a(0.0f, 0.0f, 0.0f);
        a3.v = new sfc(a3, 0, 48);
        a3.v.p(-4.0f, 10.0f, -1.0f, 8, 2, 2, a2);
        a3.v.a(0.0f, 0.0f, 0.0f);
        a3.d = new sfc(a3, 0, 32);
        a3.d.p(-6.0f, 11.0f, -6.0f, 12, 1, 12, a2);
        a3.d.a(0.0f, 12.0f, 0.0f);
    }

    @Override
    public void a(float a2, float a3, float a4, float a5, float a6, float a7, rj a8) {
        cxa a9;
        super.a(a2, a3, a4, a5, a6, a7, a8);
        if (a8 instanceof ioa) {
            ioa ioa2 = (ioa)a8;
            a9.h.g = ioa2.pa();
            a9.f.g = ioa2.pa();
            a9.d.g = !ioa2.wa();
            a9.l.a(1.9f, 12.0f, 0.0f);
            a9.z.a(-1.9f, 12.0f, 0.0f);
            a9.b.j = (float)Math.PI / 180 * ioa2.z().o();
            a9.b.o = (float)Math.PI / 180 * ioa2.z().p();
            a9.b.m = (float)Math.PI / 180 * ioa2.z().a();
            a9.c.j = (float)Math.PI / 180 * ioa2.z().o();
            a9.c.o = (float)Math.PI / 180 * ioa2.z().p();
            a9.c.m = (float)Math.PI / 180 * ioa2.z().a();
            a9.v.j = (float)Math.PI / 180 * ioa2.z().o();
            a9.v.o = (float)Math.PI / 180 * ioa2.z().p();
            a9.v.m = (float)Math.PI / 180 * ioa2.z().a();
            float f2 = (ioa2.p().o() + ioa2.a().o()) / 2.0f;
            float f3 = (ioa2.p().p() + ioa2.a().p()) / 2.0f;
            float f4 = (ioa2.p().a() + ioa2.a().a()) / 2.0f;
            a9.d.j = 0.0f;
            a9.d.o = (float)Math.PI / 180 * -a8.nb;
            a9.d.m = 0.0f;
        }
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        cxa a9;
        super.a(a2, a3, a4, a5, a6, a7, a8);
        ewa.m();
        if (a9.l) {
            float f2 = 2.0f;
            ewa.o(1.0f / f2, 1.0f / f2, 1.0f / f2);
            ewa.p(0.0f, 24.0f * a8, 0.0f);
            a9.b.y(a8);
            a9.c.y(a8);
            a9.v.y(a8);
            a9.d.y(a8);
        } else {
            if (a2.c()) {
                ewa.p(0.0f, 0.2f, 0.0f);
            }
            a9.b.y(a8);
            a9.c.y(a8);
            a9.v.y(a8);
            a9.d.y(a8);
        }
        ewa.h();
    }

    @Override
    public void a(float a2) {
        cxa a3;
        boolean bl2 = a3.f.g;
        a3.f.g = true;
        super.a(a2);
        a3.f.g = bl2;
    }
}

