/*
 * Decompiled with CFR 0.152.
 */
public class bhd
extends bh {
    public bhd() {
        super("FPS Display", 0, gk.l);
        bhd a2;
    }

    @fo
    public void a(thb a2) {
        bhd a3;
        a3.p(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS"))) + 9) : rxb.o.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS"))) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
        if (a3.z()) {
            a3.k.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS")), (float)a3.x() + 4.5f, (float)a3.j() + 4.5f, -1);
        } else {
            rxb.o.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS")), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 4.5f), -1);
        }
        a3.x((int)(rxb.o.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS"))) + 8.0));
        a3.j((int)(rxb.ba.a() + 8.0));
    }

    @fo
    public void a(iw a2) {
        bhd a3;
        a3.a(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS"))) + 9) : rxb.o.a(String.valueOf(new StringBuilder(String.valueOf(oj.a())).append(" FPS"))) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
    }
}

