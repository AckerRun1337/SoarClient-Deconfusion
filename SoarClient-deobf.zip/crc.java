/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class crc {
    private static final Logger v = LogManager.getLogger();
    private final List<joc> d = Collections.synchronizedList(Lists.newArrayList());

    public crc() {
        crc a2;
    }

    public void a(String a2, hcc a3) throws UnknownHostException {
        if (a2 != null && !a2.startsWith("0.0.0.0") && !a2.isEmpty()) {
            crc a4;
            kpa kpa2 = kpa.a(a2);
            joc joc2 = joc.a(InetAddress.getByName(kpa2.a()), kpa2.a(), false);
            a4.d.add(joc2);
            joc2.a(new rja(a4, a3, joc2, a2));
            try {
                joc2.a(new lec(eua.b, kpa2.a(), kpa2.a(), bs.r));
                joc2.a(new eaa());
            }
            catch (Throwable throwable) {
                v.error((Object)throwable);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void p() {
        crc a2;
        List<joc> list = a2.d;
        synchronized (list) {
            Iterator<joc> iterator = a2.d.iterator();
            while (iterator.hasNext()) {
                joc joc2 = iterator.next();
                if (joc2.o()) {
                    joc2.o();
                    continue;
                }
                iterator.remove();
                joc2.a();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a() {
        crc a2;
        List<joc> list = a2.d;
        synchronized (list) {
            Iterator<joc> iterator = a2.d.iterator();
            while (iterator.hasNext()) {
                joc joc2 = iterator.next();
                if (!joc2.o()) continue;
                iterator.remove();
                joc2.a(new gkb("Cancelled"));
            }
        }
    }

    static /* synthetic */ Logger a() {
        return v;
    }
}

