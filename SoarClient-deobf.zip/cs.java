/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class cs
extends rg {
    private static final ba v = cl.ej.a().a(puc.c, cfd.n);
    private static final ba d = cl.de.a().a(ncb.d, cfd.n).a(gdb.l, false);

    public cs(boolean a2) {
        super(a2);
        cs a3;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4) {
        int n2 = a3.nextInt(4) + 6;
        int n3 = 1 + a3.nextInt(2);
        int n4 = n2 - n3;
        int n5 = 2 + a3.nextInt(2);
        boolean bl2 = true;
        if (a4.p() >= 1 && a4.p() + n2 + 1 <= 256) {
            int n6;
            int n7;
            int n8;
            int n9 = a4.p();
            while (n9 <= a4.p() + 1 + n2 && bl2) {
                n8 = 1;
                n8 = n9 - a4.p() < n3 ? 0 : n5;
                qt qt2 = new qt();
                n7 = a4.o() - n8;
                while (n7 <= a4.o() + n8 && bl2) {
                    n6 = a4.a() - n8;
                    while (n6 <= a4.a() + n8 && bl2) {
                        if (n9 >= 0 && n9 < 256) {
                            yd yd2 = a2.a(qt2.a(n7, n9, n6)).a();
                            if (yd2.a() != dr.ua && yd2.a() != dr.ja) {
                                bl2 = false;
                            }
                        } else {
                            bl2 = false;
                        }
                        ++n6;
                    }
                    ++n7;
                }
                ++n9;
            }
            if (!bl2) {
                return false;
            }
            yd yd3 = a2.a(a4.z()).a();
            if ((yd3 == cl.ik || yd3 == cl.zk || yd3 == cl.uh) && a4.p() < 256 - n2 - 1) {
                cs a5;
                a5.a(a2, a4.z());
                n8 = a3.nextInt(2);
                int n10 = 1;
                n7 = 0;
                n6 = 0;
                while (n6 <= n4) {
                    int n11 = a4.p() + n2 - n6;
                    int n12 = a4.o() - n8;
                    while (n12 <= a4.o() + n8) {
                        int n13 = n12 - a4.o();
                        int n14 = a4.a() - n8;
                        while (n14 <= a4.a() + n8) {
                            tp tp2;
                            int n15 = n14 - a4.a();
                            if (!(Math.abs(n13) == n8 && Math.abs(n15) == n8 && n8 > 0 || a2.a(tp2 = new tp(n12, n11, n14)).a().n())) {
                                a5.a(a2, tp2, d);
                            }
                            ++n14;
                        }
                        ++n12;
                    }
                    if (n8 >= n10) {
                        n8 = n7;
                        n7 = 1;
                        if (++n10 > n5) {
                            n10 = n5;
                        }
                    } else {
                        ++n8;
                    }
                    ++n6;
                }
                n6 = a3.nextInt(3);
                int n16 = 0;
                while (n16 < n2 - n6) {
                    yd yd4 = a2.a(a4.j(n16)).a();
                    if (yd4.a() == dr.ua || yd4.a() == dr.ja) {
                        a5.a(a2, a4.j(n16), v);
                    }
                    ++n16;
                }
                return true;
            }
            return false;
        }
        return false;
    }
}

