/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class bdc
implements j {
    final /* synthetic */ qna d;

    bdc(qna a2) {
        bdc a3;
        a3.d = a2;
    }

    @Override
    public String a() {
        return "Sign";
    }

    @Override
    public ga a() {
        bdc a2;
        return new gkb(a2.a());
    }

    @Override
    public void a(ga a2) {
    }

    @Override
    public boolean a(int a2, String a3) {
        return true;
    }

    @Override
    public tp a() {
        bdc a2;
        return a2.d.b;
    }

    @Override
    public tta a() {
        bdc a2;
        return new tta((double)a2.d.b.o() + 0.5, (double)a2.d.b.p() + 0.5, (double)a2.d.b.a() + 0.5);
    }

    @Override
    public xga a() {
        bdc a2;
        return a2.d.l;
    }

    @Override
    public rj a() {
        return null;
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public void a(wtc a2, int a3) {
    }
}

