/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public class axa
extends yd {
    public static final kcb<kja> d = kcb.a("color", kja.class);

    public axa(dr a2) {
        super(a2);
        axa a3;
        a3.a(a3.c.a().a(d, kja.j));
        a3.a(md.g);
    }

    @Override
    public int p(ba a2) {
        return a2.a(d).p();
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        kja[] kjaArray = kja.values();
        int n2 = kjaArray.length;
        int n3 = 0;
        while (n3 < n2) {
            kja kja2 = kjaArray[n3];
            a4.add(new wfc(a2, 1, kja2.p()));
            ++n3;
        }
    }

    @Override
    public rpb a(ba a2) {
        return a2.a(d).a();
    }

    @Override
    public ba a(int a2) {
        axa a3;
        return a3.a().a(d, kja.a(a2));
    }

    @Override
    public int o(ba a2) {
        return a2.a(d).p();
    }

    @Override
    protected lf p() {
        axa a2;
        return new lf(a2, d);
    }
}

