/*
 * Decompiled with CFR 0.152.
 */
public class aha
extends bh {
    private /* synthetic */ kk l;
    public /* synthetic */ String b;
    private /* synthetic */ boolean c;
    private /* synthetic */ boolean v;
    private /* synthetic */ boolean d;

    public aha() {
        super("AutoHypixel", 0, gk.c);
        aha a2;
        a2.l = new kk();
        a2.b = "";
        a2.c = false;
        a2.v = false;
        a2.d = false;
    }

    @Override
    public void y() {
        aha a2;
        gsc.t.w.a(new egd("AutoGG", a2, false));
        gsc.t.w.a(new egd("AutoPlay", a2, false));
        gsc.t.w.a(new egd("Delay", a2, 3.0, 0.0, 5.0, true));
    }

    @Override
    public void o() {
        aha a2;
        a2.c = false;
        a2.v = false;
        a2.l.a();
        super.o();
    }

    @fo
    public void a(zgd a2) {
        aha a3;
        int n2 = (int)gsc.t.w.a(a3, "Delay").o();
        if (!ptc.a()) {
            return;
        }
        if (gsc.t.w.a(a3, "AutoGG").z() && a3.v) {
            a3.g.ob.o("/achat gg");
            a3.v = false;
        }
        if (gsc.t.w.a(a3, "AutoPlay").z()) {
            if (a3.c) {
                if (!a3.d) {
                    a3.d = true;
                    wy.a(au.b, "Auto Hypixel", "Sending you to the next game");
                }
                if (a3.l.a(1000 * n2)) {
                    a3.g.ob.o(a3.b);
                    a3.l.a();
                    a3.c = false;
                    a3.d = false;
                }
            } else {
                a3.l.a();
            }
        }
    }

    @fo
    public void a(xn a2) {
        aha a3;
        a3.c = false;
        a3.v = false;
        a3.l.a();
    }

    @fo
    public void a(aja a2) {
        if (a2.a() instanceof qgc) {
            qgc qgc2 = (qgc)a2.a();
            String string = qgc2.a().p();
            if (string.contains("WINNER!") || string.contains("1st Killer -") || string.contains("Top Survivors")) {
                a.v = true;
            }
            if (string.contains("WINNER!") || string.contains("1st Killer -") || string.contains("Top Survivors") || string.contains("You died!")) {
                a.c = true;
            }
        }
    }

    @fo
    public void a(euc a2) {
        int n2;
        Object object;
        aha a3;
        if (a3.b.startsWith("/play ")) {
            object = a3.b.replace("/play ", "").replace("_", " ");
            boolean bl2 = true;
            char[] cArray = ((String)object).toCharArray();
            int n3 = cArray.length;
            int n4 = 0;
            while (n4 < n3) {
                n2 = cArray[n4];
                if (n2 == 32) {
                    bl2 = true;
                } else if (bl2) {
                    bl2 = false;
                }
                ++n4;
            }
        }
        if (a2.a() instanceof sza) {
            object = (sza)a2.a();
            if (((sza)object).a() == null) {
                return;
            }
            String string = ((sza)object).a().a();
            if (((sza)object).a().a().startsWith("\u00a7a")) {
                n2 = ge.a(((sza)object).a().a());
                if (n2 == 381 || n2 == 368) {
                    if (string.contains("SkyWars")) {
                        if (string.contains("Doubles")) {
                            if (string.contains("Normal")) {
                                a3.b = "/play teams_normal";
                            } else if (string.contains("Insane")) {
                                a3.b = "/play teams_insane";
                            }
                        } else if (string.contains("Solo")) {
                            if (string.contains("Normal")) {
                                a3.b = "/play solo_normal";
                            } else if (string.contains("Insane")) {
                                a3.b = "/play solo_insane";
                            }
                        }
                    }
                } else if (n2 == 355 && string.contains("Bed Wars")) {
                    if (string.contains("4v4")) {
                        a3.b = "/play bedwars_four_four";
                    } else if (string.contains("3v3")) {
                        a3.b = "/play bedwars_four_three";
                    } else if (string.contains("Doubles")) {
                        a3.b = "/play bedwars_eight_two";
                    } else if (string.contains("Solo")) {
                        a3.b = "/play bedwars_eight_one";
                    }
                }
            }
        } else if (a2.a() instanceof in && ((in)(object = (in)a2.a())).a().startsWith("/play")) {
            a3.b = ((in)object).a();
        }
    }
}

