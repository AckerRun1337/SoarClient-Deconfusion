/*
 * Decompiled with CFR 0.152.
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.lang.reflect.Type;

public class dbb
implements o<tb> {
    private static final Gson v = new GsonBuilder().a((Type)((Object)fyc.class), (Object)new wpc()).a((Type)((Object)pfc.class), (Object)new jq()).a((Type)((Object)ahc.class), (Object)new rna()).a(ga.class, (Object)new rs()).a(vib.class, (Object)new jhc()).a(new xqb()).a();
    private ahc d;

    public dbb() {
        dbb a2;
    }

    public dbb(ahc a2) {
        dbb a3;
        a3.d = a2;
    }

    @Override
    public void p(io a2) throws IOException {
        a.d = v.a(a2.a(Short.MAX_VALUE), ahc.class);
    }

    @Override
    public void a(io a2) throws IOException {
        dbb a3;
        a2.a(v.a(a3.d));
    }

    @Override
    public void a(tb a2) {
        dbb a3;
        a2.a(a3);
    }

    public ahc a() {
        dbb a2;
        return a2.d;
    }
}

