/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ccc
extends yd {
    public static final iab z = iab.a("facing", wta.b);
    public static final ewc l = ewc.a("open");
    public static final kcb<bub> b = kcb.a("hinge", bub.class);
    public static final ewc c = ewc.a("powered");
    public static final kcb<nkd> v = kcb.a("half", nkd.class);
    private static volatile /* synthetic */ int[] d;

    protected ccc(dr a2) {
        super(a2);
        ccc a3;
        a3.a(((lf)((Object)a3.c)).a().a(z, hnd.x).a(l, false).a(b, bub.c).a(c, false).a(v, nkd.v));
    }

    @Override
    public String p() {
        ccc a2;
        return bwa.p((String.valueOf(a2.a()) + ".name").replaceAll("tile", "item"));
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean a(cb a2, tp a3) {
        return ccc.o(ccc.o(a2, a3));
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public tca a(xga a2, tp a3) {
        ccc a4;
        a4.a((cb)a2, a3);
        return super.a(a2, a3);
    }

    @Override
    public tca a(xga a2, tp a3, ba a4) {
        ccc a5;
        a5.a((cb)a2, a3);
        return super.a(a2, a3, a4);
    }

    @Override
    public void a(cb a2, tp a3) {
        ccc a4;
        a4.a(ccc.o(a2, a3));
    }

    private /* synthetic */ void a(int a2) {
        ccc a3;
        a3.a(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 1.0f);
        hnd hnd2 = ccc.a(a2);
        boolean bl2 = ccc.o(a2);
        boolean bl3 = ccc.a(a2);
        switch (ccc.a()[hnd2.ordinal()]) {
            case 6: {
                if (bl2) {
                    if (bl3) {
                        a3.a(0.0f, 0.0f, 0.8125f, 1.0f, 1.0f, 1.0f);
                        break;
                    }
                    a3.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.1875f);
                    break;
                }
                a3.a(0.0f, 0.0f, 0.0f, 0.1875f, 1.0f, 1.0f);
                break;
            }
            case 4: {
                if (bl2) {
                    if (bl3) {
                        a3.a(0.0f, 0.0f, 0.0f, 0.1875f, 1.0f, 1.0f);
                        break;
                    }
                    a3.a(0.8125f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                    break;
                }
                a3.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.1875f);
                break;
            }
            case 5: {
                if (bl2) {
                    if (bl3) {
                        a3.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.1875f);
                        break;
                    }
                    a3.a(0.0f, 0.0f, 0.8125f, 1.0f, 1.0f, 1.0f);
                    break;
                }
                a3.a(0.8125f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 3: {
                if (bl2) {
                    if (bl3) {
                        a3.a(0.8125f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                        break;
                    }
                    a3.a(0.0f, 0.0f, 0.0f, 0.1875f, 1.0f, 1.0f);
                    break;
                }
                a3.a(0.0f, 0.0f, 0.8125f, 1.0f, 1.0f, 1.0f);
            }
        }
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, pm a5, hnd a6, float a7, float a8, float a9) {
        ba ba2;
        ccc a10;
        if (a10.z == dr.ha) {
            return true;
        }
        tp tp2 = a4.a(v) == nkd.v ? a3 : a3.z();
        ba ba3 = ba2 = a3.equals(tp2) ? a4 : a2.a(tp2);
        if (ba2.a() != a10) {
            return false;
        }
        a4 = ba2.a(l);
        a2.a(tp2, a4, 2);
        a2.a(tp2, a3);
        a2.a(a5, a4.a(l) != false ? 1003 : 1006, a3, 0);
        return true;
    }

    public void a(xga a2, tp a3, boolean a4) {
        ccc a5;
        ba ba2 = a2.a(a3);
        if (ba2.a() == a5) {
            ba ba3;
            tp tp2 = ba2.a(v) == nkd.v ? a3 : a3.z();
            ba ba4 = ba3 = a3 == tp2 ? ba2 : a2.a(tp2);
            if (ba3.a() == a5 && ba3.a(l) != a4) {
                a2.a(tp2, ba3.a(l, a4), 2);
                a2.a(tp2, a3);
                a2.a(null, a4 ? 1003 : 1006, a3, 0);
            }
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        ccc a6;
        if (a4.a(v) == nkd.c) {
            tp tp2 = a3.z();
            ba ba2 = a2.a(tp2);
            if (ba2.a() != a6) {
                a2.r(a3);
            } else if (a5 != a6) {
                a6.a(a2, tp2, ba2, a5);
            }
        } else {
            boolean bl2 = false;
            tp tp3 = a3.j();
            ba ba3 = a2.a(tp3);
            if (ba3.a() != a6) {
                a2.r(a3);
                bl2 = true;
            }
            if (!xga.a(a2, a3.z())) {
                a2.r(a3);
                bl2 = true;
                if (ba3.a() == a6) {
                    a2.r(tp3);
                }
            }
            if (bl2) {
                if (!a2.f) {
                    a6.a(a2, a3, a4, 0);
                }
            } else {
                boolean bl3;
                boolean bl4 = bl3 = a2.y(a3) || a2.y(tp3);
                if ((bl3 || a5.x()) && a5 != a6 && bl3 != ba3.a(c)) {
                    a2.a(tp3, ba3.a(c, bl3), 2);
                    if (bl3 != a4.a(l)) {
                        a2.a(a3, a4.a(l, bl3), 2);
                        a2.a(a3, a3);
                        a2.a(null, bl3 ? 1003 : 1006, a3, 0);
                    }
                }
            }
        }
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        ccc a5;
        return a2.a(v) == nkd.c ? null : a5.a();
    }

    @Override
    public lwa a(xga a2, tp a3, tta a4, tta a5) {
        ccc a6;
        a6.a((cb)a2, a3);
        return super.a(a2, a3, a4, a5);
    }

    @Override
    public boolean a(xga a2, tp a3) {
        ccc a4;
        return a3.p() >= 255 ? false : xga.a(a2, a3.z()) && super.a(a2, a3) && super.a(a2, a3.j());
    }

    @Override
    public int a() {
        return 1;
    }

    public static int o(cb a2, tp a3) {
        ba ba2 = a2.a(a3);
        int n2 = ba2.a().o(ba2);
        boolean bl2 = ccc.p(n2);
        ba ba3 = a2.a(a3.z());
        int n3 = ba3.a().o(ba3);
        int n4 = bl2 ? n3 : n2;
        ba ba4 = a2.a(a3.j());
        int n5 = ba4.a().o(ba4);
        int n6 = bl2 ? n2 : n5;
        boolean bl3 = (n6 & 1) != 0;
        boolean bl4 = (n6 & 2) != 0;
        return ccc.a(n4) | (bl2 ? 8 : 0) | (bl3 ? 16 : 0) | (bl4 ? 32 : 0);
    }

    @Override
    public ge a(xga a2, tp a3) {
        ccc a4;
        return a4.a();
    }

    private /* synthetic */ ge a() {
        ccc a2;
        return a2 == cl.hh ? sxa.dg : (a2 == cl.ao ? sxa.sf : (a2 == cl.ni ? sxa.un : (a2 == cl.lm ? sxa.kf : (a2 == cl.hk ? sxa.di : (a2 == cl.hf ? sxa.ne : sxa.ae)))));
    }

    @Override
    public void a(xga a2, tp a3, ba a4, pm a5) {
        ccc a6;
        tp tp2 = a3.z();
        if (a5.y.b && a4.a(v) == nkd.c && a2.a(tp2).a() == a6) {
            a2.r(tp2);
        }
    }

    @Override
    public hdc a() {
        return hdc.b;
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        ccc a5;
        if (a2.a(v) == nkd.v) {
            ba ba2 = a3.a(a4.j());
            if (ba2.a() == a5) {
                a2 = a2.a(b, ba2.a(b)).a(c, ba2.a(c));
            }
        } else {
            ba ba3 = a3.a(a4.z());
            if (ba3.a() == a5) {
                a2 = a2.a(z, ba3.a(z)).a(l, ba3.a(l));
            }
        }
        return a2;
    }

    @Override
    public ba a(int a2) {
        ccc a3;
        return (a2 & 8) > 0 ? a3.a().a(v, nkd.c).a(b, (a2 & 1) > 0 ? bub.v : bub.c).a(c, (a2 & 2) > 0) : a3.a().a(v, nkd.v).a(z, hnd.a(a2 & 3).a()).a(l, (a2 & 4) > 0);
    }

    @Override
    public int o(ba a2) {
        int n2 = 0;
        if (a2.a(v) == nkd.c) {
            n2 |= 8;
            if (a2.a(b) == bub.v) {
                n2 |= 1;
            }
            if (a2.a(c).booleanValue()) {
                n2 |= 2;
            }
        } else {
            n2 |= a2.a(z).y().y();
            if (a2.a(l).booleanValue()) {
                n2 |= 4;
            }
        }
        return n2;
    }

    protected static int a(int a2) {
        return a2 & 7;
    }

    public static boolean p(cb a2, tp a3) {
        return ccc.o(ccc.o(a2, a3));
    }

    public static hnd a(cb a2, tp a3) {
        return ccc.a(ccc.o(a2, a3));
    }

    public static hnd a(int a2) {
        return hnd.a(a2 & 3).a();
    }

    protected static boolean o(int a2) {
        return (a2 & 4) != 0;
    }

    protected static boolean p(int a2) {
        return (a2 & 8) != 0;
    }

    protected static boolean a(int a2) {
        return (a2 & 0x10) != 0;
    }

    @Override
    protected lf p() {
        ccc a2;
        return new lf(a2, v, z, l, b, c);
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[hnd.values().length];
        try {
            nArray[hnd.g.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.s.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.x.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.t.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.k.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.p.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

