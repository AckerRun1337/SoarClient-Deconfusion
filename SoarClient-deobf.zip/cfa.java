/*
 * Decompiled with CFR 0.152.
 */
public class cfa
extends xk<etc> {
    private static final wmc v = new wmc("textures/entity/lead_knot.png");
    private sua d = new sua();

    public cfa(gub a2) {
        super(a2);
        cfa a3;
    }

    @Override
    public void a(etc a2, double a3, double a4, double a5, float a6, float a7) {
        cfa a8;
        ewa.m();
        ewa.v();
        ewa.p((float)a3, (float)a4, (float)a5);
        float f2 = 0.0625f;
        ewa.r();
        ewa.o(-1.0f, -1.0f, 1.0f);
        ewa.ta();
        a8.a(a2);
        a8.d.a(a2, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, f2);
        ewa.h();
        super.y(a2, a3, a4, a5, a6, a7);
    }

    @Override
    protected wmc a(etc a2) {
        return v;
    }
}

