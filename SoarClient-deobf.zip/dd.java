/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class dd {
    protected int c = 8;
    protected Random v = new Random();
    protected xga d;

    public dd() {
        dd a2;
    }

    public void a(c a2, xga a3, int a4, int a5, qic a6) {
        dd a7;
        int n2 = a7.c;
        a7.d = a3;
        a7.v.setSeed(a3.o());
        long l2 = a7.v.nextLong();
        long l3 = a7.v.nextLong();
        int n3 = a4 - n2;
        while (n3 <= a4 + n2) {
            int n4 = a5 - n2;
            while (n4 <= a5 + n2) {
                long l4 = (long)n3 * l2;
                long l5 = (long)n4 * l3;
                a7.v.setSeed(l4 ^ l5 ^ a3.o());
                a7.a(a3, n3, n4, a4, a5, a6);
                ++n4;
            }
            ++n3;
        }
    }

    protected void a(xga a2, int a3, int a4, int a5, int a6, qic a7) {
    }
}

