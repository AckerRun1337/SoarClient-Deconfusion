/*
 * Decompiled with CFR 0.152.
 */
class asb
extends it {
    final /* synthetic */ ssb d;

    asb(ssb a2, ll a3) {
        asb a4;
        a4.d = a2;
        super(a3);
    }

    @Override
    protected void a() {
        a.e = new rd(0.5f, true);
        a.r = new rd(1.0f, true);
    }
}

