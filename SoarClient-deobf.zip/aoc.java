/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aoc
extends yd {
    public static final ewc f = ewc.a("powered");
    public static final ewc h = ewc.a("suspended");
    public static final ewc z = ewc.a("attached");
    public static final ewc l = ewc.a("disarmed");
    public static final ewc b = ewc.a("north");
    public static final ewc c = ewc.a("east");
    public static final ewc v = ewc.a("south");
    public static final ewc d = ewc.a("west");

    public aoc() {
        super(dr.u);
        aoc a2;
        a2.a(((lf)((Object)a2.c)).a().a(f, false).a(h, false).a(z, false).a(l, false).a(b, false).a(c, false).a(v, false).a(d, false));
        a2.a(0.0f, 0.0f, 0.0f, 1.0f, 0.15625f, 1.0f);
        a2.a(true);
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        return a2.a(b, aoc.a(a3, a4, a2, hnd.x)).a(c, aoc.a(a3, a4, a2, hnd.s)).a(v, aoc.a(a3, a4, a2, hnd.t)).a(d, aoc.a(a3, a4, a2, hnd.p));
    }

    @Override
    public tca a(xga a2, tp a3, ba a4) {
        return null;
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public hdc a() {
        return hdc.c;
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return sxa.vk;
    }

    @Override
    public ge a(xga a2, tp a3) {
        return sxa.vk;
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        boolean bl2;
        boolean bl3 = a4.a(h);
        boolean bl4 = bl2 = !xga.a(a2, a3.z());
        if (bl3 != bl2) {
            aoc a6;
            a6.a(a2, a3, a4, 0);
            a2.r(a3);
        }
    }

    @Override
    public void a(cb a2, tp a3) {
        aoc a4;
        ba ba2 = a2.a(a3);
        boolean bl2 = ba2.a(z);
        boolean bl3 = ba2.a(h);
        if (!bl3) {
            a4.a(0.0f, 0.0f, 0.0f, 1.0f, 0.09375f, 1.0f);
        } else if (!bl2) {
            a4.a(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
        } else {
            a4.a(0.0f, 0.0625f, 0.0f, 1.0f, 0.15625f, 1.0f);
        }
    }

    @Override
    public void p(xga a2, tp a3, ba a4) {
        aoc a5;
        a4 = a4.a(h, !xga.a(a2, a3.z()));
        a2.a(a3, a4, 3);
        a5.y(a2, a3, a4);
    }

    @Override
    public void a(xga a2, tp a3, ba a4) {
        aoc a5;
        a5.y(a2, a3, a4.a(f, true));
    }

    @Override
    public void a(xga a2, tp a3, ba a4, pm a5) {
        if (!a2.f && a5.p() != null && a5.p().a() == sxa.oc) {
            a2.a(a3, a4.a(l, true), 4);
        }
    }

    private /* synthetic */ void y(xga a2, tp a3, ba a4) {
        hnd[] hndArray = new hnd[]{hnd.t, hnd.p};
        int n2 = hndArray.length;
        int n3 = 0;
        while (n3 < n2) {
            hnd hnd2 = hndArray[n3];
            int n4 = 1;
            while (n4 < 42) {
                tp tp2 = a3.a(hnd2, n4);
                ba ba2 = a2.a(tp2);
                if (ba2.a() == cl.aa) {
                    if (ba2.a(xha.l) != hnd2.z()) break;
                    cl.aa.a(a2, tp2, ba2, false, true, n4, a4);
                    break;
                }
                if (ba2.a() != cl.za) break;
                ++n4;
            }
            ++n3;
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, rj a5) {
        if (!a2.f && !a4.a(f).booleanValue()) {
            aoc a6;
            a6.p(a2, a3);
        }
    }

    @Override
    public void o(xga a2, tp a3, ba a4, Random a5) {
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        if (!a2.f && a2.a(a3).a(f).booleanValue()) {
            aoc a6;
            a6.p(a2, a3);
        }
    }

    private /* synthetic */ void p(xga a2, tp a3) {
        aoc a4;
        ba ba2 = a2.a(a3);
        boolean bl2 = ba2.a(f);
        boolean bl3 = false;
        List<rj> list = a2.a((rj)null, new tca((double)a3.o() + a4.s, (double)a3.p() + a4.w, (double)a3.a() + a4.i, (double)a3.o() + a4.n, (double)a3.p() + a4.e, (double)a3.a() + a4.r));
        if (!list.isEmpty()) {
            for (rj rj2 : list) {
                if (rj2.d()) continue;
                bl3 = true;
                break;
            }
        }
        if (bl3 != bl2) {
            ba2 = ba2.a(f, bl3);
            a2.a(a3, ba2, 3);
            a4.y(a2, a3, ba2);
        }
        if (bl3) {
            a2.a(a3, (yd)a4, a4.a(a2));
        }
    }

    public static boolean a(cb a2, tp a3, ba a4, hnd a5) {
        tp tp2 = a3.a(a5);
        ba ba2 = a2.a(tp2);
        yd yd2 = ba2.a();
        if (yd2 == cl.aa) {
            hnd hnd2 = a5.z();
            return ba2.a(xha.l) == hnd2;
        }
        if (yd2 == cl.za) {
            boolean bl2;
            boolean bl3 = a4.a(h);
            return bl3 == (bl2 = ba2.a(h).booleanValue());
        }
        return false;
    }

    @Override
    public ba a(int a2) {
        aoc a3;
        return a3.a().a(f, (a2 & 1) > 0).a(h, (a2 & 2) > 0).a(z, (a2 & 4) > 0).a(l, (a2 & 8) > 0);
    }

    @Override
    public int o(ba a2) {
        int n2 = 0;
        if (a2.a(f).booleanValue()) {
            n2 |= 1;
        }
        if (a2.a(h).booleanValue()) {
            n2 |= 2;
        }
        if (a2.a(z).booleanValue()) {
            n2 |= 4;
        }
        if (a2.a(l).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    protected lf p() {
        aoc a2;
        return new lf(a2, f, h, z, l, b, c, d, v);
    }
}

