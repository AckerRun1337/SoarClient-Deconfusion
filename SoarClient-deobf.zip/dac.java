/*
 * Decompiled with CFR 0.152.
 */
class dac
implements sb {
    final /* synthetic */ kp d;

    dac(kp a2) {
        dac a3;
        a3.d = a2;
    }

    @Override
    public yjc a(wfc a2) {
        return sca.p(a2.y()) ? new yjc("bottle_splash", "inventory") : new yjc("bottle_drinkable", "inventory");
    }
}

