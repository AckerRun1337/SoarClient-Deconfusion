/*
 * Decompiled with CFR 0.152.
 */
class acb
implements bb {
    acb() {
        acb a2;
    }

    @Override
    public int a(ba a2, cb a3, tp a4) {
        nk nk2 = lha.a(a3, a4);
        return lha.z() != null && nk2 == nk.zb ? lha.z().o(nk2, a4) : nk2.p(a4);
    }

    @Override
    public boolean a() {
        return false;
    }
}

