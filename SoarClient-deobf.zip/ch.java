/*
 * Decompiled with CFR 0.152.
 */
import org.lwjgl.input.Mouse;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ch {
    protected final oj o;
    protected int m;
    protected int y;
    protected int a;
    protected int q;
    protected int g;
    protected int k;
    protected final int x;
    private int t;
    private int p;
    protected int s;
    protected int w;
    protected boolean i = true;
    protected int n = -2;
    protected float e;
    protected float r;
    protected int f = -1;
    protected long h;
    protected boolean z = true;
    protected boolean l = true;
    protected boolean b;
    protected int c;
    private boolean v = true;
    private fgb d = new fgb(0.0f);

    public ch(oj a2, int a3, int a4, int a5, int a6, int a7) {
        ch a8;
        a8.o = a2;
        a8.m = a3;
        a8.y = a4;
        a8.a = a5;
        a8.q = a6;
        a8.x = a7;
        a8.k = 0;
        a8.g = a3;
    }

    public void o(int a2, int a3, int a4, int a5) {
        a.m = a2;
        a.y = a3;
        a.a = a4;
        a.q = a5;
        a.k = 0;
        a.g = a2;
    }

    public void p(boolean a2) {
        a.l = a2;
    }

    protected void a(boolean a2, int a3) {
        a.b = a2;
        a.c = a3;
        if (!a2) {
            a.c = 0;
        }
    }

    protected abstract int x();

    protected abstract void a(int var1, boolean var2, int var3, int var4);

    protected abstract boolean p(int var1);

    protected int j() {
        ch a2;
        return a2.x() * a2.x + a2.c;
    }

    protected abstract void o();

    protected void a(int a2, int a3, int a4) {
    }

    protected abstract void a(int var1, int var2, int var3, int var4, int var5, int var6);

    protected void a(int a2, int a3, xlb a4) {
    }

    protected void o(int a2, int a3) {
    }

    protected void p(int a2, int a3) {
    }

    public int a(int a2, int a3) {
        ch a4;
        int n2 = a4.k + a4.m / 2 - a4.o() / 2;
        int n3 = a4.k + a4.m / 2 + a4.o() / 2;
        int n4 = a3 - a4.a - a4.c + (int)a4.r - 4;
        int n5 = n4 / a4.x;
        return a2 < a4.p() && a2 >= n2 && a2 <= n3 && n5 >= 0 && n4 >= 0 && n5 < a4.x() ? n5 : -1;
    }

    public void a(int a2, int a3) {
        a.t = a2;
        a.p = a3;
    }

    protected void p() {
        ch a2;
        a2.r = smb.a(a2.r, 0.0f, (float)a2.z());
    }

    public int z() {
        ch a2;
        return Math.max(0, a2.j() - (a2.q - a2.a - 4));
    }

    public int y() {
        ch a2;
        return (int)a2.r;
    }

    public boolean a(int a2) {
        ch a3;
        return a2 >= a3.a && a2 <= a3.q && a3.s >= a3.k && a3.s <= a3.g;
    }

    public void p(int a2) {
        ch a3;
        a3.r += (float)a2;
        a3.p();
        a3.n = -2;
    }

    public void a(ff a2) {
        if (a2.c) {
            ch a3;
            if (a2.b == a3.t) {
                a3.r -= (float)(a3.x * 2 / 3);
                a3.n = -2;
                a3.p();
            } else if (a2.b == a3.p) {
                a3.r += (float)(a3.x * 2 / 3);
                a3.n = -2;
                a3.p();
            }
        }
    }

    public void a(int a2, int a3, float a4) {
        ch a5;
        if (a5.z) {
            a5.d.a(a5.r, 16.0);
            a5.s = a2;
            a5.w = a3;
            a5.o();
            int n2 = a5.p();
            int n3 = n2 + 6;
            a5.p();
            ewa.ka();
            ewa.s();
            xlb xlb2 = xlb.a();
            krb krb2 = xlb2.a();
            a5.a(xlb2);
            int n4 = a5.k + a5.m / 2 - a5.o() / 2 + 2;
            int n5 = a5.a + 4 - (int)a5.d.a();
            if (a5.b) {
                a5.a(n4, n5, xlb2);
            }
            a5.p(n4, n5, a2, a3);
            ewa.ua();
            int n6 = 4;
            a5.a(0, a5.a, 255, 255);
            a5.a(a5.q, a5.y, 255, 255);
            ewa.w();
            ewa.z(770, 771, 0, 1);
            ewa.fa();
            ewa.x(7425);
            ewa.c();
            krb2.a(7, ybd.e);
            krb2.a((double)a5.k, (double)(a5.a + n6), 0.0).a(0.0, 1.0).a(0, 0, 0, 0).z();
            krb2.a((double)a5.g, (double)(a5.a + n6), 0.0).a(1.0, 1.0).a(0, 0, 0, 0).z();
            krb2.a((double)a5.g, (double)a5.a, 0.0).a(1.0, 0.0).a(0, 0, 0, 255).z();
            krb2.a((double)a5.k, (double)a5.a, 0.0).a(0.0, 0.0).a(0, 0, 0, 255).z();
            xlb2.a();
            krb2.a(7, ybd.e);
            krb2.a((double)a5.k, (double)a5.q, 0.0).a(0.0, 1.0).a(0, 0, 0, 255).z();
            krb2.a((double)a5.g, (double)a5.q, 0.0).a(1.0, 1.0).a(0, 0, 0, 255).z();
            krb2.a((double)a5.g, (double)(a5.q - n6), 0.0).a(1.0, 0.0).a(0, 0, 0, 0).z();
            krb2.a((double)a5.k, (double)(a5.q - n6), 0.0).a(0.0, 0.0).a(0, 0, 0, 0).z();
            xlb2.a();
            int n7 = a5.z();
            if (n7 > 0) {
                int n8 = (a5.q - a5.a) * (a5.q - a5.a) / a5.j();
                n8 = smb.p(n8, 32, a5.q - a5.a - 8);
                int n9 = (int)a5.d.a() * (a5.q - a5.a - n8) / n7 + a5.a;
                if (n9 < a5.a) {
                    n9 = a5.a;
                }
                krb2.a(7, ybd.e);
                krb2.a((double)n2, (double)a5.q, 0.0).a(0.0, 1.0).a(0, 0, 0, 255).z();
                krb2.a((double)n3, (double)a5.q, 0.0).a(1.0, 1.0).a(0, 0, 0, 255).z();
                krb2.a((double)n3, (double)a5.a, 0.0).a(1.0, 0.0).a(0, 0, 0, 255).z();
                krb2.a((double)n2, (double)a5.a, 0.0).a(0.0, 0.0).a(0, 0, 0, 255).z();
                xlb2.a();
                krb2.a(7, ybd.e);
                krb2.a((double)n2, (double)(n9 + n8), 0.0).a(0.0, 1.0).a(128, 128, 128, 255).z();
                krb2.a((double)n3, (double)(n9 + n8), 0.0).a(1.0, 1.0).a(128, 128, 128, 255).z();
                krb2.a((double)n3, (double)n9, 0.0).a(1.0, 0.0).a(128, 128, 128, 255).z();
                krb2.a((double)n2, (double)n9, 0.0).a(0.0, 0.0).a(128, 128, 128, 255).z();
                xlb2.a();
                krb2.a(7, ybd.e);
                krb2.a((double)n2, (double)(n9 + n8 - 1), 0.0).a(0.0, 1.0).a(192, 192, 192, 255).z();
                krb2.a((double)(n3 - 1), (double)(n9 + n8 - 1), 0.0).a(1.0, 1.0).a(192, 192, 192, 255).z();
                krb2.a((double)(n3 - 1), (double)n9, 0.0).a(1.0, 0.0).a(192, 192, 192, 255).z();
                krb2.a((double)n2, (double)n9, 0.0).a(0.0, 0.0).a(192, 192, 192, 255).z();
                xlb2.a();
            }
            a5.p(a2, a3);
            ewa.e();
            ewa.x(7424);
            ewa.ta();
            ewa.b();
        }
    }

    public void a() {
        ch a2;
        if (a2.a(a2.w)) {
            int n2;
            int n3;
            int n4;
            int n5;
            if (Mouse.r() == 0 && Mouse.y() && a2.w >= a2.a && a2.w <= a2.q) {
                n5 = (a2.m - a2.o()) / 2;
                n4 = (a2.m + a2.o()) / 2;
                n3 = a2.w - a2.a - a2.c + (int)a2.r - 4;
                n2 = n3 / a2.x;
                if (n2 < a2.x() && a2.s >= n5 && a2.s <= n4 && n2 >= 0 && n3 >= 0) {
                    a2.a(n2, false, a2.s, a2.w);
                    a2.f = n2;
                } else if (a2.s >= n5 && a2.s <= n4 && n3 < 0) {
                    a2.o(a2.s - n5, a2.w - a2.a + (int)a2.r - 4);
                }
            }
            if (Mouse.a(0) && a2.a()) {
                if (a2.n != -1) {
                    if (a2.n >= 0) {
                        a2.r -= (float)(a2.w - a2.n) * a2.e;
                        a2.n = a2.w;
                    }
                } else {
                    n5 = 1;
                    if (a2.w >= a2.a && a2.w <= a2.q) {
                        int n6;
                        n4 = (a2.m - a2.o()) / 2;
                        n3 = (a2.m + a2.o()) / 2;
                        n2 = a2.w - a2.a - a2.c + (int)a2.r - 4;
                        int n7 = n2 / a2.x;
                        if (n7 < a2.x() && a2.s >= n4 && a2.s <= n3 && n7 >= 0 && n2 >= 0) {
                            n6 = n7 == a2.f && oj.a() - a2.h < 250L ? 1 : 0;
                            a2.a(n7, n6 != 0, a2.s, a2.w);
                            a2.f = n7;
                            a2.h = oj.a();
                        } else if (a2.s >= n4 && a2.s <= n3 && n2 < 0) {
                            a2.o(a2.s - n4, a2.w - a2.a + (int)a2.r - 4);
                            n5 = 0;
                        }
                        n6 = a2.p();
                        int n8 = n6 + 6;
                        if (a2.s >= n6 && a2.s <= n8) {
                            a2.e = -1.0f;
                            int n9 = a2.z();
                            if (n9 < 1) {
                                n9 = 1;
                            }
                            int n10 = (int)((float)((a2.q - a2.a) * (a2.q - a2.a)) / (float)a2.j());
                            n10 = smb.p(n10, 32, a2.q - a2.a - 8);
                            a2.e /= (float)(a2.q - a2.a - n10) / (float)n9;
                        } else {
                            a2.e = 1.0f;
                        }
                        a2.n = n5 != 0 ? a2.w : -2;
                    } else {
                        a2.n = -2;
                    }
                }
            } else {
                a2.n = -1;
            }
            if ((n5 = Mouse.x()) != 0) {
                if (n5 > 0) {
                    n5 = -1;
                } else if (n5 < 0) {
                    n5 = 1;
                }
                a2.r += (float)(n5 * a2.x / 2);
            }
        }
    }

    public void a(boolean a2) {
        a.v = a2;
    }

    public boolean a() {
        ch a2;
        return a2.v;
    }

    public int o() {
        return 220;
    }

    protected void p(int a2, int a3, int a4, int a5) {
        ch a6;
        int n2 = a6.x();
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        int n3 = 0;
        while (n3 < n2) {
            int n4 = a3 + n3 * a6.x + a6.c;
            int n5 = a6.x - 4;
            if (n4 > a6.q || n4 + n5 < a6.a) {
                a6.a(n3, a2, n4);
            }
            if (a6.l && a6.p(n3)) {
                int n6 = a6.k + (a6.m / 2 - a6.o() / 2);
                int n7 = a6.k + a6.m / 2 + a6.o() / 2;
                ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
                ewa.c();
                krb2.a(7, ybd.e);
                krb2.a((double)n6, (double)(n4 + n5 + 2), 0.0).a(0.0, 1.0).a(128, 128, 128, 255).z();
                krb2.a((double)n7, (double)(n4 + n5 + 2), 0.0).a(1.0, 1.0).a(128, 128, 128, 255).z();
                krb2.a((double)n7, (double)(n4 - 2), 0.0).a(1.0, 0.0).a(128, 128, 128, 255).z();
                krb2.a((double)n6, (double)(n4 - 2), 0.0).a(0.0, 0.0).a(128, 128, 128, 255).z();
                krb2.a((double)(n6 + 1), (double)(n4 + n5 + 1), 0.0).a(0.0, 1.0).a(0, 0, 0, 255).z();
                krb2.a((double)(n7 - 1), (double)(n4 + n5 + 1), 0.0).a(1.0, 1.0).a(0, 0, 0, 255).z();
                krb2.a((double)(n7 - 1), (double)(n4 - 1), 0.0).a(1.0, 0.0).a(0, 0, 0, 255).z();
                krb2.a((double)(n6 + 1), (double)(n4 - 1), 0.0).a(0.0, 0.0).a(0, 0, 0, 255).z();
                xlb2.a();
                ewa.e();
            }
            if (!(a6 instanceof wda) || n4 >= a6.a - a6.x && n4 <= a6.q) {
                a6.a(n3, a2, n4, n5, a4, a5);
            }
            ++n3;
        }
    }

    protected int p() {
        ch a2;
        return a2.m / 2 + 124;
    }

    protected void a(int a2, int a3, int a4, int a5) {
        ch a6;
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        a6.o.a().p(xf.b);
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        float f2 = 32.0f;
        krb2.a(7, ybd.e);
        krb2.a((double)a6.k, (double)a3, 0.0).a(0.0, (float)a3 / 32.0f).a(64, 64, 64, a5).z();
        krb2.a((double)(a6.k + a6.m), (double)a3, 0.0).a((float)a6.m / 32.0f, (float)a3 / 32.0f).a(64, 64, 64, a5).z();
        krb2.a((double)(a6.k + a6.m), (double)a2, 0.0).a((float)a6.m / 32.0f, (float)a2 / 32.0f).a(64, 64, 64, a4).z();
        krb2.a((double)a6.k, (double)a2, 0.0).a(0.0, (float)a2 / 32.0f).a(64, 64, 64, a4).z();
        xlb2.a();
    }

    public void a(int a2) {
        ch a3;
        a3.k = a2;
        a3.g = a2 + a3.m;
    }

    public int a() {
        ch a2;
        return a2.x;
    }

    protected void a(xlb a2) {
        ch a3;
        krb krb2 = a2.a();
        a3.o.a().p(xf.b);
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        float f2 = 32.0f;
        krb2.a(7, ybd.e);
        krb2.a((double)a3.k, (double)a3.q, 0.0).a((float)a3.k / f2, (float)(a3.q + (int)a3.r) / f2).a(32, 32, 32, 255).z();
        krb2.a((double)a3.g, (double)a3.q, 0.0).a((float)a3.g / f2, (float)(a3.q + (int)a3.r) / f2).a(32, 32, 32, 255).z();
        krb2.a((double)a3.g, (double)a3.a, 0.0).a((float)a3.g / f2, (float)(a3.a + (int)a3.r) / f2).a(32, 32, 32, 255).z();
        krb2.a((double)a3.k, (double)a3.a, 0.0).a((float)a3.k / f2, (float)(a3.a + (int)a3.r) / f2).a(32, 32, 32, 255).z();
        a2.a();
    }
}

