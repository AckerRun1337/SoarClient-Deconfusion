/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.LinkedHashMap;

class cza
extends rq {
    final /* synthetic */ rhc d;

    cza(rhc a2) {
        cza a3;
        a3.d = a2;
    }

    @Override
    protected yjc a(ba a2) {
        cza a3;
        LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(a2.a());
        if (a2.a(cuc.v) != hnd.k) {
            linkedHashMap.remove(cuc.c);
        }
        return new yjc((wmc)yd.ma.p(a2.a()), a3.a(linkedHashMap));
    }
}

