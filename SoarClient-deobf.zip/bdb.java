/*
 * Decompiled with CFR 0.152.
 */
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;

public class bdb
implements qa {
    public bdb() {
        bdb a2;
    }

    @Override
    public Field a() {
        bdb a2;
        Class<oj> clazz = oj.class;
        Field field = a2.p();
        if (field == null) {
            xfc.o("(Reflector) Field not present: " + clazz.getName() + ".actionKeyF3 (field renderChunksMany not found)");
            return null;
        }
        Field field2 = lma.a(oj.class, field, Boolean.TYPE, 0);
        if (field2 == null) {
            xfc.o("(Reflector) Field not present: " + clazz.getName() + ".actionKeyF3");
            return null;
        }
        return field2;
    }

    private /* synthetic */ Field p() {
        oj oj2 = oj.a();
        boolean bl2 = oj2.f;
        Field[] fieldArray = oj.class.getDeclaredFields();
        oj2.f = true;
        Field[] fieldArray2 = lma.a((Object)oj2, fieldArray, Boolean.TYPE, (Object)Boolean.TRUE);
        oj2.f = false;
        Field[] fieldArray3 = lma.a((Object)oj2, fieldArray, Boolean.TYPE, (Object)Boolean.FALSE);
        oj2.f = bl2;
        HashSet<Field> hashSet = new HashSet<Field>(Arrays.asList(fieldArray2));
        HashSet<Field> hashSet2 = new HashSet<Field>(Arrays.asList(fieldArray3));
        HashSet<Field> hashSet3 = new HashSet<Field>(hashSet);
        hashSet3.retainAll(hashSet2);
        Field[] fieldArray4 = hashSet3.toArray(new Field[hashSet3.size()]);
        return fieldArray4.length != 1 ? null : fieldArray4[0];
    }
}

