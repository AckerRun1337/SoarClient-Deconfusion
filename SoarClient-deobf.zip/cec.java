/*
 * Decompiled with CFR 0.152.
 */
public class cec
extends rdc {
    public cec(xga a2) {
        super(a2);
        cec a3;
        a3.y(0.9f, 1.3f);
        a3.c = cl.yb;
    }

    @Override
    public boolean a(pm a2) {
        cec a3;
        wfc wfc2 = a2.ob.p();
        if (wfc2 != null && wfc2.a() == sxa.rh && a3.c() >= 0) {
            if (wfc2.e == 1) {
                a2.ob.a(a2.ob.b, new wfc(sxa.ui));
                return true;
            }
            if (a2.ob.p(new wfc(sxa.ui)) && !a2.y.b) {
                a2.ob.a(a2.ob.b, 1);
                return true;
            }
        }
        if (wfc2 != null && wfc2.a() == sxa.oc && a3.c() >= 0) {
            a3.g();
            a3.ib.a(wra.wa, a3.fb, a3.zb + (double)(a3.ua / 2.0f), a3.db, 0.0, 0.0, 0.0, new int[0]);
            if (!a3.ib.f) {
                rdc rdc2 = new rdc(a3.ib);
                rdc2.p(a3.fb, a3.zb, a3.db, a3.nb, a3.rb);
                rdc2.j(a3.a());
                rdc2.wa = a3.wa;
                if (a3.p()) {
                    rdc2.a(a3.y());
                }
                a3.ib.a(rdc2);
                int n2 = 0;
                while (n2 < 5) {
                    a3.ib.a(new xsc(a3.ib, a3.fb, a3.zb + (double)a3.ua, a3.db, new wfc(cl.vk)));
                    ++n2;
                }
                wfc2.a(1, (xi)a2);
                a3.a("mob.sheep.shear", 1.0f, 1.0f);
            }
            return true;
        }
        return super.a(a2);
    }

    @Override
    public cec a(oe a2) {
        cec a3;
        return new cec(a3.ib);
    }

    @Override
    public /* synthetic */ rdc a(oe a2) {
        cec a3;
        return a3.a(a2);
    }

    @Override
    public /* synthetic */ oe a(oe a2) {
        cec a3;
        return a3.a(a2);
    }
}

