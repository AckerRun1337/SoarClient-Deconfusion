/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class caa
extends lr {
    public caa() {
        caa a2;
    }

    public caa(xga a2, Random a3, int a4, int a5) {
        super(a4, a5);
        caa a6;
        nk nk2 = a2.a(new tp(a4 * 16 + 8, 0, a5 * 16 + 8));
        if (nk2 != nk.sa && nk2 != nk.ea) {
            if (nk2 == nk.zb) {
                wob wob2 = new wob(a3, a4 * 16, a5 * 16);
                a6.b.add(wob2);
            } else if (nk2 == nk.sb || nk2 == nk.za) {
                nwb nwb2 = new nwb(a3, a4 * 16, a5 * 16);
                a6.b.add(nwb2);
            }
        } else {
            sdc sdc2 = new sdc(a3, a4 * 16, a5 * 16);
            a6.b.add(sdc2);
        }
        a6.a();
    }
}

