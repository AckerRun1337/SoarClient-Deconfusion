/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ComparisonChain
 */
import com.google.common.collect.ComparisonChain;
import java.util.Comparator;

class cgb
implements Comparator<mjb> {
    private /* synthetic */ cgb() {
        cgb a2;
    }

    public int a(mjb a2, mjb a3) {
        fhb fhb2 = a2.a();
        fhb fhb3 = a3.a();
        return ComparisonChain.start().compareTrueFirst(a2.a() != lq.b, a3.a() != lq.b).compare((Comparable)((Object)(fhb2 != null ? fhb2.a() : "")), (Comparable)((Object)(fhb3 != null ? fhb3.a() : ""))).compare((Comparable)((Object)a2.a().getName()), (Comparable)((Object)a3.a().getName())).result();
    }

    @Override
    public /* synthetic */ int compare(Object a2, Object a3) {
        cgb a4;
        return a4.a((mjb)a2, (mjb)a3);
    }

    /* synthetic */ cgb(cgb a2) {
        a3();
        cgb a3;
    }
}

