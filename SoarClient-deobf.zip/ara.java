/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ara
extends ff {
    private float f = 1.0f;
    public boolean h;
    private String z;
    private final float l;
    private final float b;
    private final nl c;
    private ke v;
    private fgb d;

    public ara(nl a2, int a3, int a4, int a5, String a6, float a7, float a8, float a9, ke a10) {
        super(a3, a4, a5, 150, 20, "");
        ara a11;
        a11.z = a6;
        a11.l = a7;
        a11.b = a8;
        a11.f = (a9 - a7) / (a8 - a7);
        a11.v = a10;
        a11.c = a2;
        a11.l = (float)a11.a();
        a11.d = new fgb(a11.f);
    }

    public float p() {
        ara a2;
        return a2.l + (a2.b - a2.l) * a2.f;
    }

    public void a(float a2, boolean a3) {
        ara a4;
        a4.f = (a2 - a4.l) / (a4.b - a4.l);
        a4.l = (float)a4.a();
        if (a3) {
            a4.c.a((int)a4.b, a4.p());
        }
    }

    public float a() {
        ara a2;
        return a2.f;
    }

    private /* synthetic */ String a() {
        ara a2;
        return a2.v == null ? String.valueOf(xab.a(a2.z, new Object[0])) + ": " + a2.p() : a2.v.a((int)a2.b, xab.a(a2.z, new Object[0]), a2.p());
    }

    @Override
    protected int a(boolean a2) {
        return 0;
    }

    @Override
    protected void a(oj a2, int a3, int a4) {
        ara a5;
        if (a5.v != false) {
            if (a5.h) {
                a5.f = (float)(a3 - (a5.h + 4)) / (float)(a5.r - 8);
                if (a5.f < 0.0f) {
                    a5.f = 0.0f;
                }
                if (a5.f > 1.0f) {
                    a5.f = 1.0f;
                }
                a5.l = (float)a5.a();
                a5.c.a((int)a5.b, a5.p());
            }
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            a5.d.a(a5.f, 12.0);
            a5.a(a5.h + (int)(a5.d.a() * (float)(a5.r - 8)), (int)a5.z, 0, 66, 4, 20);
            a5.a(a5.h + (int)(a5.d.a() * (float)(a5.r - 8)) + 4, (int)a5.z, 196, 66, 4, 20);
        }
    }

    public void a(float a2) {
        ara a3;
        a3.f = a2;
        a3.l = (float)a3.a();
        a3.c.a((int)a3.b, a3.p());
    }

    @Override
    public boolean a(oj a2, int a3, int a4) {
        ara a5;
        if (super.a(a2, a3, a4)) {
            a5.f = (float)(a3 - (a5.h + 4)) / (float)(a5.r - 8);
            if (a5.f < 0.0f) {
                a5.f = 0.0f;
            }
            if (a5.f > 1.0f) {
                a5.f = 1.0f;
            }
            a5.l = (float)a5.a();
            a5.c.a((int)a5.b, a5.p());
            a5.h = true;
            return true;
        }
        return false;
    }

    @Override
    public void p(int a2, int a3) {
        a.h = false;
    }
}

