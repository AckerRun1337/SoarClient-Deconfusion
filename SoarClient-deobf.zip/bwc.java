/*
 * Decompiled with CFR 0.152.
 */
public class bwc
extends iu {
    public bwc(yd a2) {
        super(a2);
        bwc a3;
    }

    @Override
    public int a(int a2) {
        return 7;
    }
}

