/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 */
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cga<T extends rj>
extends mi {
    private final Predicate<rj> e;
    protected sj r;
    private double f;
    private double h;
    protected T z;
    private float l;
    private zjb b;
    private qta c;
    private Class<T> v;
    private Predicate<? super T> d;

    public cga(sj a2, Class<T> a3, float a4, double a5, double a6) {
        a7(a2, a3, Predicates.alwaysTrue(), a4, a5, a6);
        cga<T> a7;
    }

    public cga(sj a2, Class<T> a3, Predicate<? super T> a4, float a5, double a6, double a7) {
        cga a8;
        a8.e = new ypc(a8);
        a8.r = a2;
        a8.v = a3;
        a8.d = a4;
        a8.l = a5;
        a8.f = a6;
        a8.h = a7;
        a8.c = a2.a();
        a8.a(1);
    }

    @Override
    public boolean o() {
        cga a2;
        Predicate predicate = a2.r.ib.a(a2.v, a2.r.a().o(a2.l, 3.0, a2.l), Predicates.and((Predicate[])new Predicate[]{fm.d, a2.e, a2.d}));
        if (predicate.isEmpty()) {
            return false;
        }
        a2.z = (rj)predicate.get(0);
        tta tta2 = yg.p(a2.r, 16, 7, new tta(((rj)a2.z).fb, ((rj)a2.z).zb, ((rj)a2.z).db));
        if (tta2 == null) {
            return false;
        }
        if (((rj)a2.z).p(tta2.c, tta2.v, tta2.d) < ((rj)a2.z).a((rj)a2.r)) {
            return false;
        }
        a2.b = a2.c.a(tta2.c, tta2.v, tta2.d);
        return a2.b == null ? false : a2.b.a(tta2);
    }

    @Override
    public boolean p() {
        cga a2;
        return !a2.c.o();
    }

    @Override
    public void o() {
        cga a2;
        a2.c.a(a2.b, a2.f);
    }

    @Override
    public void p() {
        a.z = null;
    }

    @Override
    public void a() {
        cga a2;
        if (a2.r.a((rj)a2.z) < 49.0) {
            a2.r.a().a(a2.h);
        } else {
            a2.r.a().a(a2.f);
        }
    }
}

