/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aya
extends zxa {
    private float l = 1.0f;
    public boolean b;
    private hya d = null;

    public aya(int a2, int a3, int a4, int a5, int a6, hya a7, String a8) {
        super(a2, a3, a4, a5, a6, a7, a8);
        aya a9;
        a9.d = a7;
        a9.l = a7.a();
        a9.l = (float)jl.a(a7, a9.r);
    }

    @Override
    protected int a(boolean a2) {
        return 0;
    }

    @Override
    protected void a(oj a2, int a3, int a4) {
        aya a5;
        if (a5.v) {
            if (a5.b && !en.p()) {
                a5.l = (float)(a3 - (a5.h + 4)) / (float)(a5.r - 8);
                a5.l = smb.a(a5.l, 0.0f, 1.0f);
                a5.d.a(a5.l);
                a5.l = a5.d.a();
                a5.l = (float)jl.a(a5.d, a5.r);
            }
            a2.a().p(e);
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            a5.a(a5.h + (int)(a5.l * (float)(a5.r - 8)), a5.z, 0, 66, 4, 20);
            a5.a(a5.h + (int)(a5.l * (float)(a5.r - 8)) + 4, a5.z, 196, 66, 4, 20);
        }
    }

    @Override
    public boolean a(oj a2, int a3, int a4) {
        aya a5;
        if (super.a(a2, a3, a4)) {
            a5.l = (float)(a3 - (a5.h + 4)) / (float)(a5.r - 8);
            a5.l = smb.a(a5.l, 0.0f, 1.0f);
            a5.d.a(a5.l);
            a5.l = (float)jl.a(a5.d, a5.r);
            a5.b = true;
            return true;
        }
        return false;
    }

    @Override
    public void p(int a2, int a3) {
        a.b = false;
    }

    @Override
    public void a() {
        aya a2;
        a2.l = a2.d.a();
    }

    @Override
    public boolean p() {
        return false;
    }
}

