/*
 * Decompiled with CFR 0.152.
 */
import java.awt.image.BufferedImage;
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cbc
extends sla {
    private final int[] c;
    private final int v;
    private final int d;

    public cbc(BufferedImage a2) {
        a3(a2.getWidth(), a2.getHeight());
        cbc a3;
        a2.getRGB(0, 0, a2.getWidth(), a2.getHeight(), a3.c, 0, a2.getWidth());
        a3.a();
    }

    public cbc(int a2, int a3) {
        cbc a4;
        a4.v = a2;
        a4.d = a3;
        a4.c = new int[a2 * a3];
        zjc.a(a4.a(), a2, a3);
    }

    @Override
    public void a(fa a2) throws IOException {
    }

    public void a() {
        cbc a2;
        zjc.a(a2.a(), a2.c, a2.v, a2.d);
    }

    public int[] a() {
        cbc a2;
        return a2.c;
    }
}

