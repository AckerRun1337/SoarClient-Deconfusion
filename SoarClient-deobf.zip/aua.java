/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public class aua
extends ge {
    public aua() {
        aua a2;
        a2.a(true);
        a2.a(0);
        a2.a(md.r);
    }

    @Override
    public String o(wfc a2) {
        return a2.y() == 1 ? "item.charcoal" : "item.coal";
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        a4.add(new wfc(a2, 1, 0));
        a4.add(new wfc(a2, 1, 1));
    }
}

