/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class bab
implements Callable<String> {
    final /* synthetic */ cbd v;
    private final /* synthetic */ int d;

    bab(cbd a2, int a3) {
        bab a4;
        a4.v = a2;
        a4.d = a3;
    }

    public String a() throws Exception {
        bab a2;
        String string = "Once per " + a2.d + " ticks";
        if (a2.d == Integer.MAX_VALUE) {
            string = "Maximum (" + string + ")";
        }
        return string;
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        bab a2;
        return a2.a();
    }
}

