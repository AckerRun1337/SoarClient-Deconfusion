/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.UUID;

public class blc
extends zm
implements n {
    private static final UUID b = UUID.fromString("5CD17E52-A79A-43D3-A529-90FDE04B181E");
    private static final rob c = new rob(b, "Drinking speed penalty", -0.25, 0).a(false);
    private static final ge[] v = new ge[]{sxa.bc, sxa.xc, sxa.yd, sxa.nb, sxa.wb, sxa.do, sxa.yk, sxa.yk};
    private int d;

    public blc(xga a2) {
        super(a2);
        blc a3;
        a3.y(0.6f, 1.95f);
        a3.s.a(1, new nhd(a3));
        a3.s.a(2, new jba(a3, 1.0, 60, 10.0f));
        a3.s.a(2, new fva(a3, 1.0));
        a3.s.a(3, new yi(a3, pm.class, 8.0f));
        a3.s.a(3, new nia(a3));
        a3.w.a(1, new kab((sj)a3, false, new Class[0]));
        a3.w.a(2, new iva<pm>((sj)a3, pm.class, true));
    }

    @Override
    protected void v() {
        blc a2;
        super.v();
        a2.a().p(21, (byte)0);
    }

    @Override
    protected String m() {
        return null;
    }

    @Override
    protected String h() {
        return null;
    }

    @Override
    protected String p() {
        return null;
    }

    public void q(boolean a2) {
        blc a3;
        a3.a().a(21, Byte.valueOf((byte)(a2 ? 1 : 0)));
    }

    public boolean la() {
        blc a2;
        return a2.a().a(21) == 1;
    }

    @Override
    protected void ma() {
        blc a2;
        super.ma();
        a2.a(prc.l).a(26.0);
        a2.a(prc.v).a(0.25);
    }

    @Override
    public void w() {
        blc a2;
        if (!a2.ib.f) {
            if (a2.la()) {
                if (a2.d-- <= 0) {
                    List<ihd> list;
                    a2.q(false);
                    wfc wfc2 = a2.a();
                    a2.p(0, null);
                    if (wfc2 != null && wfc2.a() == sxa.gb && (list = sxa.gb.a(wfc2)) != null) {
                        for (ihd ihd2 : list) {
                            a2.o(new ihd(ihd2));
                        }
                    }
                    a2.a(prc.v).a(c);
                }
            } else {
                int n2 = -1;
                if (a2.oa.nextFloat() < 0.15f && a2.a(dr.ca) && !a2.a(ira.la)) {
                    n2 = 8237;
                } else if (a2.oa.nextFloat() < 0.15f && a2.i() && !a2.a(ira.ba)) {
                    n2 = 16307;
                } else if (a2.oa.nextFloat() < 0.05f && a2.a() < a2.p()) {
                    n2 = 16341;
                } else if (a2.oa.nextFloat() < 0.25f && a2.y() != null && !a2.a(ira.na) && a2.y().a((rj)a2) > 121.0) {
                    n2 = 16274;
                } else if (a2.oa.nextFloat() < 0.25f && a2.y() != null && !a2.a(ira.na) && a2.y().a((rj)a2) > 121.0) {
                    n2 = 16274;
                }
                if (n2 > -1) {
                    a2.p(0, new wfc(sxa.gb, 1, n2));
                    a2.d = a2.a().p();
                    a2.q(true);
                    pb pb2 = a2.a(prc.v);
                    pb2.a(c);
                    pb2.p(c);
                }
            }
            if (a2.oa.nextFloat() < 7.5E-4f) {
                a2.ib.a((rj)a2, (byte)15);
            }
        }
        super.w();
    }

    @Override
    public void a(byte a2) {
        blc a3;
        if (a2 == 15) {
            int n2 = 0;
            while (n2 < a3.oa.nextInt(35) + 10) {
                a3.ib.a(wra.ia, a3.fb + a3.oa.nextGaussian() * (double)0.13f, a3.a().v + 0.5 + a3.oa.nextGaussian() * (double)0.13f, a3.db + a3.oa.nextGaussian() * (double)0.13f, 0.0, 0.0, 0.0, new int[0]);
                ++n2;
            }
        } else {
            super.a(a2);
        }
    }

    @Override
    protected float a(sy a2, float a3) {
        blc a4;
        a3 = super.a(a2, a3);
        if (a2.a() == a4) {
            a3 = 0.0f;
        }
        if (a2.p()) {
            a3 = (float)((double)a3 * 0.15);
        }
        return a3;
    }

    @Override
    protected void a(boolean a2, int a3) {
        blc a4;
        int n2 = a4.oa.nextInt(3) + 1;
        int n3 = 0;
        while (n3 < n2) {
            int n4 = a4.oa.nextInt(3);
            ge ge2 = v[a4.oa.nextInt(v.length)];
            if (a3 > 0) {
                n4 += a4.oa.nextInt(a3 + 1);
            }
            int n5 = 0;
            while (n5 < n4) {
                a4.a(ge2, 1);
                ++n5;
            }
            ++n3;
        }
    }

    @Override
    public void a(xi a2, float a3) {
        blc a4;
        if (!a4.la()) {
            fub fub2 = new fub(a4.ib, (xi)a4, 32732);
            float f2 = a2.zb + (double)a2.o() - (double)1.1f;
            fub2.rb -= -20.0f;
            int n2 = a2.fb + a2.mb - a4.fb;
            float f3 = f2 - a4.zb;
            float f4 = a2.db + a2.wb - a4.db;
            float f5 = smb.a((double)(n2 * n2 + f4 * f4));
            if (f5 >= 8.0f && !a2.a(ira.ka)) {
                fub2.x(32698);
            } else if (a2.a() >= 8.0f && !a2.a(ira.a)) {
                fub2.x(32660);
            } else if (f5 <= 3.0f && !a2.a(ira.y) && a4.oa.nextFloat() < 0.25f) {
                fub2.x(32696);
            }
            fub2.a((double)n2, (double)(f3 + (double)(f5 * 0.2f)), (double)f4, 0.75f, 8.0f);
            a4.ib.a(fub2);
        }
    }

    @Override
    public float o() {
        return 1.62f;
    }
}

