/*
 * Decompiled with CFR 0.152.
 */
public class bt
extends bh {
    public bt() {
        super("FPS Limiter", 0, gk.v);
        bt a2;
    }
}

