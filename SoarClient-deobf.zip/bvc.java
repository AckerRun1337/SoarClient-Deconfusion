/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bvc {
    private static final bvc c = new bvc();
    private Random v = new Random();
    private String[] d = "the elder scrolls klaatu berata niktu xyzzy bless curse light darkness fire air earth water hot dry cold wet ignite snuff embiggen twist shorten stretch fiddle destroy imbue galvanize enchant free limited range of towards inside sphere cube self other ball mental physical grow shrink demon elemental spirit animal creature beast humanoid undead fresh stale ".split(" ");

    public bvc() {
        bvc a2;
    }

    public static bvc a() {
        return c;
    }

    public String a() {
        bvc a2;
        int n2 = a2.v.nextInt(2) + 3;
        String string = "";
        int n3 = 0;
        while (n3 < n2) {
            if (n3 > 0) {
                string = String.valueOf(string) + " ";
            }
            string = String.valueOf(string) + a2.d[a2.v.nextInt(a2.d.length)];
            ++n3;
        }
        return string;
    }

    public void a(long a2) {
        bvc a3;
        a3.v.setSeed(a2);
    }
}

