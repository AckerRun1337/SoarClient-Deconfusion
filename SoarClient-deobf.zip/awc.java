/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;
import net.optifine.util.\u5c2d\u837b\u679a\u8f44\u67a0\u4faf\u7aea\u6e8c\u6a4b\u8d70\u932f\u77ef\u6749\u96e8\u626e\u515c\u92f3\u830e\u7984\u5de8\u6d66\u58a8\u5553\u9edb\u4f4e\u7a17\u4fb6\u5404\u970a\u6d45\u4e19\u6291\u67ff\u5446\u51b7\u50cd\u6ce1\u6f2c\u9084\u7d4c;
import net.optifine.util.\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class awc {
    private static glc v = null;
    private static final Random d = new Random();

    public awc() {
        awc a2;
    }

    public static glc a() {
        return v;
    }

    public static void a() {
        v = null;
        String[] stringArray = awc.a();
        if (stringArray.length > 1) {
            glc glc2;
            Properties[] propertiesArray = awc.a(stringArray);
            int[] nArray = awc.a(propertiesArray);
            int n2 = awc.a(nArray);
            String string = stringArray[n2];
            Properties properties = propertiesArray[n2];
            if (properties == null) {
                properties = propertiesArray[0];
            }
            if (properties == null) {
                properties = new \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a();
            }
            v = glc2 = new glc(string, properties);
        }
    }

    private static /* synthetic */ String[] a() {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("textures/gui/title/background");
        int n2 = 0;
        while (n2 < 100) {
            String string = "optifine/gui/background" + n2;
            String string2 = String.valueOf(string) + "/panorama_0.png";
            wmc wmc2 = new wmc(string2);
            if (xfc.p(wmc2)) {
                arrayList.add(string);
            }
            ++n2;
        }
        String[] stringArray = arrayList.toArray(new String[arrayList.size()]);
        return stringArray;
    }

    private static /* synthetic */ Properties[] a(String[] a2) {
        Properties[] propertiesArray = new Properties[a2.length];
        int n2 = 0;
        while (n2 < a2.length) {
            String string = a2[n2];
            if (n2 == 0) {
                string = "optifine/gui";
            } else {
                xfc.j("CustomPanorama: " + string);
            }
            wmc wmc2 = new wmc(String.valueOf(string) + "/background.properties");
            try {
                InputStream inputStream = xfc.a(wmc2);
                if (inputStream != null) {
                    \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2 = new \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a();
                    \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2.load(inputStream);
                    xfc.j("CustomPanorama: " + wmc2.p());
                    propertiesArray[n2] = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2;
                    inputStream.close();
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
            ++n2;
        }
        return propertiesArray;
    }

    private static /* synthetic */ int[] a(Properties[] a2) {
        int[] nArray = new int[a2.length];
        int n2 = 0;
        while (n2 < nArray.length) {
            Properties properties = a2[n2];
            if (properties == null) {
                properties = a2[0];
            }
            if (properties == null) {
                nArray[n2] = 1;
            } else {
                String string = properties.getProperty("weight", null);
                nArray[n2] = xfc.a(string, 1);
            }
            ++n2;
        }
        return nArray;
    }

    private static /* synthetic */ int a(int[] a2) {
        int n2 = \u5c2d\u837b\u679a\u8f44\u67a0\u4faf\u7aea\u6e8c\u6a4b\u8d70\u932f\u77ef\u6749\u96e8\u626e\u515c\u92f3\u830e\u7984\u5de8\u6d66\u58a8\u5553\u9edb\u4f4e\u7a17\u4fb6\u5404\u970a\u6d45\u4e19\u6291\u67ff\u5446\u51b7\u50cd\u6ce1\u6f2c\u9084\u7d4c.a(a2);
        int n3 = d.nextInt(n2);
        int n4 = 0;
        int n5 = 0;
        while (n5 < a2.length) {
            if ((n4 += a2[n5]) > n3) {
                return n5;
            }
            ++n5;
        }
        return a2.length - 1;
    }
}

