/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class abb
extends jj {
    public abb() {
        abb a2;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4) {
        int n2 = 0;
        while (n2 < 64) {
            tp tp2 = a4.a(a3.nextInt(8) - a3.nextInt(8), a3.nextInt(4) - a3.nextInt(4), a3.nextInt(8) - a3.nextInt(8));
            if (a2.a(tp2) && a2.a(tp2.z()).a() == cl.zc) {
                a2.a(tp2, cl.ef.a(), 2);
            }
            ++n2;
        }
        return true;
    }
}

