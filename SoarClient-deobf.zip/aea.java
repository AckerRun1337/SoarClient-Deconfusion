/*
 * Decompiled with CFR 0.152.
 */
public class aea
extends yh {
    private static final wmc l = new wmc("textures/gui/container/furnace.png");
    private final mnb v;
    private zb d;

    public aea(mnb a2, zb a3) {
        super(new jfc(a2, a3));
        aea a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    protected void p(int a2, int a3) {
        aea a4;
        String string = a4.d.a().p();
        a4.z.a(string, a4.ta / 2 - a4.z.a(string) / 2, 6, 0x404040);
        a4.z.a(a4.v.a().p(), 8, a4.oa - 96 + 2, 0x404040);
    }

    @Override
    protected void a(float a2, int a3, int a4) {
        int n2;
        aea a5;
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        a5.w.a().p(l);
        int n3 = (n - a5.ta) / 2;
        int n4 = (e - a5.oa) / 2;
        a5.a(n3, n4, 0, 0, a5.ta, a5.oa);
        if (evb.a(a5.d)) {
            n2 = a5.a(13);
            a5.a(n3 + 56, n4 + 36 + 12 - n2, 176, 12 - n2, 14, n2 + 1);
        }
        n2 = a5.p(24);
        a5.a(n3 + 79, n4 + 34, 176, 14, n2 + 1, 16);
    }

    private /* synthetic */ int p(int a2) {
        aea a3;
        int n2 = a3.d.a(2);
        int n3 = a3.d.a(3);
        return n3 != 0 && n2 != 0 ? n2 * a2 / n3 : 0;
    }

    private /* synthetic */ int a(int a2) {
        aea a3;
        int n2 = a3.d.a(1);
        if (n2 == 0) {
            n2 = 200;
        }
        return a3.d.a(0) * a2 / n2;
    }
}

