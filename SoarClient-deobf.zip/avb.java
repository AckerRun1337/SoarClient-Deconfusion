/*
 * Decompiled with CFR 0.152.
 */
public class avb
extends nk {
    public avb(int a2) {
        super(a2);
        avb a3;
        a3.n.clear();
        a3.e.clear();
        a3.r.clear();
        a3.f.clear();
        a3.n.add(new bz(cnb.class, 10, 4, 4));
        a3.q = cl.zk.a();
        a3.g = cl.zk.a();
        a3.i = new aeb();
    }

    @Override
    public int a(float a2) {
        return 0;
    }
}

