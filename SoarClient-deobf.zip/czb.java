/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class czb
extends hf {
    public czb() {
        czb a2;
    }

    @Override
    public String a() {
        return "stats";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String a(j a2) {
        return "commands.stats.usage";
    }

    @Override
    public void a(j a2, String[] a3) throws tqa {
        czb a4;
        hva hva2;
        Object object;
        Object object2;
        wtc wtc2;
        int n2;
        boolean bl2;
        if (a3.length < 1) {
            throw new xvb("commands.stats.usage", new Object[0]);
        }
        if (a3[0].equals("entity")) {
            bl2 = false;
        } else {
            if (!a3[0].equals("block")) {
                throw new xvb("commands.stats.usage", new Object[0]);
            }
            bl2 = true;
        }
        if (bl2) {
            if (a3.length < 5) {
                throw new xvb("commands.stats.block.usage", new Object[0]);
            }
            n2 = 4;
        } else {
            if (a3.length < 3) {
                throw new xvb("commands.stats.entity.usage", new Object[0]);
            }
            n2 = 2;
        }
        String string = a3[n2++];
        if ("set".equals(string)) {
            if (a3.length < n2 + 3) {
                if (n2 == 5) {
                    throw new xvb("commands.stats.block.set.usage", new Object[0]);
                }
                throw new xvb("commands.stats.entity.set.usage", new Object[0]);
            }
        } else {
            if (!"clear".equals(string)) {
                throw new xvb("commands.stats.usage", new Object[0]);
            }
            if (a3.length < n2 + 1) {
                if (n2 == 5) {
                    throw new xvb("commands.stats.block.clear.usage", new Object[0]);
                }
                throw new xvb("commands.stats.entity.clear.usage", new Object[0]);
            }
        }
        if ((wtc2 = wtc.a(a3[n2++])) == null) {
            throw new tqa("commands.stats.failed", new Object[0]);
        }
        xga xga2 = a2.a();
        if (bl2) {
            object2 = czb.a(a2, a3, 1, false);
            object = xga2.a((tp)object2);
            if (object == null) {
                throw new tqa("commands.stats.noCompatibleBlock", ((vx)object2).o(), ((vx)object2).p(), ((vx)object2).a());
            }
            if (object instanceof jw) {
                hva2 = ((jw)object).a();
            } else {
                if (!(object instanceof qna)) {
                    throw new tqa("commands.stats.noCompatibleBlock", ((vx)object2).o(), ((vx)object2).p(), ((vx)object2).a());
                }
                hva2 = ((qna)object).a();
            }
        } else {
            object2 = czb.a(a2, a3[1]);
            hva2 = ((rj)object2).a();
        }
        if ("set".equals(string)) {
            object2 = a3[n2++];
            object = a3[n2];
            if (((String)object2).length() == 0 || ((String)object).length() == 0) {
                throw new tqa("commands.stats.failed", new Object[0]);
            }
            hva.a(hva2, wtc2, (String)object2, (String)object);
            czb.a(a2, (w)a4, "commands.stats.success", wtc2.a(), object, object2);
        } else if ("clear".equals(string)) {
            hva.a(hva2, wtc2, null, null);
            czb.a(a2, (w)a4, "commands.stats.cleared", wtc2.a());
        }
        if (bl2) {
            object2 = czb.a(a2, a3, 1, false);
            object = xga2.a((tp)object2);
            ((kv)object).o();
        }
    }

    @Override
    public List<String> a(j a2, String[] a3, tp a4) {
        czb a5;
        return a3.length == 1 ? czb.a(a3, "entity", "block") : (a3.length == 2 && a3[0].equals("entity") ? czb.a(a3, a5.a()) : (a3.length >= 2 && a3.length <= 4 && a3[0].equals("block") ? czb.p(a3, 1, a4) : (!(a3.length == 3 && a3[0].equals("entity") || a3.length == 5 && a3[0].equals("block")) ? (!(a3.length == 4 && a3[0].equals("entity") || a3.length == 6 && a3[0].equals("block")) ? (!(a3.length == 6 && a3[0].equals("entity") || a3.length == 8 && a3[0].equals("block")) ? null : czb.a(a3, a5.p())) : czb.a(a3, wtc.a())) : czb.a(a3, "set", "clear"))));
    }

    protected String[] a() {
        return ccb.a().a();
    }

    protected List<String> p() {
        Collection<kxa> collection = ccb.a().a(0).a().z();
        ArrayList arrayList = Lists.newArrayList();
        for (kxa kxa2 : collection) {
            if (kxa2.a().a()) continue;
            arrayList.add(kxa2.p());
        }
        return arrayList;
    }

    @Override
    public boolean a(String[] a2, int a3) {
        return a2.length > 0 && a2[0].equals("entity") && a3 == 1;
    }
}

