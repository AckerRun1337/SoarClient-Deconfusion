/*
 * Decompiled with CFR 0.152.
 */
public class ayb
extends xu {
    public ayb() {
        super(uea.class, "zombie", 0.5f);
        ayb a2;
    }

    @Override
    public qm a() {
        return new lh();
    }

    @Override
    public h a(qm a2, float a3) {
        gub gub2 = oj.a().a();
        dib dib2 = new dib(gub2);
        xk.a(dib2, (dk)a2);
        dib2.k = a2;
        dib2.b = (dk)a3;
        return dib2;
    }
}

