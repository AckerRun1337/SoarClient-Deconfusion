/*
 * Decompiled with CFR 0.152.
 */
import java.util.Collection;

public class af
extends bh {
    protected /* synthetic */ float b;
    private /* synthetic */ int c;
    private /* synthetic */ int v;
    private /* synthetic */ boolean d;

    public af() {
        super("PotionStatus", 0, gk.l);
        af a2;
        a2.v = 0;
    }

    @fo
    public void a(thb a2) {
        af a3;
        int n2 = 21;
        int n3 = 14;
        int n4 = 16;
        int n5 = a3.x();
        int n6 = a3.j();
        Collection<ihd> collection = a3.g.ob.a();
        if (a3.g.sb instanceof qsa) {
            a3.p(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a("Regeneration") + 29) : rxb.o.a("Regeneration") + 29.0), 50.0f);
            ira ira2 = ira.na;
            ira ira3 = ira.oa;
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            a3.g.a().p(new wmc("textures/gui/container/inventory.png"));
            int n7 = ira2.p();
            int n8 = ira3.p();
            ewa.w();
            a3.a(n5 + n2 - 17, n6 + n4 - n3 + 2, 0 + n7 % 8 * 18, 198 + n7 / 8 * 18, 18, 18);
            a3.a(n5 + n2 - 17, n6 + n4 - (n3 - 24) + 2, 0 + n8 % 8 * 18, 198 + n7 / 8 * 18, 18, 18);
            if (a3.z()) {
                a3.k.a("Speed", (float)(n5 + n2 + 3), (float)(n6 + n4 - n3 + 2), -1);
                a3.k.a("Regeneration", (float)(n5 + n2 + 3), (float)(n6 + n4 - (n3 - 24) + 2), -1);
                a3.k.a("*:**", (float)(n5 + n2 + 3), (float)(n6 + n4 + 11 - n3 + 2), -1);
                a3.k.a("*:**", (float)(n5 + n2 + 3), (float)(n6 + n4 + 11 - (n3 - 24) + 2), -1);
            } else {
                rxb.o.a("Speed", (double)(n5 + n2 + 3), (double)(n6 + n4 - n3 + 2), -1);
                rxb.o.a("Regeneration", (double)(n5 + n2 + 3), (double)(n6 + n4 - (n3 - 24) + 2), -1);
                rxb.ba.a("*:**", (double)(n5 + n2 + 3), (double)(n6 + n4 + 11 - n3 + 2), -1);
                rxb.ba.a("*:**", (double)(n5 + n2 + 3), (double)(n6 + n4 + 11 - (n3 - 24) + 2), -1);
            }
        } else {
            if (collection.isEmpty()) {
                a3.v = 0;
                a3.d = false;
            }
            if (!collection.isEmpty()) {
                ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
                ewa.ka();
                int n9 = 24;
                a3.c = collection.size();
                a3.d = true;
                a3.p(a3.x(), a3.j(), a3.v + 29, 24 * a3.c + 2);
                for (ihd ihd2 : a3.g.ob.a()) {
                    ira ira4 = ira.ua[ihd2.y()];
                    ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
                    if (ira4.o()) {
                        a3.g.a().p(new wmc("textures/gui/container/inventory.png"));
                        int n10 = ira4.p();
                        ewa.w();
                        a3.a(n5 + n2 - 17, n6 + n4 - n3 + 2, 0 + n10 % 8 * 18, 198 + n10 / 8 * 18, 18, 18);
                    }
                    String string = xab.a(ira4.a(), new Object[0]);
                    if (ihd2.p() == 1) {
                        string = String.valueOf(new StringBuilder(String.valueOf(string)).append(" ").append(xab.a("enchantment.level.2", new Object[0])));
                    } else if (ihd2.p() == 2) {
                        string = String.valueOf(new StringBuilder(String.valueOf(string)).append(" ").append(xab.a("enchantment.level.3", new Object[0])));
                    } else if (ihd2.p() == 3) {
                        string = String.valueOf(new StringBuilder(String.valueOf(string)).append(" ").append(xab.a("enchantment.level.4", new Object[0])));
                    }
                    String string2 = ira.a(ihd2);
                    if (a3.z()) {
                        a3.k.a(string, (float)(n5 + n2 + 3), (float)(n6 + n4 - n3 + 2), -1);
                        a3.k.a(string2, (float)(n5 + n2 + 3), (float)(n6 + n4 + 11 - n3 + 2), -1);
                    } else {
                        rxb.o.a(string, (double)(n5 + n2 + 3), (double)(n6 + n4 - n3 + 2), -1);
                        rxb.ba.a(string2, (double)(n5 + n2 + 3), (double)(n6 + n4 + 11 - n3 + 2), -1);
                    }
                    n4 += n9;
                    if (a3.v >= a3.k.a(string)) continue;
                    a3.v = a3.k.a(string);
                }
            }
        }
        a3.x((int)(a3.z() ? (double)(a3.k.a("Regeneration") + 29) : rxb.o.a("Regeneration") + 29.0));
        a3.j(50);
    }

    @fo
    public void a(iw a2) {
        af a3;
        if (a3.g.sb instanceof qsa) {
            a3.a(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a("Regeneration") + 29) : rxb.o.a("Regeneration") + 29.0), 50.0f);
        } else if (a3.d) {
            a3.a(a3.x(), a3.j(), a3.v + 29, 24 * a3.c + 2);
        }
    }

    public void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        af a8;
        float f2 = 0.00390625f;
        float f3 = 0.00390625f;
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        krb2.a(7, ybd.i);
        krb2.a((double)(a2 + 0), (double)(a3 + a7), (double)a8.b).a((float)(a4 + 0) * f2, (float)(a5 + a7) * f3).z();
        krb2.a((double)(a2 + a6), (double)(a3 + a7), (double)a8.b).a((float)(a4 + a6) * f2, (float)(a5 + a7) * f3).z();
        krb2.a((double)(a2 + a6), (double)(a3 + 0), (double)a8.b).a((float)(a4 + a6) * f2, (float)(a5 + 0) * f3).z();
        krb2.a((double)(a2 + 0), (double)(a3 + 0), (double)a8.b).a((float)(a4 + 0) * f2, (float)(a5 + 0) * f3).z();
        xlb2.a();
    }
}

