/*
 * Decompiled with CFR 0.152.
 */
public enum cea {
    h,
    z,
    l,
    b,
    c,
    v;


    private /* synthetic */ cea(String a2, int a3) {
        cea a4;
    }
}

