/*
 * Decompiled with CFR 0.152.
 */
import java.util.Calendar;

public class bza
extends tu<fja> {
    private static final wmc r = new wmc("textures/entity/chest/trapped_double.png");
    private static final wmc f = new wmc("textures/entity/chest/christmas_double.png");
    private static final wmc h = new wmc("textures/entity/chest/normal_double.png");
    private static final wmc z = new wmc("textures/entity/chest/trapped.png");
    private static final wmc l = new wmc("textures/entity/chest/christmas.png");
    private static final wmc b = new wmc("textures/entity/chest/normal.png");
    private pdb c = new pdb();
    private pdb v = new web();
    private boolean d;

    public bza() {
        bza a2;
        Calendar calendar = Calendar.getInstance();
        if (calendar.get(2) + 1 == 12 && calendar.get(5) >= 24 && calendar.get(5) <= 26) {
            a2.d = true;
        }
    }

    @Override
    public void a(fja a2, double a3, double a4, double a5, float a6, int a7) {
        Object object;
        int n2;
        ewa.sa();
        ewa.f(515);
        ewa.p(true);
        if (!a2.z()) {
            n2 = 0;
        } else {
            object = a2.a();
            n2 = a2.y();
            if (object instanceof zsc && n2 == 0) {
                ((zsc)object).p(a2.p(), a2.a(), a2.p().a(a2.a()));
                n2 = a2.y();
            }
            a2.x();
        }
        if (a2.n == null && a2.r == null) {
            float f2;
            bza a8;
            if (a2.e == null && a2.f == null) {
                object = a8.c;
                if (a7 >= 0) {
                    a8.p(b[a7]);
                    ewa.z(5890);
                    ewa.m();
                    ewa.o(4.0f, 4.0f, 1.0f);
                    ewa.p(0.0625f, 0.0625f, 0.0625f);
                    ewa.z(5888);
                } else if (a8.d) {
                    a8.p(l);
                } else if (a2.z() == 1) {
                    a8.p(z);
                } else {
                    a8.p(b);
                }
            } else {
                object = a8.v;
                if (a7 >= 0) {
                    a8.p(b[a7]);
                    ewa.z(5890);
                    ewa.m();
                    ewa.o(8.0f, 4.0f, 1.0f);
                    ewa.p(0.0625f, 0.0625f, 0.0625f);
                    ewa.z(5888);
                } else if (a8.d) {
                    a8.p(f);
                } else if (a2.z() == 1) {
                    a8.p(r);
                } else {
                    a8.p(h);
                }
            }
            ewa.m();
            ewa.r();
            if (a7 < 0) {
                ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            }
            ewa.p((float)a3, (float)a4 + 1.0f, (float)a5 + 1.0f);
            ewa.o(1.0f, -1.0f, -1.0f);
            ewa.p(0.5f, 0.5f, 0.5f);
            int n3 = 0;
            if (n2 == 2) {
                n3 = 180;
            }
            if (n2 == 3) {
                n3 = 0;
            }
            if (n2 == 4) {
                n3 = 90;
            }
            if (n2 == 5) {
                n3 = -90;
            }
            if (n2 == 2 && a2.e != null) {
                ewa.p(1.0f, 0.0f, 0.0f);
            }
            if (n2 == 5 && a2.f != null) {
                ewa.p(0.0f, 0.0f, -1.0f);
            }
            ewa.p((float)n3, 0.0f, 1.0f, 0.0f);
            ewa.p(-0.5f, -0.5f, -0.5f);
            float f3 = a2.z + (a2.h - a2.z) * a6;
            if (a2.n != null && (f2 = a2.n.z + (a2.n.h - a2.n.z) * a6) > f3) {
                f3 = f2;
            }
            if (a2.r != null && (f2 = a2.r.z + (a2.r.h - a2.r.z) * a6) > f3) {
                f3 = f2;
            }
            f3 = 1.0f - f3;
            f3 = 1.0f - f3 * f3 * f3;
            ((pdb)object).c.j = -(f3 * (float)Math.PI / 2.0f);
            ((pdb)object).a();
            ewa.q();
            ewa.h();
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            if (a7 >= 0) {
                ewa.z(5890);
                ewa.h();
                ewa.z(5888);
            }
        }
    }
}

