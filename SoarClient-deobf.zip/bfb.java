/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.ArrayUtils
 */
import java.util.Properties;
import org.apache.commons.lang3.ArrayUtils;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bfb {
    private int z = 0;
    private String l = null;
    private String[] b = null;
    private String c = null;
    private String[] v = null;
    private int d = 0;

    public bfb(String a2, String[] a3, String a4, String[] a5, int a6) {
        bfb a7;
        a7.l = a2;
        a7.b = a3;
        a7.c = a4;
        a7.v = a5;
        a7.z = a6;
        if (a3.length != a5.length) {
            throw new IllegalArgumentException("Property and user values have different lengths: " + a3.length + " != " + a5.length);
        }
        if (a6 < 0 || a6 >= a3.length) {
            throw new IllegalArgumentException("Invalid default value: " + a6);
        }
        a7.d = a6;
    }

    public boolean a(String a2) {
        bfb a3;
        if (a2 == null) {
            a3.d = a3.z;
            return false;
        }
        a3.d = ArrayUtils.indexOf((Object[])a3.b, (Object)a2);
        if (a3.d >= 0 && a3.d < a3.b.length) {
            return true;
        }
        a3.d = a3.z;
        return false;
    }

    public void a(boolean a2) {
        bfb a3;
        int n2 = 0;
        int n3 = a3.b.length - 1;
        a3.d = xfc.a(a3.d, n2, n3);
        if (a2) {
            ++a3.d;
            if (a3.d > n3) {
                a3.d = n2;
            }
        } else {
            --a3.d;
            if (a3.d < n2) {
                a3.d = n3;
            }
        }
    }

    public void a(int a2) {
        bfb a3;
        a3.d = a2;
        if (a3.d < 0 || a3.d >= a3.b.length) {
            a3.d = a3.z;
        }
    }

    public int a() {
        bfb a2;
        return a2.d;
    }

    public String y() {
        bfb a2;
        return a2.v[a2.d];
    }

    public String o() {
        bfb a2;
        return a2.b[a2.d];
    }

    public String p() {
        bfb a2;
        return a2.c;
    }

    public String a() {
        bfb a2;
        return a2.l;
    }

    public void a() {
        bfb a2;
        a2.d = a2.z;
    }

    public boolean a(Properties a2) {
        bfb a3;
        a3.a();
        if (a2 == null) {
            return false;
        }
        String string = a2.getProperty(a3.l);
        return string == null ? false : a3.a(string);
    }

    public void a(Properties a2) {
        if (a2 != null) {
            bfb a3;
            a2.setProperty(a3.a(), a3.o());
        }
    }

    public String toString() {
        bfb a2;
        return a2.l + "=" + a2.o() + " [" + xfc.a(a2.b) + "], value: " + a2.d;
    }
}

