/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cqb
extends am {
    public cqb() {
        super(fja.class, "chest_large", 0.0f);
        cqb a2;
    }

    @Override
    public qm a() {
        return new web();
    }

    @Override
    public sfc a(qm a2, String a3) {
        if (!(a2 instanceof pdb)) {
            return null;
        }
        pdb pdb2 = (pdb)a2;
        return a3.equals("lid") ? pdb2.c : (a3.equals("base") ? pdb2.v : (a3.equals("knob") ? pdb2.d : null));
    }

    @Override
    public String[] a() {
        return new String[]{"lid", "base", "knob"};
    }

    @Override
    public h a(qm a2, float a3) {
        ffc ffc2 = ffc.t;
        bza bza2 = ffc2.a(fja.class);
        if (!(bza2 instanceof bza)) {
            return null;
        }
        if (bza2.a() == null) {
            bza2 = new bza();
            bza2.a(ffc2);
        }
        if (!xe.s.a()) {
            xfc.z("Field not found: TileEntityChestRenderer.largeChest");
            return null;
        }
        xe.a((Object)bza2, xe.s, (Object)a2);
        return bza2;
    }
}

