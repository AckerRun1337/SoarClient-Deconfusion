/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.io.PrintStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bnb {
    private static final PrintStream c = System.out;
    private static boolean v = false;
    private static final Logger d = LogManager.getLogger();

    public bnb() {
        bnb a2;
    }

    public static boolean a() {
        return v;
    }

    static void o() {
        kkb.v.a(sxa.ej, new jt());
        kkb.v.a(sxa.dc, new msc());
        kkb.v.a(sxa.if, new swc());
        kkb.v.a(sxa.va, new aub());
        kkb.v.a(sxa.gb, new pdd());
        kkb.v.a(sxa.wa, new gmc());
        kkb.v.a(sxa.oa, new vaa());
        kkb.v.a(sxa.sa, new gbd());
        kkb.v.a(sxa.ee, new nxc());
        qpc qpc2 = new qpc();
        kkb.v.a(sxa.kn, qpc2);
        kkb.v.a(sxa.mn, qpc2);
        kkb.v.a(sxa.hd, new ydb());
        kkb.v.a(sxa.ii, new pka());
        kkb.v.a(sxa.rc, new ym());
        kkb.v.a(ge.a(cl.hn), new uma());
        kkb.v.a(sxa.ga, new yga());
        kkb.v.a(ge.a(cl.cc), new jbb());
    }

    public static void p() {
        if (!v) {
            v = true;
            if (d.isDebugEnabled()) {
                bnb.a();
            }
            yd.a();
            mn.o();
            ge.a();
            hca.z();
            bnb.o();
        }
    }

    private static /* synthetic */ void a() {
        System.setErr(new ld("STDERR", System.err));
        System.setOut(new ld("STDOUT", c));
    }

    public static void a(String a2) {
        c.println(a2);
    }
}

