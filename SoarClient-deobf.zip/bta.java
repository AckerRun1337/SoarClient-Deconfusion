/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class bta
extends yd {
    protected bta(dr a2) {
        a3(a2, a2.a());
        bta a3;
    }

    protected bta(dr a2, rpb a3) {
        super(a2, a3);
        bta a4;
        a4.a(md.x);
        a4.a(true);
    }

    @Override
    public void a(cb a2, tp a3) {
        bta a4;
        a4.p(a2.a(a3));
    }

    protected void p(ba a2) {
        bta a3;
        if (a3.z(a2) > 0) {
            a3.a(0.0625f, 0.0f, 0.0625f, 0.9375f, 0.03125f, 0.9375f);
        } else {
            a3.a(0.0625f, 0.0f, 0.0625f, 0.9375f, 0.0625f, 0.9375f);
        }
    }

    @Override
    public int a(xga a2) {
        return 20;
    }

    @Override
    public tca a(xga a2, tp a3, ba a4) {
        return null;
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean a(cb a2, tp a3) {
        return true;
    }

    @Override
    public boolean z() {
        return true;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        bta a4;
        return a4.o(a2, a3.z());
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        bta a6;
        if (!a6.o(a2, a3.z())) {
            a6.a(a2, a3, a4, 0);
            a2.r(a3);
        }
    }

    private /* synthetic */ boolean o(xga a2, tp a3) {
        return xga.a(a2, a3) || a2.a(a3).a() instanceof cx;
    }

    @Override
    public void o(xga a2, tp a3, ba a4, Random a5) {
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        bta a6;
        int n2;
        if (!a2.f && (n2 = a6.z(a4)) > 0) {
            a6.p(a2, a3, a4, n2);
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, rj a5) {
        bta a6;
        int n2;
        if (!a2.f && (n2 = a6.z(a4)) == 0) {
            a6.p(a2, a3, a4, n2);
        }
    }

    protected void p(xga a2, tp a3, ba a4, int a5) {
        boolean bl2;
        bta a6;
        int n2 = a6.o(a2, a3);
        boolean bl3 = a5 > 0;
        boolean bl4 = bl2 = n2 > 0;
        if (a5 != n2) {
            a4 = a6.a(a4, n2);
            a2.a(a3, a4, 2);
            a6.p(a2, a3);
            a2.a(a3, a3);
        }
        if (!bl2 && bl3) {
            a2.a((double)a3.o() + 0.5, (double)a3.p() + 0.1, (double)a3.a() + 0.5, "random.click", 0.3f, 0.5f);
        } else if (bl2 && !bl3) {
            a2.a((double)a3.o() + 0.5, (double)a3.p() + 0.1, (double)a3.a() + 0.5, "random.click", 0.3f, 0.6f);
        }
        if (bl2) {
            a2.a(a3, (yd)a6, a6.a(a2));
        }
    }

    protected tca a(tp a2) {
        float f2 = 0.125f;
        return new tca((float)a2.o() + 0.125f, a2.p(), (float)a2.a() + 0.125f, (float)(a2.o() + 1) - 0.125f, (double)a2.p() + 0.25, (float)(a2.a() + 1) - 0.125f);
    }

    @Override
    public void a(xga a2, tp a3, ba a4) {
        bta a5;
        if (a5.z(a4) > 0) {
            a5.p(a2, a3);
        }
        super.a(a2, a3, a4);
    }

    protected void p(xga a2, tp a3) {
        bta a4;
        a2.o(a3, a4);
        a2.o(a3.z(), a4);
    }

    @Override
    public int p(cb a2, tp a3, ba a4, hnd a5) {
        bta a6;
        return a6.z(a4);
    }

    @Override
    public int a(cb a2, tp a3, ba a4, hnd a5) {
        bta a6;
        return a5 == hnd.k ? a6.z(a4) : 0;
    }

    @Override
    public boolean x() {
        return true;
    }

    @Override
    public void p() {
        bta a2;
        float f2 = 0.5f;
        float f3 = 0.125f;
        float f4 = 0.5f;
        a2.a(0.0f, 0.375f, 0.0f, 1.0f, 0.625f, 1.0f);
    }

    @Override
    public int a() {
        return 1;
    }

    protected abstract int o(xga var1, tp var2);

    protected abstract int z(ba var1);

    protected abstract ba a(ba var1, int var2);
}

