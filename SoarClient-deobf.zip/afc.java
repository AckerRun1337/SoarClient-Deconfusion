/*
 * Decompiled with CFR 0.152.
 */
public class afc
extends wg {
    public afc(long a2, wg a3) {
        super(a2);
        afc a4;
        a4.c = a3;
    }

    @Override
    public int[] a(int a2, int a3, int a4, int a5) {
        afc a6;
        int[] nArray = a6.c.a(a2 - 1, a3 - 1, a4 + 2, a5 + 2);
        int[] nArray2 = xeb.a(a4 * a5);
        int n2 = 0;
        while (n2 < a5) {
            int n3 = 0;
            while (n3 < a4) {
                a6.a((long)(n3 + a2), (long)(n2 + a3));
                int n4 = nArray[n3 + 1 + (n2 + 1) * (a4 + 2)];
                if (!(a6.p(nArray, nArray2, n3, n2, a4, n4, nk.tb.l, nk.va.l) || a6.a(nArray, nArray2, n3, n2, a4, n4, nk.pa.l, nk.oa.l) || a6.a(nArray, nArray2, n3, n2, a4, n4, nk.ba.l, nk.oa.l) || a6.a(nArray, nArray2, n3, n2, a4, n4, nk.ca.l, nk.fb.l))) {
                    int n5;
                    int n6;
                    int n7;
                    int n8;
                    if (n4 == nk.sb.l) {
                        n8 = nArray[n3 + 1 + (n2 + 1 - 1) * (a4 + 2)];
                        n7 = nArray[n3 + 1 + 1 + (n2 + 1) * (a4 + 2)];
                        n6 = nArray[n3 + 1 - 1 + (n2 + 1) * (a4 + 2)];
                        n5 = nArray[n3 + 1 + (n2 + 1 + 1) * (a4 + 2)];
                        nArray2[n3 + n2 * a4] = n8 != nk.rb.l && n7 != nk.rb.l && n6 != nk.rb.l && n5 != nk.rb.l ? n4 : nk.ja.l;
                    } else if (n4 == nk.zb.l) {
                        n8 = nArray[n3 + 1 + (n2 + 1 - 1) * (a4 + 2)];
                        n7 = nArray[n3 + 1 + 1 + (n2 + 1) * (a4 + 2)];
                        n6 = nArray[n3 + 1 - 1 + (n2 + 1) * (a4 + 2)];
                        n5 = nArray[n3 + 1 + (n2 + 1 + 1) * (a4 + 2)];
                        nArray2[n3 + n2 * a4] = n8 != nk.sb.l && n7 != nk.sb.l && n6 != nk.sb.l && n5 != nk.sb.l && n8 != nk.ha.l && n7 != nk.ha.l && n6 != nk.ha.l && n5 != nk.ha.l && n8 != nk.rb.l && n7 != nk.rb.l && n6 != nk.rb.l && n5 != nk.rb.l ? (n8 != nk.sa.l && n5 != nk.sa.l && n7 != nk.sa.l && n6 != nk.sa.l ? n4 : nk.qa.l) : nk.ib.l;
                    } else {
                        nArray2[n3 + n2 * a4] = n4;
                    }
                }
                ++n3;
            }
            ++n2;
        }
        return nArray2;
    }

    private /* synthetic */ boolean p(int[] a2, int[] a3, int a4, int a5, int a6, int a7, int a8, int a9) {
        afc a10;
        if (!afc.a(a7, a8)) {
            return false;
        }
        int n2 = a2[a4 + 1 + (a5 + 1 - 1) * (a6 + 2)];
        int n3 = a2[a4 + 1 + 1 + (a5 + 1) * (a6 + 2)];
        int n4 = a2[a4 + 1 - 1 + (a5 + 1) * (a6 + 2)];
        int n5 = a2[a4 + 1 + (a5 + 1 + 1) * (a6 + 2)];
        a3[a4 + a5 * a6] = a10.p(n2, a8) && a10.p(n3, a8) && a10.p(n4, a8) && a10.p(n5, a8) ? a7 : a9;
        return true;
    }

    private /* synthetic */ boolean a(int[] a2, int[] a3, int a4, int a5, int a6, int a7, int a8, int a9) {
        if (a7 != a8) {
            return false;
        }
        int n2 = a2[a4 + 1 + (a5 + 1 - 1) * (a6 + 2)];
        int n3 = a2[a4 + 1 + 1 + (a5 + 1) * (a6 + 2)];
        int n4 = a2[a4 + 1 - 1 + (a5 + 1) * (a6 + 2)];
        int n5 = a2[a4 + 1 + (a5 + 1 + 1) * (a6 + 2)];
        a3[a4 + a5 * a6] = afc.a(n2, a8) && afc.a(n3, a8) && afc.a(n4, a8) && afc.a(n5, a8) ? a7 : a9;
        return true;
    }

    private /* synthetic */ boolean p(int a2, int a3) {
        if (afc.a(a2, a3)) {
            return true;
        }
        nk nk2 = nk.a(a2);
        nk nk3 = nk.a(a3);
        if (nk2 != null && nk3 != null) {
            nrb nrb2;
            nrb nrb3 = nk2.a();
            return nrb3 == (nrb2 = nk3.a()) || nrb3 == nrb.c || nrb2 == nrb.c;
        }
        return false;
    }
}

