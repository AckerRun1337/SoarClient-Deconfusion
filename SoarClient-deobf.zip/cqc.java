/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class cqc {
    private final wgc b;
    private int c;
    private int v;
    private final int d;

    public cqc(wgc a2, int a3, int a4) {
        cqc a5;
        a5.b = a2;
        a5.c = a3;
        a5.v = a3;
        a5.d = a4;
    }

    public void a(int a2) {
        cqc a3;
        if (a2 < a3.c) {
            a3.c = a2;
        } else if (a2 > a3.v) {
            a3.v = a2;
        }
    }

    public wgc a() {
        cqc a2;
        return a2.b;
    }

    public int o() {
        cqc a2;
        return a2.c;
    }

    public int p() {
        cqc a2;
        return a2.v;
    }

    public int a() {
        cqc a2;
        return a2.d;
    }
}

