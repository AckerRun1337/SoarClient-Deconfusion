/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface c {
    public boolean a(int var1, int var2);

    public dsc a(int var1, int var2);

    public dsc a(tp var1);

    public void a(c var1, int var2, int var3);

    public boolean a(c var1, dsc var2, int var3, int var4);

    public boolean a(boolean var1, z var2);

    public boolean p();

    public boolean a();

    public String a();

    public List<bz> a(zwb var1, tp var2);

    public tp a(xga var1, String var2, tp var3);

    public int a();

    public void a(dsc var1, int var2, int var3);

    public void a();
}

