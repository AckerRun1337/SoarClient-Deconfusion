/*
 * Decompiled with CFR 0.152.
 */
public enum chb {
    b,
    c,
    v;


    private /* synthetic */ chb(String a2, int a3) {
        chb a4;
    }
}

