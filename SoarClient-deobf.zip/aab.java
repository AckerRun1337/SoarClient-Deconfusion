/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class aab
implements Callable<String> {
    final /* synthetic */ rj d;

    aab(rj a2) {
        aab a3;
        a3.d = a2;
    }

    public String a() throws Exception {
        aab a2;
        return a2.d.a();
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        aab a2;
        return a2.a();
    }
}

