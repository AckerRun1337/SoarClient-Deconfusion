/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Rectangle;

public interface bc {
    public Rectangle a(en var1, int var2, int var3);

    public String[] a(ff var1, int var2);

    public boolean a();
}

