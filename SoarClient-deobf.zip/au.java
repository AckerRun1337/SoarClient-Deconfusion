/*
 * Decompiled with CFR 0.152.
 */
public enum au {
    b,
    c,
    v;


    private /* synthetic */ au(String a2, int a3) {
        au a4;
    }
}

