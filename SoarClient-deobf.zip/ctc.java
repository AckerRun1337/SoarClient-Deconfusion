/*
 * Decompiled with CFR 0.152.
 */
class ctc
extends hcd {
    ctc(long a2) {
        super(a2);
        ctc a3;
    }

    @Override
    public void a(long a2) {
    }
}

