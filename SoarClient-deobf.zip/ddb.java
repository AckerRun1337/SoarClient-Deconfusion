/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.Validate
 */
import java.io.IOException;
import org.apache.commons.lang3.Validate;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ddb
implements o<vi> {
    private String z;
    private int l;
    private int b;
    private int c;
    private float v;
    private int d;

    public ddb() {
        ddb a2;
        a2.b = Integer.MAX_VALUE;
    }

    public ddb(String a2, double a3, double a4, double a5, float a6, float a7) {
        ddb a8;
        a8.b = Integer.MAX_VALUE;
        Validate.notNull((Object)a2, (String)"name", (Object[])new Object[0]);
        a8.z = a2;
        a8.l = (int)(a3 * 8.0);
        a8.b = (int)(a4 * 8.0);
        a8.c = (int)(a5 * 8.0);
        a8.v = a6;
        a8.d = (int)(a7 * 63.0f);
        a7 = smb.a(a7, 0.0f, 255.0f);
    }

    @Override
    public void p(io a2) throws IOException {
        a.z = a2.a(256);
        a.l = a2.y();
        a.b = a2.y();
        a.c = a2.y();
        a.v = a2.a();
        a.d = a2.p();
    }

    @Override
    public void a(io a2) throws IOException {
        ddb a3;
        a2.a(a3.z);
        a2.y(a3.l);
        a2.y(a3.b);
        a2.y(a3.c);
        a2.a(a3.v);
        a2.x(a3.d);
    }

    public String a() {
        ddb a2;
        return a2.z;
    }

    public double o() {
        ddb a2;
        return (float)a2.l / 8.0f;
    }

    public double p() {
        ddb a2;
        return (float)a2.b / 8.0f;
    }

    public double a() {
        ddb a2;
        return (float)a2.c / 8.0f;
    }

    public float p() {
        ddb a2;
        return a2.v;
    }

    public float a() {
        ddb a2;
        return (float)a2.d / 63.0f;
    }

    @Override
    public void a(vi a2) {
        ddb a3;
        a2.a(a3);
    }
}

