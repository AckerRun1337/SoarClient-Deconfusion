/*
 * Decompiled with CFR 0.152.
 */
import java.lang.reflect.Method;

public class bsc {
    public final /* synthetic */ Object c;
    public final /* synthetic */ Method v;
    public final /* synthetic */ byte d;

    public bsc(Object a2, Method a3, byte a4) {
        bsc a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }
}

