/*
 * Decompiled with CFR 0.152.
 */
public class byb
extends ucc {
    private final int d = kjb.a(hdc.values().length);

    public byb(xga a2, qda a3, tp a4, int a5) {
        super(a2, a3, a4, a5);
        byb a6;
    }

    public int a(hdc a2, kub a3) {
        byb a4;
        return !a3.p(a2) ? a4.d + a2.ordinal() : -1;
    }

    @Override
    public void p() {
        byb a2;
        super.p();
        kjb.a(a2.d, hdc.values().length);
    }
}

