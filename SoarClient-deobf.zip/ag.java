/*
 * Decompiled with CFR 0.152.
 */
public class ag
extends qm {
    public ag() {
        ag a2;
        a2.l = false;
    }
}

