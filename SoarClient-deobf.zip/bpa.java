/*
 * Decompiled with CFR 0.152.
 */
public class bpa
implements va<ilc> {
    private static final wmc v = new wmc("textures/entity/wolf/wolf_collar.png");
    private final dmd d;

    public bpa(dmd a2) {
        bpa a3;
        a3.d = a2;
    }

    @Override
    public void a(ilc a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9) {
        if (a2.na() && !a2.l()) {
            bpa a10;
            a10.d.p(v);
            kja kja2 = kja.a(a2.a().p());
            float[] fArray = rga.a(kja2);
            if (xfc.xa()) {
                fArray = lha.p(kja2, fArray);
            }
            ewa.a(fArray[0], fArray[1], fArray[2]);
            a10.d.a().a(a2, a3, a4, a6, a7, a8, a9);
        }
    }

    @Override
    public boolean a() {
        return true;
    }
}

