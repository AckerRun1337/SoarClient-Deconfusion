/*
 * Decompiled with CFR 0.152.
 */
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.callbacks.ReadyCallback;

class bbc
implements ReadyCallback {
    final /* synthetic */ fjc d;

    bbc(fjc a2) {
        bbc a3;
        a3.d = a2;
    }

    @Override
    public void a(DiscordUser a2) {
        bbc a3;
        a3.d.a(String.valueOf(new StringBuilder("Playing Soar Client v").append(gsc.t.a())), "");
    }
}

