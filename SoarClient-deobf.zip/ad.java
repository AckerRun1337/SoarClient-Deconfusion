/*
 * Decompiled with CFR 0.152.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ad
extends ml {
    private int[] d;

    ad() {
        ad a2;
    }

    public ad(int[] a2) {
        ad a3;
        a3.d = a2;
    }

    @Override
    void a(DataOutput a2) throws IOException {
        ad a3;
        a2.writeInt(a3.d.length);
        int n2 = 0;
        while (n2 < a3.d.length) {
            a2.writeInt(a3.d[n2]);
            ++n2;
        }
    }

    @Override
    void a(DataInput a2, int a3, hcd a4) throws IOException {
        a4.a(192L);
        int n2 = a2.readInt();
        a4.a(32 * n2);
        a.d = new int[n2];
        int n3 = 0;
        while (n3 < n2) {
            a.d[n3] = a2.readInt();
            ++n3;
        }
    }

    @Override
    public byte a() {
        return 11;
    }

    @Override
    public String toString() {
        ad a2;
        String string = "[";
        int[] nArray = a2.d;
        int n2 = a2.d.length;
        int n3 = 0;
        while (n3 < n2) {
            int n4 = nArray[n3];
            string = String.valueOf(string) + n4 + ",";
            ++n3;
        }
        return String.valueOf(string) + "]";
    }

    @Override
    public ml a() {
        ad a2;
        int[] nArray = new int[a2.d.length];
        System.arraycopy(a2.d, 0, nArray, 0, a2.d.length);
        return new ad(nArray);
    }

    @Override
    public boolean equals(Object a2) {
        ad a3;
        return super.equals(a2) ? Arrays.equals(a3.d, ((ad)a2).d) : false;
    }

    @Override
    public int hashCode() {
        ad a2;
        return super.hashCode() ^ Arrays.hashCode(a2.d);
    }

    public int[] a() {
        ad a2;
        return a2.d;
    }
}

