/*
 * Decompiled with CFR 0.152.
 */
public class aqc
extends bh {
    public aqc() {
        super("ServerIP", 0, gk.l);
        aqc a2;
    }

    @fo
    public void a(thb a2) {
        aqc a3;
        a3.p(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(ptc.p()) + 9) : rxb.o.a(ptc.p()) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
        if (a3.z()) {
            a3.k.a(ptc.p(), (float)a3.x() + 4.5f, (float)a3.j() + 4.5f, -1);
        } else {
            rxb.o.a(ptc.p(), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 4.5f), -1);
        }
        a3.x((int)(a3.z() ? (double)(a3.k.a(ptc.p()) + 8) : rxb.o.a(ptc.p()) + 8.0));
        a3.j((int)(a3.z() ? (double)((float)a3.k.u + 8.0f) : rxb.ba.a() + 8.0));
    }

    @fo
    public void a(iw a2) {
        aqc a3;
        a3.a(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(ptc.p()) + 9) : rxb.o.a(ptc.p()) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
    }
}

