/*
 * Decompiled with CFR 0.152.
 */
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.optifine.util.\u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94;
import net.optifine.util.\u773a\u9d3b\u9d60\u5acc\u9091\u822c\u7aea\u8ce0\u8ddd\u8ab9\u7d9c\u666f\u8ab9\u5f25\u9ed2\u58f2\u559a\u7c92\u67fe\u6355\u5316\u7ffb\u7ac3\u4e00\u6a58\u5531\u6052\u88fd\u848b\u6b63\u5c2d\u7511\u64c1\u7e41\u4ff3\u5217\u76c3\u9354\u6a4b\u4e09;
import net.optifine.util.\u8f44\u8607\u8a51\u5ca8\u5f71\u64ae\u5e38\u67cf\u639b\u4ec7\u9283\u6bce\u7a84\u7336\u4ef0\u7149\u745b\u4f50\u5c2d\u6607\u6190\u541b\u83cc\u7279\u5e63\u80c3\u983c\u7aea\u540a\u6108\u9091\u614b\u6271\u52b4\u5a46\u77ad\u99c1\u6258\u8607\u795e;
import net.optifine.util.\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a;

public class bpb {
    private static Map<String, xsa> k = new HashMap<String, xsa>();
    private static boolean x = false;
    private static qda t;
    private static ii p;
    private static ffc s;
    private static fad w;
    private static boolean i;
    public static final String n = ".png";
    public static final String e = ".properties";
    public static final String r = "textures/entity/";
    public static final String f = "textures/painting/";
    public static final String h = "textures/";
    public static final String z = "optifine/random/";
    public static final String l = "mcpatcher/mob/";
    private static final String[] b;
    private static final String c = "horse/";
    private static final String[] v;
    private static final String[] d;

    static {
        p = new ii();
        w = new fad();
        i = false;
        b = new String[]{"_armor", "_eyes", "_exploding", "_shooting", "_fur", "_eyes", "_invulnerable", "_angry", "_tame", "_collar"};
        v = (String[])lma.a(null, obb.class, String[].class, 2);
        d = (String[])lma.a(null, obb.class, String[].class, 3);
    }

    public bpb() {
        bpb a2;
    }

    public static void p(rj a2, xga a3) {
        if (a3 != null) {
            ypa ypa2 = a2.a();
            ypa2.d = a2.a();
            ypa2.v = a3.a(ypa2.d);
            UUID uUID = a2.a();
            if (a2 instanceof tfa) {
                bpb.a(uUID, (tfa)a2);
            }
        }
    }

    public static void a(rj a2, xga a3) {
    }

    private static /* synthetic */ void a(UUID a2, tfa a3) {
        rj rj2 = \u8f44\u8607\u8a51\u5ca8\u5f71\u64ae\u5e38\u67cf\u639b\u4ec7\u9283\u6bce\u7a84\u7336\u4ef0\u7149\u745b\u4f50\u5c2d\u6607\u6190\u541b\u83cc\u7279\u5e63\u80c3\u983c\u7aea\u540a\u6108\u9091\u614b\u6271\u52b4\u5a46\u77ad\u99c1\u6258\u8607\u795e.a(a2);
        if (rj2 instanceof tfa) {
            tfa tfa2 = (tfa)rj2;
            int n2 = tfa2.e();
            a3.r(n2);
            int n3 = xe.a((Object)tfa2, xe.ac, 0);
            xe.a((Object)a3, xe.ac, n3);
            int n4 = xe.a((Object)tfa2, xe.jc, 0);
            xe.a((Object)a3, xe.jc, n4);
        }
    }

    public static void a(xga a2, xga a3) {
        if (a3 != null) {
            List<rj> list = a3.a();
            int n2 = 0;
            while (n2 < list.size()) {
                rj rj2 = list.get(n2);
                bpb.p(rj2, a3);
                ++n2;
            }
        }
        p.a(null);
        w.a(null);
    }

    public static wmc a(wmc a2) {
        wmc wmc2;
        if (!x) {
            return a2;
        }
        if (i) {
            return a2;
        }
        try {
            i = true;
            u u2 = bpb.a();
            if (u2 != null) {
                wmc wmc3;
                String string = a2.p();
                if (string.startsWith(c)) {
                    string = bpb.a(string, c.length());
                }
                if (!string.startsWith(r) && !string.startsWith(f)) {
                    wmc wmc4;
                    wmc wmc5 = wmc4 = a2;
                    return wmc5;
                }
                xsa xsa2 = k.get(string);
                if (xsa2 == null) {
                    wmc wmc6;
                    wmc wmc7 = wmc6 = a2;
                    return wmc7;
                }
                wmc wmc8 = wmc3 = xsa2.a(a2, u2);
                return wmc8;
            }
            wmc2 = a2;
        }
        finally {
            i = false;
        }
        return wmc2;
    }

    private static /* synthetic */ String a(String a2, int a3) {
        if (v != null && d != null) {
            int n2 = 0;
            while (n2 < d.length) {
                String string = d[n2];
                if (a2.startsWith(string, a3)) {
                    return v[n2];
                }
                ++n2;
            }
            return a2;
        }
        return a2;
    }

    private static /* synthetic */ u a() {
        kv kv2;
        if (bpb.t.j != null) {
            p.a(bpb.t.j);
            return p;
        }
        if (bpb.s.c != null && (kv2 = bpb.s.c).p() != null) {
            w.a(kv2);
            return w;
        }
        return null;
    }

    private static /* synthetic */ xsa a(wmc a2, boolean a3) {
        wmc[] wmcArray;
        String string = a2.p();
        wmc wmc2 = bpb.p(a2, a3);
        if (wmc2 != null && (wmcArray = bpb.a(wmc2, a2)) != null) {
            return wmcArray;
        }
        wmcArray = bpb.a(a2, a3);
        return wmcArray == null ? null : new xsa(string, wmcArray);
    }

    private static /* synthetic */ xsa a(wmc a2, wmc a3) {
        InputStream inputStream;
        String string;
        block4: {
            string = a2.p();
            bpb.p(String.valueOf(a3.p()) + ", properties: " + string);
            inputStream = xfc.a(a2);
            if (inputStream != null) break block4;
            bpb.a("Properties not found: " + string);
            return null;
        }
        try {
            \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2 = new \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a();
            \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2.load(inputStream);
            inputStream.close();
            xsa xsa2 = new xsa(\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2, string, a3);
            return !xsa2.a(string) ? null : xsa2;
        }
        catch (FileNotFoundException fileNotFoundException) {
            bpb.a("File not found: " + a3.p());
            return null;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    private static /* synthetic */ wmc p(wmc a2, boolean a3) {
        String string;
        String string2;
        String string3;
        wmc wmc2 = bpb.a(a2, a3);
        if (wmc2 == null) {
            return null;
        }
        String string4 = wmc2.a();
        wmc wmc3 = new wmc(string4, string3 = String.valueOf(string2 = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.j(string = wmc2.p(), n)) + e);
        if (xfc.p(wmc3)) {
            return wmc3;
        }
        String string5 = bpb.a(string2);
        if (string5 == null) {
            return null;
        }
        wmc wmc4 = new wmc(string4, String.valueOf(string5) + e);
        return xfc.p(wmc4) ? wmc4 : null;
    }

    protected static wmc a(wmc a2, boolean a3) {
        String string = a2.a();
        String string2 = a2.p();
        String string3 = h;
        String string4 = z;
        if (a3) {
            string3 = r;
            string4 = l;
        }
        if (!string2.startsWith(string3)) {
            return null;
        }
        String string5 = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.o(string2, string3, string4);
        return new wmc(string, string5);
    }

    private static /* synthetic */ String p(String a2) {
        return a2.startsWith(z) ? \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.o(a2, z, h) : (a2.startsWith(l) ? \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.o(a2, l, r) : null);
    }

    protected static wmc a(wmc a2, int a3) {
        if (a2 == null) {
            return null;
        }
        String string = a2.p();
        int n2 = string.lastIndexOf(46);
        if (n2 < 0) {
            return null;
        }
        String string2 = string.substring(0, n2);
        String string3 = string.substring(n2);
        String string4 = String.valueOf(string2) + a3 + string3;
        wmc wmc2 = new wmc(a2.a(), string4);
        return wmc2;
    }

    private static /* synthetic */ String a(String a2) {
        int n2 = 0;
        while (n2 < b.length) {
            String string = b[n2];
            if (a2.endsWith(string)) {
                String string2 = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.j(a2, string);
                return string2;
            }
            ++n2;
        }
        return null;
    }

    private static /* synthetic */ wmc[] a(wmc a2, boolean a3) {
        ArrayList<wmc> arrayList = new ArrayList<wmc>();
        arrayList.add(a2);
        wmc wmc2 = bpb.a(a2, a3);
        if (wmc2 == null) {
            return null;
        }
        int n2 = 1;
        while (n2 < arrayList.size() + 10) {
            int n3 = n2 + 1;
            wmc wmc3 = bpb.a(wmc2, n3);
            if (xfc.p(wmc3)) {
                arrayList.add(wmc3);
            }
            ++n2;
        }
        if (arrayList.size() <= 1) {
            return null;
        }
        wmc[] wmcArray = arrayList.toArray(new wmc[arrayList.size()]);
        bpb.p(String.valueOf(a2.p()) + ", variants: " + wmcArray.length);
        return wmcArray;
    }

    public static void p() {
        k.clear();
        x = false;
        if (xfc.ra()) {
            bpb.a();
        }
    }

    private static /* synthetic */ void a() {
        t = xfc.a();
        s = ffc.t;
        String[] stringArray = new String[]{z, l};
        String[] stringArray2 = new String[]{n, e};
        String[] stringArray3 = \u773a\u9d3b\u9d60\u5acc\u9091\u822c\u7aea\u8ce0\u8ddd\u8ab9\u7d9c\u666f\u8ab9\u5f25\u9ed2\u58f2\u559a\u7c92\u67fe\u6355\u5316\u7ffb\u7ac3\u4e00\u6a58\u5531\u6052\u88fd\u848b\u6b63\u5c2d\u7511\u64c1\u7e41\u4ff3\u5217\u76c3\u9354\u6a4b\u4e09.a(stringArray, stringArray2);
        HashSet<String> hashSet = new HashSet<String>();
        int n2 = 0;
        while (n2 < stringArray3.length) {
            String string = stringArray3[n2];
            string = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.p(string, stringArray2);
            string = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.a(string, "0123456789");
            String string2 = bpb.p(string = String.valueOf(string) + n);
            if (!hashSet.contains(string2)) {
                xsa xsa2;
                hashSet.add(string2);
                wmc wmc2 = new wmc(string2);
                if (xfc.p(wmc2) && (xsa2 = k.get(string2)) == null) {
                    xsa2 = bpb.a(wmc2, false);
                    if (xsa2 == null) {
                        xsa2 = bpb.a(wmc2, true);
                    }
                    if (xsa2 != null) {
                        k.put(string2, xsa2);
                    }
                }
            }
            ++n2;
        }
        x = !k.isEmpty();
    }

    public static void p(String a2) {
        xfc.j("RandomEntities: " + a2);
    }

    public static void a(String a2) {
        xfc.z("RandomEntities: " + a2);
    }
}

