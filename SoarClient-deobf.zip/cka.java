/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public class cka
extends IOException {
    private final List<eh> v;
    private final String d;

    public cka(String a2) {
        cka a3;
        a3.v = Lists.newArrayList();
        a3.v.add(new eh(null));
        a3.d = a2;
    }

    public cka(String a2, Throwable a3) {
        super(a3);
        cka a4;
        a4.v = Lists.newArrayList();
        a4.v.add(new eh(null));
        a4.d = a2;
    }

    public void p(String a2) {
        cka a3;
        eh.p(a3.v.get(0), a2);
    }

    public void a(String a2) {
        cka a3;
        eh.a(a3.v.get(0), a2);
        a3.v.add(0, new eh(null));
    }

    @Override
    public String getMessage() {
        cka a2;
        return "Invalid " + a2.v.get(a2.v.size() - 1).toString() + ": " + a2.d;
    }

    public static cka a(Exception a2) {
        if (a2 instanceof cka) {
            return (cka)a2;
        }
        String string = a2.getMessage();
        if (a2 instanceof FileNotFoundException) {
            string = "File not found";
        }
        return new cka(string, a2);
    }
}

