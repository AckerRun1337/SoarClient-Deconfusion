/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

class ctb
implements k {
    public wfc v;
    public dxc d;

    public ctb(ge a2, dxc a3) {
        ctb a4;
        a4.v = new wfc(a2);
        a4.d = a3;
    }

    @Override
    public void a(iga a2, Random a3) {
        ctb a4;
        int n2 = 1;
        if (a4.d != null) {
            n2 = a4.d.a(a3);
        }
        wfc wfc2 = new wfc(sxa.xa, n2, 0);
        wfc wfc3 = new wfc(a4.v.a(), 1, a4.v.y());
        wfc3 = fi.a(a3, wfc3, 5 + a3.nextInt(15));
        a2.add(new yw(wfc2, wfc3));
    }
}

