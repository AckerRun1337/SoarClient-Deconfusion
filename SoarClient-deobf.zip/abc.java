/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.minecraft.MinecraftProfileTexture
 *  com.mojang.authlib.minecraft.MinecraftProfileTexture$Type
 */
import com.mojang.authlib.minecraft.MinecraftProfileTexture;

class abc
implements vn {
    final /* synthetic */ mjb v;
    private static volatile /* synthetic */ int[] d;

    abc(mjb a2) {
        abc a3;
        a3.v = a2;
    }

    @Override
    public void a(MinecraftProfileTexture.Type a2, wmc a3, MinecraftProfileTexture a4) {
        switch (abc.a()[a2.ordinal()]) {
            case 1: {
                abc a5;
                mjb.p(a5.v, a3);
                mjb.a(a5.v, a4.getMetadata("model"));
                if (mjb.a(a5.v) != null) break;
                mjb.a(a5.v, "default");
                break;
            }
            case 2: {
                abc a5;
                mjb.a(a5.v, a3);
            }
        }
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[MinecraftProfileTexture.Type.values().length];
        try {
            nArray[MinecraftProfileTexture.Type.CAPE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[MinecraftProfileTexture.Type.SKIN.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

