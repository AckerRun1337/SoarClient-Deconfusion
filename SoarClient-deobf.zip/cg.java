/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

public class cg
extends ej {
    public cg() {
        cg a2;
    }

    public cg(moa a2, int a3, Random a4, uxc a5, hnd a6) {
        super(a2, a3);
        cg a7;
        a7.c = a6;
        a7.b = a5;
    }

    public static cg a(moa a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        uxc uxc2 = uxc.a(a5, a6, a7, 0, 0, 0, 9, 7, 11, a8);
        return cg.a(uxc2) && ae.a(a3, uxc2) == null ? new cg(a2, a9, a4, uxc2, a8) : null;
    }

    @Override
    public boolean a(xga a2, Random a3, uxc a4) {
        int n2;
        cg a5;
        if (a5.b < 0) {
            a5.b = a5.a(a2, a4);
            if (a5.b < 0) {
                return true;
            }
            a5.b.a(0, a5.b - a5.b.c + 7 - 1, 0);
        }
        a5.a(a2, a4, 1, 1, 1, 7, 4, 4, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 2, 1, 6, 8, 4, 10, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 2, 0, 6, 8, 0, 10, cl.zk.a(), cl.zk.a(), false);
        a5.p(a2, cl.um.a(), 6, 0, 6, a4);
        a5.a(a2, a4, 2, 1, 6, 2, 1, 10, cl.if.a(), cl.if.a(), false);
        a5.a(a2, a4, 8, 1, 6, 8, 1, 10, cl.if.a(), cl.if.a(), false);
        a5.a(a2, a4, 3, 1, 10, 7, 1, 10, cl.if.a(), cl.if.a(), false);
        a5.a(a2, a4, 1, 0, 1, 7, 0, 4, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 0, 0, 0, 3, 5, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 8, 0, 0, 8, 3, 5, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 1, 0, 0, 7, 1, 0, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 1, 0, 5, 7, 1, 5, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 1, 2, 0, 7, 3, 0, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 1, 2, 5, 7, 3, 5, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 4, 1, 8, 4, 1, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 4, 4, 8, 4, 4, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 5, 2, 8, 5, 3, cl.yl.a(), cl.yl.a(), false);
        a5.p(a2, cl.yl.a(), 0, 4, 2, a4);
        a5.p(a2, cl.yl.a(), 0, 4, 3, a4);
        a5.p(a2, cl.yl.a(), 8, 4, 2, a4);
        a5.p(a2, cl.yl.a(), 8, 4, 3, a4);
        int n3 = a5.a(cl.ri, 3);
        int n4 = a5.a(cl.ri, 2);
        int n5 = -1;
        while (n5 <= 2) {
            n2 = 0;
            while (n2 <= 8) {
                a5.p(a2, cl.ri.a(n3), n2, 4 + n5, n5, a4);
                a5.p(a2, cl.ri.a(n4), n2, 4 + n5, 5 - n5, a4);
                ++n2;
            }
            ++n5;
        }
        a5.p(a2, cl.ej.a(), 0, 2, 1, a4);
        a5.p(a2, cl.ej.a(), 0, 2, 4, a4);
        a5.p(a2, cl.ej.a(), 8, 2, 1, a4);
        a5.p(a2, cl.ej.a(), 8, 2, 4, a4);
        a5.p(a2, cl.xc.a(), 0, 2, 2, a4);
        a5.p(a2, cl.xc.a(), 0, 2, 3, a4);
        a5.p(a2, cl.xc.a(), 8, 2, 2, a4);
        a5.p(a2, cl.xc.a(), 8, 2, 3, a4);
        a5.p(a2, cl.xc.a(), 2, 2, 5, a4);
        a5.p(a2, cl.xc.a(), 3, 2, 5, a4);
        a5.p(a2, cl.xc.a(), 5, 2, 0, a4);
        a5.p(a2, cl.xc.a(), 6, 2, 5, a4);
        a5.p(a2, cl.if.a(), 2, 1, 3, a4);
        a5.p(a2, cl.ae.a(), 2, 2, 3, a4);
        a5.p(a2, cl.yl.a(), 1, 1, 4, a4);
        a5.p(a2, cl.ri.a(a5.a(cl.ri, 3)), 2, 1, 4, a4);
        a5.p(a2, cl.ri.a(a5.a(cl.ri, 1)), 1, 1, 3, a4);
        a5.a(a2, a4, 5, 0, 1, 7, 0, 3, cl.cg.a(), cl.cg.a(), false);
        a5.p(a2, cl.cg.a(), 6, 1, 1, a4);
        a5.p(a2, cl.cg.a(), 6, 1, 2, a4);
        a5.p(a2, cl.cd.a(), 2, 1, 0, a4);
        a5.p(a2, cl.cd.a(), 2, 2, 0, a4);
        a5.p(a2, cl.jm.a().a(hlb.v, a5.c), 2, 3, 1, a4);
        a5.a(a2, a4, a3, 2, 1, 0, hnd.a(a5.a(cl.tm, 1)));
        if (a5.a(a2, 2, 0, -1, a4).a().a() == dr.ua && a5.a(a2, 2, -1, -1, a4).a().a() != dr.ua) {
            a5.p(a2, cl.ig.a(a5.a(cl.ig, 3)), 2, 0, -1, a4);
        }
        a5.p(a2, cl.cd.a(), 6, 1, 5, a4);
        a5.p(a2, cl.cd.a(), 6, 2, 5, a4);
        a5.p(a2, cl.jm.a().a(hlb.v, a5.c.z()), 6, 3, 4, a4);
        a5.a(a2, a4, a3, 6, 1, 5, hnd.a(a5.a(cl.tm, 1)));
        n5 = 0;
        while (n5 < 5) {
            n2 = 0;
            while (n2 < 9) {
                a5.a(a2, n2, 7, n5, a4);
                a5.a(a2, cl.um.a(), n2, -1, n5, a4);
                ++n2;
            }
            ++n5;
        }
        a5.a(a2, a4, 4, 1, 2, 2);
        return true;
    }

    @Override
    protected int o(int a2, int a3) {
        cg a4;
        return a2 == 0 ? 4 : super.o(a2, a3);
    }
}

