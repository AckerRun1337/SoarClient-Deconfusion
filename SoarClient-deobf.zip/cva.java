/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  tv.twitch.broadcast.IStatCallbacks
 *  tv.twitch.broadcast.StatType
 */
import tv.twitch.broadcast.IStatCallbacks;
import tv.twitch.broadcast.StatType;

class cva
implements IStatCallbacks {
    final /* synthetic */ tic d;

    cva(tic a2) {
        cva a3;
        a3.d = a2;
    }

    public void statCallback(StatType a2, long a3) {
    }
}

