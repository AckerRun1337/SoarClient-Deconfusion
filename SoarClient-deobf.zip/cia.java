/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cia
extends hia {
    fda v;
    xi d;

    public cia(fda a2) {
        super(a2, false, true);
        cia a3;
        a3.v = a2;
        a3.a(1);
    }

    @Override
    public boolean o() {
        cia a2;
        ao ao2 = a2.v.a();
        if (ao2 == null) {
            return false;
        }
        a2.d = ao2.a(a2.v);
        if (a2.d instanceof rua) {
            return false;
        }
        if (!a2.a(a2.d, false)) {
            if (a2.z.a().nextInt(20) == 0) {
                a2.d = ao2.a(a2.v);
                return a2.a(a2.d, false);
            }
            return false;
        }
        return true;
    }

    @Override
    public void o() {
        cia a2;
        a2.v.o(a2.d);
        super.o();
    }
}

