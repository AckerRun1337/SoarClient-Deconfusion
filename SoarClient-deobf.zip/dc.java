/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import net.optifine.shaders.\u8a6e\u5016\u86cd\u53ca\u6adb\u9baa\u63d0\u6d78\u5426\u821e\u8f44\u7a7a\u6176\u76c3\u7a0e\u690e\u6d74\u5bbf\u654f\u66fd\u5516\u5bff\u64fe\u4fca\u52ff\u8f44\u5446\u5516\u79e6\u8755\u758f\u8074\u7121\u83cc\u6dd1\u5efa\u4f7f\u7577\u6795\u8acf;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface dc {
    public void a(boolean var1, boolean var2);

    public void p();

    public void a(fa var1) throws IOException;

    public int a();

    public \u8a6e\u5016\u86cd\u53ca\u6adb\u9baa\u63d0\u6d78\u5426\u821e\u8f44\u7a7a\u6176\u76c3\u7a0e\u690e\u6d74\u5bbf\u654f\u66fd\u5516\u5bff\u64fe\u4fca\u52ff\u8f44\u5446\u5516\u79e6\u8755\u758f\u8074\u7121\u83cc\u6dd1\u5efa\u4f7f\u7577\u6795\u8acf a();
}

