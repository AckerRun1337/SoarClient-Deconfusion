/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class coc
implements Serializable,
Cloneable {
    private int c;
    double[] v;
    static final long d = 1398850036893875112L;

    public coc(int a2) {
        coc a3;
        a3.c = a2;
        a3.v = new double[a2];
        int n2 = 0;
        while (n2 < a2) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public coc(double[] a2) {
        coc a3;
        a3.c = a2.length;
        a3.v = new double[a2.length];
        int n2 = 0;
        while (n2 < a3.c) {
            a3.v[n2] = a2[n2];
            ++n2;
        }
    }

    public coc(coc a2) {
        coc a3;
        a3.v = new double[a2.c];
        a3.c = a2.c;
        int n2 = 0;
        while (n2 < a3.c) {
            a3.v[n2] = a2.v[n2];
            ++n2;
        }
    }

    public coc(cm a2) {
        coc a3;
        a3.v = new double[2];
        a3.v[0] = a2.v;
        a3.v[1] = a2.d;
        a3.c = 2;
    }

    public coc(jp a2) {
        coc a3;
        a3.v = new double[3];
        a3.v[0] = a2.c;
        a3.v[1] = a2.v;
        a3.v[2] = a2.d;
        a3.c = 3;
    }

    public coc(dva a2) {
        coc a3;
        a3.v = new double[3];
        a3.v[0] = a2.c;
        a3.v[1] = a2.v;
        a3.v[2] = a2.d;
        a3.c = 3;
    }

    public coc(cf a2) {
        coc a3;
        a3.v = new double[4];
        a3.v[0] = a2.b;
        a3.v[1] = a2.c;
        a3.v[2] = a2.v;
        a3.v[3] = a2.d;
        a3.c = 4;
    }

    public coc(nx a2) {
        coc a3;
        a3.v = new double[4];
        a3.v[0] = a2.b;
        a3.v[1] = a2.c;
        a3.v[2] = a2.v;
        a3.v[3] = a2.d;
        a3.c = 4;
    }

    public coc(double[] a2, int a3) {
        coc a4;
        a4.c = a3;
        a4.v = new double[a3];
        int n2 = 0;
        while (n2 < a3) {
            a4.v[n2] = a2[n2];
            ++n2;
        }
    }

    public final double p() {
        coc a2;
        double d2 = 0.0;
        int n2 = 0;
        while (n2 < a2.c) {
            d2 += a2.v[n2] * a2.v[n2];
            ++n2;
        }
        return Math.sqrt(d2);
    }

    public final double a() {
        coc a2;
        double d2 = 0.0;
        int n2 = 0;
        while (n2 < a2.c) {
            d2 += a2.v[n2] * a2.v[n2];
            ++n2;
        }
        return d2;
    }

    public final void y(coc a2) {
        coc a3;
        double d2 = 0.0;
        if (a3.c != a2.c) {
            throw new efa(awb.a("GVector0"));
        }
        int n2 = 0;
        while (n2 < a3.c) {
            d2 += a2.v[n2] * a2.v[n2];
            ++n2;
        }
        double d3 = 1.0 / Math.sqrt(d2);
        n2 = 0;
        while (n2 < a3.c) {
            a3.v[n2] = a2.v[n2] * d3;
            ++n2;
        }
    }

    public final void o() {
        coc a2;
        double d2 = 0.0;
        int n2 = 0;
        while (n2 < a2.c) {
            d2 += a2.v[n2] * a2.v[n2];
            ++n2;
        }
        double d3 = 1.0 / Math.sqrt(d2);
        n2 = 0;
        while (n2 < a2.c) {
            a2.v[n2] = a2.v[n2] * d3;
            ++n2;
        }
    }

    public final void a(double a2, coc a3) {
        coc a4;
        if (a4.c != a3.c) {
            throw new efa(awb.a("GVector1"));
        }
        int n2 = 0;
        while (n2 < a4.c) {
            a4.v[n2] = a3.v[n2] * a2;
            ++n2;
        }
    }

    public final void a(double a2) {
        coc a3;
        int n2 = 0;
        while (n2 < a3.c) {
            a3.v[n2] = a3.v[n2] * a2;
            ++n2;
        }
    }

    public final void a(double a2, coc a3, coc a4) {
        coc a5;
        if (a4.c != a3.c) {
            throw new efa(awb.a("GVector2"));
        }
        if (a5.c != a3.c) {
            throw new efa(awb.a("GVector3"));
        }
        int n2 = 0;
        while (n2 < a5.c) {
            a5.v[n2] = a3.v[n2] * a2 + a4.v[n2];
            ++n2;
        }
    }

    public final void o(coc a2) {
        coc a3;
        if (a3.c != a2.c) {
            throw new efa(awb.a("GVector4"));
        }
        int n2 = 0;
        while (n2 < a3.c) {
            int n3 = n2;
            a3.v[n3] = a3.v[n3] + a2.v[n2];
            ++n2;
        }
    }

    public final void p(coc a2, coc a3) {
        coc a4;
        if (a2.c != a3.c) {
            throw new efa(awb.a("GVector5"));
        }
        if (a4.c != a2.c) {
            throw new efa(awb.a("GVector6"));
        }
        int n2 = 0;
        while (n2 < a4.c) {
            a4.v[n2] = a2.v[n2] + a3.v[n2];
            ++n2;
        }
    }

    public final void p(coc a2) {
        coc a3;
        if (a3.c != a2.c) {
            throw new efa(awb.a("GVector7"));
        }
        int n2 = 0;
        while (n2 < a3.c) {
            int n3 = n2;
            a3.v[n3] = a3.v[n3] - a2.v[n2];
            ++n2;
        }
    }

    public final void a(coc a2, coc a3) {
        coc a4;
        if (a2.c != a3.c) {
            throw new efa(awb.a("GVector8"));
        }
        if (a4.c != a2.c) {
            throw new efa(awb.a("GVector9"));
        }
        int n2 = 0;
        while (n2 < a4.c) {
            a4.v[n2] = a2.v[n2] - a3.v[n2];
            ++n2;
        }
    }

    public final void a(vw a2, coc a3) {
        coc a4;
        if (a2.a() != a3.c) {
            throw new efa(awb.a("GVector10"));
        }
        if (a4.c != a2.p()) {
            throw new efa(awb.a("GVector11"));
        }
        double[] dArray = a3 != a4 ? a3.v : (double[])a4.v.clone();
        int n2 = a4.c - 1;
        while (n2 >= 0) {
            a4.v[n2] = 0.0;
            int n3 = a3.c - 1;
            while (n3 >= 0) {
                int n4 = n2;
                a4.v[n4] = a4.v[n4] + a2.v[n2][n3] * dArray[n3];
                --n3;
            }
            --n2;
        }
    }

    public final void a(coc a2, vw a3) {
        coc a4;
        if (a3.p() != a2.c) {
            throw new efa(awb.a("GVector12"));
        }
        if (a4.c != a3.a()) {
            throw new efa(awb.a("GVector13"));
        }
        double[] dArray = a2 != a4 ? a2.v : (double[])a4.v.clone();
        int n2 = a4.c - 1;
        while (n2 >= 0) {
            a4.v[n2] = 0.0;
            int n3 = a2.c - 1;
            while (n3 >= 0) {
                int n4 = n2;
                a4.v[n4] = a4.v[n4] + a3.v[n3][n2] * dArray[n3];
                --n3;
            }
            --n2;
        }
    }

    public final void p() {
        coc a2;
        int n2 = a2.c - 1;
        while (n2 >= 0) {
            int n3 = n2--;
            a2.v[n3] = a2.v[n3] * -1.0;
        }
    }

    public final void a() {
        coc a2;
        int n2 = 0;
        while (n2 < a2.c) {
            a2.v[n2] = 0.0;
            ++n2;
        }
    }

    public final void a(int a2) {
        coc a3;
        double[] dArray = new double[a2];
        int n2 = a3.c < a2 ? a3.c : a2;
        int n3 = 0;
        while (n3 < n2) {
            dArray[n3] = a3.v[n3];
            ++n3;
        }
        a3.c = a2;
        a3.v = dArray;
    }

    public final void a(double[] a2) {
        coc a3;
        int n2 = a3.c - 1;
        while (n2 >= 0) {
            a3.v[n2] = a2[n2];
            --n2;
        }
    }

    public final void a(coc a2) {
        coc a3;
        if (a3.c < a2.c) {
            a3.c = a2.c;
            a3.v = new double[a3.c];
            int n2 = 0;
            while (n2 < a3.c) {
                a3.v[n2] = a2.v[n2];
                ++n2;
            }
        } else {
            int n3 = 0;
            while (n3 < a2.c) {
                a3.v[n3] = a2.v[n3];
                ++n3;
            }
            n3 = a2.c;
            while (n3 < a3.c) {
                a3.v[n3] = 0.0;
                ++n3;
            }
        }
    }

    public final void a(cm a2) {
        coc a3;
        if (a3.c < 2) {
            a3.c = 2;
            a3.v = new double[2];
        }
        a3.v[0] = a2.v;
        a3.v[1] = a2.d;
        int n2 = 2;
        while (n2 < a3.c) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public final void a(jp a2) {
        coc a3;
        if (a3.c < 3) {
            a3.c = 3;
            a3.v = new double[3];
        }
        a3.v[0] = a2.c;
        a3.v[1] = a2.v;
        a3.v[2] = a2.d;
        int n2 = 3;
        while (n2 < a3.c) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public final void a(dva a2) {
        coc a3;
        if (a3.c < 3) {
            a3.c = 3;
            a3.v = new double[3];
        }
        a3.v[0] = a2.c;
        a3.v[1] = a2.v;
        a3.v[2] = a2.d;
        int n2 = 3;
        while (n2 < a3.c) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public final void a(cf a2) {
        coc a3;
        if (a3.c < 4) {
            a3.c = 4;
            a3.v = new double[4];
        }
        a3.v[0] = a2.b;
        a3.v[1] = a2.c;
        a3.v[2] = a2.v;
        a3.v[3] = a2.d;
        int n2 = 4;
        while (n2 < a3.c) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public final void a(nx a2) {
        coc a3;
        if (a3.c < 4) {
            a3.c = 4;
            a3.v = new double[4];
        }
        a3.v[0] = a2.b;
        a3.v[1] = a2.c;
        a3.v[2] = a2.v;
        a3.v[3] = a2.d;
        int n2 = 4;
        while (n2 < a3.c) {
            a3.v[n2] = 0.0;
            ++n2;
        }
    }

    public final int a() {
        coc a2;
        return a2.v.length;
    }

    public final double a(int a2) {
        coc a3;
        return a3.v[a2];
    }

    public final void a(int a2, double a3) {
        a.v[a2] = a3;
    }

    public String toString() {
        coc a2;
        StringBuffer stringBuffer = new StringBuffer(a2.c * 8);
        int n2 = 0;
        while (n2 < a2.c) {
            stringBuffer.append(a2.v[n2]).append(" ");
            ++n2;
        }
        return stringBuffer.toString();
    }

    public int hashCode() {
        coc a2;
        long l2 = 1L;
        int n2 = 0;
        while (n2 < a2.c) {
            l2 = kbd.a(l2, a2.v[n2]);
            ++n2;
        }
        return kbd.a(l2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a(coc a2) {
        try {
            coc a3;
            if (a3.c != a2.c) {
                return false;
            }
            int n2 = 0;
            while (true) {
                if (n2 >= a3.c) {
                    return true;
                }
                if (a3.v[n2] != a2.v[n2]) {
                    return false;
                }
                ++n2;
            }
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean equals(Object a2) {
        try {
            coc a3;
            coc coc2 = (coc)a2;
            if (a3.c != coc2.c) {
                return false;
            }
            int n2 = 0;
            while (true) {
                if (n2 >= a3.c) {
                    return true;
                }
                if (a3.v[n2] != coc2.v[n2]) {
                    return false;
                }
                ++n2;
            }
        }
        catch (ClassCastException classCastException) {
            return false;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean a(coc a2, double a3) {
        coc a4;
        if (a4.c != a2.c) {
            return false;
        }
        int n2 = 0;
        while (n2 < a4.c) {
            double d2 = a4.v[n2] - a2.v[n2];
            double d3 = d2 < 0.0 ? -d2 : d2;
            if (d3 > a3) {
                return false;
            }
            ++n2;
        }
        return true;
    }

    public final double p(coc a2) {
        coc a3;
        if (a3.c != a2.c) {
            throw new efa(awb.a("GVector14"));
        }
        double d2 = 0.0;
        int n2 = 0;
        while (n2 < a3.c) {
            d2 += a3.v[n2] * a2.v[n2];
            ++n2;
        }
        return d2;
    }

    public final void a(vw a2, vw a3, vw a4, coc a5) {
        coc a6;
        if (a2.b != a5.a() || a2.b != a2.c || a2.b != a3.b) {
            throw new efa(awb.a("GVector15"));
        }
        if (a3.c != a6.v.length || a3.c != a4.c || a3.c != a4.b) {
            throw new efa(awb.a("GVector23"));
        }
        vw vw2 = new vw(a2.b, a3.c);
        vw2.j(a2, a4);
        vw2.p(a2, a3);
        vw2.p();
        a6.a(vw2, a5);
    }

    public final void a(vw a2, coc a3, coc a4) {
        int n2 = a2.b * a2.c;
        double[] dArray = new double[n2];
        double[] dArray2 = new double[n2];
        int[] nArray = new int[a3.a()];
        if (a2.b != a3.a()) {
            throw new efa(awb.a("GVector16"));
        }
        if (a2.b != a4.a()) {
            throw new efa(awb.a("GVector24"));
        }
        if (a2.b != a2.c) {
            throw new efa(awb.a("GVector25"));
        }
        int n3 = 0;
        while (n3 < a2.b) {
            int n4 = 0;
            while (n4 < a2.c) {
                dArray[n3 * a2.c + n4] = a2.v[n3][n4];
                ++n4;
            }
            ++n3;
        }
        n3 = 0;
        while (n3 < n2) {
            dArray2[n3] = 0.0;
            ++n3;
        }
        n3 = 0;
        while (n3 < a2.b) {
            dArray2[n3 * a2.c] = a3.v[n3];
            ++n3;
        }
        n3 = 0;
        while (n3 < a2.c) {
            nArray[n3] = (int)a4.v[n3];
            ++n3;
        }
        vw.a(a2.b, dArray, nArray, dArray2);
        n3 = 0;
        while (n3 < a2.b) {
            a.v[n3] = dArray2[n3 * a2.c];
            ++n3;
        }
    }

    public final double a(coc a2) {
        coc a3;
        return Math.acos(a3.p(a2) / (a3.p() * a2.p()));
    }

    public final void a(coc a2, coc a3, float a4) {
        coc a5;
        a5.a(a2, a3, (double)a4);
    }

    public final void a(coc a2, float a3) {
        coc a4;
        a4.a(a2, (double)a3);
    }

    public final void a(coc a2, coc a3, double a4) {
        coc a5;
        if (a3.c != a2.c) {
            throw new efa(awb.a("GVector20"));
        }
        if (a5.c != a2.c) {
            throw new efa(awb.a("GVector21"));
        }
        int n2 = 0;
        while (n2 < a5.c) {
            a5.v[n2] = (1.0 - a4) * a2.v[n2] + a4 * a3.v[n2];
            ++n2;
        }
    }

    public final void a(coc a2, double a3) {
        coc a4;
        if (a2.c != a4.c) {
            throw new efa(awb.a("GVector22"));
        }
        int n2 = 0;
        while (n2 < a4.c) {
            a4.v[n2] = (1.0 - a3) * a4.v[n2] + a3 * a2.v[n2];
            ++n2;
        }
    }

    public Object clone() {
        coc a2;
        coc coc2 = null;
        try {
            coc2 = (coc)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
        coc2.v = new double[a2.c];
        int n2 = 0;
        while (n2 < a2.c) {
            coc2.v[n2] = a2.v[n2];
            ++n2;
        }
        return coc2;
    }
}

