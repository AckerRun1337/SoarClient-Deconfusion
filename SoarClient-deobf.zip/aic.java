/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.base.Predicate;
import java.util.Collections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aic
extends mi {
    private static final Logger z = LogManager.getLogger();
    private dj l;
    private final Predicate<xi> b;
    private final qy c;
    private xi v;
    private Class<? extends xi> d;

    public aic(dj a2, Class<? extends xi> a3) {
        aic a4;
        a4.l = a2;
        a4.d = a3;
        if (a2 instanceof sj) {
            z.warn("Use NearestAttackableTargetGoal.class for PathfinerMob mobs!");
        }
        a4.b = new vh(a4);
        a4.c = new qy(a2);
    }

    @Override
    public boolean o() {
        aic a2;
        double d2 = a2.a();
        Predicate<xi> predicate = a2.l.ib.a(a2.d, a2.l.a().o(d2, 4.0, d2), a2.b);
        Collections.sort(predicate, a2.c);
        if (predicate.isEmpty()) {
            return false;
        }
        a2.v = (xi)predicate.get(0);
        return true;
    }

    @Override
    public boolean p() {
        aic a2;
        xi xi2 = a2.l.y();
        if (xi2 == null) {
            return false;
        }
        if (!xi2.g()) {
            return false;
        }
        double d2 = a2.a();
        return a2.l.a((rj)xi2) > d2 * d2 ? false : !(xi2 instanceof xj) || !((xj)xi2).oa.a();
    }

    @Override
    public void o() {
        aic a2;
        a2.l.o(a2.v);
        super.o();
    }

    @Override
    public void p() {
        aic a2;
        a2.l.o((xi)null);
        super.o();
    }

    protected double a() {
        aic a2;
        pb pb2 = a2.l.a(prc.b);
        return pb2 == null ? 16.0 : pb2.a();
    }

    static /* synthetic */ dj a(aic a2) {
        return a2.l;
    }
}

