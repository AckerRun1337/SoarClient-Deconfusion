/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

interface a {
    public boolean a(bw var1);

    public fj a(hnd var1, bw var2, Random var3);
}

