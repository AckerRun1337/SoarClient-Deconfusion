/*
 * Decompiled with CFR 0.152.
 */
public class cvc {
    public final int v;
    public final int d;

    public cvc(int a2, int a3) {
        cvc a4;
        a4.v = a2;
        a4.d = a3;
    }
}

