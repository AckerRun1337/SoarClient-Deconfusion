/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 *  com.google.common.cache.LoadingCache
 */
import com.google.common.base.Objects;
import com.google.common.cache.LoadingCache;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class clc {
    private final tp h;
    private final hnd z;
    private final hnd l;
    private final LoadingCache<tp, rfa> b;
    private final int c;
    private final int v;
    private final int d;

    public clc(tp a2, hnd a3, hnd a4, LoadingCache<tp, rfa> a5, int a6, int a7, int a8) {
        clc a9;
        a9.h = a2;
        a9.z = a3;
        a9.l = a4;
        a9.b = a5;
        a9.c = a6;
        a9.v = a7;
        a9.d = a8;
    }

    public tp a() {
        clc a2;
        return a2.h;
    }

    public hnd p() {
        clc a2;
        return a2.z;
    }

    public hnd a() {
        clc a2;
        return a2.l;
    }

    public int p() {
        clc a2;
        return a2.c;
    }

    public int a() {
        clc a2;
        return a2.v;
    }

    public rfa a(int a2, int a3, int a4) {
        clc a5;
        return (rfa)a5.b.getUnchecked((Object)vfb.a(a5.h, a5.p(), a5.a(), a2, a3, a4));
    }

    public String toString() {
        clc a2;
        return Objects.toStringHelper((Object)a2).add("up", (Object)a2.l).add("forwards", (Object)a2.z).add("frontTopLeft", (Object)a2.h).toString();
    }
}

