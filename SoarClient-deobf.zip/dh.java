/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class dh
extends en {
    public dh() {
        dh a2;
    }

    @Override
    public void m() {
        dh a2;
        a2.r.clear();
        a2.r.add(new mkb(0, n / 2 - 155, e / 4 + 120 + 12, xab.a("gui.toTitle", new Object[0])));
        a2.r.add(new mkb(1, n / 2 - 155 + 160, e / 4 + 120 + 12, xab.a("menu.quit", new Object[0])));
    }

    @Override
    protected void a(ff a2) throws IOException {
        dh a3;
        if (a2.b == 0) {
            a3.w.a(new gqa());
        } else if (a2.b == 1) {
            a3.w.r();
        }
    }

    @Override
    protected void a(char a2, int a3) throws IOException {
    }

    @Override
    public void a(int a2, int a3, float a4) {
        dh a5;
        a5.o();
        a5.p(a5.z, "Out of memory!", n / 2, e / 4 - 60 + 20, 0xFFFFFF);
        a5.a(a5.z, "Minecraft has run out of memory.", n / 2 - 140, e / 4 - 60 + 60 + 0, 0xA0A0A0);
        a5.a(a5.z, "This could be caused by a bug in the game or by the", n / 2 - 140, e / 4 - 60 + 60 + 18, 0xA0A0A0);
        a5.a(a5.z, "Java Virtual Machine not being allocated enough", n / 2 - 140, e / 4 - 60 + 60 + 27, 0xA0A0A0);
        a5.a(a5.z, "memory.", n / 2 - 140, e / 4 - 60 + 60 + 36, 0xA0A0A0);
        a5.a(a5.z, "To prevent level corruption, the current game has quit.", n / 2 - 140, e / 4 - 60 + 60 + 54, 0xA0A0A0);
        a5.a(a5.z, "We've tried to free up enough memory to let you go back to", n / 2 - 140, e / 4 - 60 + 60 + 63, 0xA0A0A0);
        a5.a(a5.z, "the main menu and back to playing, but this may not have worked.", n / 2 - 140, e / 4 - 60 + 60 + 72, 0xA0A0A0);
        a5.a(a5.z, "Please restart the game if you see this message again.", n / 2 - 140, e / 4 - 60 + 60 + 81, 0xA0A0A0);
        super.a(a2, a3, a4);
    }
}

