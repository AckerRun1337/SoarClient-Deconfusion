/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.ListenableFuture
 *  com.mojang.authlib.GameProfile
 *  com.mojang.util.UUIDTypeAdapter
 */
import com.google.common.util.concurrent.ListenableFuture;
import com.mojang.authlib.GameProfile;
import com.mojang.util.UUIDTypeAdapter;
import java.net.Proxy;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class arc {
    public arc() {
        arc a2;
    }

    public static boolean o() {
        return oj.a().jb.kj;
    }

    public static Proxy a() {
        return oj.a().a();
    }

    public static String j() {
        dba dba2 = oj.a().a();
        return dba2 == null ? null : dba2.y();
    }

    public static String z() {
        dba dba2 = oj.a().a();
        return dba2 == null ? null : dba2.p();
    }

    public static long a() {
        return oj.a();
    }

    public static String y() {
        return oj.a().a().y();
    }

    public static String o() {
        return oj.a().a().o();
    }

    public static String p() {
        return oj.a().a().p();
    }

    public static String a(String a2) {
        return oj.a().a().fillProfileProperties(new GameProfile(UUIDTypeAdapter.fromString((String)a2), null), false).getName();
    }

    public static void a(fjb a2) {
        oj.a().a(a2.a());
    }

    public static String a() {
        return oj.a().ra.getAbsolutePath();
    }

    public static int y() {
        return lq.h.a();
    }

    public static int o() {
        return lq.z.a();
    }

    public static int p() {
        return lq.l.a();
    }

    public static int a() {
        return lq.b.a();
    }

    public static void a(boolean a2) {
        oj.a().a(a2);
    }

    public static ListenableFuture<Object> a(String a2, String a3) {
        ListenableFuture<Object> listenableFuture = oj.a().a().a(a2, a3);
        return listenableFuture;
    }

    public static void a() {
        oj.a().a().a();
    }

    public static boolean p() {
        return oj.a().jb.a(fz.tc);
    }

    public static boolean a() {
        return oj.a().sb != null && oj.a().sb instanceof gqa;
    }
}

