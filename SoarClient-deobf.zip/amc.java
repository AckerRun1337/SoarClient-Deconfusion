/*
 * Decompiled with CFR 0.152.
 */
class amc {
    public jad l = new jad(null);
    public int b = -1;
    public int c = 7680;
    public int v = 7680;
    public int d = 7680;

    private /* synthetic */ amc() {
        amc a2;
    }

    /* synthetic */ amc(amc a2) {
        a3();
        amc a3;
    }
}

