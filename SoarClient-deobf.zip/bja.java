/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bja
extends nx
implements Serializable {
    static final long d = 3938123424117448700L;

    public bja(double a2, double a3, double a4, double a5) {
        super(a2, a3, a4, a5);
        bja a6;
    }

    public bja(double[] a2) {
        super(a2);
        bja a3;
    }

    public bja(bja a2) {
        super(a2);
        bja a3;
    }

    public bja(yuc a2) {
        super(a2);
        bja a3;
    }

    public bja(cf a2) {
        super(a2);
        bja a3;
    }

    public bja(nx a2) {
        super(a2);
        bja a3;
    }

    public bja(dva a2) {
        super(a2.c, a2.v, a2.d, 0.0);
        bja a3;
    }

    public bja() {
        bja a2;
    }

    public final void a(dva a2) {
        a.b = a2.c;
        a.c = a2.v;
        a.v = a2.d;
        a.d = (long)0.0;
    }

    public final double j() {
        bja a2;
        return Math.sqrt(a2.b * a2.b + a2.c * a2.c + a2.v * a2.v + a2.d * a2.d);
    }

    public final double z() {
        bja a2;
        return a2.b * a2.b + a2.c * a2.c + a2.v * a2.v + a2.d * a2.d;
    }

    public final double p(bja a2) {
        bja a3;
        return a3.b * a2.b + a3.c * a2.c + a3.v * a2.v + a3.d * a2.d;
    }

    public final void a(bja a2) {
        double d2 = 1.0 / Math.sqrt(a2.b * a2.b + a2.c * a2.c + a2.v * a2.v + a2.d * a2.d);
        a.b = a2.b * d2;
        a.c = a2.c * d2;
        a.v = a2.v * d2;
        a.d = a2.d * d2;
    }

    public final void o() {
        bja a2;
        double d2 = 1.0 / Math.sqrt(a2.b * a2.b + a2.c * a2.c + a2.v * a2.v + a2.d * a2.d);
        a2.b *= d2;
        a2.c *= d2;
        a2.v *= d2;
        a2.d *= d2;
    }

    public final double a(bja a2) {
        bja a3;
        double d2 = a3.p(a2) / (a3.j() * a2.j());
        if (d2 < -1.0) {
            d2 = -1.0;
        }
        if (d2 > 1.0) {
            d2 = 1.0;
        }
        return Math.acos(d2);
    }
}

