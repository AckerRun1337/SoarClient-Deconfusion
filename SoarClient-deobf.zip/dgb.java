/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dgb
extends ml {
    private Map<String, ml> d = Maps.newHashMap();

    public dgb() {
        dgb a2;
    }

    @Override
    void a(DataOutput a2) throws IOException {
        dgb a3;
        for (String string : a3.d.keySet()) {
            ml ml2 = a3.d.get(string);
            dgb.a(string, ml2, a2);
        }
        a2.writeByte(0);
    }

    @Override
    void a(DataInput a2, int a3, hcd a4) throws IOException {
        byte by2;
        dgb a5;
        a4.a(384L);
        if (a3 > 512) {
            throw new RuntimeException("Tried to read NBT tag with too high complexity, depth > 512");
        }
        a5.d.clear();
        while ((by2 = a2.readByte()) != 0) {
            String string = a2.readUTF();
            a4.a(224 + 16 * string.length());
            ml ml2 = dgb.a(by2, string, a2, a3 + 1, a4);
            if (a5.d.put(string, ml2) == null) continue;
            a4.a(288L);
        }
    }

    public Set<String> a() {
        dgb a2;
        return a2.d.keySet();
    }

    @Override
    public byte a() {
        return 10;
    }

    public void a(String a2, ml a3) {
        dgb a4;
        if (a3 == null) {
            throw new IllegalArgumentException("Invalid null NBT value with key " + a2);
        }
        a4.d.put(a2, a3);
    }

    public void a(String a2, byte a3) {
        dgb a4;
        a4.d.put(a2, new jcb(a3));
    }

    public void a(String a2, short a3) {
        dgb a4;
        a4.d.put(a2, new txb(a3));
    }

    public void a(String a2, int a3) {
        dgb a4;
        a4.d.put(a2, new enc(a3));
    }

    public void a(String a2, long a3) {
        dgb a4;
        a4.d.put(a2, new tra(a3));
    }

    public void a(String a2, float a3) {
        dgb a4;
        a4.d.put(a2, new idb(a3));
    }

    public void a(String a2, double a3) {
        dgb a4;
        a4.d.put(a2, new qp(a3));
    }

    public void a(String a2, String a3) {
        dgb a4;
        a4.d.put(a2, new ep(a3));
    }

    public void a(String a2, byte[] a3) {
        dgb a4;
        a4.d.put(a2, new vha(a3));
    }

    public void a(String a2, int[] a3) {
        dgb a4;
        a4.d.put(a2, new ad(a3));
    }

    public void a(String a2, boolean a3) {
        dgb a4;
        a4.a(a2, (byte)(a3 ? (char)'\u0001' : '\u0000'));
    }

    public ml a(String a2) {
        dgb a3;
        return a3.d.get(a2);
    }

    public byte p(String a2) {
        dgb a3;
        ml ml2 = a3.d.get(a2);
        return ml2 != null ? ml2.a() : (byte)0;
    }

    public boolean p(String a2) {
        dgb a3;
        return a3.d.containsKey(a2);
    }

    public boolean a(String a2, int a3) {
        dgb a4;
        byte by2 = a4.p(a2);
        if (by2 == a3) {
            return true;
        }
        if (a3 != 99) {
            if (by2 > 0) {
                // empty if block
            }
            return false;
        }
        return by2 == 1 || by2 == 2 || by2 == 3 || by2 == 4 || by2 == 5 || by2 == 6;
    }

    public byte a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? (byte)0 : ((vu)a3.d.get(a2)).p();
        }
        catch (ClassCastException classCastException) {
            return 0;
        }
    }

    public short a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? (short)0 : ((vu)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            return 0;
        }
    }

    public int a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? 0 : ((vu)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            return 0;
        }
    }

    public long a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? 0L : ((vu)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            return 0L;
        }
    }

    public float a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? 0.0f : ((vu)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            return 0.0f;
        }
    }

    public double a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 99) ? 0.0 : ((vu)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            return 0.0;
        }
    }

    public String a(String a2) {
        try {
            dgb a3;
            return !a3.a(a2, 8) ? "" : a3.d.get(a2).a();
        }
        catch (ClassCastException classCastException) {
            return "";
        }
    }

    public byte[] a(String a2) {
        dgb a3;
        try {
            return !a3.a(a2, 7) ? new byte[]{} : ((vha)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            throw new yja(a3.a(a2, 7, classCastException));
        }
    }

    public int[] a(String a2) {
        dgb a3;
        try {
            return !a3.a(a2, 11) ? new int[]{} : ((ad)a3.d.get(a2)).a();
        }
        catch (ClassCastException classCastException) {
            throw new yja(a3.a(a2, 11, classCastException));
        }
    }

    public dgb a(String a2) {
        dgb a3;
        try {
            return !a3.a(a2, 10) ? new dgb() : (dgb)a3.d.get(a2);
        }
        catch (ClassCastException classCastException) {
            throw new yja(a3.a(a2, 10, classCastException));
        }
    }

    public mxb a(String a2, int a3) {
        dgb a4;
        try {
            if (a4.p(a2) != 9) {
                return new mxb();
            }
            mxb mxb2 = (mxb)a4.d.get(a2);
            return mxb2.p() > 0 && mxb2.a() != a3 ? new mxb() : mxb2;
        }
        catch (ClassCastException classCastException) {
            throw new yja(a4.a(a2, 9, classCastException));
        }
    }

    public boolean a(String a2) {
        dgb a3;
        return a3.a(a2) != 0;
    }

    public void a(String a2) {
        dgb a3;
        a3.d.remove(a2);
    }

    @Override
    public String toString() {
        dgb a2;
        StringBuilder stringBuilder = new StringBuilder("{");
        for (Map.Entry<String, ml> entry : a2.d.entrySet()) {
            if (stringBuilder.length() != 1) {
                stringBuilder.append(',');
            }
            stringBuilder.append(entry.getKey()).append(':').append(entry.getValue());
        }
        return stringBuilder.append('}').toString();
    }

    @Override
    public boolean a() {
        dgb a2;
        return a2.d.isEmpty();
    }

    private /* synthetic */ hna a(String a2, int a3, ClassCastException a4) {
        dgb a5;
        hna hna2 = hna.a(a4, "Reading NBT data");
        cya cya2 = hna2.a("Corrupt NBT tag", 1);
        cya2.a("Tag type found", new ila(a5, a2));
        cya2.a("Tag type expected", new jea(a5, a3));
        cya2.a("Tag name", a2);
        return hna2;
    }

    @Override
    public ml a() {
        dgb a2;
        dgb dgb2 = new dgb();
        for (String string : a2.d.keySet()) {
            dgb2.a(string, a2.d.get(string).a());
        }
        return dgb2;
    }

    @Override
    public boolean equals(Object a2) {
        dgb a3;
        if (super.equals(a2)) {
            dgb dgb2 = (dgb)a2;
            return a3.d.entrySet().equals(dgb2.d.entrySet());
        }
        return false;
    }

    @Override
    public int hashCode() {
        dgb a2;
        return super.hashCode() ^ a2.d.hashCode();
    }

    private static /* synthetic */ void a(String a2, ml a3, DataOutput a4) throws IOException {
        a4.writeByte(a3.a());
        if (a3.a() != 0) {
            a4.writeUTF(a2);
            a3.a(a4);
        }
    }

    static ml a(byte a2, String a3, DataInput a4, int a5, hcd a6) throws IOException {
        ml ml2 = ml.a(a2);
        try {
            ml2.a(a4, a5, a6);
            return ml2;
        }
        catch (IOException iOException) {
            hna hna2 = hna.a(iOException, "Loading NBT data");
            cya cya2 = hna2.a("NBT Tag");
            cya2.a("Tag name", a3);
            cya2.a("Tag type", a2);
            throw new yja(hna2);
        }
    }

    public void a(dgb a2) {
        for (String string : a2.d.keySet()) {
            dgb a3;
            ml ml2 = a2.d.get(string);
            if (ml2.a() == 10) {
                if (a3.a(string, 10)) {
                    ml ml3 = a3.a(string);
                    ((dgb)ml3).a((dgb)ml2);
                    continue;
                }
                a3.a(string, ml2.a());
                continue;
            }
            a3.a(string, ml2.a());
        }
    }

    static /* synthetic */ Map a(dgb a2) {
        return a2.d;
    }
}

