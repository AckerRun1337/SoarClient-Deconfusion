/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Charsets
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Queues
 *  com.google.common.util.concurrent.Futures
 *  com.google.common.util.concurrent.ListenableFuture
 *  com.google.common.util.concurrent.ListenableFutureTask
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.GameProfileRepository
 *  com.mojang.authlib.minecraft.MinecraftSessionService
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  org.apache.commons.lang3.Validate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import SoarClientDeobf-ByAckerRun.ac;
import SoarClientDeobf-ByAckerRun.bga;
import SoarClientDeobf-ByAckerRun.daa;
import SoarClientDeobf-ByAckerRun.fda;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.net.Proxy;
import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import javax.imageio.ImageIO;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ccb
implements Runnable,
j,
y,
r {
    private static final Logger hb = LogManager.getLogger();
    public static final File ra = new File("usercache.json");
    private static ccb aa;
    private final ha za;
    private final hzc fa;
    private final File wa;
    private final List<t> va;
    protected final kc sa;
    public final ntc ea;
    private final em qa;
    private final ahc xa;
    private final Random ua;
    private int da;
    public oeb[] ma;
    private uzb na;
    private boolean ka;
    private boolean ha;
    private int ya;
    protected final Proxy ca;
    public String ga;
    public int ja;
    private boolean ia;
    private boolean ta;
    private boolean oa;
    private boolean pa;
    private boolean ba;
    private String la;
    private int u;
    private int j;
    public final long[] o;
    public long[][] m;
    private KeyPair y;
    private String a;
    private String q;
    private String g;
    private boolean k;
    private boolean x;
    private boolean t;
    private String p;
    private String s;
    private boolean w;
    private long i;
    private String n;
    private boolean e;
    private boolean r;
    private final YggdrasilAuthenticationService f;
    private final MinecraftSessionService h;
    private long z;
    private final GameProfileRepository l;
    private final sm b;
    protected final Queue<FutureTask<?>> c;
    private Thread v;
    private long d;

    public ccb(Proxy a2, File a3) {
        ccb a4;
        a4.fa = new hzc("server", a4, ccb.a());
        a4.va = Lists.newArrayList();
        a4.ea = new ntc();
        a4.xa = new ahc();
        a4.ua = new Random();
        a4.da = -1;
        a4.ka = true;
        a4.j = 0;
        a4.o = new long[100];
        a4.p = "";
        a4.s = "";
        a4.z = 0L;
        a4.c = Queues.newArrayDeque();
        a4.d = ccb.a();
        a4.ca = a2;
        aa = a4;
        a4.wa = null;
        a4.qa = null;
        a4.b = new sm(a4, a3);
        a4.sa = null;
        a4.za = null;
        a4.f = new YggdrasilAuthenticationService(a2, UUID.randomUUID().toString());
        a4.h = a4.f.createMinecraftSessionService();
        a4.l = a4.f.createProfileRepository();
    }

    public ccb(File a2, Proxy a3, File a4) {
        ccb a5;
        a5.fa = new hzc("server", a5, ccb.a());
        a5.va = Lists.newArrayList();
        a5.ea = new ntc();
        a5.xa = new ahc();
        a5.ua = new Random();
        a5.da = -1;
        a5.ka = true;
        a5.j = 0;
        a5.o = new long[100];
        a5.p = "";
        a5.s = "";
        a5.z = 0L;
        a5.c = Queues.newArrayDeque();
        a5.d = ccb.a();
        a5.ca = a3;
        aa = a5;
        a5.wa = a2;
        a5.qa = new em(a5);
        a5.b = new sm(a5, a4);
        a5.sa = a5.a();
        a5.za = new ws(a2);
        a5.f = new YggdrasilAuthenticationService(a3, UUID.randomUUID().toString());
        a5.h = a5.f.createMinecraftSessionService();
        a5.l = a5.f.createProfileRepository();
    }

    protected reb a() {
        return new reb();
    }

    protected abstract boolean sa() throws IOException;

    protected void x(String a2) {
        ccb a3;
        if (a3.a().p(a2)) {
            hb.info("Converting map!");
            a3.j("menu.convertingLevel");
            a3.a().a(a2, new uk(a3));
        }
    }

    protected synchronized void j(String a2) {
        a.n = a2;
    }

    public synchronized String d() {
        ccb a2;
        return a2.n;
    }

    protected void a(String a2, String a3, long a4, rkb a5, String a6) {
        gjb gjb2;
        ccb a7;
        a7.x(a2);
        a7.j("menu.loadingLevel");
        a7.ma = new oeb[3];
        a7.m = new long[a7.ma.length][100];
        wb wb2 = a7.za.a(a2, true);
        a7.a(a7.j(), wb2);
        yyb yyb2 = wb2.a();
        if (yyb2 == null) {
            if (a7.i()) {
                gjb2 = tcb.d;
            } else {
                gjb2 = new gjb(a4, a7.a(), a7.b(), a7.w(), a5);
                gjb2.a(a6);
                if (a7.x) {
                    gjb2.p();
                }
            }
            yyb2 = new yyb(gjb2, a3);
        } else {
            yyb2.a(a3);
            gjb2 = new gjb(yyb2);
        }
        int n2 = 0;
        while (n2 < a7.ma.length) {
            int n3 = 0;
            if (n2 == 1) {
                n3 = -1;
            }
            if (n2 == 2) {
                n3 = 1;
            }
            if (n2 == 0) {
                a7.ma[n2] = a7.i() ? (oeb)new tcb(a7, wb2, yyb2, n3, a7.ea).a() : (oeb)new oeb(a7, wb2, yyb2, n3, a7.ea).a();
                a7.ma[n2].a(gjb2);
            } else {
                a7.ma[n2] = (oeb)new jpc(a7, wb2, n3, a7.ma[0], a7.ea).a();
            }
            a7.ma[n2].p(new iz(a7, a7.ma[n2]));
            if (!a7.g()) {
                a7.ma[n2].a().a(a7.a());
            }
            ++n2;
        }
        a7.na.a(a7.ma);
        a7.a(a7.a());
        a7.r();
    }

    protected void r() {
        ccb a2;
        int n2 = 16;
        int n3 = 4;
        int n4 = 192;
        int n5 = 625;
        int n6 = 0;
        a2.j("menu.generatingTerrain");
        int n7 = 0;
        hb.info("Preparing start region for level " + n7);
        oeb oeb2 = a2.ma[n7];
        tp tp2 = oeb2.a();
        long l2 = ccb.a();
        int n8 = -192;
        while (n8 <= 192 && a2.t()) {
            int n9 = -192;
            while (n9 <= 192 && a2.t()) {
                long l3 = ccb.a();
                if (l3 - l2 > 1000L) {
                    a2.a("Preparing spawn area", n6 * 100 / 625);
                    l2 = l3;
                }
                ++n6;
                oeb2.n.o(tp2.o() + n8 >> 4, tp2.a() + n9 >> 4);
                n9 += 16;
            }
            n8 += 16;
        }
        a2.q();
    }

    protected void a(String a2, wb a3) {
        File file = new File(a3.a(), "resources.zip");
        if (file.isFile()) {
            ccb a4;
            a4.a("level://" + a2 + "/" + file.getName(), "");
        }
    }

    public abstract boolean b();

    public abstract lq a();

    public abstract ncc a();

    public abstract boolean w();

    public abstract int m();

    public abstract boolean u();

    public abstract boolean s();

    protected void a(String a2, int a3) {
        a.ga = a2;
        a.ja = a3;
        hb.info(String.valueOf(a2) + ": " + a3 + "%");
    }

    protected void q() {
        a.ga = null;
        a.ja = 0;
    }

    protected void h(boolean a2) {
        ccb a3;
        if (!a3.t) {
            oeb[] oebArray = a3.ma;
            int n2 = a3.ma.length;
            int n3 = 0;
            while (n3 < n2) {
                oeb oeb2 = oebArray[n3];
                if (oeb2 != null) {
                    if (!a2) {
                        hb.info("Saving chunks for level '" + oeb2.a().p() + "'/" + oeb2.g.p());
                    }
                    try {
                        oeb2.a(true, null);
                    }
                    catch (rwa rwa2) {
                        hb.warn(rwa2.getMessage());
                    }
                }
                ++n3;
            }
        }
    }

    public void d() {
        ccb a2;
        if (!a2.t) {
            hb.info("Stopping server");
            if (a2.a() != null) {
                a2.a().p();
            }
            if (a2.na != null) {
                hb.info("Saving players");
                a2.na.o();
                a2.na.a();
            }
            if (a2.ma != null) {
                hb.info("Saving worlds");
                a2.h(false);
                int n2 = 0;
                while (n2 < a2.ma.length) {
                    oeb oeb2 = a2.ma[n2];
                    oeb2.r();
                    ++n2;
                }
            }
            if (a2.fa.a()) {
                a2.fa.a();
            }
        }
    }

    public boolean t() {
        ccb a2;
        return a2.ka;
    }

    public void m() {
        a.ka = false;
    }

    protected void h() {
        ccb a2;
        aa = a2;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void run() {
        block24: {
            try {
                try {
                    block27: {
                        if (!a.sa()) break block27;
                        a.d = ccb.a();
                        var1_1 = 0L;
                        a.xa.a(new gkb(a.la));
                        a.xa.a(new fyc("1.8.9", 47));
                        a.a(a.xa);
                        while (a.ka) {
                            block28: {
                                var3_3 = ccb.a();
                                var5_5 = var3_3 - a.d;
                                if (var5_5 > 2000L && a.d - a.i >= 15000L) {
                                    ccb.hb.warn("Can't keep up! Did the system time change, or is the server overloaded? Running {}ms behind, skipping {} tick(s)", new Object[]{var5_5, var5_5 / 50L});
                                    var5_5 = 2000L;
                                    a.i = a.d;
                                }
                                if (var5_5 < 0L) {
                                    ccb.hb.warn("Time ran backwards! Did the system time change?");
                                    var5_5 = 0L;
                                }
                                var1_1 += var5_5;
                                a.d = var3_3;
                                if (!a.ma[0].m()) ** GOTO lbl27
                                a.j();
                                var1_1 = 0L;
                                break block28;
lbl-1000:
                                // 1 sources

                                {
                                    var1_1 -= 50L;
                                    a.j();
lbl27:
                                    // 2 sources

                                    ** while (var1_1 > 50L)
                                }
                            }
                            Thread.sleep(Math.max(1L, 50L - var1_1));
                            a.w = true;
                        }
                        break block24;
                    }
                    a.a((hna)null);
                }
                catch (Throwable var1_2) {
                    ccb.hb.error("Encountered an unexpected exception", var1_2);
                    var2_6 = null;
                    var2_6 = var1_2 instanceof yja != false ? a.a(((yja)var1_2).a()) : a.a(new hna("Exception in server tick loop", var1_2));
                    var3_4 = new File(new File(a.a(), "crash-reports"), "crash-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + "-server.txt");
                    if (var2_6.a(var3_4)) {
                        ccb.hb.error("This crash report has been saved to: " + var3_4.getAbsolutePath());
                    } else {
                        ccb.hb.error("We were unable to save this crash report to disk.");
                    }
                    a.a(var2_6);
                    try {
                        try {
                            a.ha = true;
                            a.d();
                        }
                        catch (Throwable var8_7) {
                            ccb.hb.error("Exception stopping the server", var8_7);
                            a.x();
                        }
                    }
                    finally {
                        a.x();
                    }
                }
            }
            finally {
                block26: {
                    try {
                        try {
                            a.ha = true;
                            a.d();
                        }
                        catch (Throwable var8_9) {
                            ccb.hb.error("Exception stopping the server", var8_9);
                            a.x();
                            break block26;
                        }
                    }
                    catch (Throwable var9_12) {
                        a.x();
                        throw var9_12;
                    }
                    a.x();
                }
            }
        }
    }

    private /* synthetic */ void a(ahc a2) {
        ccb a3;
        File file = a3.a("server-icon.png");
        if (file.isFile()) {
            ac ac2 = bga.p();
            try {
                try {
                    BufferedImage bufferedImage = ImageIO.read(file);
                    Validate.validState((bufferedImage.getWidth() == 64 ? 1 : 0) != 0, (String)"Must be 64 pixels wide", (Object[])new Object[0]);
                    Validate.validState((bufferedImage.getHeight() == 64 ? 1 : 0) != 0, (String)"Must be 64 pixels high", (Object[])new Object[0]);
                    ImageIO.write((RenderedImage)bufferedImage, "PNG", new daa(ac2));
                    ac ac3 = fda.p(ac2);
                    a2.a("data:image/png;base64," + ac3.a(Charsets.UTF_8));
                }
                catch (Exception exception) {
                    hb.error("Couldn't load server icon", (Throwable)exception);
                    ac2.a();
                }
            }
            finally {
                ac2.a();
            }
        }
    }

    public File a() {
        return new File(".");
    }

    protected void a(hna a2) {
    }

    protected void x() {
    }

    public void j() {
        ccb a2;
        long l2 = System.nanoTime();
        ++a2.ya;
        if (a2.e) {
            a2.e = false;
            a2.ea.p = true;
            a2.ea.p();
        }
        a2.ea.p("root");
        a2.z();
        if (l2 - a2.z >= 5000000000L) {
            a2.z = l2;
            a2.xa.a(new pfc(a2.x(), a2.h()));
            GameProfile[] gameProfileArray = new GameProfile[Math.min(a2.h(), 12)];
            int n2 = smb.a(a2.ua, 0, a2.h() - gameProfileArray.length);
            int n3 = 0;
            while (n3 < gameProfileArray.length) {
                gameProfileArray[n3] = a2.na.a().get(n2 + n3).a();
                ++n3;
            }
            Collections.shuffle(Arrays.asList(gameProfileArray));
            a2.xa.a().a(gameProfileArray);
        }
        if (a2.ya % 900 == 0) {
            a2.ea.p("save");
            a2.na.o();
            a2.h(true);
            a2.ea.a();
        }
        a2.ea.p("tallying");
        a2.o[a2.ya % 100] = System.nanoTime() - l2;
        a2.ea.a();
        a2.ea.p("snooper");
        if (!a2.fa.a() && a2.ya > 100) {
            a2.fa.z();
        }
        if (a2.ya % 6000 == 0) {
            a2.fa.p();
        }
        a2.ea.a();
        a2.ea.a();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void z() {
        ccb a2;
        a2.ea.p("jobs");
        Queue<FutureTask<?>> queue = a2.c;
        synchronized (queue) {
            while (!a2.c.isEmpty()) {
                pdc.a(a2.c.poll(), hb);
            }
        }
        a2.ea.a("levels");
        int n2 = 0;
        while (n2 < a2.ma.length) {
            long l2 = System.nanoTime();
            if (n2 == 0 || a2.v()) {
                oeb oeb2 = a2.ma[n2];
                a2.ea.p(oeb2.a().p());
                if (a2.ya % 20 == 0) {
                    a2.ea.p("timeSync");
                    a2.na.a(new odc(oeb2.p(), oeb2.a(), oeb2.a().p("doDaylightCycle")), oeb2.g.a());
                    a2.ea.a();
                }
                a2.ea.p("tick");
                try {
                    oeb2.h();
                }
                catch (Throwable throwable) {
                    hna hna2 = hna.a(throwable, "Exception ticking world");
                    oeb2.a(hna2);
                    throw new yja(hna2);
                }
                try {
                    oeb2.d();
                }
                catch (Throwable throwable) {
                    hna hna3 = hna.a(throwable, "Exception ticking world entities");
                    oeb2.a(hna3);
                    throw new yja(hna3);
                }
                a2.ea.a();
                a2.ea.p("tracker");
                oeb2.a().a();
                a2.ea.a();
                a2.ea.a();
            }
            a2.m[n2][a2.ya % 100] = System.nanoTime() - l2;
            ++n2;
        }
        a2.ea.a("connection");
        a2.a().a();
        a2.ea.a("players");
        a2.na.y();
        a2.ea.a("tickables");
        n2 = 0;
        while (n2 < a2.va.size()) {
            a2.va.get(n2).a();
            ++n2;
        }
        a2.ea.a();
    }

    public boolean v() {
        return true;
    }

    public void y() {
        ccb a2;
        a2.v = new Thread((Runnable)a2, "Server thread");
        a2.v.start();
    }

    public File a(String a2) {
        ccb a3;
        return new File(a3.a(), a2);
    }

    public void z(String a2) {
        hb.warn(a2);
    }

    public oeb a(int a2) {
        ccb a3;
        return a2 == -1 ? a3.ma[1] : (a2 == 1 ? a3.ma[2] : a3.ma[0]);
    }

    public String m() {
        return "1.8.9";
    }

    public int h() {
        ccb a2;
        return a2.na.o();
    }

    public int x() {
        ccb a2;
        return a2.na.p();
    }

    public String[] a() {
        ccb a2;
        return a2.na.y();
    }

    public GameProfile[] a() {
        ccb a2;
        return a2.na.a();
    }

    public String h() {
        return "vanilla";
    }

    public hna a(hna a2) {
        ccb a3;
        a2.a().a("Profiler Position", new qac(a3));
        if (a3.na != null) {
            a2.a().a("Player Count", new kha(a3));
        }
        return a2;
    }

    public List<String> a(j a2, String a3, tp a4) {
        ccb a5;
        ArrayList arrayList = Lists.newArrayList();
        if (a3.startsWith("/")) {
            boolean bl2 = !(a3 = a3.substring(1)).contains(" ");
            List<String> list = a5.sa.a(a2, a3, a4);
            if (list != null) {
                for (String string : list) {
                    if (bl2) {
                        arrayList.add("/" + string);
                        continue;
                    }
                    arrayList.add(string);
                }
            }
            return arrayList;
        }
        String[] stringArray = a3.split(" ", -1);
        String string = stringArray[stringArray.length - 1];
        String[] stringArray2 = a5.na.y();
        int n2 = stringArray2.length;
        int n3 = 0;
        while (n3 < n2) {
            String string2 = stringArray2[n3];
            if (hf.a(string, string2)) {
                arrayList.add(string2);
            }
            ++n3;
        }
        return arrayList;
    }

    public static ccb a() {
        return aa;
    }

    public boolean k() {
        ccb a2;
        return a2.wa != null;
    }

    @Override
    public String a() {
        return "Server";
    }

    @Override
    public void a(ga a2) {
        hb.info(a2.p());
    }

    @Override
    public boolean a(int a2, String a3) {
        return true;
    }

    public kc a() {
        ccb a2;
        return a2.sa;
    }

    public KeyPair a() {
        ccb a2;
        return a2.y;
    }

    public String x() {
        ccb a2;
        return a2.a;
    }

    public void y(String a2) {
        a.a = a2;
    }

    public boolean g() {
        ccb a2;
        return a2.a != null;
    }

    public String j() {
        ccb a2;
        return a2.q;
    }

    public void o(String a2) {
        a.q = a2;
    }

    public void p(String a2) {
        a.g = a2;
    }

    public String z() {
        ccb a2;
        return a2.g;
    }

    public void a(KeyPair a2) {
        a.y = a2;
    }

    public void a(ncc a2) {
        ccb a3;
        int n2 = 0;
        while (n2 < a3.ma.length) {
            oeb oeb2 = a3.ma[n2];
            if (oeb2 != null) {
                if (oeb2.a().y()) {
                    oeb2.a().a(ncc.l);
                    oeb2.a(true, true);
                } else if (a3.g()) {
                    oeb2.a().a(a2);
                    oeb2.a(oeb2.a() != ncc.f, true);
                } else {
                    oeb2.a().a(a2);
                    oeb2.a(a3.n(), a3.ta);
                }
            }
            ++n2;
        }
    }

    protected boolean n() {
        return true;
    }

    public boolean i() {
        ccb a2;
        return a2.k;
    }

    public void x(boolean a2) {
        a.k = a2;
    }

    public void j(boolean a2) {
        a.x = a2;
    }

    public ha a() {
        ccb a2;
        return a2.za;
    }

    public void o() {
        ccb a2;
        a2.t = true;
        a2.a().a();
        int n2 = 0;
        while (n2 < a2.ma.length) {
            oeb oeb2 = a2.ma[n2];
            if (oeb2 != null) {
                oeb2.r();
            }
            ++n2;
        }
        a2.a().y(a2.ma[0].a().a());
        a2.m();
    }

    public String y() {
        ccb a2;
        return a2.p;
    }

    public String o() {
        ccb a2;
        return a2.s;
    }

    public void a(String a2, String a3) {
        a.p = a2;
        a.s = a3;
    }

    @Override
    public void p(hzc a2) {
        ccb a3;
        a2.p("whitelist_enabled", false);
        a2.p("whitelist_count", 0);
        if (a3.na != null) {
            a2.p("players_current", a3.h());
            a2.p("players_max", a3.x());
            a2.p("players_seen", a3.na.a().length);
        }
        a2.p("uses_auth", a3.ia);
        a2.p("gui_state", a3.j() ? "enabled" : "disabled");
        a2.p("run_time", (ccb.a() - a2.a()) / 60L * 1000L);
        a2.p("avg_tick_ms", (int)(smb.a(a3.o) * 1.0E-6));
        int n2 = 0;
        if (a3.ma != null) {
            int n3 = 0;
            while (n3 < a3.ma.length) {
                if (a3.ma[n3] != null) {
                    oeb oeb2 = a3.ma[n3];
                    yyb yyb2 = oeb2.a();
                    a2.p("world[" + n2 + "][dimension]", oeb2.g.a());
                    a2.p("world[" + n2 + "][mode]", (Object)yyb2.a());
                    a2.p("world[" + n2 + "][difficulty]", (Object)oeb2.a());
                    a2.p("world[" + n2 + "][hardcore]", yyb2.y());
                    a2.p("world[" + n2 + "][generator_name]", yyb2.a().o());
                    a2.p("world[" + n2 + "][generator_version]", yyb2.a().p());
                    a2.p("world[" + n2 + "][height]", a3.u);
                    a2.p("world[" + n2 + "][chunks_loaded]", oeb2.a().a());
                    ++n2;
                }
                ++n3;
            }
        }
        a2.p("worlds", n2);
    }

    @Override
    public void a(hzc a2) {
        ccb a3;
        a2.a("singleplayer", a3.g());
        a2.a("server_brand", a3.h());
        a2.a("gui_supported", GraphicsEnvironment.isHeadless() ? "headless" : "supported");
        a2.a("dedicated", a3.e());
    }

    @Override
    public boolean o() {
        return true;
    }

    public abstract boolean e();

    public boolean c() {
        ccb a2;
        return a2.ia;
    }

    public void z(boolean a2) {
        a.ia = a2;
    }

    public boolean f() {
        ccb a2;
        return a2.ta;
    }

    public void y(boolean a2) {
        a.ta = a2;
    }

    public boolean l() {
        ccb a2;
        return a2.oa;
    }

    public abstract boolean r();

    public void o(boolean a2) {
        a.oa = a2;
    }

    public boolean q() {
        ccb a2;
        return a2.pa;
    }

    public void p(boolean a2) {
        a.pa = a2;
    }

    public boolean d() {
        ccb a2;
        return a2.ba;
    }

    public void a(boolean a2) {
        a.ba = a2;
    }

    public abstract boolean m();

    public String p() {
        ccb a2;
        return a2.la;
    }

    public void a(String a2) {
        a.la = a2;
    }

    public int j() {
        ccb a2;
        return a2.u;
    }

    public void p(int a2) {
        a.u = a2;
    }

    public boolean h() {
        ccb a2;
        return a2.ha;
    }

    public uzb a() {
        ccb a2;
        return a2.na;
    }

    public void a(uzb a2) {
        a.na = a2;
    }

    public void a(lq a2) {
        ccb a3;
        int n2 = 0;
        while (n2 < a3.ma.length) {
            ccb.a().ma[n2].a().a(a2);
            ++n2;
        }
    }

    public em a() {
        ccb a2;
        return a2.qa;
    }

    public boolean x() {
        ccb a2;
        return a2.w;
    }

    public boolean j() {
        return false;
    }

    public abstract String a(lq var1, boolean var2);

    public int z() {
        ccb a2;
        return a2.ya;
    }

    public void p() {
        a.e = true;
    }

    public hzc a() {
        ccb a2;
        return a2.fa;
    }

    @Override
    public tp a() {
        return tp.r;
    }

    @Override
    public tta a() {
        return new tta(0.0, 0.0, 0.0);
    }

    @Override
    public xga a() {
        ccb a2;
        return a2.ma[0];
    }

    @Override
    public rj a() {
        return null;
    }

    public int y() {
        return 16;
    }

    public boolean a(xga a2, tp a3, pm a4) {
        return false;
    }

    public boolean z() {
        ccb a2;
        return a2.r;
    }

    public Proxy a() {
        ccb a2;
        return a2.ca;
    }

    public static long a() {
        return System.currentTimeMillis();
    }

    public int o() {
        ccb a2;
        return a2.j;
    }

    public void a(int a2) {
        a.j = a2;
    }

    @Override
    public ga a() {
        ccb a2;
        return new gkb(a2.a());
    }

    public boolean y() {
        return true;
    }

    public MinecraftSessionService a() {
        ccb a2;
        return a2.h;
    }

    public GameProfileRepository a() {
        ccb a2;
        return a2.l;
    }

    public sm a() {
        ccb a2;
        return a2.b;
    }

    public ahc a() {
        ccb a2;
        return a2.xa;
    }

    public void a() {
        a.z = 0L;
    }

    public rj a(UUID a2) {
        ccb a3;
        oeb[] oebArray = a3.ma;
        int n2 = a3.ma.length;
        int n3 = 0;
        while (n3 < n2) {
            rj rj2;
            oeb oeb2 = oebArray[n3];
            if (oeb2 != null && (rj2 = oeb2.a(a2)) != null) {
                return rj2;
            }
            ++n3;
        }
        return null;
    }

    @Override
    public boolean a() {
        return ccb.a().ma[0].a().p("sendCommandFeedback");
    }

    @Override
    public void a(wtc a2, int a3) {
    }

    public int p() {
        return 29999984;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <V> ListenableFuture<V> a(Callable<V> a2) {
        ccb a3;
        Validate.notNull(a2);
        if (!a3.p() && !a3.h()) {
            ListenableFutureTask listenableFutureTask = ListenableFutureTask.create(a2);
            Queue<FutureTask<?>> queue = a3.c;
            synchronized (queue) {
                a3.c.add((FutureTask<?>)listenableFutureTask);
                return listenableFutureTask;
            }
        }
        try {
            return Futures.immediateFuture(a2.call());
        }
        catch (Exception exception) {
            return Futures.immediateFailedCheckedFuture((Exception)exception);
        }
    }

    @Override
    public ListenableFuture<Object> a(Runnable a2) {
        ccb a3;
        Validate.notNull((Object)a2);
        return a3.a(Executors.callable(a2));
    }

    @Override
    public boolean p() {
        ccb a2;
        return Thread.currentThread() == a2.v;
    }

    public int a() {
        return 256;
    }

    static /* synthetic */ Logger a() {
        return hb;
    }

    static /* synthetic */ uzb a(ccb a2) {
        return a2.na;
    }
}

