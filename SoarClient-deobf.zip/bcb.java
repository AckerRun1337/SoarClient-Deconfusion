/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bcb {
    private List<ro> c = new ArrayList<ro>();
    private List<ba> v = new ArrayList<ba>();
    private List<ro> d = Arrays.asList(new ro[1]);

    public bcb() {
        bcb a2;
    }

    public void a(ro a2, ba a3) {
        if (a2 != null) {
            bcb a4;
            a4.c.add(a2);
            a4.v.add(a3);
        }
    }

    public int a() {
        bcb a2;
        return a2.c.size();
    }

    public ro a(int a2) {
        bcb a3;
        return a3.c.get(a2);
    }

    public ba a(int a2) {
        bcb a3;
        return a2 >= 0 && a2 < a3.v.size() ? a3.v.get(a2) : cl.cd.a();
    }

    public List<ro> a(ro a2) {
        bcb a3;
        a3.d.set(0, a2);
        return a3.d;
    }

    public void a() {
        bcb a2;
        a2.c.clear();
        a2.v.clear();
    }
}

