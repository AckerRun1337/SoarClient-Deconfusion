/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class byc
extends vvc {
    private boolean c = false;
    private tp v = null;
    private rj d = null;

    public byc(oj a2, rmb a3) {
        super(a2, a3);
        byc a4;
    }

    @Override
    public boolean p(tp a2, hnd a3) {
        byc a4;
        a4.c = true;
        a4.v = a2;
        boolean bl2 = super.p(a2, a3);
        a4.c = false;
        return bl2;
    }

    @Override
    public boolean a(tp a2, hnd a3) {
        byc a4;
        a4.c = true;
        a4.v = a2;
        boolean bl2 = super.a(a2, a3);
        a4.c = false;
        return bl2;
    }

    @Override
    public boolean a(pm a2, xga a3, wfc a4) {
        byc a5;
        a5.c = true;
        boolean bl2 = super.a(a2, a3, a4);
        a5.c = false;
        return bl2;
    }

    @Override
    public boolean a(sva a2, wfa a3, wfc a4, tp a5, hnd a6, tta a7) {
        byc a8;
        a8.c = true;
        a8.v = a5;
        boolean bl2 = super.a(a2, a3, a4, a5, a6, a7);
        a8.c = false;
        return bl2;
    }

    @Override
    public boolean a(pm a2, rj a3) {
        byc a4;
        a4.d = a3;
        return super.a(a2, a3);
    }

    @Override
    public boolean a(pm a2, rj a3, lwa a4) {
        byc a5;
        a5.d = a3;
        return super.a(a2, a3, a4);
    }

    public boolean d() {
        byc a2;
        return a2.c;
    }

    public tp a() {
        byc a2;
        return a2.v;
    }

    public rj a() {
        byc a2;
        return a2.d;
    }
}

