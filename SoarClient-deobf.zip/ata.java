/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class ata
extends yd {
    protected ata() {
        super(dr.s, rpb.g);
        ata a2;
        a2.a(md.g);
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return sxa.ab;
    }

    @Override
    public int a(Random a2) {
        return 3 + a2.nextInt(5);
    }

    @Override
    public int a(int a2, Random a3) {
        ata a4;
        return Math.min(9, a4.a(a3) + a3.nextInt(1 + a2));
    }
}

