/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bo
extends cm
implements Serializable {
    static final long d = -2168194326883512320L;

    public bo(float a2, float a3) {
        super(a2, a3);
        bo a4;
    }

    public bo(float[] a2) {
        super(a2);
        bo a3;
    }

    public bo(bo a2) {
        super(a2);
        bo a3;
    }

    public bo(qyb a2) {
        super(a2);
        bo a3;
    }

    public bo(cm a2) {
        super(a2);
        bo a3;
    }

    public bo(hu a2) {
        super(a2);
        bo a3;
    }

    public bo() {
        bo a2;
    }

    public final float p(bo a2) {
        bo a3;
        return a3.v * a2.v + a3.d * a2.d;
    }

    public final float y() {
        bo a2;
        return (float)Math.sqrt(a2.v * a2.v + a2.d * a2.d);
    }

    public final float o() {
        bo a2;
        return a2.v * a2.v + a2.d * a2.d;
    }

    public final void a(bo a2) {
        float f2 = (float)(1.0 / Math.sqrt(a2.v * a2.v + a2.d * a2.d));
        a.v = a2.v * f2;
        a.d = a2.d * f2;
    }

    public final void o() {
        bo a2;
        float f2 = (float)(1.0 / Math.sqrt(a2.v * a2.v + a2.d * a2.d));
        a2.v *= f2;
        a2.d *= f2;
    }

    public final float a(bo a2) {
        bo a3;
        double d2 = a3.p(a2) / (a3.y() * a2.y());
        if (d2 < -1.0) {
            d2 = -1.0;
        }
        if (d2 > 1.0) {
            d2 = 1.0;
        }
        return (float)Math.acos(d2);
    }
}

