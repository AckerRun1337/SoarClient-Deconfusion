/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class at
implements kb {
    private final xga v;
    private final tp d;

    public at(xga a2, tp a3) {
        at a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public xga a() {
        at a2;
        return a2.v;
    }

    @Override
    public double o() {
        at a2;
        return (double)a2.d.o() + 0.5;
    }

    @Override
    public double p() {
        at a2;
        return (double)a2.d.p() + 0.5;
    }

    @Override
    public double a() {
        at a2;
        return (double)a2.d.a() + 0.5;
    }

    @Override
    public tp a() {
        at a2;
        return a2.d;
    }

    @Override
    public int a() {
        at a2;
        ba ba2 = a2.v.a(a2.d);
        return ba2.a().o(ba2);
    }

    @Override
    public <T extends kv> T a() {
        at a2;
        return (T)a2.v.a(a2.d);
    }
}

