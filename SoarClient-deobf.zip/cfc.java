/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cfc
extends hf {
    public cfc() {
        cfc a2;
    }

    @Override
    public String a() {
        return "testforblock";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String a(j a2) {
        return "commands.testforblock.usage";
    }

    @Override
    public void a(j a2, String[] a3) throws tqa {
        cfc a4;
        int n2;
        yd yd2;
        Object object;
        xga xga2;
        if (a3.length < 4) {
            throw new xvb("commands.testforblock.usage", new Object[0]);
        }
        a2.a(wtc.h, 0);
        tp tp2 = cfc.a(a2, a3, 0, false);
        yd yd3 = yd.p(a3[3]);
        if (yd3 == null) {
            throw new jsc("commands.setblock.notFound", a3[3]);
        }
        int n3 = -1;
        if (a3.length >= 5) {
            n3 = cfc.a(a3[4], -1, 15);
        }
        if (!(xga2 = a2.a()).l(tp2)) {
            throw new tqa("commands.testforblock.outOfWorld", new Object[0]);
        }
        dgb dgb2 = new dgb();
        boolean bl2 = false;
        if (a3.length >= 6 && yd3.d()) {
            object = cfc.a(a2, a3, 5).p();
            try {
                dgb2 = dw.a((String)object);
                bl2 = true;
            }
            catch (rl rl2) {
                throw new tqa("commands.setblock.tagError", rl2.getMessage());
            }
        }
        if ((yd2 = (object = xga2.a(tp2)).a()) != yd3) {
            throw new tqa("commands.testforblock.failed.tile", tp2.o(), tp2.p(), tp2.a(), yd2.p(), yd3.p());
        }
        if (n3 > -1 && (n2 = object.a().o((ba)object)) != n3) {
            throw new tqa("commands.testforblock.failed.data", tp2.o(), tp2.p(), tp2.a(), n2, n3);
        }
        if (bl2) {
            kv kv2 = xga2.a(tp2);
            if (kv2 == null) {
                throw new tqa("commands.testforblock.failed.tileEntity", tp2.o(), tp2.p(), tp2.a());
            }
            dgb dgb3 = new dgb();
            kv2.a(dgb3);
            if (!nvb.a(dgb2, dgb3, true)) {
                throw new tqa("commands.testforblock.failed.nbt", tp2.o(), tp2.p(), tp2.a());
            }
        }
        a2.a(wtc.h, 1);
        cfc.a(a2, (w)a4, "commands.testforblock.success", tp2.o(), tp2.p(), tp2.a());
    }

    @Override
    public List<String> a(j a2, String[] a3, tp a4) {
        return a3.length > 0 && a3.length <= 3 ? cfc.p(a3, 0, a4) : (a3.length == 4 ? cfc.a(a3, yd.ma.a()) : null);
    }
}

