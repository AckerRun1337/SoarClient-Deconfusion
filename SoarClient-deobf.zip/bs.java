/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.common.collect.HashBiMap
 *  com.google.common.collect.Maps
 *  org.apache.logging.log4j.LogManager
 */
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Maps;
import java.util.Map;
import org.apache.logging.log4j.LogManager;

public class bs
extends Enum<bs> {
    public static final /* enum */ bs n = new lla(-1);
    public static final /* enum */ bs e = new una(0);
    public static final /* enum */ bs r = new mx(1);
    public static final /* enum */ bs f = new fib(2);
    private static int h;
    private static int z;
    private static final bs[] l;
    private static final Map<Class<? extends o>, bs> b;
    private final int c;
    private final Map<izc, BiMap<Integer, Class<? extends o>>> v = Maps.newEnumMap(izc.class);
    private static final /* synthetic */ bs[] d;

    static {
        d = new bs[]{n, e, r, f};
        h = -1;
        z = 2;
        l = new bs[z - h + 1];
        b = Maps.newHashMap();
        bs[] bsArray = bs.values();
        int n2 = bsArray.length;
        int n3 = 0;
        while (n3 < n2) {
            bs bs2 = bsArray[n3];
            int n4 = bs2.a();
            if (n4 < h || n4 > z) {
                throw new Error("Invalid protocol ID " + Integer.toString(n4));
            }
            bs.l[n4 - bs.h] = bs2;
            for (izc izc2 : bs2.v.keySet()) {
                for (Class clazz : bs2.v.get((Object)izc2).values()) {
                    if (b.containsKey(clazz) && b.get(clazz) != bs2) {
                        throw new Error("Packet " + clazz + " is already assigned to protocol " + (Object)((Object)b.get(clazz)) + " - can't reassign to " + (Object)((Object)bs2));
                    }
                    try {
                        clazz.newInstance();
                    }
                    catch (Throwable throwable) {
                        throw new Error("Packet " + clazz + " fails instantiation checks! " + clazz);
                    }
                    b.put(clazz, bs2);
                }
            }
            ++n3;
        }
    }

    private /* synthetic */ bs(String a2, int a3, int a4) {
        bs a5;
        a5.c = a4;
    }

    protected bs a(izc a2, Class<? extends o> a3) {
        bs a4;
        HashBiMap hashBiMap = a4.v.get((Object)a2);
        if (hashBiMap == null) {
            hashBiMap = HashBiMap.create();
            a4.v.put(a2, (BiMap<Integer, Class<? extends o>>)hashBiMap);
        }
        if (hashBiMap.containsValue(a3)) {
            String string = (Object)((Object)a2) + " packet " + a3 + " is already known to ID " + hashBiMap.inverse().get(a3);
            LogManager.getLogger().fatal(string);
            throw new IllegalArgumentException(string);
        }
        hashBiMap.put((Object)hashBiMap.size(), a3);
        return a4;
    }

    public Integer a(izc a2, o a3) {
        bs a4;
        return (Integer)a4.v.get((Object)a2).inverse().get(a3.getClass());
    }

    public o a(izc a2, int a3) throws InstantiationException, IllegalAccessException {
        bs a4;
        Class clazz = (Class)a4.v.get((Object)a2).get((Object)a3);
        return clazz == null ? null : (o)clazz.newInstance();
    }

    public int a() {
        bs a2;
        return a2.c;
    }

    public static bs a(int a2) {
        return a2 >= h && a2 <= z ? l[a2 - h] : null;
    }

    public static bs a(o a2) {
        return b.get(a2.getClass());
    }

    public static bs[] values() {
        bs[] bsArray = d;
        int n2 = bsArray.length;
        bs[] bsArray2 = new bs[n2];
        System.arraycopy(d, 0, bsArray2, 0, n2);
        return bsArray2;
    }

    public static bs valueOf(String a2) {
        return Enum.valueOf(bs.class, a2);
    }

    /* synthetic */ bs(String a2, int a3, int a4, bs a5) {
        a6(a2, a3, a4);
        bs a6;
    }
}

