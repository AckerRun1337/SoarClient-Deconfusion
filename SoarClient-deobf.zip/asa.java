/*
 * Decompiled with CFR 0.152.
 */
public class asa
extends qm {
    public sfc f;
    public sfc h;
    public sfc z;
    public sfc l;
    public sfc b;
    public sfc c;
    protected float v;
    protected float d;

    public asa(int a2, float a3) {
        asa a4;
        a4.f = new sfc(a4, 0, 0);
        a4.v = 8.0f;
        a4.d = 4.0f;
        a4.f.p(-4.0f, -4.0f, -8.0f, 8, 8, 8, a3);
        a4.f.a(0.0f, 18 - a2, -6.0f);
        a4.h = new sfc(a4, 28, 8);
        a4.h.p(-5.0f, -10.0f, -7.0f, 10, 16, 8, a3);
        a4.h.a(0.0f, 17 - a2, 2.0f);
        a4.z = new sfc(a4, 0, 16);
        a4.z.p(-2.0f, 0.0f, -2.0f, 4, a2, 4, a3);
        a4.z.a(-3.0f, 24 - a2, 7.0f);
        a4.l = new sfc(a4, 0, 16);
        a4.l.p(-2.0f, 0.0f, -2.0f, 4, a2, 4, a3);
        a4.l.a(3.0f, 24 - a2, 7.0f);
        a4.b = new sfc(a4, 0, 16);
        a4.b.p(-2.0f, 0.0f, -2.0f, 4, a2, 4, a3);
        a4.b.a(-3.0f, 24 - a2, -5.0f);
        a4.c = new sfc(a4, 0, 16);
        a4.c.p(-2.0f, 0.0f, -2.0f, 4, a2, 4, a3);
        a4.c.a(3.0f, 24 - a2, -5.0f);
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        asa a9;
        a9.a(a3, a4, a5, a6, a7, a8, a2);
        if (a9.l != false) {
            float f2 = 2.0f;
            ewa.m();
            ewa.p(0.0f, a9.v * a8, a9.d * a8);
            a9.f.y(a8);
            ewa.h();
            ewa.m();
            ewa.o(1.0f / f2, 1.0f / f2, 1.0f / f2);
            ewa.p(0.0f, 24.0f * a8, 0.0f);
            a9.h.y(a8);
            a9.z.y(a8);
            a9.l.y(a8);
            a9.b.y(a8);
            a9.c.y(a8);
            ewa.h();
        } else {
            a9.f.y(a8);
            a9.h.y(a8);
            a9.z.y(a8);
            a9.l.y(a8);
            a9.b.y(a8);
            a9.c.y(a8);
        }
    }

    @Override
    public void a(float a2, float a3, float a4, float a5, float a6, float a7, rj a8) {
        float f2 = 57.295776f;
        a.f.j = a6 / 57.295776f;
        a.f.o = a5 / 57.295776f;
        a.h.j = 1.5707964f;
        a.z.j = smb.y(a2 * 0.6662f) * 1.4f * a3;
        a.l.j = smb.y(a2 * 0.6662f + (float)Math.PI) * 1.4f * a3;
        a.b.j = smb.y(a2 * 0.6662f + (float)Math.PI) * 1.4f * a3;
        a.c.j = smb.y(a2 * 0.6662f) * 1.4f * a3;
    }
}

