/*
 * Decompiled with CFR 0.152.
 */
public class bhb
extends yi {
    public bhb(dj a2, Class<? extends rj> a3, float a4, float a5) {
        super(a2, a3, a4, a5);
        bhb a6;
        a6.a(3);
    }
}

