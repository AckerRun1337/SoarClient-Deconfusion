/*
 * Decompiled with CFR 0.152.
 */
public enum bka {
    z(3552),
    l(3553),
    b(32879),
    c(34037);

    private int v;

    private /* synthetic */ bka(String a2, int a3, int a4) {
        bka a5;
        a5.v = a4;
    }

    public int a() {
        bka a2;
        return a2.v;
    }
}

