/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class cf
implements Serializable,
Cloneable {
    static final long l = 7068460319248845763L;
    public float b;
    public float c;
    public float v;
    public float d;

    public cf(float a2, float a3, float a4, float a5) {
        cf a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    public cf(float[] a2) {
        cf a3;
        a3.b = a2[0];
        a3.c = a2[1];
        a3.v = a2[2];
        a3.d = a2[3];
    }

    public cf(cf a2) {
        cf a3;
        a3.b = a2.b;
        a3.c = a2.c;
        a3.v = a2.v;
        a3.d = a2.d;
    }

    public cf(nx a2) {
        cf a3;
        a3.b = (float)a2.b;
        a3.c = (float)a2.c;
        a3.v = (float)a2.v;
        a3.d = (float)a2.d;
    }

    public cf() {
        cf a2;
        a2.b = 0.0f;
        a2.c = 0.0f;
        a2.v = 0.0f;
        a2.d = 0.0f;
    }

    public final void a(float a2, float a3, float a4, float a5) {
        a.b = a2;
        a.c = a3;
        a.v = a4;
        a.d = a5;
    }

    public final void p(float[] a2) {
        a.b = a2[0];
        a.c = a2[1];
        a.v = a2[2];
        a.d = a2[3];
    }

    public final void j(cf a2) {
        a.b = a2.b;
        a.c = a2.c;
        a.v = a2.v;
        a.d = a2.d;
    }

    public final void a(nx a2) {
        a.b = (float)a2.b;
        a.c = (float)a2.c;
        a.v = (float)a2.v;
        a.d = (float)a2.d;
    }

    public final void a(float[] a2) {
        cf a3;
        a2[0] = a3.b;
        a2[1] = a3.c;
        a2[2] = a3.v;
        a2[3] = a3.d;
    }

    public final void z(cf a2) {
        cf a3;
        a2.b = a3.b;
        a2.c = a3.c;
        a2.v = a3.v;
        a2.d = a3.d;
    }

    public final void p(cf a2, cf a3) {
        a.b = a2.b + a3.b;
        a.c = a2.c + a3.c;
        a.v = a2.v + a3.v;
        a.d = a2.d + a3.d;
    }

    public final void y(cf a2) {
        a.b += a2.b;
        a.c += a2.c;
        a.v += a2.v;
        a.d += a2.d;
    }

    public final void a(cf a2, cf a3) {
        a.b = a2.b - a3.b;
        a.c = a2.c - a3.c;
        a.v = a2.v - a3.v;
        a.d = a2.d - a3.d;
    }

    public final void o(cf a2) {
        a.b -= a2.b;
        a.c -= a2.c;
        a.v -= a2.v;
        a.d -= a2.d;
    }

    public final void p(cf a2) {
        a.b = -a2.b;
        a.c = -a2.c;
        a.v = -a2.v;
        a.d = -a2.d;
    }

    public final void p() {
        cf a2;
        a2.b = -a2.b;
        a2.c = -a2.c;
        a2.v = -a2.v;
        a2.d = -a2.d;
    }

    public final void y(float a2, cf a3) {
        a.b = a2 * a3.b;
        a.c = a2 * a3.c;
        a.v = a2 * a3.v;
        a.d = a2 * a3.d;
    }

    public final void x(float a2) {
        a.b *= a2;
        a.c *= a2;
        a.v *= a2;
        a.d *= a2;
    }

    public final void a(float a2, cf a3, cf a4) {
        a.b = a2 * a3.b + a4.b;
        a.c = a2 * a3.c + a4.c;
        a.v = a2 * a3.v + a4.v;
        a.d = a2 * a3.d + a4.d;
    }

    public final void o(float a2, cf a3) {
        cf a4;
        a4.b = a2 * a4.b + a3.b;
        a4.c = a2 * a4.c + a3.c;
        a4.v = a2 * a4.v + a3.v;
        a4.d = a2 * a4.d + a3.d;
    }

    public String toString() {
        cf a2;
        return "(" + a2.b + ", " + a2.c + ", " + a2.v + ", " + a2.d + ")";
    }

    public boolean a(cf a2) {
        try {
            cf a3;
            return a3.b == a2.b && a3.c == a2.c && a3.v == a2.v && a3.d == a2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean equals(Object a2) {
        try {
            cf a3;
            cf cf2 = (cf)a2;
            return a3.b == cf2.b && a3.c == cf2.c && a3.v == cf2.v && a3.d == cf2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
        catch (ClassCastException classCastException) {
            return false;
        }
    }

    public boolean a(cf a2, float a3) {
        cf a4;
        float f2 = a4.b - a2.b;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f3 = f2 < 0.0f ? -f2 : f2;
        if (f3 > a3) {
            return false;
        }
        f2 = a4.c - a2.c;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f4 = f2 < 0.0f ? -f2 : f2;
        if (f4 > a3) {
            return false;
        }
        f2 = a4.v - a2.v;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f5 = f2 < 0.0f ? -f2 : f2;
        if (f5 > a3) {
            return false;
        }
        f2 = a4.d - a2.d;
        if (Float.isNaN(f2)) {
            return false;
        }
        float f6 = f2 < 0.0f ? -f2 : f2;
        return !(f6 > a3);
    }

    public int hashCode() {
        cf a2;
        long l2 = 1L;
        l2 = kbd.a(l2, a2.b);
        l2 = kbd.a(l2, a2.c);
        l2 = kbd.a(l2, a2.v);
        l2 = kbd.a(l2, a2.d);
        return kbd.a(l2);
    }

    public final void a(float a2, float a3, cf a4) {
        a.b = a4.b > a3 ? a3 : (a4.b < a2 ? a2 : a4.b);
        a.c = a4.c > a3 ? a3 : (a4.c < a2 ? a2 : a4.c);
        a.v = a4.v > a3 ? a3 : (a4.v < a2 ? a2 : a4.v);
        a.d = a4.d > a3 ? a3 : (a4.d < a2 ? a2 : a4.d);
    }

    public final void p(float a2, cf a3) {
        a.b = a3.b < a2 ? a2 : a3.b;
        a.c = a3.c < a2 ? a2 : a3.c;
        a.v = a3.v < a2 ? a2 : a3.v;
        a.d = a3.d < a2 ? a2 : a3.d;
    }

    public final void a(float a2, cf a3) {
        a.b = a3.b > a2 ? a2 : a3.b;
        a.c = a3.c > a2 ? a2 : a3.c;
        a.v = a3.v > a2 ? a2 : a3.v;
        a.d = a3.d > a2 ? a2 : a3.v;
    }

    public final void a(cf a2) {
        a.b = Math.abs(a2.b);
        a.c = Math.abs(a2.c);
        a.v = Math.abs(a2.v);
        a.d = Math.abs(a2.d);
    }

    public final void a(float a2, float a3) {
        cf a4;
        if (a4.b > a3) {
            a4.b = a3;
        } else if (a4.b < a2) {
            a4.b = a2;
        }
        if (a4.c > a3) {
            a4.c = a3;
        } else if (a4.c < a2) {
            a4.c = a2;
        }
        if (a4.v > a3) {
            a4.v = a3;
        } else if (a4.v < a2) {
            a4.v = a2;
        }
        if (a4.d > a3) {
            a4.d = a3;
        } else if (a4.d < a2) {
            a4.d = a2;
        }
    }

    public final void j(float a2) {
        cf a3;
        if (a3.b < a2) {
            a3.b = a2;
        }
        if (a3.c < a2) {
            a3.c = a2;
        }
        if (a3.v < a2) {
            a3.v = a2;
        }
        if (a3.d < a2) {
            a3.d = a2;
        }
    }

    public final void z(float a2) {
        cf a3;
        if (a3.b > a2) {
            a3.b = a2;
        }
        if (a3.c > a2) {
            a3.c = a2;
        }
        if (a3.v > a2) {
            a3.v = a2;
        }
        if (a3.d > a2) {
            a3.d = a2;
        }
    }

    public final void a() {
        cf a2;
        a2.b = Math.abs(a2.b);
        a2.c = Math.abs(a2.c);
        a2.v = Math.abs(a2.v);
        a2.d = Math.abs(a2.d);
    }

    public void a(cf a2, cf a3, float a4) {
        a.b = (1.0f - a4) * a2.b + a4 * a3.b;
        a.c = (1.0f - a4) * a2.c + a4 * a3.c;
        a.v = (1.0f - a4) * a2.v + a4 * a3.v;
        a.d = (1.0f - a4) * a2.d + a4 * a3.d;
    }

    public void a(cf a2, float a3) {
        cf a4;
        a4.b = (1.0f - a3) * a4.b + a3 * a2.b;
        a4.c = (1.0f - a3) * a4.c + a3 * a2.c;
        a4.v = (1.0f - a3) * a4.v + a3 * a2.v;
        a4.d = (1.0f - a3) * a4.d + a3 * a2.d;
    }

    public Object clone() {
        try {
            cf a2;
            return super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
    }

    public final float y() {
        cf a2;
        return a2.b;
    }

    public final void y(float a2) {
        a.b = a2;
    }

    public final float o() {
        cf a2;
        return a2.c;
    }

    public final void o(float a2) {
        a.c = a2;
    }

    public final float p() {
        cf a2;
        return a2.v;
    }

    public final void p(float a2) {
        a.v = a2;
    }

    public final float a() {
        cf a2;
        return a2.d;
    }

    public final void a(float a2) {
        a.d = a2;
    }
}

