/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class akd
extends gba {
    public zb h;
    private xga z;
    private tp l;
    private Random b;
    public int c;
    public int[] v;
    public int[] d;

    public akd(mnb a2, xga a3) {
        a4(a2, a3, tp.r);
        akd a4;
    }

    public akd(mnb a2, xga a3, tp a4) {
        akd a5;
        a5.h = new gcd(a5, "Enchant", true, 2);
        a5.b = new Random();
        a5.v = new int[3];
        a5.d = new int[]{-1, -1, -1};
        a5.z = a3;
        a5.l = a4;
        a5.c = a2.c.l();
        a5.a(new wdb(a5, a5.h, 0, 15, 47));
        a5.a(new gpc(a5, a5.h, 1, 35, 47));
        int n2 = 0;
        while (n2 < 3) {
            int n3 = 0;
            while (n3 < 9) {
                a5.a(new se(a2, n3 + n2 * 9 + 9, 8 + n3 * 18, 84 + n2 * 18));
                ++n3;
            }
            ++n2;
        }
        n2 = 0;
        while (n2 < 9) {
            a5.a(new se(a2, n2, 8 + n2 * 18, 142));
            ++n2;
        }
    }

    @Override
    public void p(d a2) {
        akd a3;
        super.p(a2);
        a2.a((gba)a3, 0, a3.v[0]);
        a2.a((gba)a3, 1, a3.v[1]);
        a2.a((gba)a3, 2, a3.v[2]);
        a2.a((gba)a3, 3, a3.c & 0xFFFFFFF0);
        a2.a((gba)a3, 4, a3.d[0]);
        a2.a((gba)a3, 5, a3.d[1]);
        a2.a((gba)a3, 6, a3.d[2]);
    }

    @Override
    public void p() {
        akd a2;
        super.p();
        int n2 = 0;
        while (n2 < a2.v.size()) {
            d d2 = (d)a2.v.get(n2);
            d2.a((gba)a2, 0, a2.v[0]);
            d2.a((gba)a2, 1, a2.v[1]);
            d2.a((gba)a2, 2, a2.v[2]);
            d2.a((gba)a2, 3, a2.c & 0xFFFFFFF0);
            d2.a((gba)a2, 4, a2.d[0]);
            d2.a((gba)a2, 5, a2.d[1]);
            d2.a((gba)a2, 6, a2.d[2]);
            ++n2;
        }
    }

    @Override
    public void a(int a2, int a3) {
        if (a2 >= 0 && a2 <= 2) {
            a4.v[a2] = a3;
        } else if (a2 == 3) {
            a4.c = a3;
        } else if (a2 >= 4 && a2 <= 6) {
            a4.d[a2 - 4] = a3;
        } else {
            akd a4;
            super.a(a2, a3);
        }
    }

    @Override
    public void a(zb a2) {
        akd a3;
        if (a2 == a3.h) {
            wfc wfc2 = a2.p(0);
            if (wfc2 != null && wfc2.y()) {
                if (!a3.z.f) {
                    int n2 = 0;
                    int n3 = -1;
                    while (n3 <= 1) {
                        int n4 = -1;
                        while (n4 <= 1) {
                            if ((n3 != 0 || n4 != 0) && a3.z.a(a3.l.a(n4, 0, n3)) && a3.z.a(a3.l.a(n4, 1, n3))) {
                                if (a3.z.a(a3.l.a(n4 * 2, 0, n3 * 2)).a() == cl.ch) {
                                    ++n2;
                                }
                                if (a3.z.a(a3.l.a(n4 * 2, 1, n3 * 2)).a() == cl.ch) {
                                    ++n2;
                                }
                                if (n4 != 0 && n3 != 0) {
                                    if (a3.z.a(a3.l.a(n4 * 2, 0, n3)).a() == cl.ch) {
                                        ++n2;
                                    }
                                    if (a3.z.a(a3.l.a(n4 * 2, 1, n3)).a() == cl.ch) {
                                        ++n2;
                                    }
                                    if (a3.z.a(a3.l.a(n4, 0, n3 * 2)).a() == cl.ch) {
                                        ++n2;
                                    }
                                    if (a3.z.a(a3.l.a(n4, 1, n3 * 2)).a() == cl.ch) {
                                        ++n2;
                                    }
                                }
                            }
                            ++n4;
                        }
                        ++n3;
                    }
                    a3.b.setSeed(a3.c);
                    n3 = 0;
                    while (n3 < 3) {
                        a3.v[n3] = fi.a(a3.b, n3, n2, wfc2);
                        a3.d[n3] = -1;
                        if (a3.v[n3] < n3 + 1) {
                            a3.v[n3] = 0;
                        }
                        ++n3;
                    }
                    n3 = 0;
                    while (n3 < 3) {
                        List<vjc> list;
                        if (a3.v[n3] > 0 && (list = a3.a(wfc2, n3, a3.v[n3])) != null && !list.isEmpty()) {
                            vjc vjc2 = list.get(a3.b.nextInt(list.size()));
                            a3.d[n3] = vjc2.c.b | vjc2.v << 8;
                        }
                        ++n3;
                    }
                    a3.p();
                }
            } else {
                int n5 = 0;
                while (n5 < 3) {
                    a3.v[n5] = 0;
                    a3.d[n5] = -1;
                    ++n5;
                }
            }
        }
    }

    @Override
    public boolean a(pm a2, int a3) {
        akd a4;
        wfc wfc2 = a4.h.p(0);
        wfc wfc3 = a4.h.p(1);
        int n2 = a3 + 1;
        if (!(wfc3 != null && wfc3.e >= n2 || a2.y.b)) {
            return false;
        }
        if (a4.v[a3] > 0 && wfc2 != null && (a2.a >= n2 && a2.a >= a4.v[a3] || a2.y.b)) {
            if (!a4.z.f) {
                boolean bl2;
                List<vjc> list = a4.a(wfc2, a3, a4.v[a3]);
                boolean bl3 = bl2 = wfc2.a() == sxa.uc;
                if (list != null) {
                    a2.q(n2);
                    if (bl2) {
                        wfc2.a(sxa.ba);
                    }
                    int n3 = 0;
                    while (n3 < list.size()) {
                        vjc vjc2 = list.get(n3);
                        if (bl2) {
                            sxa.ba.a(wfc2, vjc2);
                        } else {
                            wfc2.a(vjc2.c, vjc2.v);
                        }
                        ++n3;
                    }
                    if (!a2.y.b) {
                        wfc3.e -= n2;
                        if (wfc3.e <= 0) {
                            a4.h.a(1, null);
                        }
                    }
                    a2.p(hca.r);
                    a4.h.o();
                    a4.c = a2.l();
                    a4.a(a4.h);
                }
            }
            return true;
        }
        return false;
    }

    private /* synthetic */ List<vjc> a(wfc a2, int a3, int a4) {
        akd a5;
        a5.b.setSeed(a5.c + a3);
        List<vjc> list = fi.a(a5.b, a2, a4);
        if (a2.a() == sxa.uc && list != null && list.size() > 1) {
            list.remove(a5.b.nextInt(list.size()));
        }
        return list;
    }

    public int a() {
        akd a2;
        wfc wfc2 = a2.h.p(1);
        return wfc2 == null ? 0 : wfc2.e;
    }

    @Override
    public void a(pm a2) {
        akd a3;
        super.a(a2);
        if (!a3.z.f) {
            int n2 = 0;
            while (n2 < a3.h.o()) {
                wfc wfc2 = a3.h.a(n2);
                if (wfc2 != null) {
                    a2.a(wfc2, false);
                }
                ++n2;
            }
        }
    }

    @Override
    public boolean a(pm a2) {
        akd a3;
        return a3.z.a(a3.l).a() != cl.ib ? false : a2.p((double)a3.l.o() + 0.5, (double)a3.l.p() + 0.5, (double)a3.l.a() + 0.5) <= 64.0;
    }

    @Override
    public wfc a(pm a2, int a3) {
        akd a4;
        wfc wfc2 = null;
        se se2 = (se)a4.f.get(a3);
        if (se2 != null && se2.p()) {
            wfc wfc3 = se2.a();
            wfc2 = wfc3.a();
            if (a3 == 0) {
                if (!a4.a(wfc3, 2, 38, true)) {
                    return null;
                }
            } else if (a3 == 1) {
                if (!a4.a(wfc3, 2, 38, true)) {
                    return null;
                }
            } else if (wfc3.a() == sxa.rc && kja.p(wfc3.y()) == kja.s) {
                if (!a4.a(wfc3, 1, 2, true)) {
                    return null;
                }
            } else {
                if (((se)a4.f.get(0)).p() || !((se)a4.f.get(0)).a(wfc3)) {
                    return null;
                }
                if (wfc3.x() && wfc3.e == 1) {
                    ((se)a4.f.get(0)).a(wfc3.a());
                    wfc3.e = 0;
                } else if (wfc3.e >= 1) {
                    ((se)a4.f.get(0)).a(new wfc(wfc3.a(), 1, wfc3.y()));
                    --wfc3.e;
                }
            }
            if (wfc3.e == 0) {
                se2.a((wfc)null);
            } else {
                se2.a();
            }
            if (wfc3.e == wfc2.e) {
                return null;
            }
            se2.a(a2, wfc3);
        }
        return wfc2;
    }
}

