/*
 * Decompiled with CFR 0.152.
 */
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.optifine.expr.\u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd8;
import net.optifine.expr.\u631f\u6052\u92f2\u9858\u6715\u8acf\u66fd\u53f6\u697d\u502b\u8ca0\u6a39\u4eee\u8ad2\u7363\u6c41\u8b90\u4e39\u643e\u6d66\u733f\u5229\u514e\u5e06\u5fae\u8efd\u8adc\u75d4\u6fc3\u7336\u7e04\u55aa\u9817\u524a\u4f1a\u6b3e\u7d10\u5d29\u72fd\u6e7f;
import net.optifine.expr.\u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8;
import net.optifine.expr.\u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f;
import net.optifine.expr.\u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c;
import net.optifine.expr.\u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe1;
import net.optifine.expr.\u898b\u8236\u58f2\u67ff\u578b\u6e07\u4ec7\u790e\u6d6e\u86cd\u8fce\u63d0\u63a1\u554f\u6dbc\u4fbf\u85aa\u7345\u97fb\u67d4\u65ad\u86ee\u5bc5\u62b5\u86ce\u6de1\u4ec7\u8a2a\u614b\u8a6b\u6368\u5f10\u85af\u9858\u6dd1\u5404\u5efa\u822a\u6ed1\u847a;
import net.optifine.expr.\u8f44\u8607\u8a51\u5ca8\u5f71\u64ae\u5e38\u67cf\u639b\u4ec7\u9283\u6bce\u7a84\u7336\u4ef0\u7149\u745b\u4f50\u5c2d\u6607\u6190\u541b\u83cc\u7279\u5e63\u80c3\u983c\u7aea\u540a\u6108\u9091\u614b\u6271\u52b4\u5a46\u77ad\u99c1\u6258\u8607\u795e;
import net.optifine.expr.\u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f06;
import net.optifine.shaders.\u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80;
import net.optifine.shaders.\u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9;
import net.optifine.shaders.\u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345;
import net.optifine.shaders.\u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u9022;
import net.optifine.shaders.\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a;
import net.optifine.util.\u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class agb {
    private static final Pattern l = Pattern.compile("^\\s*#version\\s+.*$");
    private static final Pattern b = Pattern.compile("^\\s*#include\\s+\"([A-Za-z0-9_/\\.]+)\".*$");
    private static final Set<String> c = agb.a();
    private static final Map<String, Integer> v = agb.p();
    private static final Map<String, Integer> d = agb.a();

    public agb() {
        agb a2;
    }

    public static hya[] a(\u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a2, String[] a3, List<Integer> a4) {
        hya[] hyaArray;
        if (a2 == null) {
            return new hya[0];
        }
        HashMap<String, hya> hashMap = new HashMap<String, hya>();
        agb.a(a2, "/shaders", a3, hashMap);
        for (int n2 : a4) {
            hyaArray = "/shaders/world" + n2;
            agb.a(a2, (String)hyaArray, a3, hashMap);
        }
        Collection collection = hashMap.values();
        hyaArray = collection.toArray(new hya[collection.size()]);
        lqb lqb2 = new lqb();
        Arrays.sort(hyaArray, lqb2);
        return hyaArray;
    }

    private static /* synthetic */ void a(\u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a2, String a3, String[] a4, Map<String, hya> a5) {
        int n2 = 0;
        while (n2 < a4.length) {
            String string = a4[n2];
            if (!string.equals("")) {
                String string2 = String.valueOf(a3) + "/" + string + ".vsh";
                String string3 = String.valueOf(a3) + "/" + string + ".fsh";
                agb.a(a2, string2, a5);
                agb.a(a2, string3, a5);
            }
            ++n2;
        }
    }

    private static /* synthetic */ void a(\u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a2, String a3, Map<String, hya> a4) {
        String[] stringArray = agb.a(a2, a3);
        int n2 = 0;
        while (n2 < stringArray.length) {
            String string = stringArray[n2];
            hya hya2 = agb.a(string, a3);
            if (!(hya2 == null || hya2.x().startsWith(hsc.o()) || hya2.a() && !agb.a(hya2, stringArray))) {
                String string2 = hya2.x();
                hya hya3 = a4.get(string2);
                if (hya3 != null) {
                    if (!xfc.a((Object)hya3.o(), (Object)hya2.o())) {
                        xfc.z("Ambiguous shader option: " + hya2.x());
                        xfc.z(" - in " + xfc.a(hya3.p()) + ": " + hya3.o());
                        xfc.z(" - in " + xfc.a(hya2.p()) + ": " + hya2.o());
                        hya3.p(false);
                    }
                    if (hya3.j() == null || hya3.j().length() <= 0) {
                        hya3.a(hya2.j());
                    }
                    hya3.a(hya2.p());
                } else {
                    a4.put(string2, hya2);
                }
            }
            ++n2;
        }
    }

    private static /* synthetic */ boolean a(hya a2, String[] a3) {
        int n2 = 0;
        while (n2 < a3.length) {
            String string = a3[n2];
            if (a2.a(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    private static /* synthetic */ String[] a(\u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a2, String a3) {
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            String string = agb.a(a3, a2, 0, arrayList, 0);
            if (string == null) {
                return new String[0];
            }
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(string.getBytes());
            String[] stringArray = xfc.a(byteArrayInputStream);
            return stringArray;
        }
        catch (IOException iOException) {
            xfc.j(String.valueOf(iOException.getClass().getName()) + ": " + iOException.getMessage());
            return new String[0];
        }
    }

    private static /* synthetic */ hya a(String a2, String a3) {
        hya hya2 = null;
        if (hya2 == null) {
            hya2 = ulb.a(a2, a3);
        }
        if (hya2 == null) {
            hya2 = gzc.a(a2, a3);
        }
        if (hya2 != null) {
            return hya2;
        }
        if (hya2 == null) {
            hya2 = sob.p(a2, a3);
        }
        if (hya2 == null) {
            hya2 = ead.p(a2, a3);
        }
        return hya2 != null && c.contains(hya2.x()) ? hya2 : null;
    }

    private static /* synthetic */ Set<String> a() {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add("shadowMapResolution");
        hashSet.add("shadowMapFov");
        hashSet.add("shadowDistance");
        hashSet.add("shadowDistanceRenderMul");
        hashSet.add("shadowIntervalSize");
        hashSet.add("generateShadowMipmap");
        hashSet.add("generateShadowColorMipmap");
        hashSet.add("shadowHardwareFiltering");
        hashSet.add("shadowHardwareFiltering0");
        hashSet.add("shadowHardwareFiltering1");
        hashSet.add("shadowtex0Mipmap");
        hashSet.add("shadowtexMipmap");
        hashSet.add("shadowtex1Mipmap");
        hashSet.add("shadowcolor0Mipmap");
        hashSet.add("shadowColor0Mipmap");
        hashSet.add("shadowcolor1Mipmap");
        hashSet.add("shadowColor1Mipmap");
        hashSet.add("shadowtex0Nearest");
        hashSet.add("shadowtexNearest");
        hashSet.add("shadow0MinMagNearest");
        hashSet.add("shadowtex1Nearest");
        hashSet.add("shadow1MinMagNearest");
        hashSet.add("shadowcolor0Nearest");
        hashSet.add("shadowColor0Nearest");
        hashSet.add("shadowColor0MinMagNearest");
        hashSet.add("shadowcolor1Nearest");
        hashSet.add("shadowColor1Nearest");
        hashSet.add("shadowColor1MinMagNearest");
        hashSet.add("wetnessHalflife");
        hashSet.add("drynessHalflife");
        hashSet.add("eyeBrightnessHalflife");
        hashSet.add("centerDepthHalflife");
        hashSet.add("sunPathRotation");
        hashSet.add("ambientOcclusionLevel");
        hashSet.add("superSamplingLevel");
        hashSet.add("noiseTextureResolution");
        return hashSet;
    }

    public static zsa[] a(Properties a2, hya[] a3) {
        String string = "profile.";
        ArrayList<zsa> arrayList = new ArrayList<zsa>();
        for (Object zsaArray2 : a2.keySet()) {
            String string2 = (String)zsaArray2;
            if (!string2.startsWith(string)) continue;
            String string3 = string2.substring(string.length());
            a2.getProperty(string2);
            HashSet<String> hashSet = new HashSet<String>();
            zsa zsa2 = agb.a(string3, a2, hashSet, a3);
            if (zsa2 == null) continue;
            arrayList.add(zsa2);
        }
        if (arrayList.size() <= 0) {
            return null;
        }
        zsa[] zsaArray = arrayList.toArray(new zsa[arrayList.size()]);
        return zsaArray;
    }

    public static Map<String, \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8> a(Properties a2, hya[] a3) {
        String string = "program.";
        Pattern pattern = Pattern.compile("program\\.([^.]+)\\.enabled");
        HashMap<String, \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8> hashMap = new HashMap<String, \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8>();
        for (Object object : a2.keySet()) {
            String string2 = (String)object;
            Matcher matcher = pattern.matcher(string2);
            if (!matcher.matches()) continue;
            String string3 = matcher.group(1);
            String string4 = a2.getProperty(string2).trim();
            \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8 \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b82 = agb.a(string4, a3);
            if (\u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b82 == null) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Error parsing program condition: " + string2);
                continue;
            }
            hashMap.put(string3, \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b82);
        }
        return hashMap;
    }

    private static /* synthetic */ \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8 a(String a2, hya[] a3) {
        try {
            qx qx2 = new qx(a3);
            \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f06 \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f062 = new \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f06(qx2);
            \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8 \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b82 = \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f062.a(a2);
            return \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b82;
        }
        catch (\u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd8 \u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82) {
            \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.o(String.valueOf(\u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82.getClass().getName()) + ": " + \u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82.getMessage());
            return null;
        }
    }

    public static Set<String> a(Properties a2, hya[] a3) {
        HashSet<String> hashSet = new HashSet<String>();
        String string = a2.getProperty("sliders");
        if (string == null) {
            return hashSet;
        }
        String[] stringArray = xfc.a(string, " ");
        int n2 = 0;
        while (n2 < stringArray.length) {
            String string2 = stringArray[n2];
            hya hya2 = \u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a(string2, a3);
            if (hya2 == null) {
                xfc.z("Invalid shader option: " + string2);
            } else {
                hashSet.add(string2);
            }
            ++n2;
        }
        return hashSet;
    }

    private static /* synthetic */ zsa a(String a2, Properties a3, Set<String> a4, hya[] a5) {
        String string = "profile.";
        String string2 = String.valueOf(string) + a2;
        if (a4.contains(string2)) {
            xfc.z("[Shaders] Profile already parsed: " + a2);
            return null;
        }
        a4.add(a2);
        zsa zsa2 = new zsa(a2);
        String string3 = a3.getProperty(string2);
        String[] stringArray = xfc.a(string3, " ");
        int n2 = 0;
        while (n2 < stringArray.length) {
            Object object;
            Object object2;
            String string4 = stringArray[n2];
            if (string4.startsWith(string)) {
                object2 = string4.substring(string.length());
                object = agb.a((String)object2, a3, a4, a5);
                if (zsa2 != null) {
                    zsa2.a((zsa)object);
                    zsa2.a(((zsa)object).a());
                }
            } else {
                Object object3;
                object2 = xfc.a(string4, ":=");
                if (((String[])object2).length == 1) {
                    Object object4;
                    object = object2[0];
                    boolean bl2 = true;
                    if (((String)object).startsWith("!")) {
                        bl2 = false;
                        object = ((String)object).substring(1);
                    }
                    if (((String)object).startsWith((String)(object3 = "program."))) {
                        object4 = ((String)object).substring(((String)object3).length());
                        if (!\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a((String)object4)) {
                            xfc.z("Invalid program: " + (String)object4 + " in profile: " + zsa2.a());
                        } else if (bl2) {
                            zsa2.a((String)object4);
                        } else {
                            zsa2.p((String)object4);
                        }
                    } else {
                        object4 = \u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a((String)object, a5);
                        if (!(object4 instanceof ulb)) {
                            xfc.z("[Shaders] Invalid option: " + (String)object);
                        } else {
                            zsa2.a((String)object, String.valueOf(bl2));
                            ((hya)object4).a(true);
                        }
                    }
                } else if (((String[])object2).length != 2) {
                    xfc.z("[Shaders] Invalid option value: " + string4);
                } else {
                    object = object2[0];
                    String string5 = object2[1];
                    object3 = \u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a((String)object, a5);
                    if (object3 == null) {
                        xfc.z("[Shaders] Invalid option: " + string4);
                    } else if (!((hya)object3).o(string5)) {
                        xfc.z("[Shaders] Invalid value: " + string4);
                    } else {
                        ((hya)object3).a(true);
                        zsa2.a((String)object, string5);
                    }
                }
            }
            ++n2;
        }
        return zsa2;
    }

    public static Map<String, gha> a(Properties a2, zsa[] a3, hya[] a4) {
        HashMap<String, gha> hashMap = new HashMap<String, gha>();
        agb.a("screen", a2, hashMap, a3, a4);
        return hashMap.isEmpty() ? null : hashMap;
    }

    private static /* synthetic */ boolean a(String a2, Properties a3, Map<String, gha> a4, zsa[] a5, hya[] a6) {
        Object object;
        String string;
        String string2 = a3.getProperty(a2);
        if (string2 == null) {
            return false;
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        HashSet<String> hashSet = new HashSet<String>();
        String[] stringArray = xfc.a(string2, " ");
        int n2 = 0;
        while (n2 < stringArray.length) {
            string = stringArray[n2];
            if (string.equals("<empty>")) {
                arrayList.add(null);
            } else if (hashSet.contains(string)) {
                xfc.z("[Shaders] Duplicate option: " + string + ", key: " + a2);
            } else {
                Object object2;
                hashSet.add(string);
                if (string.equals("<profile>")) {
                    if (a5 == null) {
                        xfc.z("[Shaders] Option profile can not be used, no profiles defined: " + string + ", key: " + a2);
                    } else {
                        object2 = new adb(a5, a6);
                        arrayList.add(object2);
                    }
                } else if (string.equals("*")) {
                    object2 = new hub("<rest>");
                    arrayList.add(object2);
                } else if (string.startsWith("[") && string.endsWith("]")) {
                    object2 = \u6a4b\u670b\u5f6a\u9061\u8108\u7de0\u68f2\u7530\u62d2\u9c48\u5858\u723d\u4f1d\u4e00\u5bbf\u8cac\u9c0d\u9451\u53ca\u5264\u67fe\u5f10\u7e26\u4e94\u81e8\u623b\u6e08\u8150\u5144\u540d\u8adc\u63d0\u5c04\u7e41\u56f3\u4f50\u9001\u9e9f\u6bcd\u7b94.p(string, "[", "]");
                    if (!((String)object2).matches("^[a-zA-Z0-9_]+$")) {
                        xfc.z("[Shaders] Invalid screen: " + string + ", key: " + a2);
                    } else if (!agb.a("screen." + (String)object2, a3, a4, a5, a6)) {
                        xfc.z("[Shaders] Invalid screen: " + string + ", key: " + a2);
                    } else {
                        object = new ycb((String)object2);
                        arrayList.add(object);
                    }
                } else {
                    object2 = \u52aa\u983b\u97d3\u5be9\u8c46\u516b\u91c7\u6803\u633a\u59bb\u8997\u9a0e\u6e1b\u5c04\u76c8\u8f09\u5404\u7389\u5265\u5a41\u5229\u5bc5\u4e5f\u5b64\u80a2\u96e2\u8237\u87ba\u6e5b\u8eca\u7fe0\u6dc0\u5869\u7b86\u515c\u6d44\u9854\u5531\u5c51\u4e80.a(string, a6);
                    if (object2 == null) {
                        xfc.z("[Shaders] Invalid option: " + string + ", key: " + a2);
                        arrayList.add(null);
                    } else {
                        ((hya)object2).a(true);
                        arrayList.add(object2);
                    }
                }
            }
            ++n2;
        }
        hya[] hyaArray = arrayList.toArray(new hya[arrayList.size()]);
        string = a3.getProperty(String.valueOf(a2) + ".columns");
        int n3 = xfc.a(string, 2);
        object = new gha(a2, hyaArray, n3);
        a4.put(a2, (gha)object);
        return true;
    }

    public static BufferedReader a(BufferedReader a2, String a3, \u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a4, int a5, List<String> a6, int a7) throws IOException {
        String string = "/";
        int n2 = a3.lastIndexOf("/");
        if (n2 >= 0) {
            string = a3.substring(0, n2);
        }
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        int n3 = -1;
        LinkedHashSet<Object> linkedHashSet = new LinkedHashSet<Object>();
        int n4 = 1;
        while (true) {
            Object object;
            Object object2;
            Object object3;
            String string2;
            if ((string2 = a2.readLine()) == null) {
                object3 = charArrayWriter.toCharArray();
                if (n3 >= 0 && linkedHashSet.size() > 0) {
                    Object object42;
                    object2 = new StringBuilder();
                    for (Object object42 : linkedHashSet) {
                        object2.append("#define ");
                        object2.append(((hw)object42).o());
                        object2.append(" ");
                        object2.append(((hw)object42).p());
                        object2.append("\n");
                    }
                    object42 = object2.toString();
                    object = new StringBuilder(new String((char[])object3));
                    ((StringBuilder)object).insert(n3, (String)object42);
                    String string3 = ((StringBuilder)object).toString();
                    object3 = string3.toCharArray();
                }
                object2 = new CharArrayReader((char[])object3);
                return new BufferedReader((Reader)object2);
            }
            if (n3 < 0 && (object3 = (Object)l.matcher(string2)).matches()) {
                object2 = String.valueOf(hsc.p()) + hsc.a();
                String string4 = String.valueOf(string2) + "\n" + (String)object2;
                object = "#line " + (n4 + 1) + " " + a5;
                string2 = String.valueOf(string4) + (String)object;
                n3 = charArrayWriter.size() + string4.length();
            }
            if ((object3 = (Object)b.matcher(string2)).matches()) {
                int n5;
                object2 = object3.group(1);
                boolean bl2 = object2.startsWith("/");
                Object object5 = object = bl2 ? "/shaders" + (String)object2 : String.valueOf(string) + "/" + (String)object2;
                if (!a6.contains(object)) {
                    a6.add((String)object);
                }
                if ((string2 = agb.a((String)object, a4, n5 = a6.indexOf(object) + 1, a6, a7)) == null) {
                    throw new IOException("Included file not found: " + a3);
                }
                if (string2.endsWith("\n")) {
                    string2 = string2.substring(0, string2.length() - 1);
                }
                String string5 = "#line 1 " + n5 + "\n";
                if (string2.startsWith("#version ")) {
                    string5 = "";
                }
                string2 = String.valueOf(string5) + string2 + "\n" + "#line " + (n4 + 1) + " " + a5;
            }
            if (n3 >= 0 && string2.contains(hsc.o())) {
                object2 = agb.a(string2, hsc.a());
                int n6 = 0;
                while (n6 < ((hw[])object2).length) {
                    object = object2[n6];
                    linkedHashSet.add(object);
                    ++n6;
                }
            }
            charArrayWriter.write(string2);
            charArrayWriter.write("\n");
            ++n4;
        }
    }

    private static /* synthetic */ hw[] a(String a2, hw[] a3) {
        ArrayList<hw> arrayList = new ArrayList<hw>();
        int n2 = 0;
        while (n2 < a3.length) {
            hw hw2 = a3[n2];
            if (a2.contains(hw2.o())) {
                arrayList.add(hw2);
            }
            ++n2;
        }
        hw[] hwArray = arrayList.toArray(new hw[arrayList.size()]);
        return hwArray;
    }

    private static /* synthetic */ String a(String a2, \u59be\u9858\u6253\u5bff\u8997\u8eab\u6577\u5019\u98e2\u63a5\u826f\u8b0e\u85aa\u53db\u96bb\u8087\u9d2c\u5f71\u76f2\u9db4\u7b94\u975e\u4e95\u7e82\u60dc\u7436\u4f1d\u62bc\u7121\u5375\u8a2a\u6e07\u7247\u6deb\u6cc1\u8e5f\u8aad\u808b\u5e8a\u59b9 a3, int a4, List<String> a5, int a6) throws IOException {
        if (a6 >= 10) {
            throw new IOException("#include depth exceeded: " + a6 + ", file: " + a2);
        }
        ++a6;
        InputStream inputStream = a3.a(a2);
        if (inputStream == null) {
            return null;
        }
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ASCII");
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        bufferedReader = agb.a(bufferedReader, a2, a3, a4, a5, a6);
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        String string;
        while ((string = bufferedReader.readLine()) != null) {
            charArrayWriter.write(string);
            charArrayWriter.write("\n");
        }
        return charArrayWriter.toString();
    }

    public static eia a(Properties a2) {
        String string = "uniform";
        String string2 = "variable";
        String string3 = String.valueOf(string) + ".";
        String string4 = String.valueOf(string2) + ".";
        HashMap<String, \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f> hashMap = new HashMap<String, \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f>();
        ArrayList<quc> arrayList = new ArrayList<quc>();
        for (Object qucArray2 : a2.keySet()) {
            String string5 = (String)qucArray2;
            String[] stringArray = xfc.a(string5, ".");
            if (stringArray.length != 3) continue;
            String string6 = stringArray[0];
            String string7 = stringArray[1];
            String string8 = stringArray[2];
            String string9 = a2.getProperty(string5).trim();
            if (hashMap.containsKey(string8)) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.o("Expression already defined: " + string8);
                continue;
            }
            if (!string6.equals(string) && !string6.equals(string2)) continue;
            \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.p("Custom " + string6 + ": " + string8);
            quc quc2 = agb.a(string6, string8, string7, string9, hashMap);
            if (quc2 == null) continue;
            hashMap.put(string8, quc2.a());
            if (string6.equals(string2)) continue;
            arrayList.add(quc2);
        }
        if (arrayList.size() <= 0) {
            return null;
        }
        quc[] qucArray = arrayList.toArray(new quc[arrayList.size()]);
        eia eia2 = new eia(qucArray, hashMap);
        return eia2;
    }

    private static /* synthetic */ quc a(String a2, String a3, String a4, String a5, Map<String, \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f> a6) {
        \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2;
        dka dka2;
        block5: {
            block4: {
                try {
                    dka2 = dka.a(a4);
                    if (dka2 != null) break block4;
                    \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.o("Unknown " + a2 + " type: " + (Object)((Object)dka2));
                    return null;
                }
                catch (\u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd8 \u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82) {
                    \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.o(String.valueOf(\u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82.getClass().getName()) + ": " + \u4e0e\u574a\u5264\u60a9\u5c2d\u65a4\u7d9c\u7b51\u690d\u52b9\u6a21\u4e5e\u7363\u5f6a\u722a\u8463\u5df4\u96c6\u83d6\u83d6\u6e2c\u5bff\u5f10\u90ce\u97d3\u58f0\u84ee\u6df3\u6e6f\u8adc\u8494\u633a\u7c8d\u65ec\u559a\u53e2\u50d1\u60a9\u93ae\u6bd82.getMessage());
                    return null;
                }
            }
            wq wq2 = new wq(a6);
            \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f06 \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f062 = new \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f06(wq2);
            \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2 = \u91dc\u4ef0\u932f\u662d\u85af\u9190\u52e4\u9ce5\u8ad2\u83cc\u51b6\u8a6e\u8a69\u6f14\u8fc4\u866b\u658c\u4f1d\u76d7\u7656\u5fd9\u7ae5\u6d41\u6d17\u623f\u63a7\u6bbb\u82d4\u5fae\u8089\u9eb9\u7984\u9583\u7363\u56de\u505c\u732e\u5e55\u6c70\u6f062.a(a5);
            \u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe1 \u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe12 = \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2.a();
            if (dka2.a(\u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe12)) break block5;
            \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.o("Expression type does not match " + a2 + " type, expression: " + (Object)((Object)\u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe12) + ", " + a2 + ": " + (Object)((Object)dka2) + " " + a3);
            return null;
        }
        \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2 = agb.a(\u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2);
        quc quc2 = new quc(a3, dka2, \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f2);
        return quc2;
    }

    private static /* synthetic */ \u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f a(\u6715\u96c1\u95a2\u5b5d\u80cc\u5f79\u5019\u81e8\u653e\u5e8f\u6802\u84ee\u83cc\u8a2d\u7b11\u5730\u98e2\u56db\u4e18\u4ef2\u98a8\u5b57\u5c01\u783f\u559a\u6e13\u679a\u6e7f\u524a\u6e2c\u65fa\u51f1\u906e\u6715\u63ac\u99d0\u647a\u723d\u7532\u968f a2) {
        return a2 instanceof \u898b\u8236\u58f2\u67ff\u578b\u6e07\u4ec7\u790e\u6d6e\u86cd\u8fce\u63d0\u63a1\u554f\u6dbc\u4fbf\u85aa\u7345\u97fb\u67d4\u65ad\u86ee\u5bc5\u62b5\u86ce\u6de1\u4ec7\u8a2a\u614b\u8a6b\u6368\u5f10\u85af\u9858\u6dd1\u5404\u5efa\u822a\u6ed1\u847a ? new \u631f\u6052\u92f2\u9858\u6715\u8acf\u66fd\u53f6\u697d\u502b\u8ca0\u6a39\u4eee\u8ad2\u7363\u6c41\u8b90\u4e39\u643e\u6d66\u733f\u5229\u514e\u5e06\u5fae\u8efd\u8adc\u75d4\u6fc3\u7336\u7e04\u55aa\u9817\u524a\u4f1a\u6b3e\u7d10\u5d29\u72fd\u6e7f((\u898b\u8236\u58f2\u67ff\u578b\u6e07\u4ec7\u790e\u6d6e\u86cd\u8fce\u63d0\u63a1\u554f\u6dbc\u4fbf\u85aa\u7345\u97fb\u67d4\u65ad\u86ee\u5bc5\u62b5\u86ce\u6de1\u4ec7\u8a2a\u614b\u8a6b\u6368\u5f10\u85af\u9858\u6dd1\u5404\u5efa\u822a\u6ed1\u847a)a2) : (a2 instanceof \u8f44\u8607\u8a51\u5ca8\u5f71\u64ae\u5e38\u67cf\u639b\u4ec7\u9283\u6bce\u7a84\u7336\u4ef0\u7149\u745b\u4f50\u5c2d\u6607\u6190\u541b\u83cc\u7279\u5e63\u80c3\u983c\u7aea\u540a\u6108\u9091\u614b\u6271\u52b4\u5a46\u77ad\u99c1\u6258\u8607\u795e ? new \u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c((\u8f44\u8607\u8a51\u5ca8\u5f71\u64ae\u5e38\u67cf\u639b\u4ec7\u9283\u6bce\u7a84\u7336\u4ef0\u7149\u745b\u4f50\u5c2d\u6607\u6190\u541b\u83cc\u7279\u5e63\u80c3\u983c\u7aea\u540a\u6108\u9091\u614b\u6271\u52b4\u5a46\u77ad\u99c1\u6258\u8607\u795e)a2) : a2);
    }

    public static void y(Properties a2) {
        for (Object object : a2.keySet()) {
            String string = (String)object;
            String[] stringArray = xfc.a(string, ".");
            if (stringArray.length != 2) continue;
            String string2 = stringArray[0];
            String string3 = stringArray[1];
            if (!string2.equals("alphaTest")) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u9022 \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a(string3);
            if (\u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 == null) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid program name: " + string3);
                continue;
            }
            String string4 = a2.getProperty(string).trim();
            lmd lmd2 = agb.a(string4);
            if (lmd2 == null) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222.a(lmd2);
        }
    }

    private static /* synthetic */ lmd a(String a2) {
        String[] stringArray = xfc.a(a2, " ");
        if (stringArray.length == 1) {
            String string = stringArray[0];
            if (string.equals("off") || string.equals("false")) {
                return new lmd(false);
            }
        } else if (stringArray.length == 2) {
            String string = stringArray[0];
            String string2 = stringArray[1];
            Integer n2 = v.get(string);
            float f2 = xfc.a(string2, -1.0f);
            if (n2 != null && f2 >= 0.0f) {
                return new lmd(true, n2, f2);
            }
        }
        \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid alpha test: " + a2);
        return null;
    }

    public static void o(Properties a2) {
        for (Object object : a2.keySet()) {
            String string = (String)object;
            String[] stringArray = xfc.a(string, ".");
            if (stringArray.length != 2) continue;
            String string2 = stringArray[0];
            String string3 = stringArray[1];
            if (!string2.equals("blend")) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u9022 \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a(string3);
            if (\u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 == null) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid program name: " + string3);
                continue;
            }
            String string4 = a2.getProperty(string).trim();
            eba eba2 = agb.a(string4);
            if (eba2 == null) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222.a(eba2);
        }
    }

    private static /* synthetic */ eba a(String a2) {
        String[] stringArray = xfc.a(a2, " ");
        if (stringArray.length == 1) {
            String string = stringArray[0];
            if (string.equals("off") || string.equals("false")) {
                return new eba(false);
            }
        } else if (stringArray.length == 2 || stringArray.length == 4) {
            String string = stringArray[0];
            String string2 = stringArray[1];
            String string3 = string;
            String string4 = string2;
            if (stringArray.length == 4) {
                string3 = stringArray[2];
                string4 = stringArray[3];
            }
            Integer n2 = d.get(string);
            Integer n3 = d.get(string2);
            Integer n4 = d.get(string3);
            Integer n5 = d.get(string4);
            if (n2 != null && n3 != null && n4 != null && n5 != null) {
                return new eba(true, n2, n3, n4, n5);
            }
        }
        \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid blend mode: " + a2);
        return null;
    }

    public static void p(Properties a2) {
        for (Object object : a2.keySet()) {
            String string = (String)object;
            String[] stringArray = xfc.a(string, ".");
            if (stringArray.length != 2) continue;
            String string2 = stringArray[0];
            String string3 = stringArray[1];
            if (!string2.equals("scale")) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u9022 \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a(string3);
            if (\u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 == null) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid program name: " + string3);
                continue;
            }
            String string4 = a2.getProperty(string).trim();
            kg kg2 = agb.a(string4);
            if (kg2 == null) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222.a(kg2);
        }
    }

    private static /* synthetic */ kg a(String a2) {
        String[] stringArray = xfc.a(a2, " ");
        float f2 = xfc.a(stringArray[0], -1.0f);
        float f3 = 0.0f;
        float f4 = 0.0f;
        if (stringArray.length > 1) {
            if (stringArray.length != 3) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid render scale: " + a2);
                return null;
            }
            f3 = xfc.a(stringArray[1], -1.0f);
            f4 = xfc.a(stringArray[2], -1.0f);
        }
        if (xfc.a(f2, 0.0f, 1.0f) && xfc.a(f3, 0.0f, 1.0f) && xfc.a(f4, 0.0f, 1.0f)) {
            return new kg(f2, f3, f4);
        }
        \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid render scale: " + a2);
        return null;
    }

    public static void a(Properties a2) {
        for (Object object : a2.keySet()) {
            String string = (String)object;
            String[] stringArray = xfc.a(string, ".");
            if (stringArray.length != 3) continue;
            String string2 = stringArray[0];
            String string3 = stringArray[1];
            String string4 = stringArray[2];
            if (!string2.equals("flip")) continue;
            \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u9022 \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.a(string3);
            if (\u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222 == null) {
                \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid program name: " + string3);
                continue;
            }
            Boolean[] booleanArray = \u8ca8\u7e82\u8997\u7ca5\u6383\u81e8\u88dc\u6d17\u5516\u868a\u52aa\u5b09\u87ba\u59a8\u96e2\u84ee\u567a\u975e\u570f\u906e\u52c3\u5fb4\u5fae\u5806\u500b\u524a\u853d\u5e1d\u8ed2\u8089\u8a73\u53f0\u5100\u9077\u866b\u9077\u54e9\u77e5\u706b\u90222.a();
            int n2 = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a.p(string4);
            if (n2 >= 0 && n2 < booleanArray.length) {
                String string5 = a2.getProperty(string).trim();
                Boolean bl2 = xfc.a(string5, null);
                if (bl2 == null) {
                    \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid boolean value: " + string5);
                    continue;
                }
                booleanArray[n2] = bl2;
                continue;
            }
            \u783a\u5e2d\u904d\u63a0\u6bce\u50ad\u5747\u96cc\u82d4\u6190\u8d66\u5f17\u4ea4\u7d22\u4f9d\u7a7f\u9baa\u4e0e\u8ced\u9f8d\u6b63\u866b\u6216\u7f77\u6a4b\u98e2\u6383\u907c\u63a0\u5e38\u4eae\u8efd\u6d5c\u9ac4\u7d9c\u4f9b\u5bb5\u4eae\u6155\u7345.y("Invalid buffer name: " + string4);
        }
    }

    private static /* synthetic */ Map<String, Integer> p() {
        HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
        hashMap.put("NEVER", new Integer(512));
        hashMap.put("LESS", new Integer(513));
        hashMap.put("EQUAL", new Integer(514));
        hashMap.put("LEQUAL", new Integer(515));
        hashMap.put("GREATER", new Integer(516));
        hashMap.put("NOTEQUAL", new Integer(517));
        hashMap.put("GEQUAL", new Integer(518));
        hashMap.put("ALWAYS", new Integer(519));
        return Collections.unmodifiableMap(hashMap);
    }

    private static /* synthetic */ Map<String, Integer> a() {
        HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
        hashMap.put("ZERO", new Integer(0));
        hashMap.put("ONE", new Integer(1));
        hashMap.put("SRC_COLOR", new Integer(768));
        hashMap.put("ONE_MINUS_SRC_COLOR", new Integer(769));
        hashMap.put("DST_COLOR", new Integer(774));
        hashMap.put("ONE_MINUS_DST_COLOR", new Integer(775));
        hashMap.put("SRC_ALPHA", new Integer(770));
        hashMap.put("ONE_MINUS_SRC_ALPHA", new Integer(771));
        hashMap.put("DST_ALPHA", new Integer(772));
        hashMap.put("ONE_MINUS_DST_ALPHA", new Integer(773));
        hashMap.put("CONSTANT_COLOR", new Integer(32769));
        hashMap.put("ONE_MINUS_CONSTANT_COLOR", new Integer(32770));
        hashMap.put("CONSTANT_ALPHA", new Integer(32771));
        hashMap.put("ONE_MINUS_CONSTANT_ALPHA", new Integer(32772));
        hashMap.put("SRC_ALPHA_SATURATE", new Integer(776));
        return Collections.unmodifiableMap(hashMap);
    }
}

