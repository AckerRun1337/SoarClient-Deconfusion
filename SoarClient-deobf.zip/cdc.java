/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.primitives.Floats
 */
import com.google.common.base.Predicate;
import com.google.common.primitives.Floats;
import java.io.IOException;
import java.util.Random;

public class cdc
extends en
implements nl,
ke {
    private pu y;
    protected String a = "Customize World Settings";
    protected String q = "Page 1 of 3";
    protected String g = "Basic Settings";
    protected String[] k = new String[4];
    private exb x;
    private ff t;
    private ff p;
    private ff s;
    private ff w;
    private ff i;
    private ff n;
    private ff e;
    private ff r;
    private boolean f = false;
    private int z = 0;
    private boolean l = false;
    private Predicate<String> b;
    private lka c;
    private lka v;
    private Random d;

    public cdc(en a2, String a3) {
        cdc a4;
        a4.b = new pba(a4);
        a4.c = new lka();
        a4.d = new Random();
        a4.y = (pu)a2;
        a4.a(a3);
    }

    @Override
    public void m() {
        cdc a2;
        int n2 = 0;
        int n3 = 0;
        if (a2.x != null) {
            n2 = a2.x.m();
            n3 = a2.x.y();
        }
        a2.a = xab.a("options.customizeTitle", new Object[0]);
        a2.r.clear();
        a2.w = new ff(302, 20, 5, 80, 20, xab.a("createWorld.customize.custom.prev", new Object[0]));
        a2.r.add(a2.w);
        a2.i = new ff(303, (int)(n - 100), 5, 80, 20, xab.a("createWorld.customize.custom.next", new Object[0]));
        a2.r.add(a2.i);
        a2.s = new ff(304, (int)(n / 2 - 187), (int)(e - 27), 90, 20, xab.a("createWorld.customize.custom.defaults", new Object[0]));
        a2.r.add(a2.s);
        a2.p = new ff(301, (int)(n / 2 - 92), (int)(e - 27), 90, 20, xab.a("createWorld.customize.custom.randomize", new Object[0]));
        a2.r.add(a2.p);
        a2.r = new ff(305, (int)(n / 2 + 3), (int)(e - 27), 90, 20, xab.a("createWorld.customize.custom.presets", new Object[0]));
        a2.r.add(a2.r);
        a2.t = new ff(300, (int)(n / 2 + 98), (int)(e - 27), 90, 20, xab.a("gui.done", new Object[0]));
        a2.r.add(a2.t);
        a2.s.c = a2.f;
        a2.n = new ff(306, (int)(n / 2 - 55), 160, 50, 20, xab.a("gui.yes", new Object[0]));
        a2.n.v = false;
        a2.r.add(a2.n);
        a2.e = new ff(307, (int)(n / 2 + 5), 160, 50, 20, xab.a("gui.no", new Object[0]));
        a2.e.v = false;
        a2.r.add(a2.e);
        if (a2.z != 0) {
            a2.n.v = true;
            a2.e.v = true;
        }
        a2.q();
        if (n2 != 0) {
            a2.x.o(n2);
            a2.x.p(n3);
            a2.a();
        }
    }

    @Override
    public void x() throws IOException {
        cdc a2;
        super.x();
        a2.x.a();
    }

    private /* synthetic */ void q() {
        cdc a2;
        jn[] jnArray = new jn[]{new al(160, xab.a("createWorld.customize.custom.seaLevel", new Object[0]), true, a2, 1.0f, 255.0f, a2.v.fb), new idd(148, xab.a("createWorld.customize.custom.useCaves", new Object[0]), true, a2.v.zb), new idd(150, xab.a("createWorld.customize.custom.useStrongholds", new Object[0]), true, a2.v.gb), new idd(151, xab.a("createWorld.customize.custom.useVillages", new Object[0]), true, a2.v.wb), new idd(152, xab.a("createWorld.customize.custom.useMineShafts", new Object[0]), true, a2.v.nb), new idd(153, xab.a("createWorld.customize.custom.useTemples", new Object[0]), true, a2.v.rb), new idd(210, xab.a("createWorld.customize.custom.useMonuments", new Object[0]), true, a2.v.jb), new idd(154, xab.a("createWorld.customize.custom.useRavines", new Object[0]), true, a2.v.hb), new idd(149, xab.a("createWorld.customize.custom.useDungeons", new Object[0]), true, a2.v.db), new al(157, xab.a("createWorld.customize.custom.dungeonChance", new Object[0]), true, a2, 1.0f, 100.0f, a2.v.mb), new idd(155, xab.a("createWorld.customize.custom.useWaterLakes", new Object[0]), true, a2.v.ra), new al(158, xab.a("createWorld.customize.custom.waterLakeChance", new Object[0]), true, a2, 1.0f, 100.0f, a2.v.aa), new idd(156, xab.a("createWorld.customize.custom.useLavaLakes", new Object[0]), true, a2.v.za), new al(159, xab.a("createWorld.customize.custom.lavaLakeChance", new Object[0]), true, a2, 10.0f, 100.0f, a2.v.fa), new idd(161, xab.a("createWorld.customize.custom.useLavaOceans", new Object[0]), true, a2.v.wa), new al(162, xab.a("createWorld.customize.custom.fixedBiome", new Object[0]), true, a2, -1.0f, 37.0f, a2.v.va), new al(163, xab.a("createWorld.customize.custom.biomeSize", new Object[0]), true, a2, 1.0f, 8.0f, a2.v.sa), new al(164, xab.a("createWorld.customize.custom.riverSize", new Object[0]), true, a2, 1.0f, 5.0f, a2.v.ea)};
        jn[] jnArray2 = new jn[66];
        jnArray2[0] = new dya(416, xab.a("tile.dirt.name", new Object[0]), false);
        jnArray2[2] = new al(165, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.qa);
        jnArray2[3] = new al(166, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.xa);
        jnArray2[4] = new al(167, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.ua);
        jnArray2[5] = new al(168, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.da);
        jnArray2[6] = new dya(417, xab.a("tile.gravel.name", new Object[0]), false);
        jnArray2[8] = new al(169, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.ma);
        jnArray2[9] = new al(170, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.na);
        jnArray2[10] = new al(171, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.ka);
        jnArray2[11] = new al(172, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.ha);
        jnArray2[12] = new dya(418, xab.a("tile.stone.granite.name", new Object[0]), false);
        jnArray2[14] = new al(173, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.ya);
        jnArray2[15] = new al(174, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.ca);
        jnArray2[16] = new al(175, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.ga);
        jnArray2[17] = new al(176, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.ja);
        jnArray2[18] = new dya(419, xab.a("tile.stone.diorite.name", new Object[0]), false);
        jnArray2[20] = new al(177, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.ia);
        jnArray2[21] = new al(178, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.ta);
        jnArray2[22] = new al(179, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.oa);
        jnArray2[23] = new al(180, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.pa);
        jnArray2[24] = new dya(420, xab.a("tile.stone.andesite.name", new Object[0]), false);
        jnArray2[26] = new al(181, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.ba);
        jnArray2[27] = new al(182, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.la);
        jnArray2[28] = new al(183, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.u);
        jnArray2[29] = new al(184, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.j);
        jnArray2[30] = new dya(421, xab.a("tile.oreCoal.name", new Object[0]), false);
        jnArray2[32] = new al(185, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.o);
        jnArray2[33] = new al(186, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.m);
        jnArray2[34] = new al(187, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.y);
        jnArray2[35] = new al(189, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.a);
        jnArray2[36] = new dya(422, xab.a("tile.oreIron.name", new Object[0]), false);
        jnArray2[38] = new al(190, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.q);
        jnArray2[39] = new al(191, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.g);
        jnArray2[40] = new al(192, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.k);
        jnArray2[41] = new al(193, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.x);
        jnArray2[42] = new dya(423, xab.a("tile.oreGold.name", new Object[0]), false);
        jnArray2[44] = new al(194, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.t);
        jnArray2[45] = new al(195, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.p);
        jnArray2[46] = new al(196, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.s);
        jnArray2[47] = new al(197, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.w);
        jnArray2[48] = new dya(424, xab.a("tile.oreRedstone.name", new Object[0]), false);
        jnArray2[50] = new al(198, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.i);
        jnArray2[51] = new al(199, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.n);
        jnArray2[52] = new al(200, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.e);
        jnArray2[53] = new al(201, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.r);
        jnArray2[54] = new dya(425, xab.a("tile.oreDiamond.name", new Object[0]), false);
        jnArray2[56] = new al(202, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.f);
        jnArray2[57] = new al(203, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.h);
        jnArray2[58] = new al(204, xab.a("createWorld.customize.custom.minHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.z);
        jnArray2[59] = new al(205, xab.a("createWorld.customize.custom.maxHeight", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.l);
        jnArray2[60] = new dya(426, xab.a("tile.oreLapis.name", new Object[0]), false);
        jnArray2[62] = new al(206, xab.a("createWorld.customize.custom.size", new Object[0]), false, a2, 1.0f, 50.0f, a2.v.b);
        jnArray2[63] = new al(207, xab.a("createWorld.customize.custom.count", new Object[0]), false, a2, 0.0f, 40.0f, a2.v.c);
        jnArray2[64] = new al(208, xab.a("createWorld.customize.custom.center", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.v);
        jnArray2[65] = new al(209, xab.a("createWorld.customize.custom.spread", new Object[0]), false, a2, 0.0f, 255.0f, a2.v.d);
        jn[] jnArray3 = jnArray2;
        jn[] jnArray4 = new jn[]{new al(100, xab.a("createWorld.customize.custom.mainNoiseScaleX", new Object[0]), false, a2, 1.0f, 5000.0f, a2.v.ub), new al(101, xab.a("createWorld.customize.custom.mainNoiseScaleY", new Object[0]), false, a2, 1.0f, 5000.0f, a2.v.pb), new al(102, xab.a("createWorld.customize.custom.mainNoiseScaleZ", new Object[0]), false, a2, 1.0f, 5000.0f, a2.v.lb), new al(103, xab.a("createWorld.customize.custom.depthNoiseScaleX", new Object[0]), false, a2, 1.0f, 2000.0f, a2.v.eb), new al(104, xab.a("createWorld.customize.custom.depthNoiseScaleZ", new Object[0]), false, a2, 1.0f, 2000.0f, a2.v.ob), new al(105, xab.a("createWorld.customize.custom.depthNoiseScaleExponent", new Object[0]), false, a2, 0.01f, 20.0f, a2.v.yb), new al(106, xab.a("createWorld.customize.custom.baseSize", new Object[0]), false, a2, 1.0f, 25.0f, a2.v.cb), new al(107, xab.a("createWorld.customize.custom.coordinateScale", new Object[0]), false, a2, 1.0f, 6000.0f, a2.v.ab), new al(108, xab.a("createWorld.customize.custom.heightScale", new Object[0]), false, a2, 1.0f, 6000.0f, a2.v.kb), new al(109, xab.a("createWorld.customize.custom.stretchY", new Object[0]), false, a2, 0.01f, 50.0f, a2.v.vb), new al(110, xab.a("createWorld.customize.custom.upperLimitScale", new Object[0]), false, a2, 1.0f, 5000.0f, a2.v.qb), new al(111, xab.a("createWorld.customize.custom.lowerLimitScale", new Object[0]), false, a2, 1.0f, 5000.0f, a2.v.xb), new al(112, xab.a("createWorld.customize.custom.biomeDepthWeight", new Object[0]), false, a2, 1.0f, 20.0f, a2.v.ib), new al(113, xab.a("createWorld.customize.custom.biomeDepthOffset", new Object[0]), false, a2, 0.0f, 20.0f, a2.v.sb), new al(114, xab.a("createWorld.customize.custom.biomeScaleWeight", new Object[0]), false, a2, 1.0f, 20.0f, a2.v.tb), new al(115, xab.a("createWorld.customize.custom.biomeScaleOffset", new Object[0]), false, a2, 0.0f, 20.0f, a2.v.bb)};
        jn[] jnArray5 = new jn[]{new dya(400, String.valueOf(xab.a("createWorld.customize.custom.mainNoiseScaleX", new Object[0])) + ":", false), new lfd(132, String.format("%5.3f", Float.valueOf(a2.v.ub)), false, a2.b), new dya(401, String.valueOf(xab.a("createWorld.customize.custom.mainNoiseScaleY", new Object[0])) + ":", false), new lfd(133, String.format("%5.3f", Float.valueOf(a2.v.pb)), false, a2.b), new dya(402, String.valueOf(xab.a("createWorld.customize.custom.mainNoiseScaleZ", new Object[0])) + ":", false), new lfd(134, String.format("%5.3f", Float.valueOf(a2.v.lb)), false, a2.b), new dya(403, String.valueOf(xab.a("createWorld.customize.custom.depthNoiseScaleX", new Object[0])) + ":", false), new lfd(135, String.format("%5.3f", Float.valueOf(a2.v.eb)), false, a2.b), new dya(404, String.valueOf(xab.a("createWorld.customize.custom.depthNoiseScaleZ", new Object[0])) + ":", false), new lfd(136, String.format("%5.3f", Float.valueOf(a2.v.ob)), false, a2.b), new dya(405, String.valueOf(xab.a("createWorld.customize.custom.depthNoiseScaleExponent", new Object[0])) + ":", false), new lfd(137, String.format("%2.3f", Float.valueOf(a2.v.yb)), false, a2.b), new dya(406, String.valueOf(xab.a("createWorld.customize.custom.baseSize", new Object[0])) + ":", false), new lfd(138, String.format("%2.3f", Float.valueOf(a2.v.cb)), false, a2.b), new dya(407, String.valueOf(xab.a("createWorld.customize.custom.coordinateScale", new Object[0])) + ":", false), new lfd(139, String.format("%5.3f", Float.valueOf(a2.v.ab)), false, a2.b), new dya(408, String.valueOf(xab.a("createWorld.customize.custom.heightScale", new Object[0])) + ":", false), new lfd(140, String.format("%5.3f", Float.valueOf(a2.v.kb)), false, a2.b), new dya(409, String.valueOf(xab.a("createWorld.customize.custom.stretchY", new Object[0])) + ":", false), new lfd(141, String.format("%2.3f", Float.valueOf(a2.v.vb)), false, a2.b), new dya(410, String.valueOf(xab.a("createWorld.customize.custom.upperLimitScale", new Object[0])) + ":", false), new lfd(142, String.format("%5.3f", Float.valueOf(a2.v.qb)), false, a2.b), new dya(411, String.valueOf(xab.a("createWorld.customize.custom.lowerLimitScale", new Object[0])) + ":", false), new lfd(143, String.format("%5.3f", Float.valueOf(a2.v.xb)), false, a2.b), new dya(412, String.valueOf(xab.a("createWorld.customize.custom.biomeDepthWeight", new Object[0])) + ":", false), new lfd(144, String.format("%2.3f", Float.valueOf(a2.v.ib)), false, a2.b), new dya(413, String.valueOf(xab.a("createWorld.customize.custom.biomeDepthOffset", new Object[0])) + ":", false), new lfd(145, String.format("%2.3f", Float.valueOf(a2.v.sb)), false, a2.b), new dya(414, String.valueOf(xab.a("createWorld.customize.custom.biomeScaleWeight", new Object[0])) + ":", false), new lfd(146, String.format("%2.3f", Float.valueOf(a2.v.tb)), false, a2.b), new dya(415, String.valueOf(xab.a("createWorld.customize.custom.biomeScaleOffset", new Object[0])) + ":", false), new lfd(147, String.format("%2.3f", Float.valueOf(a2.v.bb)), false, a2.b)};
        a2.x = new exb((oj)((Object)a2.w), (int)n, (int)e, 32, (int)(e - 32), 25, a2, jnArray, jnArray3, jnArray4, jnArray5);
        int n2 = 0;
        while (n2 < 4) {
            a2.k[n2] = xab.a("createWorld.customize.custom.page" + n2, new Object[0]);
            ++n2;
        }
        a2.a();
    }

    public String p() {
        cdc a2;
        return a2.v.toString().replace("\n", "");
    }

    public void a(String a2) {
        a.v = a2 != null && a2.length() != 0 ? lka.a(a2) : new lka();
    }

    @Override
    public void a(int a2, String a3) {
        cdc a4;
        float f2 = 0.0f;
        try {
            f2 = Float.parseFloat(a3);
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
        float f3 = 0.0f;
        switch (a2) {
            case 132: {
                f3 = a4.v.ub = smb.a(f2, 1.0f, 5000.0f);
                break;
            }
            case 133: {
                f3 = a4.v.pb = smb.a(f2, 1.0f, 5000.0f);
                break;
            }
            case 134: {
                f3 = a4.v.lb = smb.a(f2, 1.0f, 5000.0f);
                break;
            }
            case 135: {
                f3 = a4.v.eb = smb.a(f2, 1.0f, 2000.0f);
                break;
            }
            case 136: {
                f3 = a4.v.ob = smb.a(f2, 1.0f, 2000.0f);
                break;
            }
            case 137: {
                f3 = a4.v.yb = smb.a(f2, 0.01f, 20.0f);
                break;
            }
            case 138: {
                f3 = a4.v.cb = smb.a(f2, 1.0f, 25.0f);
                break;
            }
            case 139: {
                f3 = a4.v.ab = smb.a(f2, 1.0f, 6000.0f);
                break;
            }
            case 140: {
                f3 = a4.v.kb = smb.a(f2, 1.0f, 6000.0f);
                break;
            }
            case 141: {
                f3 = a4.v.vb = smb.a(f2, 0.01f, 50.0f);
                break;
            }
            case 142: {
                f3 = a4.v.qb = smb.a(f2, 1.0f, 5000.0f);
                break;
            }
            case 143: {
                f3 = a4.v.xb = smb.a(f2, 1.0f, 5000.0f);
                break;
            }
            case 144: {
                f3 = a4.v.ib = smb.a(f2, 1.0f, 20.0f);
                break;
            }
            case 145: {
                f3 = a4.v.sb = smb.a(f2, 0.0f, 20.0f);
                break;
            }
            case 146: {
                f3 = a4.v.tb = smb.a(f2, 1.0f, 20.0f);
                break;
            }
            case 147: {
                f3 = a4.v.bb = smb.a(f2, 0.0f, 20.0f);
            }
        }
        if (f3 != f2 && f2 != 0.0f) {
            ((rfd)a4.x.a(a2)).p(a4.a(a2, f3));
        }
        ((ara)a4.x.a(a2 - 132 + 100)).a(f3, false);
        if (!a4.v.equals(a4.c)) {
            a4.p(true);
        }
    }

    private /* synthetic */ void p(boolean a2) {
        a.f = a2;
        a.s.c = a2;
    }

    @Override
    public String a(int a2, String a3, float a4) {
        cdc a5;
        return String.valueOf(a3) + ": " + a5.a(a2, a4);
    }

    private /* synthetic */ String a(int a2, float a3) {
        switch (a2) {
            case 100: 
            case 101: 
            case 102: 
            case 103: 
            case 104: 
            case 107: 
            case 108: 
            case 110: 
            case 111: 
            case 132: 
            case 133: 
            case 134: 
            case 135: 
            case 136: 
            case 139: 
            case 140: 
            case 142: 
            case 143: {
                return String.format("%5.3f", Float.valueOf(a3));
            }
            case 105: 
            case 106: 
            case 109: 
            case 112: 
            case 113: 
            case 114: 
            case 115: 
            case 137: 
            case 138: 
            case 141: 
            case 144: 
            case 145: 
            case 146: 
            case 147: {
                return String.format("%2.3f", Float.valueOf(a3));
            }
            default: {
                return String.format("%d", (int)a3);
            }
            case 162: 
        }
        if (a3 < 0.0f) {
            return xab.a("gui.all", new Object[0]);
        }
        if ((int)a3 >= nk.mb.l) {
            nk nk2 = nk.a()[(int)a3 + 2];
            return nk2 != null ? nk2.m : "?";
        }
        nk nk3 = nk.a()[(int)a3];
        return nk3 != null ? nk3.m : "?";
    }

    @Override
    public void a(int a2, boolean a3) {
        cdc a4;
        switch (a2) {
            case 148: {
                a4.v.zb = a3;
                break;
            }
            case 149: {
                a4.v.db = a3;
                break;
            }
            case 150: {
                a4.v.gb = a3;
                break;
            }
            case 151: {
                a4.v.wb = a3;
                break;
            }
            case 152: {
                a4.v.nb = a3;
                break;
            }
            case 153: {
                a4.v.rb = a3;
                break;
            }
            case 154: {
                a4.v.hb = a3;
                break;
            }
            case 155: {
                a4.v.ra = a3;
                break;
            }
            case 156: {
                a4.v.za = a3;
                break;
            }
            case 161: {
                a4.v.wa = a3;
                break;
            }
            case 210: {
                a4.v.jb = a3;
            }
        }
        if (!a4.v.equals(a4.c)) {
            a4.p(true);
        }
    }

    @Override
    public void a(int a2, float a3) {
        cdc a4;
        xf xf2;
        switch (a2) {
            case 100: {
                a4.v.ub = a3;
                break;
            }
            case 101: {
                a4.v.pb = a3;
                break;
            }
            case 102: {
                a4.v.lb = a3;
                break;
            }
            case 103: {
                a4.v.eb = a3;
                break;
            }
            case 104: {
                a4.v.ob = a3;
                break;
            }
            case 105: {
                a4.v.yb = a3;
                break;
            }
            case 106: {
                a4.v.cb = a3;
                break;
            }
            case 107: {
                a4.v.ab = a3;
                break;
            }
            case 108: {
                a4.v.kb = a3;
                break;
            }
            case 109: {
                a4.v.vb = a3;
                break;
            }
            case 110: {
                a4.v.qb = a3;
                break;
            }
            case 111: {
                a4.v.xb = a3;
                break;
            }
            case 112: {
                a4.v.ib = a3;
                break;
            }
            case 113: {
                a4.v.sb = a3;
                break;
            }
            case 114: {
                a4.v.tb = a3;
                break;
            }
            case 115: {
                a4.v.bb = a3;
            }
            default: {
                break;
            }
            case 157: {
                a4.v.mb = (int)a3;
                break;
            }
            case 158: {
                a4.v.aa = (int)a3;
                break;
            }
            case 159: {
                a4.v.fa = (int)a3;
                break;
            }
            case 160: {
                a4.v.fb = (int)a3;
                break;
            }
            case 162: {
                a4.v.va = (int)a3;
                break;
            }
            case 163: {
                a4.v.sa = (int)a3;
                break;
            }
            case 164: {
                a4.v.ea = (int)a3;
                break;
            }
            case 165: {
                a4.v.qa = (int)a3;
                break;
            }
            case 166: {
                a4.v.xa = (int)a3;
                break;
            }
            case 167: {
                a4.v.ua = (int)a3;
                break;
            }
            case 168: {
                a4.v.da = (int)a3;
                break;
            }
            case 169: {
                a4.v.ma = (int)a3;
                break;
            }
            case 170: {
                a4.v.na = (int)a3;
                break;
            }
            case 171: {
                a4.v.ka = (int)a3;
                break;
            }
            case 172: {
                a4.v.ha = (int)a3;
                break;
            }
            case 173: {
                a4.v.ya = (int)a3;
                break;
            }
            case 174: {
                a4.v.ca = (int)a3;
                break;
            }
            case 175: {
                a4.v.ga = (int)a3;
                break;
            }
            case 176: {
                a4.v.ja = (int)a3;
                break;
            }
            case 177: {
                a4.v.ia = (int)a3;
                break;
            }
            case 178: {
                a4.v.ta = (int)a3;
                break;
            }
            case 179: {
                a4.v.oa = (int)a3;
                break;
            }
            case 180: {
                a4.v.pa = (int)a3;
                break;
            }
            case 181: {
                a4.v.ba = (int)a3;
                break;
            }
            case 182: {
                a4.v.la = (int)a3;
                break;
            }
            case 183: {
                a4.v.u = (int)a3;
                break;
            }
            case 184: {
                a4.v.j = (int)a3;
                break;
            }
            case 185: {
                a4.v.o = (int)a3;
                break;
            }
            case 186: {
                a4.v.m = (int)a3;
                break;
            }
            case 187: {
                a4.v.y = (int)a3;
                break;
            }
            case 189: {
                a4.v.a = (int)a3;
                break;
            }
            case 190: {
                a4.v.q = (int)a3;
                break;
            }
            case 191: {
                a4.v.g = (int)a3;
                break;
            }
            case 192: {
                a4.v.k = (int)a3;
                break;
            }
            case 193: {
                a4.v.x = (int)a3;
                break;
            }
            case 194: {
                a4.v.t = (int)a3;
                break;
            }
            case 195: {
                a4.v.p = (int)a3;
                break;
            }
            case 196: {
                a4.v.s = (int)a3;
                break;
            }
            case 197: {
                a4.v.w = (int)a3;
                break;
            }
            case 198: {
                a4.v.i = (int)a3;
                break;
            }
            case 199: {
                a4.v.n = (int)a3;
                break;
            }
            case 200: {
                a4.v.e = (int)a3;
                break;
            }
            case 201: {
                a4.v.r = (int)a3;
                break;
            }
            case 202: {
                a4.v.f = (int)a3;
                break;
            }
            case 203: {
                a4.v.h = (int)a3;
                break;
            }
            case 204: {
                a4.v.z = (int)a3;
                break;
            }
            case 205: {
                a4.v.l = (int)a3;
                break;
            }
            case 206: {
                a4.v.b = (int)a3;
                break;
            }
            case 207: {
                a4.v.c = (int)a3;
                break;
            }
            case 208: {
                a4.v.v = (int)a3;
                break;
            }
            case 209: {
                a4.v.d = (int)a3;
            }
        }
        if (a2 >= 100 && a2 < 116 && (xf2 = a4.x.a(a2 - 100 + 132)) != null) {
            ((rfd)xf2).p(a4.a(a2, a3));
        }
        if (!a4.v.equals(a4.c)) {
            a4.p(true);
        }
    }

    @Override
    protected void a(ff a2) throws IOException {
        if (a2.c) {
            switch (a2.b) {
                case 300: {
                    cdc a3;
                    a3.y.v = a3.v.toString();
                    ((oj)((Object)a3.w)).a(a3.y);
                    break;
                }
                case 301: {
                    cdc a3;
                    int n2 = 0;
                    while (n2 < a3.x.x()) {
                        xf xf2;
                        cmc cmc2 = a3.x.a(n2);
                        xf xf3 = cmc2.p();
                        if (xf3 instanceof ff) {
                            xf2 = (ff)xf3;
                            if (xf2 instanceof ara) {
                                float f2 = ((ara)xf2).a() * (0.75f + a3.d.nextFloat() * 0.5f) + (a3.d.nextFloat() * 0.1f - 0.05f);
                                ((ara)xf2).a(smb.a(f2, 0.0f, 1.0f));
                            } else if (xf2 instanceof aba) {
                                ((aba)xf2).a(a3.d.nextBoolean());
                            }
                        }
                        if ((xf2 = cmc2.a()) instanceof ff) {
                            xf xf4 = xf2;
                            if (xf4 instanceof ara) {
                                float f3 = ((ara)xf4).a() * (0.75f + a3.d.nextFloat() * 0.5f) + (a3.d.nextFloat() * 0.1f - 0.05f);
                                ((ara)xf4).a(smb.a(f3, 0.0f, 1.0f));
                            } else if (xf4 instanceof aba) {
                                ((aba)xf4).a(a3.d.nextBoolean());
                            }
                        }
                        ++n2;
                    }
                    return;
                }
                case 302: {
                    cdc a3;
                    a3.x.z();
                    a3.a();
                    break;
                }
                case 303: {
                    cdc a3;
                    a3.x.y();
                    a3.a();
                    break;
                }
                case 304: {
                    cdc a3;
                    if (!a3.f) break;
                    a3.a(304);
                    break;
                }
                case 305: {
                    cdc a3;
                    ((oj)((Object)a3.w)).a(new nwc(a3));
                    break;
                }
                case 306: {
                    cdc a3;
                    a3.p();
                    break;
                }
                case 307: {
                    cdc a3;
                    a3.z = 0;
                    a3.p();
                }
            }
        }
    }

    private /* synthetic */ void d() {
        cdc a2;
        a2.v.a();
        a2.q();
        a2.p(false);
    }

    private /* synthetic */ void a(int a2) {
        cdc a3;
        a3.z = a2;
        a3.a(true);
    }

    private /* synthetic */ void p() throws IOException {
        cdc a2;
        switch (a2.z) {
            case 300: {
                a2.a((aba)a2.x.a(300));
                break;
            }
            case 304: {
                a2.d();
            }
        }
        a2.z = 0;
        a2.l = true;
        a2.a(false);
    }

    private /* synthetic */ void a(boolean a2) {
        cdc a3;
        a3.n.v = a2;
        a3.e.v = a2;
        a3.p.c = !a2;
        a3.t.c = !a2;
        a3.w.c = !a2;
        a3.i.c = !a2;
        a3.s.c = a3.f && !a2;
        a3.r.c = !a2;
        a3.x.o(!a2);
    }

    private /* synthetic */ void a() {
        cdc a2;
        a2.w.c = a2.x.m() != 0;
        a2.i.c = a2.x.m() != a2.x.h() - 1;
        a2.q = xab.a("book.pageIndicator", a2.x.m() + 1, a2.x.h());
        a2.g = a2.k[a2.x.m()];
        a2.p.c = a2.x.m() != a2.x.h() - 1;
    }

    @Override
    protected void a(char a2, int a3) throws IOException {
        cdc a4;
        super.a(a2, a3);
        if (a4.z == 0) {
            switch (a3) {
                case 200: {
                    a4.a(1.0f);
                    break;
                }
                case 208: {
                    a4.a(-1.0f);
                    break;
                }
                default: {
                    a4.x.a(a2, a3);
                }
            }
        }
    }

    private /* synthetic */ void a(float a2) {
        cdc a3;
        xf xf2 = a3.x.a();
        if (xf2 instanceof rfd) {
            rfd rfd2;
            Float f2;
            float f3 = a2;
            if (en.p()) {
                f3 = a2 * 0.1f;
                if (en.o()) {
                    f3 *= 0.1f;
                }
            } else if (en.o()) {
                f3 = a2 * 10.0f;
                if (en.a()) {
                    f3 *= 10.0f;
                }
            }
            if ((f2 = Floats.tryParse((String)(rfd2 = (rfd)xf2).p())) != null) {
                f2 = Float.valueOf(f2.floatValue() + f3);
                int n2 = rfd2.z();
                String string = a3.a(rfd2.z(), f2.floatValue());
                rfd2.p(string);
                a3.a(n2, string);
            }
        }
    }

    @Override
    protected void p(int a2, int a3, int a4) throws IOException {
        cdc a5;
        super.p(a2, a3, a4);
        if (a5.z == 0 && !a5.l) {
            a5.x.p(a2, a3, a4);
        }
    }

    @Override
    protected void a(int a2, int a3, int a4) {
        cdc a5;
        super.a(a2, a3, a4);
        if (a5.l) {
            a5.l = false;
        } else if (a5.z == 0) {
            a5.x.a(a2, a3, a4);
        }
    }

    @Override
    public void a(int a2, int a3, float a4) {
        cdc a5;
        a5.o();
        a5.x.a(a2, a3, a4);
        a5.p((gic)a5.z, a5.a, (int)(n / 2), 2, 0xFFFFFF);
        a5.p((gic)a5.z, a5.q, (int)(n / 2), 12, 0xFFFFFF);
        a5.p((gic)a5.z, a5.g, (int)(n / 2), 22, 0xFFFFFF);
        super.a(a2, a3, a4);
        if (a5.z != 0) {
            cdc.a(0, 0, (int)n, (int)e, Integer.MIN_VALUE);
            a5.p((int)(n / 2 - 91), (int)(n / 2 + 90), 99, -2039584);
            a5.p((int)(n / 2 - 91), (int)(n / 2 + 90), 185, -6250336);
            a5.a((int)(n / 2 - 91), 99, 185, -2039584);
            a5.a((int)(n / 2 + 90), 99, 185, -6250336);
            float f2 = 85.0f;
            float f3 = 180.0f;
            ewa.ka();
            ewa.s();
            xlb xlb2 = xlb.a();
            krb krb2 = xlb2.a();
            ((oj)((Object)a5.w)).a().p((wmc)b);
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            float f4 = 32.0f;
            krb2.a(7, ybd.e);
            krb2.a((double)(n / 2 - 90), 185.0, 0.0).a(0.0, 2.65625).a(64, 64, 64, 64).z();
            krb2.a((double)(n / 2 + 90), 185.0, 0.0).a(5.625, 2.65625).a(64, 64, 64, 64).z();
            krb2.a((double)(n / 2 + 90), 100.0, 0.0).a(5.625, 0.0).a(64, 64, 64, 64).z();
            krb2.a((double)(n / 2 - 90), 100.0, 0.0).a(0.0, 0.0).a(64, 64, 64, 64).z();
            xlb2.a();
            a5.p((gic)a5.z, xab.a("createWorld.customize.custom.confirmTitle", new Object[0]), (int)(n / 2), 105, 0xFFFFFF);
            a5.p((gic)a5.z, xab.a("createWorld.customize.custom.confirm1", new Object[0]), (int)(n / 2), 125, 0xFFFFFF);
            a5.p((gic)a5.z, xab.a("createWorld.customize.custom.confirm2", new Object[0]), (int)(n / 2), 135, 0xFFFFFF);
            a5.n.p((oj)((Object)a5.w), a2, a3);
            a5.e.p((oj)((Object)a5.w), a2, a3);
        }
    }
}

