/*
 * Decompiled with CFR 0.152.
 */
public class bna
extends ne<tfa> {
    private static final wmc z = new wmc("textures/entity/villager/villager.png");
    private static final wmc l = new wmc("textures/entity/villager/farmer.png");
    private static final wmc b = new wmc("textures/entity/villager/librarian.png");
    private static final wmc c = new wmc("textures/entity/villager/priest.png");
    private static final wmc v = new wmc("textures/entity/villager/smith.png");
    private static final wmc d = new wmc("textures/entity/villager/butcher.png");

    public bna(gub a2) {
        super(a2, new we(0.0f), 0.5f);
        bna a3;
        a3.p(new fbd(a3.a().z));
    }

    @Override
    public we a() {
        bna a2;
        return (we)super.a();
    }

    @Override
    protected wmc a(tfa a2) {
        switch (a2.e()) {
            case 0: {
                return l;
            }
            case 1: {
                return b;
            }
            case 2: {
                return c;
            }
            case 3: {
                return v;
            }
            case 4: {
                return d;
            }
        }
        return z;
    }

    @Override
    protected void a(tfa a2, float a3) {
        float f2 = 0.9375f;
        if (a2.c() < 0) {
            f2 = (float)((double)f2 * 0.5);
            a.b = (wmc)0.25f;
        } else {
            a.b = (wmc)0.5f;
        }
        ewa.o(f2, f2, f2);
    }

    @Override
    public /* synthetic */ qm a() {
        bna a2;
        return a2.a();
    }
}

