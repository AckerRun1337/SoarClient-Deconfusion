/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bua
extends wma {
    public bua() {
        bua a2;
    }

    @Override
    public void a() {
        a.z = new ahb(nk.gb, 0.0f);
        a.v = 1;
        a.b = true;
    }

    @Override
    public c a() {
        bua a2;
        return new ukc(a2.r, a2.r.o());
    }

    @Override
    public float a(long a2, float a3) {
        return 0.0f;
    }

    @Override
    public float[] a(float a2, float a3) {
        return null;
    }

    @Override
    public tta a(float a2, float a3) {
        int n2 = 0xA080A0;
        float f2 = smb.y(a2 * (float)Math.PI * 2.0f) * 2.0f + 0.5f;
        f2 = smb.a(f2, 0.0f, 1.0f);
        float f3 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f4 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f5 = (float)(n2 & 0xFF) / 255.0f;
        return new tta(f3 *= f2 * 0.0f + 0.15f, f4 *= f2 * 0.0f + 0.15f, f5 *= f2 * 0.0f + 0.15f);
    }

    @Override
    public boolean o() {
        return false;
    }

    @Override
    public boolean y() {
        return false;
    }

    @Override
    public boolean z() {
        return false;
    }

    @Override
    public float a() {
        return 8.0f;
    }

    @Override
    public boolean p(int a2, int a3) {
        bua a4;
        return a4.r.a(new tp(a2, 0, a3)).a().z();
    }

    @Override
    public tp a() {
        return new tp(100, 50, 0);
    }

    @Override
    public int p() {
        return 50;
    }

    @Override
    public boolean a(int a2, int a3) {
        return true;
    }

    @Override
    public String p() {
        return "The End";
    }

    @Override
    public String a() {
        return "_end";
    }
}

