/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ae {
    protected uxc b;
    protected hnd c;
    protected int v;
    private static volatile /* synthetic */ int[] d;

    public ae() {
        ae a2;
    }

    protected ae(int a2) {
        ae a3;
        a3.v = a2;
    }

    public dgb a() {
        ae a2;
        dgb dgb2 = new dgb();
        dgb2.a("id", wcb.a(a2));
        dgb2.a("BB", a2.b.a());
        dgb2.a("O", a2.c == null ? -1 : a2.c.y());
        dgb2.a("GD", a2.v);
        a2.p(dgb2);
        return dgb2;
    }

    protected abstract void p(dgb var1);

    public void a(xga a2, dgb a3) {
        ae a4;
        int n2;
        if (a3.p("BB")) {
            a4.b = new uxc(a3.a("BB"));
        }
        a4.c = (n2 = a3.a("O")) == -1 ? null : hnd.a(n2);
        a4.v = a3.a("GD");
        a4.a(a3);
    }

    protected abstract void a(dgb var1);

    public void a(ae a2, List<ae> a3, Random a4) {
    }

    public abstract boolean a(xga var1, Random var2, uxc var3);

    public uxc a() {
        ae a2;
        return a2.b;
    }

    public int a() {
        ae a2;
        return a2.v;
    }

    public static ae a(List<ae> a2, uxc a3) {
        for (ae ae2 : a2) {
            if (ae2.a() == null || !ae2.a().a(a3)) continue;
            return ae2;
        }
        return null;
    }

    public tp a() {
        ae a2;
        return new tp(a2.b.a());
    }

    protected boolean a(xga a2, uxc a3) {
        int n2;
        ae a4;
        int n3 = Math.max(a4.b.h - 1, a3.h);
        int n4 = Math.max(a4.b.z - 1, a3.z);
        int n5 = Math.max(a4.b.l - 1, a3.l);
        int n6 = Math.min(a4.b.b + 1, a3.b);
        int n7 = Math.min(a4.b.c + 1, a3.c);
        int n8 = Math.min(a4.b.v + 1, a3.v);
        qt qt2 = new qt();
        int n9 = n3;
        while (n9 <= n6) {
            n2 = n5;
            while (n2 <= n8) {
                if (a2.a(qt2.a(n9, n4, n2)).a().a().h()) {
                    return true;
                }
                if (a2.a(qt2.a(n9, n7, n2)).a().a().h()) {
                    return true;
                }
                ++n2;
            }
            ++n9;
        }
        n9 = n3;
        while (n9 <= n6) {
            n2 = n4;
            while (n2 <= n7) {
                if (a2.a(qt2.a(n9, n2, n5)).a().a().h()) {
                    return true;
                }
                if (a2.a(qt2.a(n9, n2, n8)).a().a().h()) {
                    return true;
                }
                ++n2;
            }
            ++n9;
        }
        n9 = n5;
        while (n9 <= n8) {
            n2 = n4;
            while (n2 <= n7) {
                if (a2.a(qt2.a(n3, n2, n9)).a().a().h()) {
                    return true;
                }
                if (a2.a(qt2.a(n6, n2, n9)).a().a().h()) {
                    return true;
                }
                ++n2;
            }
            ++n9;
        }
        return false;
    }

    protected int p(int a2, int a3) {
        ae a4;
        if (a4.c == null) {
            return a2;
        }
        switch (ae.a()[a4.c.ordinal()]) {
            case 3: 
            case 4: {
                return a4.b.h + a2;
            }
            case 5: {
                return a4.b.b - a3;
            }
            case 6: {
                return a4.b.h + a3;
            }
        }
        return a2;
    }

    protected int a(int a2) {
        ae a3;
        return a3.c == null ? a2 : a2 + a3.b.z;
    }

    protected int a(int a2, int a3) {
        ae a4;
        if (a4.c == null) {
            return a3;
        }
        switch (ae.a()[a4.c.ordinal()]) {
            case 3: {
                return a4.b.v - a3;
            }
            case 4: {
                return a4.b.l + a3;
            }
            case 5: 
            case 6: {
                return a4.b.l + a2;
            }
        }
        return a3;
    }

    protected int a(yd a2, int a3) {
        ae a4;
        if (a2 == cl.ak) {
            if (a4.c == hnd.p || a4.c == hnd.s) {
                if (a3 == 1) {
                    return 0;
                }
                return 1;
            }
        } else if (a2 instanceof ccc) {
            if (a4.c == hnd.t) {
                if (a3 == 0) {
                    return 2;
                }
                if (a3 == 2) {
                    return 0;
                }
            } else {
                if (a4.c == hnd.p) {
                    return a3 + 1 & 3;
                }
                if (a4.c == hnd.s) {
                    return a3 + 3 & 3;
                }
            }
        } else if (a2 != cl.ig && a2 != cl.ri && a2 != cl.cb && a2 != cl.ob && a2 != cl.jb) {
            if (a2 == cl.sh) {
                if (a4.c == hnd.t) {
                    if (a3 == hnd.x.z()) {
                        return hnd.t.z();
                    }
                    if (a3 == hnd.t.z()) {
                        return hnd.x.z();
                    }
                } else if (a4.c == hnd.p) {
                    if (a3 == hnd.x.z()) {
                        return hnd.p.z();
                    }
                    if (a3 == hnd.t.z()) {
                        return hnd.s.z();
                    }
                    if (a3 == hnd.p.z()) {
                        return hnd.x.z();
                    }
                    if (a3 == hnd.s.z()) {
                        return hnd.t.z();
                    }
                } else if (a4.c == hnd.s) {
                    if (a3 == hnd.x.z()) {
                        return hnd.s.z();
                    }
                    if (a3 == hnd.t.z()) {
                        return hnd.p.z();
                    }
                    if (a3 == hnd.p.z()) {
                        return hnd.x.z();
                    }
                    if (a3 == hnd.s.z()) {
                        return hnd.t.z();
                    }
                }
            } else if (a2 == cl.ne) {
                if (a4.c == hnd.t) {
                    if (a3 == 3) {
                        return 4;
                    }
                    if (a3 == 4) {
                        return 3;
                    }
                } else if (a4.c == hnd.p) {
                    if (a3 == 3) {
                        return 1;
                    }
                    if (a3 == 4) {
                        return 2;
                    }
                    if (a3 == 2) {
                        return 3;
                    }
                    if (a3 == 1) {
                        return 4;
                    }
                } else if (a4.c == hnd.s) {
                    if (a3 == 3) {
                        return 2;
                    }
                    if (a3 == 4) {
                        return 1;
                    }
                    if (a3 == 2) {
                        return 3;
                    }
                    if (a3 == 1) {
                        return 4;
                    }
                }
            } else if (a2 != cl.aa && !(a2 instanceof an)) {
                if (a2 == cl.yk || a2 == cl.ci || a2 == cl.fe || a2 == cl.nm) {
                    if (a4.c == hnd.t) {
                        if (a3 == hnd.x.z() || a3 == hnd.t.z()) {
                            return hnd.p(a3).z().z();
                        }
                    } else if (a4.c == hnd.p) {
                        if (a3 == hnd.x.z()) {
                            return hnd.p.z();
                        }
                        if (a3 == hnd.t.z()) {
                            return hnd.s.z();
                        }
                        if (a3 == hnd.p.z()) {
                            return hnd.x.z();
                        }
                        if (a3 == hnd.s.z()) {
                            return hnd.t.z();
                        }
                    } else if (a4.c == hnd.s) {
                        if (a3 == hnd.x.z()) {
                            return hnd.s.z();
                        }
                        if (a3 == hnd.t.z()) {
                            return hnd.p.z();
                        }
                        if (a3 == hnd.p.z()) {
                            return hnd.x.z();
                        }
                        if (a3 == hnd.s.z()) {
                            return hnd.t.z();
                        }
                    }
                }
            } else {
                hnd hnd2 = hnd.a(a3);
                if (a4.c == hnd.t) {
                    if (hnd2 == hnd.t || hnd2 == hnd.x) {
                        return hnd2.z().y();
                    }
                } else if (a4.c == hnd.p) {
                    if (hnd2 == hnd.x) {
                        return hnd.p.y();
                    }
                    if (hnd2 == hnd.t) {
                        return hnd.s.y();
                    }
                    if (hnd2 == hnd.p) {
                        return hnd.x.y();
                    }
                    if (hnd2 == hnd.s) {
                        return hnd.t.y();
                    }
                } else if (a4.c == hnd.s) {
                    if (hnd2 == hnd.x) {
                        return hnd.s.y();
                    }
                    if (hnd2 == hnd.t) {
                        return hnd.p.y();
                    }
                    if (hnd2 == hnd.p) {
                        return hnd.x.y();
                    }
                    if (hnd2 == hnd.s) {
                        return hnd.t.y();
                    }
                }
            }
        } else if (a4.c == hnd.t) {
            if (a3 == 2) {
                return 3;
            }
            if (a3 == 3) {
                return 2;
            }
        } else if (a4.c == hnd.p) {
            if (a3 == 0) {
                return 2;
            }
            if (a3 == 1) {
                return 3;
            }
            if (a3 == 2) {
                return 0;
            }
            if (a3 == 3) {
                return 1;
            }
        } else if (a4.c == hnd.s) {
            if (a3 == 0) {
                return 2;
            }
            if (a3 == 1) {
                return 3;
            }
            if (a3 == 2) {
                return 1;
            }
            if (a3 == 3) {
                return 0;
            }
        }
        return a3;
    }

    protected void p(xga a2, ba a3, int a4, int a5, int a6, uxc a7) {
        ae a8;
        tp tp2 = new tp(a8.p(a4, a6), a8.a(a5), a8.a(a4, a6));
        if (a7.a(tp2)) {
            a2.a(tp2, a3, 2);
        }
    }

    protected ba a(xga a2, int a3, int a4, int a5, uxc a6) {
        int n2;
        int n3;
        ae a7;
        int n4 = a7.p(a3, a5);
        tp tp2 = new tp(n4, n3 = a7.a(a4), n2 = a7.a(a3, a5));
        return !a6.a(tp2) ? cl.cd.a() : a2.a(tp2);
    }

    protected void a(xga a2, uxc a3, int a4, int a5, int a6, int a7, int a8, int a9) {
        int n2 = a5;
        while (n2 <= a8) {
            int n3 = a4;
            while (n3 <= a7) {
                int n4 = a6;
                while (n4 <= a9) {
                    ae a10;
                    a10.p(a2, cl.cd.a(), n3, n2, n4, a3);
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
    }

    protected void a(xga a2, uxc a3, int a4, int a5, int a6, int a7, int a8, int a9, ba a10, ba a11, boolean a12) {
        int n2 = a5;
        while (n2 <= a8) {
            int n3 = a4;
            while (n3 <= a7) {
                int n4 = a6;
                while (n4 <= a9) {
                    ae a13;
                    if (!a12 || a13.a(a2, n3, n2, n4, a3).a().a() != dr.ua) {
                        if (n2 != a5 && n2 != a8 && n3 != a4 && n3 != a7 && n4 != a6 && n4 != a9) {
                            a13.p(a2, a11, n3, n2, n4, a3);
                        } else {
                            a13.p(a2, a10, n3, n2, n4, a3);
                        }
                    }
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
    }

    protected void a(xga a2, uxc a3, int a4, int a5, int a6, int a7, int a8, int a9, boolean a10, Random a11, plb a12) {
        int n2 = a5;
        while (n2 <= a8) {
            int n3 = a4;
            while (n3 <= a7) {
                int n4 = a6;
                while (n4 <= a9) {
                    ae a13;
                    if (!a10 || a13.a(a2, n3, n2, n4, a3).a().a() != dr.ua) {
                        a12.a(a11, n3, n2, n4, n2 == a5 || n2 == a8 || n3 == a4 || n3 == a7 || n4 == a6 || n4 == a9);
                        a13.p(a2, a12.a(), n3, n2, n4, a3);
                    }
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
    }

    protected void a(xga a2, uxc a3, Random a4, float a5, int a6, int a7, int a8, int a9, int a10, int a11, ba a12, ba a13, boolean a14) {
        int n2 = a7;
        while (n2 <= a10) {
            int n3 = a6;
            while (n3 <= a9) {
                int n4 = a8;
                while (n4 <= a11) {
                    ae a15;
                    if (a4.nextFloat() <= a5 && (!a14 || a15.a(a2, n3, n2, n4, a3).a().a() != dr.ua)) {
                        if (n2 != a7 && n2 != a10 && n3 != a6 && n3 != a9 && n4 != a8 && n4 != a11) {
                            a15.p(a2, a13, n3, n2, n4, a3);
                        } else {
                            a15.p(a2, a12, n3, n2, n4, a3);
                        }
                    }
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
    }

    protected void a(xga a2, uxc a3, Random a4, float a5, int a6, int a7, int a8, ba a9) {
        if (a4.nextFloat() < a5) {
            ae a10;
            a10.p(a2, a9, a6, a7, a8, a3);
        }
    }

    protected void a(xga a2, uxc a3, int a4, int a5, int a6, int a7, int a8, int a9, ba a10, boolean a11) {
        float f2 = a7 - a4 + 1;
        float f3 = a8 - a5 + 1;
        float f4 = a9 - a6 + 1;
        float f5 = (float)a4 + f2 / 2.0f;
        float f6 = (float)a6 + f4 / 2.0f;
        int n2 = a5;
        while (n2 <= a8) {
            float f7 = (float)(n2 - a5) / f3;
            int n3 = a4;
            while (n3 <= a7) {
                float f8 = ((float)n3 - f5) / (f2 * 0.5f);
                int n4 = a6;
                while (n4 <= a9) {
                    float f9;
                    ae a12;
                    float f10 = ((float)n4 - f6) / (f4 * 0.5f);
                    if ((!a11 || a12.a(a2, n3, n2, n4, a3).a().a() != dr.ua) && (f9 = f8 * f8 + f7 * f7 + f10 * f10) <= 1.05f) {
                        a12.p(a2, a10, n3, n2, n4, a3);
                    }
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
    }

    protected void a(xga a2, int a3, int a4, int a5, uxc a6) {
        ae a7;
        tp tp2 = new tp(a7.p(a3, a5), a7.a(a4), a7.a(a3, a5));
        if (a6.a(tp2)) {
            while (!a2.a(tp2) && tp2.p() < 255) {
                a2.a(tp2, cl.cd.a(), 2);
                tp2 = tp2.j();
            }
        }
    }

    protected void a(xga a2, ba a3, int a4, int a5, int a6, uxc a7) {
        int n2;
        int n3;
        ae a8;
        int n4 = a8.p(a4, a6);
        if (a7.a(new tp(n4, n3 = a8.a(a5), n2 = a8.a(a4, a6)))) {
            while ((a2.a(new tp(n4, n3, n2)) || a2.a(new tp(n4, n3, n2)).a().a().h()) && n3 > 1) {
                a2.a(new tp(n4, n3, n2), a3, 2);
                --n3;
            }
        }
    }

    protected boolean a(xga a2, uxc a3, Random a4, int a5, int a6, int a7, List<ond> a8, int a9) {
        ae a10;
        tp tp2 = new tp(a10.p(a5, a7), a10.a(a6), a10.a(a5, a7));
        if (a3.a(tp2) && a2.a(tp2).a() != cl.xh) {
            ba ba2 = cl.xh.a();
            a2.a(tp2, cl.xh.a(a2, tp2, ba2), 2);
            kv kv2 = a2.a(tp2);
            if (kv2 instanceof fja) {
                ond.a(a4, a8, (fja)kv2, a9);
            }
            return true;
        }
        return false;
    }

    protected boolean a(xga a2, uxc a3, Random a4, int a5, int a6, int a7, int a8, List<ond> a9, int a10) {
        ae a11;
        tp tp2 = new tp(a11.p(a5, a7), a11.a(a6), a11.a(a5, a7));
        if (a3.a(tp2) && a2.a(tp2).a() != cl.nm) {
            a2.a(tp2, cl.nm.a(a11.a(cl.nm, a8)), 2);
            kv kv2 = a2.a(tp2);
            if (kv2 instanceof hxb) {
                ond.a(a4, a9, (hxb)kv2, a10);
            }
            return true;
        }
        return false;
    }

    protected void a(xga a2, uxc a3, Random a4, int a5, int a6, int a7, hnd a8) {
        ae a9;
        tp tp2 = new tp(a9.p(a5, a7), a9.a(a6), a9.a(a5, a7));
        if (a3.a(tp2)) {
            qzb.a(a2, tp2, a8.a(), cl.tm);
        }
    }

    public void a(int a2, int a3, int a4) {
        ae a5;
        a5.b.a(a2, a3, a4);
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[hnd.values().length];
        try {
            nArray[hnd.g.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.s.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.x.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.t.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.k.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[hnd.p.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

