/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class deb
implements Callable<String> {
    final /* synthetic */ nxa d;

    deb(nxa a2) {
        deb a3;
        a3.d = a2;
    }

    public String a() throws Exception {
        return "Integrated Server (map_client.txt)";
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        deb a2;
        return a2.a();
    }
}

