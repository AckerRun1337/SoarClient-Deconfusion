/*
 * Decompiled with CFR 0.152.
 */
public class aqa
extends dk {
    public aqa() {
        a2(0.0f, 0.0f, false);
        aqa a2;
    }

    public aqa(float a2, float a3, boolean a4) {
        super(a2, 0.0f, 64, a4 ? 32 : 64);
        aqa a5;
        if (a4) {
            a5.n = new sfc(a5, 0, 0);
            a5.n.p(-4.0f, -10.0f, -4.0f, 8, 8, 8, a2);
            a5.n.a(0.0f, 0.0f + a3, 0.0f);
        } else {
            a5.n = new sfc(a5);
            a5.n.a(0.0f, 0.0f + a3, 0.0f);
            a5.n.p(0, 32).p(-4.0f, -10.0f, -4.0f, 8, 10, 8, a2);
            a5.n.p(24, 32).p(-1.0f, -3.0f, -6.0f, 2, 4, 2, a2);
        }
    }

    @Override
    public void a(float a2, float a3, float a4, float a5, float a6, float a7, rj a8) {
        aqa a9;
        super.a(a2, a3, a4, a5, a6, a7, a8);
        float f2 = smb.z(a9.h * (float)Math.PI);
        float f3 = smb.z((1.0f - (1.0f - a9.h) * (1.0f - a9.h)) * (float)Math.PI);
        a9.f.m = 0.0f;
        a9.h.m = 0.0f;
        a9.f.o = -(0.1f - f2 * 0.6f);
        a9.h.o = 0.1f - f2 * 0.6f;
        a9.f.j = -1.5707964f;
        a9.h.j = -1.5707964f;
        a9.f.j -= f2 * 1.2f - f3 * 0.4f;
        a9.h.j -= f2 * 1.2f - f3 * 0.4f;
        a9.f.m += smb.y(a4 * 0.09f) * 0.05f + 0.05f;
        a9.h.m -= smb.y(a4 * 0.09f) * 0.05f + 0.05f;
        a9.f.j += smb.z(a4 * 0.067f) * 0.05f;
        a9.h.j -= smb.z(a4 * 0.067f) * 0.05f;
    }
}

