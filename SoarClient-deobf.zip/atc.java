/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class atc
extends tf {
    private int r = 160;
    private boolean h;
    private boolean z;
    private final pi l;
    private float b;
    private float c;
    private float v;
    private boolean d;

    public atc(xga a2, double a3, double a4, double a5, double a6, double a7, double a8, pi a9) {
        super(a2, a3, a4, a5);
        atc a10;
        a10.mb = a6;
        a10.gb = a7;
        a10.wb = a8;
        a10.l = a9;
        a10.e *= 0.75f;
        a10.n = 48 + a10.oa.nextInt(12);
        a10.ia = false;
    }

    public void m(boolean a2) {
        a.h = a2;
    }

    public void h(boolean a2) {
        a.z = a2;
    }

    public void m(int a2) {
        atc a3;
        float f2 = (float)((a2 & 0xFF0000) >> 16) / 255.0f;
        float f3 = (float)((a2 & 0xFF00) >> 8) / 255.0f;
        float f4 = (float)((a2 & 0xFF) >> 0) / 255.0f;
        float f5 = 1.0f;
        a3.p(f2 * f5, f3 * f5, f4 * f5);
    }

    public void h(int a2) {
        a.b = (float)((a2 & 0xFF0000) >> 16) / 255.0f;
        a.c = (float)((a2 & 0xFF00) >> 8) / 255.0f;
        a.v = (float)((a2 & 0xFF) >> 0) / 255.0f;
        a.d = true;
    }

    @Override
    public tca p() {
        return null;
    }

    @Override
    public boolean v() {
        return false;
    }

    @Override
    public void a(krb a2, rj a3, float a4, float a5, float a6, float a7, float a8, float a9) {
        atc a10;
        if (!a10.z || a10.i < a10.n / 3 || (a10.i + a10.n) / 3 % 2 == 0) {
            super.a(a2, a3, a4, a5, a6, a7, a8, a9);
        }
    }

    @Override
    public void n() {
        atc a2;
        a2.sb = a2.fb;
        a2.tb = a2.zb;
        a2.bb = a2.db;
        if (a2.i++ >= a2.n) {
            a2.g();
        }
        if (a2.i > a2.n / 2) {
            a2.o(1.0f - ((float)a2.i - (float)(a2.n / 2)) / (float)a2.n);
            if (a2.d) {
                a2.f += (a2.b - a2.f) * 0.2f;
                a2.h += (a2.c - a2.h) * 0.2f;
                a2.z += (a2.v - a2.z) * 0.2f;
            }
        }
        a2.x(a2.r + (7 - a2.i * 8 / a2.n));
        a2.gb -= 0.004;
        a2.y(a2.mb, a2.gb, a2.wb);
        a2.mb *= (double)0.91f;
        a2.gb *= (double)0.91f;
        a2.wb *= (double)0.91f;
        if (a2.aa) {
            a2.mb *= (double)0.7f;
            a2.wb *= (double)0.7f;
        }
        if (a2.h && a2.i < a2.n / 2 && (a2.i + a2.n) % 2 == 0) {
            atc atc2 = new atc(a2.ib, a2.fb, a2.zb, a2.db, 0.0, 0.0, 0.0, a2.l);
            atc2.o(0.99f);
            atc2.p(a2.f, (float)a2.h, (float)a2.z);
            atc2.i = atc2.n / 2;
            if (a2.d) {
                atc2.d = true;
                atc2.b = a2.b;
                atc2.c = a2.c;
                atc2.v = a2.v;
            }
            atc2.z = a2.z;
            a2.l.y(atc2);
        }
    }

    @Override
    public int a(float a2) {
        return 0xF000F0;
    }

    @Override
    public float a(float a2) {
        return 1.0f;
    }
}

