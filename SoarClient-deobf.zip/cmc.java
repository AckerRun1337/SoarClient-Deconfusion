/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cmc
implements fb {
    private final oj b = oj.a();
    private final xf c;
    private final xf v;
    private xf d;

    public cmc(xf a2, xf a3) {
        cmc a4;
        a4.c = a2;
        a4.v = a3;
    }

    public xf p() {
        cmc a2;
        return a2.c;
    }

    public xf a() {
        cmc a2;
        return a2.v;
    }

    @Override
    public void a(int a2, int a3, int a4, int a5, int a6, int a7, int a8, boolean a9) {
        cmc a10;
        a10.a(a10.c, a4, a7, a8, false);
        a10.a(a10.v, a4, a7, a8, false);
    }

    private /* synthetic */ void a(xf a2, int a3, int a4, int a5, boolean a6) {
        if (a2 != null) {
            cmc a7;
            if (a2 instanceof ff) {
                a7.a((ff)a2, a3, a4, a5, a6);
            } else if (a2 instanceof rfd) {
                a7.a((rfd)a2, a3, a6);
            } else if (a2 instanceof ega) {
                a7.a((ega)a2, a3, a4, a5, a6);
            }
        }
    }

    private /* synthetic */ void a(ff a2, int a3, int a4, int a5, boolean a6) {
        a2.z = a3;
        if (!a6) {
            cmc a7;
            a2.p(a7.b, a4, a5);
        }
    }

    private /* synthetic */ void a(rfd a2, int a3, boolean a4) {
        a2.k = a3;
        if (!a4) {
            a2.a();
        }
    }

    private /* synthetic */ void a(ega a2, int a3, int a4, int a5, boolean a6) {
        a2.i = a3;
        if (!a6) {
            cmc a7;
            a2.p(a7.b, a4, a5);
        }
    }

    @Override
    public void a(int a2, int a3, int a4) {
        cmc a5;
        a5.a(a5.c, a4, 0, 0, true);
        a5.a(a5.v, a4, 0, 0, true);
    }

    @Override
    public boolean a(int a2, int a3, int a4, int a5, int a6, int a7) {
        cmc a8;
        boolean bl2 = a8.a(a8.c, a3, a4, a5);
        boolean bl3 = a8.a(a8.v, a3, a4, a5);
        return bl2 || bl3;
    }

    private /* synthetic */ boolean a(xf a2, int a3, int a4, int a5) {
        cmc a6;
        if (a2 == null) {
            return false;
        }
        if (a2 instanceof ff) {
            return a6.a((ff)a2, a3, a4, a5);
        }
        if (a2 instanceof rfd) {
            a6.a((rfd)a2, a3, a4, a5);
        }
        return false;
    }

    private /* synthetic */ boolean a(ff a2, int a3, int a4, int a5) {
        cmc a6;
        boolean bl2 = a2.a(a6.b, a3, a4);
        if (bl2) {
            a6.d = a2;
        }
        return bl2;
    }

    private /* synthetic */ void a(rfd a2, int a3, int a4, int a5) {
        a2.a(a3, a4, a5);
        if (a2.p()) {
            a.d = a2;
        }
    }

    @Override
    public void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        cmc a8;
        a8.a(a8.c, a3, a4, a5);
        a8.a(a8.v, a3, a4, a5);
    }

    private /* synthetic */ void a(xf a2, int a3, int a4, int a5) {
        if (a2 != null && a2 instanceof ff) {
            cmc a6;
            a6.a((ff)a2, a3, a4, a5);
        }
    }

    private /* synthetic */ void a(ff a2, int a3, int a4, int a5) {
        a2.p(a3, a4);
    }

    static /* synthetic */ xf o(cmc a2) {
        return a2.c;
    }

    static /* synthetic */ xf p(cmc a2) {
        return a2.v;
    }

    static /* synthetic */ xf a(cmc a2) {
        return a2.d;
    }
}

