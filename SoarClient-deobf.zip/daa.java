/*
 * Decompiled with CFR 0.152.
 */
class daa
extends zca {
    private gm d;

    public daa(gm a2, double a3) {
        super(a2, a3);
        daa a4;
        a4.d = a2;
    }

    @Override
    public void a() {
        daa a2;
        super.a();
        a2.d.a(a2.b);
    }
}

