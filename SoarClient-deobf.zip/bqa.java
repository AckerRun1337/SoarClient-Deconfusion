/*
 * Decompiled with CFR 0.152.
 */
public class bqa
extends dl {
    public bqa() {
        bqa a2;
    }
}

