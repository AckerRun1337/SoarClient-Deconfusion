/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class aca {
    static final Gson v = new GsonBuilder().a((Type)((Object)aca.class), (Object)new yic()).a((Type)((Object)lmc.class), (Object)new gkd()).a();
    private final Map<String, wjb> d = Maps.newHashMap();

    public static aca a(Reader a2) {
        return v.a(a2, aca.class);
    }

    public aca(Collection<wjb> a2) {
        aca a3;
        for (wjb wjb2 : a2) {
            a3.d.put(wjb.a(wjb2), wjb2);
        }
    }

    public aca(List<aca> a2) {
        aca a3;
        for (aca aca2 : a2) {
            a3.d.putAll(aca2.d);
        }
    }

    public wjb a(String a2) {
        aca a3;
        wjb wjb2 = a3.d.get(a2);
        if (wjb2 == null) {
            throw new wad(a3);
        }
        return wjb2;
    }

    public boolean equals(Object a2) {
        aca a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 instanceof aca) {
            aca aca2 = (aca)a2;
            return a3.d.equals(aca2.d);
        }
        return false;
    }

    public int hashCode() {
        aca a2;
        return a2.d.hashCode();
    }
}

