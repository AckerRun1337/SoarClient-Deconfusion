/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.List;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bcd
implements Comparable<bcd> {
    private static final List<bcd> r = Lists.newArrayList();
    private static final ct<bcd> f = new ct();
    private static final Set<String> h = Sets.newHashSet();
    private final String z;
    private final int l;
    private final String b;
    private int c;
    private boolean v;
    private int d;

    public static void p(int a2) {
        bcd bcd2;
        if (a2 != 0 && (bcd2 = f.p(a2)) != null) {
            ++bcd2.d;
        }
    }

    public static void a(int a2, boolean a3) {
        bcd bcd2;
        if (a2 != 0 && (bcd2 = f.p(a2)) != null) {
            bcd2.v = a3;
        }
    }

    public static void o() {
        for (bcd bcd2 : r) {
            bcd2.a();
        }
    }

    public static void p() {
        f.a();
        for (bcd bcd2 : r) {
            f.a(bcd2.c, bcd2);
        }
    }

    public static Set<String> a() {
        return h;
    }

    public bcd(String a2, int a3, String a4) {
        bcd a5;
        a5.z = a2;
        a5.c = a3;
        a5.l = a3;
        a5.b = a4;
        r.add(a5);
        f.a(a3, a5);
        h.add(a4);
    }

    public boolean p() {
        bcd a2;
        return a2.v;
    }

    public String p() {
        bcd a2;
        return a2.b;
    }

    public boolean a() {
        bcd a2;
        if (a2.d == 0) {
            return false;
        }
        --a2.d;
        return true;
    }

    private /* synthetic */ void a() {
        a.d = 0;
        a.v = false;
    }

    public String a() {
        bcd a2;
        return a2.z;
    }

    public int p() {
        bcd a2;
        return a2.l;
    }

    public int a() {
        bcd a2;
        return a2.c;
    }

    public void a(int a2) {
        a.c = a2;
    }

    public int a(bcd a2) {
        bcd a3;
        int n2 = xab.a(a3.b, new Object[0]).compareTo(xab.a(a2.b, new Object[0]));
        if (n2 == 0) {
            n2 = xab.a(a3.z, new Object[0]).compareTo(xab.a(a2.z, new Object[0]));
        }
        return n2;
    }

    public static List<bcd> a() {
        return r;
    }

    @Override
    public /* synthetic */ int compareTo(Object a2) {
        bcd a3;
        return a3.a((bcd)a2);
    }
}

