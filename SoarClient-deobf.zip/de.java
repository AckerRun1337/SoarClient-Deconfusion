/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

public class de
extends ji {
    public de() {
        de a2;
    }

    public de(int a2, Random a3, uxc a4, hnd a5) {
        super(a2);
        de a6;
        a6.c = a5;
        a6.b = a4;
    }

    @Override
    public void a(ae a2, List<ae> a3, Random a4) {
        de a5;
        a5.o((mdc)a2, a3, a4, 2, 0, false);
        a5.p((mdc)a2, a3, a4, 0, 2, false);
        a5.a((mdc)a2, a3, a4, 0, 2, false);
    }

    public static de a(List<ae> a2, Random a3, int a4, int a5, int a6, hnd a7, int a8) {
        uxc uxc2 = uxc.a(a4, a5, a6, -2, 0, 0, 7, 9, 7, a7);
        return de.a(uxc2) && ae.a(a2, uxc2) == null ? new de(a8, a3, uxc2, a7) : null;
    }

    @Override
    public boolean a(xga a2, Random a3, uxc a4) {
        de a5;
        a5.a(a2, a4, 0, 0, 0, 6, 1, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 0, 2, 0, 6, 7, 6, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 0, 2, 0, 1, 6, 0, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 0, 2, 6, 1, 6, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 5, 2, 0, 6, 6, 0, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 5, 2, 6, 6, 6, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 0, 2, 0, 0, 6, 1, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 0, 2, 5, 0, 6, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 6, 2, 0, 6, 6, 1, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 6, 2, 5, 6, 6, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 2, 6, 0, 4, 6, 0, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 2, 5, 0, 4, 5, 0, cl.lb.a(), cl.lb.a(), false);
        a5.a(a2, a4, 2, 6, 6, 4, 6, 6, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 2, 5, 6, 4, 5, 6, cl.lb.a(), cl.lb.a(), false);
        a5.a(a2, a4, 0, 6, 2, 0, 6, 4, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 0, 5, 2, 0, 5, 4, cl.lb.a(), cl.lb.a(), false);
        a5.a(a2, a4, 6, 6, 2, 6, 6, 4, cl.pb.a(), cl.pb.a(), false);
        a5.a(a2, a4, 6, 5, 2, 6, 5, 4, cl.lb.a(), cl.lb.a(), false);
        int n2 = 0;
        while (n2 <= 6) {
            int n3 = 0;
            while (n3 <= 6) {
                a5.a(a2, cl.pb.a(), n2, -1, n3, a4);
                ++n3;
            }
            ++n2;
        }
        return true;
    }
}

