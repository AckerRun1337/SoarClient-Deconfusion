/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dec
extends mi {
    private fda c;
    private tfa v;
    private int d;

    public dec(fda a2) {
        dec a3;
        a3.c = a2;
        a3.a(3);
    }

    @Override
    public boolean o() {
        dec a2;
        if (!a2.c.ib.j()) {
            return false;
        }
        if (a2.c.a().nextInt(8000) != 0) {
            return false;
        }
        a2.v = (tfa)((Object)a2.c.ib.a(tfa.class, a2.c.a().o(6.0, 2.0, 6.0), a2.c));
        return a2.v != null;
    }

    @Override
    public boolean p() {
        dec a2;
        return a2.d > 0;
    }

    @Override
    public void o() {
        dec a2;
        a2.d = 400;
        a2.c.r(true);
    }

    @Override
    public void p() {
        dec a2;
        a2.c.r(false);
        a2.v = null;
    }

    @Override
    public void a() {
        dec a2;
        a2.c.a().a(a2.v, 30.0f, 30.0f);
        --a2.d;
    }
}

