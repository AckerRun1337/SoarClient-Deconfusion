/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 */
import com.google.common.base.Predicate;

class bzc
implements Predicate<rj> {
    bzc() {
        bzc a2;
    }

    public boolean zpa(rj a2) {
        return a2 instanceof i && !a2.l();
    }

    public /* synthetic */ boolean apply(Object a2) {
        bzc a3;
        return a3.zpa((rj)a2);
    }
}

