/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;

public class alc {
    private /* synthetic */ ArrayList<ku> v;
    public /* synthetic */ en d;

    public alc() {
        alc a2;
        a2.v = new ArrayList();
        a2.d = new nq();
        a2.v.add(new jeb());
        a2.v.add(new nyb());
        a2.v.add(new av());
        a2.v.add(new wzc());
        a2.v.add(new xaa());
        a2.v.add(new umc());
        a2.v.add(new khb());
    }

    public ArrayList<ku> a() {
        alc a2;
        return a2.v;
    }
}

