/*
 * Decompiled with CFR 0.152.
 */
import org.lwjgl.opengl.GL11;

public class cjd {
    private sfc s = null;
    private int w = 0;
    private int i = 0;
    private float n = 0.0f;
    private float e = 0.0f;
    private float r = 0.0f;
    private int f = 0;
    private int h = 0;
    private int z = 0;
    private float l = 0.0f;
    private float b = 0.0f;
    private float c = 0.0f;
    private float v = 0.0f;
    private float d = 0.0f;

    public cjd(sfc a2, int a3, int a4, float a5, float a6, float a7, int a8, int a9, int a10, float a11) {
        cjd a12;
        a12.s = a2;
        a12.w = a3;
        a12.i = a4;
        a12.n = a5;
        a12.e = a6;
        a12.r = a7;
        a12.f = a8;
        a12.h = a9;
        a12.z = a10;
        a12.l = a11;
        a12.b = (float)a3 / a2.ia;
        a12.c = (float)a4 / a2.ta;
        a12.v = (float)(a3 + a8) / a2.ia;
        a12.d = (float)(a4 + a9) / a2.ta;
    }

    public void a(xlb a2, float a3) {
        cjd a4;
        ewa.p(a4.n * a3, a4.e * a3, a4.r * a3);
        float f2 = a4.b;
        float f3 = a4.v;
        float f4 = a4.c;
        float f5 = a4.d;
        if (a4.s.q) {
            f2 = a4.v;
            f3 = a4.b;
        }
        if (a4.s.r) {
            f4 = a4.d;
            f5 = a4.c;
        }
        cjd.a(a2, f2, f4, f3, f5, a4.f, a4.h, a3 * (float)a4.z, a4.s.ia, a4.s.ta);
        ewa.p(-a4.n * a3, -a4.e * a3, -a4.r * a3);
    }

    public static void a(xlb a2, float a3, float a4, float a5, float a6, int a7, int a8, float a9, float a10, float a11) {
        float f2;
        float f3;
        float f4;
        if (a9 < 6.25E-4f) {
            a9 = 6.25E-4f;
        }
        float f5 = a5 - a3;
        float f6 = a6 - a4;
        double d2 = smb.p(f5) * (a10 / 16.0f);
        double d3 = smb.p(f6) * (a11 / 16.0f);
        krb krb2 = a2.a();
        GL11.j(0.0f, 0.0f, -1.0f);
        krb2.a(7, ybd.i);
        krb2.a(0.0, d3, 0.0).a(a3, a6).z();
        krb2.a(d2, d3, 0.0).a(a5, a6).z();
        krb2.a(d2, 0.0, 0.0).a(a5, a4).z();
        krb2.a(0.0, 0.0, 0.0).a(a3, a4).z();
        a2.a();
        GL11.j(0.0f, 0.0f, 1.0f);
        krb2.a(7, ybd.i);
        krb2.a(0.0, 0.0, (double)a9).a(a3, a4).z();
        krb2.a(d2, 0.0, (double)a9).a(a5, a4).z();
        krb2.a(d2, d3, (double)a9).a(a5, a6).z();
        krb2.a(0.0, d3, (double)a9).a(a3, a6).z();
        a2.a();
        float f7 = 0.5f * f5 / (float)a7;
        float f8 = 0.5f * f6 / (float)a8;
        GL11.j(-1.0f, 0.0f, 0.0f);
        krb2.a(7, ybd.i);
        int n2 = 0;
        while (n2 < a7) {
            f4 = (float)n2 / (float)a7;
            f3 = a3 + f5 * f4 + f7;
            krb2.a((double)f4 * d2, d3, (double)a9).a(f3, a6).z();
            krb2.a((double)f4 * d2, d3, 0.0).a(f3, a6).z();
            krb2.a((double)f4 * d2, 0.0, 0.0).a(f3, a4).z();
            krb2.a((double)f4 * d2, 0.0, (double)a9).a(f3, a4).z();
            ++n2;
        }
        a2.a();
        GL11.j(1.0f, 0.0f, 0.0f);
        krb2.a(7, ybd.i);
        n2 = 0;
        while (n2 < a7) {
            f4 = (float)n2 / (float)a7;
            f3 = a3 + f5 * f4 + f7;
            f2 = f4 + 1.0f / (float)a7;
            krb2.a((double)f2 * d2, 0.0, (double)a9).a(f3, a4).z();
            krb2.a((double)f2 * d2, 0.0, 0.0).a(f3, a4).z();
            krb2.a((double)f2 * d2, d3, 0.0).a(f3, a6).z();
            krb2.a((double)f2 * d2, d3, (double)a9).a(f3, a6).z();
            ++n2;
        }
        a2.a();
        GL11.j(0.0f, 1.0f, 0.0f);
        krb2.a(7, ybd.i);
        n2 = 0;
        while (n2 < a8) {
            f4 = (float)n2 / (float)a8;
            f3 = a4 + f6 * f4 + f8;
            f2 = f4 + 1.0f / (float)a8;
            krb2.a(0.0, (double)f2 * d3, (double)a9).a(a3, f3).z();
            krb2.a(d2, (double)f2 * d3, (double)a9).a(a5, f3).z();
            krb2.a(d2, (double)f2 * d3, 0.0).a(a5, f3).z();
            krb2.a(0.0, (double)f2 * d3, 0.0).a(a3, f3).z();
            ++n2;
        }
        a2.a();
        GL11.j(0.0f, -1.0f, 0.0f);
        krb2.a(7, ybd.i);
        n2 = 0;
        while (n2 < a8) {
            f4 = (float)n2 / (float)a8;
            f3 = a4 + f6 * f4 + f8;
            krb2.a(d2, (double)f4 * d3, (double)a9).a(a5, f3).z();
            krb2.a(0.0, (double)f4 * d3, (double)a9).a(a3, f3).z();
            krb2.a(0.0, (double)f4 * d3, 0.0).a(a3, f3).z();
            krb2.a(d2, (double)f4 * d3, 0.0).a(a5, f3).z();
            ++n2;
        }
        a2.a();
    }
}

