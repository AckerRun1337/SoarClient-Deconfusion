/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.mojang.authlib.GameProfile;

public class dca
extends fca {
    private boolean h;
    private int z;
    private double l;
    private double b;
    private double c;
    private double v;
    private double d;

    public dca(xga a2, GameProfile a3) {
        super(a2, a3);
        dca a4;
        a4.ja = 0.0f;
        a4.ia = true;
        a4.ya = 0.25f;
        a4.ub = 10.0;
    }

    @Override
    public boolean a(sy a2, float a3) {
        return true;
    }

    @Override
    public void a(double a2, double a3, double a4, float a5, float a6, int a7, boolean a8) {
        a.l = a2;
        a.b = a3;
        a.c = a4;
        a.v = a5;
        a.d = a6;
        a.z = a7;
    }

    @Override
    public void n() {
        dca a2;
        a2.ya = 0.0f;
        super.n();
        a2.mb = a2.gb;
        double d2 = a2.fb - a2.sb;
        double d3 = a2.db - a2.bb;
        float f2 = smb.a(d2 * d2 + d3 * d3) * 4.0f;
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        a2.gb += (f2 - a2.gb) * 0.4f;
        a2.wb += a2.gb;
        if (!a2.h && a2.r() && a2.ob.z[a2.ob.b] != null) {
            wfc wfc2 = a2.ob.z[a2.ob.b];
            a2.a(a2.ob.z[a2.ob.b], wfc2.a().a(wfc2));
            a2.h = true;
        } else if (a2.h && !a2.r()) {
            a2.da();
            a2.h = false;
        }
    }

    @Override
    public void w() {
        dca a2;
        if (a2.z > 0) {
            double d2 = a2.fb + (a2.l - a2.fb) / (double)a2.z;
            double d3 = a2.zb + (a2.b - a2.zb) / (double)a2.z;
            double d4 = a2.db + (a2.c - a2.db) / (double)a2.z;
            double d5 = a2.v - (double)a2.nb;
            while (d5 < -180.0) {
                d5 += 360.0;
            }
            while (d5 >= 180.0) {
                d5 -= 360.0;
            }
            a2.nb = (float)((double)a2.nb + d5 / (double)a2.z);
            a2.rb = (float)((double)a2.rb + (a2.d - (double)a2.rb) / (double)a2.z);
            --a2.z;
            a2.z(d2, d3, d4);
            a2.o(a2.nb, a2.rb);
        }
        a2.tb = a2.fb;
        a2.ia();
    }

    @Override
    public void p(int a2, wfc a3) {
        if (a2 == 0) {
            a.ob.z[a.ob.b] = a3;
        } else {
            a.ob.l[a2 - 1] = a3;
        }
    }

    @Override
    public void a(ga a2) {
        oj.a().wb.a().a(a2);
    }

    @Override
    public boolean a(int a2, String a3) {
        return false;
    }

    @Override
    public tp a() {
        dca a2;
        return new tp(a2.fb + 0.5, a2.zb + 0.5, a2.db + 0.5);
    }
}

