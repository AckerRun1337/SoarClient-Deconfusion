/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

public class dfa
extends cm
implements Serializable {
    static final long d = -4801347926528714435L;

    public dfa(float a2, float a3) {
        super(a2, a3);
        dfa a4;
    }

    public dfa(float[] a2) {
        super(a2);
        dfa a3;
    }

    public dfa(dfa a2) {
        super(a2);
        dfa a3;
    }

    public dfa(wo a2) {
        super(a2);
        dfa a3;
    }

    public dfa(hu a2) {
        super(a2);
        dfa a3;
    }

    public dfa(cm a2) {
        super(a2);
        dfa a3;
    }

    public dfa() {
        dfa a2;
    }

    public final float y(dfa a2) {
        dfa a3;
        float f2 = a3.v - a2.v;
        long l2 = a3.d - a2.d;
        return f2 * f2 + l2 * l2;
    }

    public final float o(dfa a2) {
        dfa a3;
        float f2 = a3.v - a2.v;
        long l2 = a3.d - a2.d;
        return (float)Math.sqrt(f2 * f2 + l2 * l2);
    }

    public final float p(dfa a2) {
        dfa a3;
        return Math.abs(a3.v - a2.v) + Math.abs((float)(a3.d - a2.d));
    }

    public final float a(dfa a2) {
        dfa a3;
        return Math.max(Math.abs(a3.v - a2.v), Math.abs((float)(a3.d - a2.d)));
    }
}

