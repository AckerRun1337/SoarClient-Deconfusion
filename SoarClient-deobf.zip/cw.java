/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.LinkedHashMap;

class cw
extends rq {
    final /* synthetic */ rhc d;

    cw(rhc a2) {
        cw a3;
        a3.d = a2;
    }

    @Override
    protected yjc a(ba a2) {
        LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(a2.a());
        String string = nib.v.a((pxb)linkedHashMap.remove(nib.v));
        linkedHashMap.remove(ywa.c);
        String string2 = a2.a(nib.c) != false ? "all" : "normal";
        return new yjc(String.valueOf(string) + "_double_slab", string2);
    }
}

