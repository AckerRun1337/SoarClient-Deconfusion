/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.base.Predicate;
import java.util.Collections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aga
extends mi {
    private static final Logger l = LogManager.getLogger();
    private dj b;
    private final Predicate<rj> c;
    private final qy v;
    private xi d;

    public aga(dj a2) {
        aga a3;
        a3.b = a2;
        if (a2 instanceof sj) {
            l.warn("Use NearestAttackableTargetGoal.class for PathfinerMob mobs!");
        }
        a3.c = new ns(a3);
        a3.v = new qy(a2);
    }

    @Override
    public boolean o() {
        aga a2;
        double d2 = a2.a();
        Predicate<rj> predicate = a2.b.ib.a(pm.class, a2.b.a().o(d2, 4.0, d2), a2.c);
        Collections.sort(predicate, a2.v);
        if (predicate.isEmpty()) {
            return false;
        }
        a2.d = (xi)predicate.get(0);
        return true;
    }

    @Override
    public boolean p() {
        aga a2;
        xi xi2 = a2.b.y();
        if (xi2 == null) {
            return false;
        }
        if (!xi2.g()) {
            return false;
        }
        if (xi2 instanceof pm && ((pm)xi2).y.h) {
            return false;
        }
        exa exa2 = a2.b.a();
        exa exa3 = xi2.a();
        if (exa2 != null && exa3 == exa2) {
            return false;
        }
        double d2 = a2.a();
        return a2.b.a((rj)xi2) > d2 * d2 ? false : !(xi2 instanceof xj) || !((xj)xi2).oa.a();
    }

    @Override
    public void o() {
        aga a2;
        a2.b.o(a2.d);
        super.o();
    }

    @Override
    public void p() {
        aga a2;
        a2.b.o((xi)null);
        super.o();
    }

    protected double a() {
        aga a2;
        pb pb2 = a2.b.a(prc.b);
        return pb2 == null ? 16.0 : pb2.a();
    }

    static /* synthetic */ dj a(aga a2) {
        return a2.b;
    }
}

