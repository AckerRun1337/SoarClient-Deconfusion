/*
 * Decompiled with CFR 0.152.
 */
public class ci
extends dl {
    public /* synthetic */ int d;

    public ci(int a2) {
        ci a3;
        a3.d = a2;
    }
}

