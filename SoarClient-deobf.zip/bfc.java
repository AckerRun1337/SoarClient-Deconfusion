/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bfc
extends am {
    public bfc() {
        super(qcd.class, "wither", 0.5f);
        bfc a2;
    }

    @Override
    public qm a() {
        return new lg(0.0f);
    }

    @Override
    public sfc a(qm a2, String a3) {
        if (!(a2 instanceof lg)) {
            return null;
        }
        lg lg2 = (lg)a2;
        String string = "body";
        if (a3.startsWith(string)) {
            sfc[] sfcArray = (sfc[])xe.a(lg2, xe.ya);
            if (sfcArray == null) {
                return null;
            }
            String string2 = a3.substring(string.length());
            int n2 = xfc.a(string2, -1);
            return --n2 >= 0 && n2 < sfcArray.length ? sfcArray[n2] : null;
        }
        String string3 = "head";
        if (a3.startsWith(string3)) {
            sfc[] sfcArray = (sfc[])xe.a(lg2, xe.ca);
            if (sfcArray == null) {
                return null;
            }
            String string4 = a3.substring(string3.length());
            int n3 = xfc.a(string4, -1);
            return --n3 >= 0 && n3 < sfcArray.length ? sfcArray[n3] : null;
        }
        return null;
    }

    @Override
    public String[] a() {
        return new String[]{"body1", "body2", "body3", "head1", "head2", "head3"};
    }

    @Override
    public h a(qm a2, float a3) {
        gub gub2 = oj.a().a();
        mfb mfb2 = new mfb(gub2);
        mfb2.k = a2;
        mfb2.b = a3;
        return mfb2;
    }
}

