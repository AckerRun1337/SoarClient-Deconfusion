/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ala
implements o<ib> {
    private float b;
    private float c;
    private boolean v;
    private boolean d;

    public ala() {
        ala a2;
    }

    public ala(float a2, float a3, boolean a4, boolean a5) {
        ala a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    @Override
    public void p(io a2) throws IOException {
        a.b = a2.a();
        a.c = a2.a();
        byte by2 = a2.a();
        a.v = (by2 & 1) > 0;
        a.d = (by2 & 2) > 0;
    }

    @Override
    public void a(io a2) throws IOException {
        ala a3;
        a2.a(a3.b);
        a2.a(a3.c);
        byte by2 = 0;
        if (a3.v) {
            by2 = (byte)(by2 | 1);
        }
        if (a3.d) {
            by2 = (byte)(by2 | 2);
        }
        a2.x(by2);
    }

    @Override
    public void a(ib a2) {
        ala a3;
        a2.a(a3);
    }

    public float p() {
        ala a2;
        return a2.b;
    }

    public float a() {
        ala a2;
        return a2.c;
    }

    public boolean p() {
        ala a2;
        return a2.v;
    }

    public boolean a() {
        ala a2;
        return a2.d;
    }
}

