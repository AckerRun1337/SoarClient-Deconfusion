/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bh {
    public /* synthetic */ oj g;
    public /* synthetic */ gic k;
    private /* synthetic */ String x;
    private /* synthetic */ int t;
    private /* synthetic */ int p;
    private /* synthetic */ int s;
    private /* synthetic */ int w;
    private /* synthetic */ int i;
    private /* synthetic */ int n;
    private /* synthetic */ int e;
    private /* synthetic */ boolean r;
    private /* synthetic */ boolean f;
    private /* synthetic */ boolean h;
    private /* synthetic */ boolean z;
    private /* synthetic */ gk l;
    public /* synthetic */ fgb b;
    public /* synthetic */ fgb c;
    public /* synthetic */ fgb v;
    public /* synthetic */ fgb d;

    public bh(String a2, int a3, gk a4) {
        bh a5;
        a5.g = oj.a();
        a5.k = a5.g.vb;
        a5.b = new fgb(46.0f);
        a5.c = new fgb(0.0f);
        a5.v = new fgb(0.0f);
        a5.d = new fgb(0.0f);
        a5.x = a2;
        a5.e = a3;
        a5.r = false;
        a5.t = 100;
        a5.p = 100;
        a5.i = 100;
        a5.n = 100;
        a5.z = false;
        a5.l = a4;
        a5.y();
    }

    public void y() {
    }

    public void o() {
        bh a2;
        gsc.t.i.p(a2);
    }

    public void p() {
        bh a2;
        gsc.t.i.a(a2);
    }

    public void a() {
        bh a2;
        boolean bl2 = a2.r = !a2.r;
        if (a2.r) {
            a2.o();
        } else {
            a2.p();
        }
    }

    public void y(boolean a2) {
        bh a3;
        a3.r = a2;
        if (a2) {
            a3.o();
        } else {
            a3.p();
        }
    }

    public void x(int a2) {
        bh a3;
        a3.i = a3.x() + a2;
    }

    public void j(int a2) {
        bh a3;
        a3.n = a3.j() + a2;
    }

    public void p(float a2, float a3, float a4, float a5) {
        String string = gsc.t.w.a(gsc.t.n.a("ClickGUI"), "Design").p();
        int n2 = (int)gsc.t.w.a(gsc.t.n.a("ClickGUI"), "Radius").o();
        switch (string) {
            case "Color": {
                frc.a(a2, a3, a4, a5, n2, trc.a(0, trc.a()), trc.a(90, trc.a()), trc.a(180, trc.a()), trc.a(270, trc.a()));
                break;
            }
            case "Normal": {
                frc.a(a2, a3, a4, a5, n2, new Color(0.0f, 0.0f, 0.0f, 0.35f), new Color(0.0f, 0.0f, 0.0f, 0.35f), new Color(0.0f, 0.0f, 0.0f, 0.35f), new Color(0.0f, 0.0f, 0.0f, 0.35f));
                break;
            }
            case "Rainbow": {
                frc.a(a2, a3, a4, a5, n2, trc.a(0, 25.0, trc.a()), trc.a(90, 25.0, trc.a()), trc.a(180, 25.0, trc.a()), trc.a(270, 25.0, trc.a()));
                break;
            }
            case "Classic": {
                frc.a(a2, a3, a4, a5, n2, 1.0f, new Color(25, 25, 25), new Color(65, 65, 65));
                break;
            }
            case "Outline": {
                frc.a(a2, a3, a4, a5, n2, 1.0f, new Color(0.0f, 0.0f, 0.0f, 0.35f), trc.a(0));
                break;
            }
            case "Outline2": {
                dnd.a(a2, a3, a2 + a4, a3 + a5, 4.0f, (float)(n2 * 2), trc.a(0).getRGB(), trc.a(90).getRGB(), trc.a(180).getRGB(), trc.a(270).getRGB());
            }
        }
    }

    public void a(float a2, float a3, float a4, float a5) {
        String string = gsc.t.w.a(gsc.t.n.a("ClickGUI"), "Design").p();
        int n2 = (int)gsc.t.w.a(gsc.t.n.a("ClickGUI"), "Radius").o();
        switch (string) {
            case "Color": {
                frc.p(a2, a3, a4, a5, n2, new Color(0, 0, 0));
                break;
            }
            case "Clear": {
                dnd.a(a2, a3, a2 + a4, a3 + a5, (float)(n2 * 2), new Color(0, 0, 0).getRGB());
                break;
            }
            case "Outline2": {
                dnd.a(a2, a3, a2 + a4, a3 + a5, (float)(n2 * 2), new Color(0, 0, 0).getRGB());
                break;
            }
            case "Normal": {
                frc.p(a2, a3, a4, a5, n2, new Color(0, 0, 0));
                break;
            }
            case "Rainbow": {
                frc.p(a2, a3, a4, a5, n2, new Color(0, 0, 0));
                break;
            }
            case "Classic": {
                frc.p(a2, a3, a4, a5, n2, new Color(0, 0, 0));
                break;
            }
            case "Outline": {
                frc.p(a2, a3, a4, a5, n2, new Color(0, 0, 0));
            }
        }
    }

    public boolean z() {
        String string = gsc.t.w.a(gsc.t.n.a("ClickGUI"), "Font").p();
        return string.equals("Vanilla");
    }

    public String a() {
        bh a2;
        return a2.x;
    }

    public void a(String a2) {
        a.x = a2;
    }

    public int x() {
        bh a2;
        return a2.t;
    }

    public int j() {
        bh a2;
        return a2.p;
    }

    public int z() {
        bh a2;
        return a2.s;
    }

    public int y() {
        bh a2;
        return a2.w;
    }

    public void z(int a2) {
        a.t = a2;
    }

    public void y(int a2) {
        a.p = a2;
    }

    public void o(int a2) {
        a.s = a2;
    }

    public void p(int a2) {
        a.w = a2;
    }

    public int o() {
        bh a2;
        return a2.i;
    }

    public int p() {
        bh a2;
        return a2.n;
    }

    public int a() {
        bh a2;
        return a2.e;
    }

    public void a(int a2) {
        a.e = a2;
    }

    public boolean y() {
        bh a2;
        return a2.r;
    }

    public boolean o() {
        bh a2;
        return a2.f;
    }

    public boolean p() {
        bh a2;
        return a2.h;
    }

    public boolean a() {
        bh a2;
        return a2.z;
    }

    public void o(boolean a2) {
        a.f = a2;
    }

    public void p(boolean a2) {
        a.h = a2;
    }

    public void a(boolean a2) {
        a.z = a2;
    }

    public gk a() {
        bh a2;
        return a2.l;
    }

    public void a(gk a2) {
        a.l = a2;
    }
}

