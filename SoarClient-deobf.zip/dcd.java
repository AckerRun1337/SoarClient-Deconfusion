/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

public class dcd
extends nd {
    public dcd(int a2, float a3, boolean a4) {
        super(a2, a3, a4);
        dcd a5;
        a5.a(true);
    }

    @Override
    public boolean p(wfc a2) {
        return a2.y() > 0;
    }

    @Override
    public ve a(wfc a2) {
        return a2.y() == 0 ? ve.l : ve.b;
    }

    @Override
    protected void p(wfc a2, xga a3, pm a4) {
        if (!a3.f) {
            a4.o(new ihd(ira.k.f, 2400, 0));
        }
        if (a2.y() > 0) {
            if (!a3.f) {
                a4.o(new ihd(ira.oa.f, 600, 4));
                a4.o(new ihd(ira.pa.f, 6000, 0));
                a4.o(new ihd(ira.ba.f, 6000, 0));
            }
        } else {
            dcd a5;
            super.p(a2, a3, a4);
        }
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        a4.add(new wfc(a2, 1, 0));
        a4.add(new wfc(a2, 1, 1));
    }
}

