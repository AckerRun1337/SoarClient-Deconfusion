/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.util.UUID;

public class aia
implements o<ib> {
    private UUID d;

    public aia() {
        aia a2;
    }

    public aia(UUID a2) {
        aia a3;
        a3.d = a2;
    }

    @Override
    public void p(io a2) throws IOException {
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        aia a3;
        a2.a(a3.d);
    }

    @Override
    public void a(ib a2) {
        aia a3;
        a2.a(a3);
    }

    public rj a(oeb a2) {
        aia a3;
        return a2.a(a3.d);
    }
}

