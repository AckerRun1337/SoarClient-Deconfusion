/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import java.io.File;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class anc
extends xja<GameProfile, ioc> {
    public anc(File a2) {
        super(a2);
        anc a3;
    }

    @Override
    protected gka<GameProfile> a(JsonObject a2) {
        return new ioc(a2);
    }

    @Override
    public String[] a() {
        anc a2;
        String[] stringArray = new String[a2.a().size()];
        int n2 = 0;
        for (ioc ioc2 : a2.a().values()) {
            stringArray[n2++] = ((GameProfile)ioc2.a()).getName();
        }
        return stringArray;
    }

    @Override
    public boolean a(GameProfile a2) {
        anc a3;
        ioc ioc2 = (ioc)a3.a(a2);
        return ioc2 != null ? ioc2.p() : false;
    }

    @Override
    protected String a(GameProfile a2) {
        return a2.getId().toString();
    }

    @Override
    public GameProfile a(String a2) {
        anc a3;
        for (ioc ioc2 : a3.a().values()) {
            if (!a2.equalsIgnoreCase(((GameProfile)ioc2.a()).getName())) continue;
            return (GameProfile)ioc2.a();
        }
        return null;
    }

    @Override
    protected /* synthetic */ String a(Object a2) {
        anc a3;
        return a3.a((GameProfile)a2);
    }
}

