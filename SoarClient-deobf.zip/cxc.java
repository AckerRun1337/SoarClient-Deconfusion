/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.mojang.authlib.GameProfile;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cxc
implements ya {
    private final GameProfile v;
    private final wmc d;

    public cxc(GameProfile a2) {
        cxc a3;
        a3.v = a2;
        a3.d = fca.a(a2.getName());
        fca.a(a3.d, a2.getName());
    }

    @Override
    public void a(bgb a2) {
        cxc a3;
        oj.a().a().a(new aia(a3.v.getId()));
    }

    @Override
    public ga a() {
        cxc a2;
        return new gkb(a2.v.getName());
    }

    @Override
    public void a(float a2, int a3) {
        cxc a4;
        oj.a().a().p(a4.d);
        ewa.a(1.0f, 1.0f, 1.0f, (float)a3 / 255.0f);
        xf.a(2, 2, 8.0f, 8.0f, 8, 8, 12, 12, 64.0f, 64.0f);
        xf.a(2, 2, 40.0f, 8.0f, 8, 8, 12, 12, 64.0f, 64.0f);
    }

    @Override
    public boolean a() {
        return true;
    }
}

