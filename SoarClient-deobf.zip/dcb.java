/*
 * Decompiled with CFR 0.152.
 */
public class dcb
extends bh {
    public dcb() {
        super("Coords", 0, gk.l);
        dcb a2;
    }

    @fo
    public void a(thb a2) {
        dcb a3;
        String string = "";
        dsc dsc2 = a3.g.ab.a(new tp(a3.g.ob));
        int n2 = 100;
        string = dsc2.a((tp)new tp((rj)a3.g.ob), (wfb)a3.g.ab.a()).m;
        n2 = (double)n2 < (a3.z() ? (double)a3.k.a(String.valueOf(new StringBuilder("Biome: ").append(string))) : rxb.o.a(String.valueOf(new StringBuilder("Biome: ").append(string)))) ? (int)(a3.z() ? (double)(a3.k.a(String.valueOf(new StringBuilder("Biome: ").append(string))) + 5) : rxb.o.a(String.valueOf(new StringBuilder("Biome: ").append(string))) + 5.0) : 100;
        a3.p(a3.x(), a3.j(), (float)n2 + 4.5f, 46.5f);
        if (a3.z()) {
            a3.k.a(String.valueOf(new StringBuilder("X: ").append((int)a3.g.ob.fb)), (float)a3.x() + 4.5f, (float)a3.j() + 4.5f, -1);
            a3.k.a(String.valueOf(new StringBuilder("Y: ").append((int)a3.g.ob.zb)), (float)a3.x() + 4.5f, (float)a3.j() + 14.5f, -1);
            a3.k.a(String.valueOf(new StringBuilder("Z: ").append((int)a3.g.ob.db)), (float)a3.x() + 4.5f, (float)a3.j() + 24.5f, -1);
            a3.k.a(String.valueOf(new StringBuilder("Biome: ").append(string)), (float)a3.x() + 4.5f, (float)a3.j() + 34.5f, -1);
        } else {
            rxb.o.a(String.valueOf(new StringBuilder("X: ").append((int)a3.g.ob.fb)), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 4.5f), -1);
            rxb.o.a(String.valueOf(new StringBuilder("Y: ").append((int)a3.g.ob.zb)), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 14.5f), -1);
            rxb.o.a(String.valueOf(new StringBuilder("Z: ").append((int)a3.g.ob.db)), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 24.5f), -1);
            rxb.o.a(String.valueOf(new StringBuilder("Biome: ").append(string)), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 34.5f), -1);
        }
        a3.x((int)((float)n2 + 5.0f));
        a3.j(47);
    }

    @fo
    public void a(iw a2) {
        dcb a3;
        a3.a(a3.x(), a3.j(), (float)(a3.o() - a3.x()) - 0.5f, 46.5f);
    }
}

