/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class ajb
implements xa {
    private static final wmc d = new wmc("textures/colormap/grass.png");

    public ajb() {
        ajb a2;
    }

    @Override
    public void a(fa a2) {
        try {
            iwa.a(zjc.a(a2, d));
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}

