/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cob
implements c {
    private static final Logger l = LogManager.getLogger();
    private dsc b;
    private fha<dsc> c = new fha();
    private List<dsc> v = Lists.newArrayList();
    private xga d;

    public cob(xga a2) {
        cob a3;
        a3.b = new abd(a2, 0, 0);
        a3.d = a2;
    }

    @Override
    public boolean a(int a2, int a3) {
        return true;
    }

    public void a(int a2, int a3) {
        cob a4;
        dsc dsc2 = a4.a(a2, a3);
        if (!dsc2.z()) {
            dsc2.j();
        }
        a4.c.a(kgb.a(a2, a3));
        a4.v.remove(dsc2);
    }

    public dsc p(int a2, int a3) {
        cob a4;
        dsc dsc2 = new dsc(a4.d, a2, a3);
        a4.c.a(kgb.a(a2, a3), dsc2);
        a4.v.add(dsc2);
        dsc2.z(true);
        return dsc2;
    }

    @Override
    public dsc a(int a2, int a3) {
        cob a4;
        dsc dsc2 = a4.c.p(kgb.a(a2, a3));
        return dsc2 == null ? a4.b : dsc2;
    }

    @Override
    public boolean a(boolean a2, z a3) {
        return true;
    }

    @Override
    public void a() {
    }

    @Override
    public boolean p() {
        cob a2;
        long l2 = System.currentTimeMillis();
        for (dsc dsc2 : a2.v) {
            dsc2.j(System.currentTimeMillis() - l2 > 5L);
        }
        if (System.currentTimeMillis() - l2 > 100L) {
            l.info("Warning: Clientside chunk ticking took {} ms", new Object[]{System.currentTimeMillis() - l2});
        }
        return false;
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public void a(c a2, int a3, int a4) {
    }

    @Override
    public boolean a(c a2, dsc a3, int a4, int a5) {
        return false;
    }

    @Override
    public String a() {
        cob a2;
        return "MultiplayerChunkCache: " + a2.c.a() + ", " + a2.v.size();
    }

    @Override
    public List<bz> a(zwb a2, tp a3) {
        return null;
    }

    @Override
    public tp a(xga a2, String a3, tp a4) {
        return null;
    }

    @Override
    public int a() {
        cob a2;
        return a2.v.size();
    }

    @Override
    public void a(dsc a2, int a3, int a4) {
    }

    @Override
    public dsc a(tp a2) {
        cob a3;
        return a3.a(a2.o() >> 4, a2.a() >> 4);
    }
}

