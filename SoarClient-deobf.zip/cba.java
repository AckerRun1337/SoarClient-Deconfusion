/*
 * Decompiled with CFR 0.152.
 */
import java.util.EnumSet;
import java.util.Random;
import java.util.Set;

public class cba
extends yha {
    int d;

    protected cba(dr a2) {
        super(a2);
        cba a3;
    }

    private /* synthetic */ void y(xga a2, tp a3, ba a4) {
        cba a5;
        a2.a(a3, cba.a(a5.z).a().a(d, (Integer)a4.a(d)), 2);
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        cba a6;
        int n2 = (Integer)a4.a(d);
        int n3 = 1;
        if (a6.z == dr.ga && !a2.g.p()) {
            n3 = 2;
        }
        int n4 = a6.a(a2);
        if (n2 > 0) {
            int n5 = -100;
            a6.d = 0;
            for (hnd hnd2 : wta.b) {
                n5 = a6.a(a2, a3.a(hnd2), n5);
            }
            int n6 = n5 + n3;
            if (n6 >= 8 || n5 < 0) {
                n6 = -1;
            }
            if (a6.y(a2, a3.j()) >= 0) {
                int n7 = a6.y(a2, a3.j());
                n6 = n7 >= 8 ? n7 : n7 + 8;
            }
            if (a6.d >= 2 && a6.z == dr.ca) {
                ba ba2 = a2.a(a3.z());
                if (ba2.a().a().x()) {
                    n6 = 0;
                } else if (ba2.a().a() == a6.z && (Integer)ba2.a(d) == 0) {
                    n6 = 0;
                }
            }
            if (a6.z == dr.ga && n2 < 8 && n6 < 8 && n6 > n2 && a5.nextInt(4) != 0) {
                n4 *= 4;
            }
            if (n6 == n2) {
                a6.y(a2, a3, a4);
            } else {
                n2 = n6;
                if (n6 < 0) {
                    a2.r(a3);
                } else {
                    a4 = a4.a(d, n6);
                    a2.a(a3, a4, 2);
                    a2.a(a3, (yd)a6, n4);
                    a2.o(a3, a6);
                }
            }
        } else {
            a6.y(a2, a3, a4);
        }
        ba ba3 = a2.a(a3.z());
        if (a6.p(a2, a3.z(), ba3)) {
            if (a6.z == dr.ga && a2.a(a3.z()).a().a() == dr.ca) {
                a2.a(a3.z(), cl.gj.a());
                a6.p(a2, a3.z());
                return;
            }
            if (n2 >= 8) {
                a6.p(a2, a3.z(), ba3, n2);
            } else {
                a6.p(a2, a3.z(), ba3, n2 + 8);
            }
        } else if (n2 >= 0 && (n2 == 0 || a6.o(a2, a3.z(), ba3))) {
            Set<hnd> set = a6.a(a2, a3);
            int n8 = n2 + n3;
            if (n2 >= 8) {
                n8 = 1;
            }
            if (n8 >= 8) {
                return;
            }
            for (hnd hnd3 : set) {
                a6.p(a2, a3.a(hnd3), a2.a(a3.a(hnd3)), n8);
            }
        }
    }

    private /* synthetic */ void p(xga a2, tp a3, ba a4, int a5) {
        cba a6;
        if (a6.p(a2, a3, a4)) {
            if (a4.a() != cl.cd) {
                if (a6.z == dr.ga) {
                    a6.p(a2, a3);
                } else {
                    a4.a().a(a2, a3, a4, 0);
                }
            }
            a2.a(a3, a6.a().a(d, a5), 3);
        }
    }

    private /* synthetic */ int a(xga a2, tp a3, int a4, hnd a5) {
        int n2 = 1000;
        for (hnd hnd2 : wta.b) {
            int n3;
            ba ba2;
            tp tp2;
            cba a6;
            if (hnd2 == a5 || a6.o(a2, tp2 = a3.a(hnd2), ba2 = a2.a(tp2)) || ba2.a().a() == a6.z && (Integer)ba2.a(d) <= 0) continue;
            if (!a6.o(a2, tp2.z(), ba2)) {
                return a4;
            }
            if (a4 >= 4 || (n3 = a6.a(a2, tp2, a4 + 1, hnd2.z())) >= n2) continue;
            n2 = n3;
        }
        return n2;
    }

    private /* synthetic */ Set<hnd> a(xga a2, tp a3) {
        int n2 = 1000;
        EnumSet<hnd> enumSet = EnumSet.noneOf(hnd.class);
        for (hnd hnd2 : wta.b) {
            int n3;
            ba ba2;
            cba a4;
            tp tp2 = a3.a(hnd2);
            if (a4.o(a2, tp2, ba2 = a2.a(tp2)) || ba2.a().a() == a4.z && (Integer)ba2.a(d) <= 0) continue;
            int n4 = n3 = a4.o(a2, tp2.z(), a2.a(tp2.z())) ? a4.a(a2, tp2, 1, hnd2.z()) : 0;
            if (n3 < n2) {
                enumSet.clear();
            }
            if (n3 > n2) continue;
            enumSet.add(hnd2);
            n2 = n3;
        }
        return enumSet;
    }

    private /* synthetic */ boolean o(xga a2, tp a3, ba a4) {
        yd yd2 = a2.a(a3).a();
        return !(yd2 instanceof ccc) && yd2 != cl.ad && yd2 != cl.sh && yd2 != cl.dg ? (yd2.z == dr.i ? true : yd2.z.z()) : true;
    }

    protected int a(xga a2, tp a3, int a4) {
        cba a5;
        int n2 = a5.y(a2, a3);
        if (n2 < 0) {
            return a4;
        }
        if (n2 == 0) {
            ++a5.d;
        }
        if (n2 >= 8) {
            n2 = 0;
        }
        return a4 >= 0 && n2 >= a4 ? a4 : n2;
    }

    private /* synthetic */ boolean p(xga a2, tp a3, ba a4) {
        cba a5;
        dr dr2 = a4.a().a();
        return dr2 != a5.z && dr2 != dr.ga && !a5.o(a2, a3, a4);
    }

    @Override
    public void p(xga a2, tp a3, ba a4) {
        cba a5;
        if (!a5.a(a2, a3, a4)) {
            a2.a(a3, (yd)a5, a5.a(a2));
        }
    }
}

