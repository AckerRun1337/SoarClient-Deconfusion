/*
 * Decompiled with CFR 0.152.
 */
public class aw
extends bh {
    private /* synthetic */ long c;
    private /* synthetic */ int v;
    private /* synthetic */ int d;

    public aw() {
        super("ComboDisplay", 0, gk.l);
        aw a2;
        a2.c = -1L;
    }

    @fo
    public void a(thb a2) {
        aw a3;
        if (System.currentTimeMillis() - a3.c > 2000L) {
            a3.v = 0;
        }
        a3.p(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(a3.p()) + 9) : rxb.o.a(a3.p()) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
        if (a3.z()) {
            a3.k.a(a3.p(), (float)a3.x() + 4.5f, (float)a3.j() + 4.5f, -1);
        } else {
            rxb.o.a(a3.p(), (double)((float)a3.x() + 4.5f), (double)((float)a3.j() + 4.5f), -1);
        }
        a3.x((int)(a3.z() ? (double)((float)a3.k.a(a3.p()) + 8.0f) : rxb.o.a(a3.p()) + 8.0));
        a3.j((int)(a3.z() ? (double)((float)a3.k.u + 8.0f) : rxb.ba.a() + 8.0));
    }

    @fo
    public void a(iw a2) {
        aw a3;
        a3.a(a3.x(), a3.j(), (float)(a3.z() ? (double)(a3.k.a(a3.p()) + 9) : rxb.o.a(a3.p()) + 9.0), (float)(a3.z() ? (double)((float)a3.k.u + 7.5f) : rxb.ba.a() + 7.5));
    }

    @fo
    public void a(ofa a2) {
        a.d = a2.d.h();
    }

    @fo
    public void a(wd a2) {
        aw a3;
        if (a2.d.h() == a3.d) {
            a3.j();
        } else if (a2.d == a3.g.ob) {
            a3.z();
        }
    }

    public void j() {
        aw a2;
        ++a2.v;
        a2.d = -1;
        a2.c = System.currentTimeMillis();
    }

    public void z() {
        a.v = 0;
    }

    public String p() {
        aw a2;
        if (a2.v == 0) {
            return "No Combo";
        }
        return String.valueOf(new StringBuilder(String.valueOf(a2.v)).append(" Combo"));
    }
}

