/*
 * Decompiled with CFR 0.152.
 */
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class ahb
extends wfb {
    private nk v;
    private float d;

    public ahb(nk a2, float a3) {
        ahb a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public nk a(tp a2) {
        ahb a3;
        return a3.v;
    }

    @Override
    public nk[] p(nk[] a2, int a3, int a4, int a5, int a6) {
        ahb a7;
        if (a2 == null || a2.length < a5 * a6) {
            a2 = new nk[a5 * a6];
        }
        Arrays.fill(a2, 0, a5 * a6, a7.v);
        return a2;
    }

    @Override
    public float[] a(float[] a2, int a3, int a4, int a5, int a6) {
        ahb a7;
        if (a2 == null || a2.length < a5 * a6) {
            a2 = new float[a5 * a6];
        }
        Arrays.fill(a2, 0, a5 * a6, a7.d);
        return a2;
    }

    @Override
    public nk[] a(nk[] a2, int a3, int a4, int a5, int a6) {
        ahb a7;
        if (a2 == null || a2.length < a5 * a6) {
            a2 = new nk[a5 * a6];
        }
        Arrays.fill(a2, 0, a5 * a6, a7.v);
        return a2;
    }

    @Override
    public nk[] a(nk[] a2, int a3, int a4, int a5, int a6, boolean a7) {
        ahb a8;
        return a8.a(a2, a3, a4, a5, a6);
    }

    @Override
    public tp a(int a2, int a3, int a4, List<nk> a5, Random a6) {
        ahb a7;
        return a5.contains(a7.v) ? new tp(a2 - a4 + a6.nextInt(a4 * 2 + 1), 0, a3 - a4 + a6.nextInt(a4 * 2 + 1)) : null;
    }

    @Override
    public boolean a(int a2, int a3, int a4, List<nk> a5) {
        ahb a6;
        return a5.contains(a6.v);
    }
}

