/*
 * Decompiled with CFR 0.152.
 */
public class ap
extends qm {
    private sfc c;
    private sfc v;
    private sfc d;

    public ap(float a2, boolean a3) {
        ap a4;
        a4.v = new sfc(a4, "glass");
        a4.v.p(0, 0).a(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        a4.c = new sfc(a4, "cube");
        a4.c.p(32, 0).a(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        if (a3) {
            a4.d = new sfc(a4, "base");
            a4.d.p(0, 16).a(-6.0f, 0.0f, -6.0f, 12, 4, 12);
        }
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        ap a9;
        ewa.m();
        ewa.o(2.0f, 2.0f, 2.0f);
        ewa.p(0.0f, -0.5f, 0.0f);
        if (a9.d != null) {
            a9.d.y(a8);
        }
        ewa.p(a4, 0.0f, 1.0f, 0.0f);
        ewa.p(0.0f, 0.8f + a5, 0.0f);
        ewa.p(60.0f, 0.7071f, 0.0f, 0.7071f);
        a9.v.y(a8);
        float f2 = 0.875f;
        ewa.o(f2, f2, f2);
        ewa.p(60.0f, 0.7071f, 0.0f, 0.7071f);
        ewa.p(a4, 0.0f, 1.0f, 0.0f);
        a9.v.y(a8);
        ewa.o(f2, f2, f2);
        ewa.p(60.0f, 0.7071f, 0.0f, 0.7071f);
        ewa.p(a4, 0.0f, 1.0f, 0.0f);
        a9.c.y(a8);
        ewa.h();
    }
}

