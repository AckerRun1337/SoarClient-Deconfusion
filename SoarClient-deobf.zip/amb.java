/*
 * Decompiled with CFR 0.152.
 */
public class amb
extends bh {
    public amb() {
        super("NameProtect", 0, gk.c);
        amb a2;
    }
}

