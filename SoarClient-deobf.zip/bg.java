/*
 * Decompiled with CFR 0.152.
 */
public class bg
extends ge {
    public bg() {
        bg a2;
        a2.a(md.i);
    }

    @Override
    public boolean a(wfc a2, pm a3, xga a4, tp a5, hnd a6, float a7, float a8, float a9) {
        yd yd2 = a4.a(a5).a();
        if (yd2 instanceof cx) {
            if (a4.f) {
                return true;
            }
            bg.a(a3, a4, a5);
            return true;
        }
        return false;
    }

    public static boolean a(pm a2, xga a3, tp a4) {
        etc etc2 = etc.a(a3, a4);
        boolean bl2 = false;
        double d2 = 7.0;
        int n2 = a4.o();
        int n3 = a4.p();
        int n4 = a4.a();
        for (dj dj2 : a3.a(dj.class, new tca((double)n2 - d2, (double)n3 - d2, (double)n4 - d2, (double)n2 + d2, (double)n3 + d2, (double)n4 + d2))) {
            if (!dj2.pa() || dj2.o() != a2) continue;
            if (etc2 == null) {
                etc2 = etc.p(a3, a4);
            }
            dj2.a((rj)etc2, true);
            bl2 = true;
        }
        return bl2;
    }
}

