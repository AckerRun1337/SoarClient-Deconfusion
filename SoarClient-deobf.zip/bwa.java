/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bwa {
    private static ye v = ye.a();
    private static ye d = new ye();

    public bwa() {
        bwa a2;
    }

    public static String p(String a2) {
        return v.p(a2);
    }

    public static String a(String a2, Object ... a3) {
        return v.a(a2, a3);
    }

    public static String a(String a2) {
        return d.p(a2);
    }

    public static boolean a(String a2) {
        return v.a(a2);
    }

    public static long a() {
        return v.a();
    }
}

