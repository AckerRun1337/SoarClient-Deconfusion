/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class cd
implements Callable<String> {
    private final /* synthetic */ tp d;

    cd(tp a2) {
        cd a3;
        a3.d = a2;
    }

    public String a() throws Exception {
        cd a2;
        return cya.a(a2.d);
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        cd a2;
        return a2.a();
    }
}

