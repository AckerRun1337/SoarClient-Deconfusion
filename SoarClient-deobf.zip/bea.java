/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bea
extends am {
    public bea() {
        super(blc.class, "witch", 0.5f);
        bea a2;
    }

    @Override
    public qm a() {
        return new hg(0.0f);
    }

    @Override
    public sfc a(qm a2, String a3) {
        if (!(a2 instanceof hg)) {
            return null;
        }
        hg hg2 = (hg)a2;
        return a3.equals("mole") ? (sfc)xe.a(hg2, xe.na) : (a3.equals("hat") ? (sfc)xe.a(hg2, xe.ka) : (a3.equals("head") ? hg2.z : (a3.equals("body") ? hg2.l : (a3.equals("arms") ? hg2.b : (a3.equals("left_leg") ? hg2.v : (a3.equals("right_leg") ? hg2.c : (a3.equals("nose") ? hg2.d : null)))))));
    }

    @Override
    public String[] a() {
        return new String[]{"mole", "head", "body", "arms", "right_leg", "left_leg", "nose"};
    }

    @Override
    public h a(qm a2, float a3) {
        gub gub2 = oj.a().a();
        fh fh2 = new fh(gub2);
        fh2.k = a2;
        fh2.b = a3;
        return fh2;
    }
}

