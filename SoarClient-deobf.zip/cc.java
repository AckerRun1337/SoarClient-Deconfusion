/*
 * Decompiled with CFR 0.152.
 */
public interface cc
extends da,
dc {
}

