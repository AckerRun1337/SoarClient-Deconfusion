/*
 * Decompiled with CFR 0.152.
 */
import java.util.MissingResourceException;
import java.util.ResourceBundle;

class awb {
    awb() {
        awb a2;
    }

    static String a(String a2) {
        String string;
        try {
            string = ResourceBundle.getBundle("javax.vecmath.ExceptionStrings").getString(a2);
        }
        catch (MissingResourceException missingResourceException) {
            System.err.println("VecMathI18N: Error looking up: " + a2);
            string = a2;
        }
        return string;
    }
}

