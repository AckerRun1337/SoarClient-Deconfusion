/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cy
extends xf {
    private static final Logger x = LogManager.getLogger();
    private final oj t;
    private final List p = Lists.newArrayList();
    public static final List s = Lists.newArrayList();
    private final List w = Lists.newArrayList();
    private int i;
    private boolean n;
    public static float e = 0.0f;
    public static int r;
    public static long f;
    private String h = "";
    private int z;
    private int l;
    private boolean b;
    private float c;
    private float v;

    static {
        f = -1L;
    }

    public cy(oj a2) {
        cy a3;
        a3.t = a2;
        a3.b = false;
    }

    @fo
    public void a(iw a2) {
        float f2;
        cy a3;
        oda oda2 = new oda(oj.a());
        float f3 = e;
        float f4 = 1.0f - (f3 -= 1.0f) * f3 * f3 * f3;
        float f5 = a3.a();
        boolean bl2 = gsc.t.w.a(gsc.t.n.a("Chat"), "SmoothChat").z();
        float f6 = f2 = bl2 ? (9.0f - 9.0f * f4) * f5 : 0.0f;
        if (gsc.t.n.a("Chat").y() && gsc.t.w.a(gsc.t.n.a("Chat"), "Shadow").z() && a3.v != 0.0f) {
            ewa.m();
            ewa.p(0.0f, (float)(oda2.p() - 30), 0.0f);
            dnd.a(2.0f, a3.c - 7.0f + f2, a3.o() + 6, 2.0f + f2, new Color(0, 0, 0).getRGB());
            ewa.h();
        }
    }

    public static void a(long a2) {
        if (e < 1.0f) {
            e = (float)((double)e + gsc.t.w.a(gsc.t.n.a("Chat"), "Speed").o() / 1000.0 * (double)a2);
        }
        e = cy.a(e, 0.0f, 1.0f);
    }

    public void o(int a2) {
        cy a3;
        boolean bl2;
        long l2 = System.currentTimeMillis();
        long l3 = l2 - f;
        boolean bl3 = bl2 = gsc.t.n.a("Chat").y() && gsc.t.w.a(gsc.t.n.a("Chat"), "Shadow").z();
        if (!a3.b) {
            a3.b = true;
            gsc.t.i.p(a3);
        }
        f = l2;
        cy.a(l3);
        float f2 = e;
        float f3 = 1.0f - (f2 -= 1.0f) * f2 * f2 * f2;
        f3 = cy.a(f3, 0.0f, 1.0f);
        if (a3.t.jb.nm != tnc.l) {
            int n2 = a3.a();
            boolean bl4 = false;
            int n3 = 0;
            int n4 = a3.w.size();
            float f4 = a3.t.jb.rn * 0.9f + 0.1f;
            if (n4 > 0) {
                int n5;
                int n6;
                int n7;
                if (a3.a()) {
                    bl4 = true;
                }
                float f5 = a3.a();
                int n8 = smb.a((float)a3.o() / f5);
                ewa.m();
                if (gsc.t.n.a("Chat").y() && gsc.t.w.a(gsc.t.n.a("Chat"), "SmoothChat").z() && !a3.n) {
                    ewa.p(2.0f, 20.0f + (9.0f - 9.0f * f3) * f5, 0.0f);
                } else {
                    ewa.p(2.0f, 20.0f, 0.0f);
                }
                ewa.o(f5, f5, 1.0f);
                a3.v = 0.0f;
                int n9 = 0;
                while (n9 + a3.i < a3.w.size() && n9 < n2) {
                    xca xca2 = (xca)a3.w.get(n9 + a3.i);
                    if (xca2 != null && ((n7 = a2 - xca2.p()) < 200 || bl4)) {
                        double d2 = (double)n7 / 200.0;
                        a3.v += 1.0f;
                        d2 = 1.0 - d2;
                        d2 *= 10.0;
                        d2 = smb.o(d2, 0.0, 1.0);
                        d2 *= d2;
                        n6 = (int)(255.0 * d2);
                        if (bl4) {
                            n6 = 255;
                        }
                        n6 = (int)((float)n6 * f4);
                        ++n3;
                        if (n6 > 3) {
                            n5 = 0;
                            int n10 = -n9 * 9;
                            a3.c = -n9 * 9;
                            if (!gsc.t.n.a("Chat").y() || gsc.t.n.a("Chat").y() && !gsc.t.w.a(gsc.t.n.a("Chat"), "ClearChat").z()) {
                                cy.a(n5, n10 - 9, n5 + n8 + 4, n10, (bl2 ? 255 : n6) / 2 << 24);
                            }
                            String string = xca2.a().a();
                            ewa.w();
                            if (gsc.t.n.a("Chat").y() && gsc.t.w.a(gsc.t.n.a("Chat"), "SmoothChat").z() && n9 <= r) {
                                a3.t.vb.a(string, (float)n5, (float)(n10 - 8), 0xFFFFFF + (bl2 ? 0 : (int)((float)n6 * f3) << 24));
                            } else {
                                a3.t.vb.a(string, (float)n5, (float)(n10 - 8), 0xFFFFFF + (bl2 ? 0 : n6 << 24));
                            }
                            ewa.fa();
                            ewa.b();
                        }
                    }
                    ++n9;
                }
                if (bl4) {
                    n9 = a3.t.vb.u;
                    ewa.p(-3.0f, 0.0f, 0.0f);
                    int n11 = n4 * n9 + n4;
                    n7 = n3 * n9 + n3;
                    int n12 = a3.i * n7 / n4;
                    int n13 = n7 * n7 / n11;
                    if (n11 != n7) {
                        n6 = n12 > 0 ? 170 : 96;
                        n5 = a3.n ? 0xCC3333 : 0x3333AA;
                        cy.a(0, -n12, 2, -n12 - n13, n5 + (bl2 ? 0 : n6 << 24));
                        cy.a(2, -n12, 1, -n12 - n13, 0xCCCCCC + (bl2 ? 0 : n6 << 24));
                    }
                }
                ewa.h();
            }
        }
    }

    public void o() {
        cy a2;
        a2.w.clear();
        s.clear();
        a2.p.clear();
    }

    public void a(ga a2) {
        cy a3;
        if (gsc.t.n.a("Chat").y() && gsc.t.w.a(gsc.t.n.a("Chat"), "CompactChat").z()) {
            if (a2.p().equals(a3.h)) {
                oj.a().wb.a().a(a3.l);
                ++a3.z;
                a3.h = a2.p();
                a2.a(" [x" + a3.z + "]");
            } else {
                a3.z = 1;
                a3.h = a2.p();
            }
            ++a3.l;
            if (a3.l > 256) {
                a3.l = 0;
            }
            a3.a(a2, a3.l);
        } else {
            a3.a(a2, 0);
        }
    }

    public void a(ga a2, int a3) {
        cy a4;
        e = 0.0f;
        a4.a(a2, a3, a4.t.wb.a(), false);
        x.info("[CHAT] " + a2.p());
    }

    private /* synthetic */ void a(ga a2, int a3, int a4, boolean a5) {
        cy a6;
        if (a3 != 0) {
            a6.a(a3);
        }
        int n2 = smb.p((float)a6.o() / a6.a());
        List<ga> list = kob.a(a2, n2, a6.t.vb, false, false);
        boolean bl2 = a6.a();
        r = list.size() - 1;
        for (ga ga2 : list) {
            if (bl2 && a6.i > 0) {
                a6.n = true;
                a6.p(1);
            }
            a6.w.add(0, new xca(a4, ga2, a3));
        }
        while (a6.w.size() > 100) {
            a6.w.remove(a6.w.size() - 1);
        }
        if (!a5) {
            s.add(0, new xca(a4, a2, a3));
            while (s.size() > 100) {
                s.remove(s.size() - 1);
            }
        }
    }

    public void p() {
        cy a2;
        a2.w.clear();
        a2.a();
        int n2 = s.size() - 1;
        while (n2 >= 0) {
            xca xca2 = (xca)s.get(n2);
            a2.a(xca2.a(), xca2.a(), xca2.p(), true);
            --n2;
        }
    }

    public List a() {
        cy a2;
        return a2.p;
    }

    public void a(String a2) {
        cy a3;
        if (a3.p.isEmpty() || !((String)a3.p.get(a3.p.size() - 1)).equals(a2)) {
            a3.p.add(a2);
        }
    }

    public void a() {
        a.i = 0;
        a.n = false;
    }

    public void p(int a2) {
        cy a3;
        a3.i += a2;
        int n2 = a3.w.size();
        if (a3.i > n2 - a3.a()) {
            a3.i = n2 - a3.a();
        }
        if (a3.i <= 0) {
            a3.i = 0;
            a3.n = false;
        }
    }

    public ga a(int a2, int a3) {
        cy a4;
        if (!a4.a()) {
            return null;
        }
        oda oda2 = new oda(a4.t);
        int n2 = oda2.a();
        float f2 = a4.a();
        int n3 = a2 / n2 - 3;
        int n4 = a3 / n2 - 27;
        n3 = smb.p((float)n3 / f2);
        n4 = smb.p((float)n4 / f2);
        if (n3 >= 0 && n4 >= 0) {
            int n5 = Math.min(a4.a(), a4.w.size());
            if (n3 <= smb.p((float)a4.o() / a4.a()) && n4 < a4.t.vb.u * n5 + n5) {
                int n6 = n4 / a4.t.vb.u + a4.i;
                if (n6 >= 0 && n6 < a4.w.size()) {
                    xca xca2 = (xca)a4.w.get(n6);
                    int n7 = 0;
                    for (ga ga2 : xca2.a()) {
                        if (!(ga2 instanceof gkb) || (n7 += a4.t.vb.a(kob.a(((gkb)ga2).y(), false))) <= n3) continue;
                        return ga2;
                    }
                }
                return null;
            }
            return null;
        }
        return null;
    }

    public boolean a() {
        cy a2;
        return a2.t.sb instanceof gia;
    }

    public void a(int a2) {
        xca xca2;
        cy a3;
        Iterator iterator = a3.w.iterator();
        while (iterator.hasNext()) {
            xca2 = (xca)iterator.next();
            if (xca2.a() != a2) continue;
            iterator.remove();
        }
        iterator = s.iterator();
        while (iterator.hasNext()) {
            xca2 = (xca)iterator.next();
            if (xca2.a() != a2) continue;
            iterator.remove();
            break;
        }
    }

    public int o() {
        cy a2;
        return cy.p(a2.t.jb.cg);
    }

    public int p() {
        cy a2;
        return cy.a(a2.a() ? a2.t.jb.wm : a2.t.jb.jn);
    }

    public float a() {
        cy a2;
        return a2.t.jb.do;
    }

    public static int p(float a2) {
        int n2 = 320;
        int n3 = 40;
        return smb.p(a2 * (float)(n2 - n3) + (float)n3);
    }

    public static int a(float a2) {
        int n2 = 180;
        int n3 = 20;
        return smb.p(a2 * (float)(n2 - n3) + (float)n3);
    }

    public int a() {
        cy a2;
        return a2.p() / 9;
    }

    public static float a(float a2, float a3, float a4) {
        return a2 < a3 ? a3 : Math.min(a2, a4);
    }
}

