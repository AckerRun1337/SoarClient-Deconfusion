/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

public class cyc {
    private static final syc[] v = new syc[]{new syc(zf.class, 30, 0, true), new syc(xec.class, 10, 4), new syc(de.class, 10, 4), new syc(syb.class, 10, 3), new syc(hja.class, 5, 2), new syc(jqb.class, 5, 1)};
    private static final syc[] d = new syc[]{new syc(oxc.class, 25, 0, true), new syc(ldb.class, 15, 5), new syc(ogb.class, 5, 10), new syc(jya.class, 5, 10), new syc(qjb.class, 10, 3, true), new syc(jwa.class, 7, 2), new syc(jz.class, 5, 2)};

    public cyc() {
        cyc a2;
    }

    public static void a() {
        wcb.a(xec.class, "NeBCr");
        wcb.a(cad.class, "NeBEF");
        wcb.a(zf.class, "NeBS");
        wcb.a(qjb.class, "NeCCS");
        wcb.a(jwa.class, "NeCTB");
        wcb.a(jqb.class, "NeCE");
        wcb.a(ldb.class, "NeSCSC");
        wcb.a(jya.class, "NeSCLT");
        wcb.a(oxc.class, "NeSC");
        wcb.a(ogb.class, "NeSCRT");
        wcb.a(jz.class, "NeCSR");
        wcb.a(hja.class, "NeMT");
        wcb.a(de.class, "NeRC");
        wcb.a(syb.class, "NeSR");
        wcb.a(mdc.class, "NeStart");
    }

    private static /* synthetic */ ji p(syc a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        Class<? extends ji> clazz = a2.l;
        ji ji2 = null;
        if (clazz == zf.class) {
            ji2 = zf.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == xec.class) {
            ji2 = xec.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == de.class) {
            ji2 = de.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == syb.class) {
            ji2 = syb.a(a3, a4, a5, a6, a7, a9, a8);
        } else if (clazz == hja.class) {
            ji2 = hja.a(a3, a4, a5, a6, a7, a9, a8);
        } else if (clazz == jqb.class) {
            ji2 = jqb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == oxc.class) {
            ji2 = oxc.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == ogb.class) {
            ji2 = ogb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == jya.class) {
            ji2 = jya.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == qjb.class) {
            ji2 = qjb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == jwa.class) {
            ji2 = jwa.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == ldb.class) {
            ji2 = ldb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (clazz == jz.class) {
            ji2 = jz.a(a3, a4, a5, a6, a7, a8, a9);
        }
        return ji2;
    }

    static /* synthetic */ ji a(syc a2, List a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        return cyc.p(a2, a3, a4, a5, a6, a7, a8, a9);
    }

    static /* synthetic */ syc[] p() {
        return v;
    }

    static /* synthetic */ syc[] a() {
        return d;
    }
}

