/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum csb implements s
{
    f(0, "sandstone", "default"),
    h(1, "chiseled_sandstone", "chiseled"),
    z(2, "smooth_sandstone", "smooth");

    private static final csb[] l;
    private final int b;
    private final String c;
    private final String v;

    static {
        l = new csb[csb.values().length];
        csb[] csbArray = csb.values();
        int n2 = csbArray.length;
        int n3 = 0;
        while (n3 < n2) {
            csb csb2;
            csb.l[csb2.a()] = csb2 = csbArray[n3];
            ++n3;
        }
    }

    private /* synthetic */ csb(String a2, int a3, int a4, String a5, String a6) {
        csb a7;
        a7.b = a4;
        a7.c = a5;
        a7.v = a6;
    }

    public int a() {
        csb a2;
        return a2.b;
    }

    public String toString() {
        csb a2;
        return a2.c;
    }

    public static csb a(int a2) {
        if (a2 < 0 || a2 >= l.length) {
            a2 = 0;
        }
        return l[a2];
    }

    @Override
    public String zpa() {
        csb a2;
        return a2.c;
    }

    public String a() {
        csb a2;
        return a2.v;
    }
}

