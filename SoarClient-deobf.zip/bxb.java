/*
 * Decompiled with CFR 0.152.
 */
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;

class bxb
implements JsonDeserializer<sf> {
    bxb() {
        bxb a2;
    }

    @Override
    public sf a(JsonElement a2, Type a3, JsonDeserializationContext a4) throws JsonParseException {
        bxb a5;
        JsonElement jsonElement = a2.a();
        float[] fArray = a5.a((JsonObject)jsonElement);
        int n2 = a5.a((JsonObject)jsonElement);
        return new sf(fArray, n2);
    }

    protected int a(JsonObject a2) {
        int n2 = px.a(a2, "rotation", 0);
        if (n2 >= 0 && n2 % 90 == 0 && n2 / 90 <= 3) {
            return n2;
        }
        throw new JsonParseException("Invalid rotation " + n2 + " found, only 0/90/180/270 allowed");
    }

    private /* synthetic */ float[] a(JsonObject a2) {
        if (!a2.a("uv")) {
            return null;
        }
        JsonArray jsonArray = px.a(a2, "uv");
        if (jsonArray.p() != 4) {
            throw new JsonParseException("Expected 4 uv values, found: " + jsonArray.p());
        }
        float[] fArray = new float[4];
        int n2 = 0;
        while (n2 < fArray.length) {
            fArray[n2] = px.a(jsonArray.a(n2), "uv[" + n2 + "]");
            ++n2;
        }
        return fArray;
    }

    @Override
    public /* synthetic */ Object a(JsonElement a2, Type a3, JsonDeserializationContext a4) throws JsonParseException {
        bxb a5;
        return a5.a(a2, a3, a4);
    }
}

