/*
 * Decompiled with CFR 0.152.
 */
import net.optifine.expr.\u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8;
import net.optifine.expr.\u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe1;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum chc implements \u635c\u5618\u6216\u5229\u5f10\u8a73\u96cc\u5208\u6368\u84cb\u4ea4\u6295\u7a7a\u61a9\u7b48\u5e06\u67fb\u732e\u5589\u7950\u5ca8\u849c\u6b53\u745a\u5742\u8089\u7ffc\u6728\u834f\u8f61\u7433\u6216\u6e08\u5264\u601c\u66fd\u885b\u5b66\u7968\u84b8
{
    g("is_alive"),
    k("is_burning"),
    x("is_child"),
    t("is_glowing"),
    p("is_hurt"),
    s("is_in_lava"),
    w("is_in_water"),
    i("is_invisible"),
    n("is_on_ground"),
    e("is_ridden"),
    r("is_riding"),
    f("is_sneaking"),
    h("is_sprinting"),
    z("is_wet");

    private String l;
    private gub b;
    private static final chc[] c;
    private static volatile /* synthetic */ int[] v;

    static {
        c = chc.values();
    }

    private /* synthetic */ chc(String a2, int a3, String a4) {
        chc a5;
        a5.l = a4;
        a5.b = oj.a().a();
    }

    public String a() {
        chc a2;
        return a2.l;
    }

    @Override
    public \u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe1 a() {
        return \u83d6\u6d3b\u66fd\u66ae\u6696\u8acb\u7ffb\u69d8\u6f38\u8511\u7279\u5264\u4e0e\u8154\u4e5f\u8139\u6e5b\u9c48\u5750\u9593\u5f79\u796d\u8ad2\u5c90\u985b\u65ed\u6590\u4e19\u8a72\u633a\u62d2\u6b8b\u7d0b\u90fd\u61d0\u58f7\u84cb\u9f8d\u8a2d\u4fe1.v;
    }

    @Override
    public boolean a() {
        rj rj2 = oj.a().a();
        if (rj2 instanceof xi) {
            chc a2;
            xi xi2 = (xi)rj2;
            switch (chc.a()[a2.ordinal()]) {
                case 1: {
                    return xi2.g();
                }
                case 2: {
                    return xi2.i();
                }
                case 3: {
                    return xi2.ga();
                }
                case 5: {
                    return xi2.sb > 0;
                }
                case 6: {
                    return xi2.s();
                }
                case 7: {
                    return xi2.w();
                }
                case 8: {
                    return xi2.l();
                }
                case 9: {
                    return (boolean)xi2.aa;
                }
                case 10: {
                    return xi2.lb != null;
                }
                case 11: {
                    return xi2.e();
                }
                case 12: {
                    return xi2.c();
                }
                case 13: {
                    return xi2.f();
                }
                case 14: {
                    return xi2.b();
                }
            }
        }
        return false;
    }

    public static chc a(String a2) {
        if (a2 == null) {
            return null;
        }
        int n2 = 0;
        while (n2 < c.length) {
            chc chc2 = c[n2];
            if (chc2.a().equals(a2)) {
                return chc2;
            }
            ++n2;
        }
        return null;
    }

    static /* synthetic */ int[] a() {
        if (v != null) {
            return v;
        }
        int[] nArray = new int[chc.values().length];
        try {
            nArray[chc.g.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.k.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.x.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.t.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.p.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.s.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.w.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.n.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.e.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.r.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.f.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.h.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[chc.z.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        v = nArray;
        return nArray;
    }
}

