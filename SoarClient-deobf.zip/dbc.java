/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

public class dbc
extends hm {
    public dbc() {
        dbc a2;
    }

    public dbc(int a2, Random a3, uxc a4, hnd a5) {
        super(a2);
        dbc a6;
        a6.c = a5;
        a6.c = a6.a(a3);
        a6.b = a4;
    }

    @Override
    public void a(ae a2, List<ae> a3, Random a4) {
        dbc a5;
        a5.o((sid)a2, a3, a4, 1, 1);
    }

    public static dbc a(List<ae> a2, Random a3, int a4, int a5, int a6, hnd a7, int a8) {
        uxc uxc2 = uxc.a(a4, a5, a6, -1, -1, 0, 9, 5, 11, a7);
        return dbc.a(uxc2) && ae.a(a2, uxc2) == null ? new dbc(a8, a3, uxc2, a7) : null;
    }

    @Override
    public boolean a(xga a2, Random a3, uxc a4) {
        dbc a5;
        if (a5.a(a2, a4)) {
            return false;
        }
        a5.a(a2, a4, 0, 0, 0, 8, 4, 10, true, a3, bi.a());
        a5.a(a2, a3, a4, a5.c, 1, 1, 0);
        a5.a(a2, a4, 1, 1, 10, 3, 3, 10, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 4, 1, 1, 4, 3, 1, false, a3, bi.a());
        a5.a(a2, a4, 4, 1, 3, 4, 3, 3, false, a3, bi.a());
        a5.a(a2, a4, 4, 1, 7, 4, 3, 7, false, a3, bi.a());
        a5.a(a2, a4, 4, 1, 9, 4, 3, 9, false, a3, bi.a());
        a5.a(a2, a4, 4, 1, 4, 4, 3, 6, cl.mc.a(), cl.mc.a(), false);
        a5.a(a2, a4, 5, 1, 5, 7, 3, 5, cl.mc.a(), cl.mc.a(), false);
        a5.p(a2, cl.mc.a(), 4, 3, 2, a4);
        a5.p(a2, cl.mc.a(), 4, 3, 8, a4);
        a5.p(a2, cl.hh.a(a5.a(cl.hh, 3)), 4, 1, 2, a4);
        a5.p(a2, cl.hh.a(a5.a(cl.hh, 3) + 8), 4, 2, 2, a4);
        a5.p(a2, cl.hh.a(a5.a(cl.hh, 3)), 4, 1, 8, a4);
        a5.p(a2, cl.hh.a(a5.a(cl.hh, 3) + 8), 4, 2, 8, a4);
        return true;
    }
}

