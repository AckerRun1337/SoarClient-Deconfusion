/*
 * Decompiled with CFR 0.152.
 */
public class ar
extends qm {
    public sfc[] d = new sfc[7];

    public ar() {
        ar a2;
        a2.d[0] = new sfc(a2, 0, 10);
        a2.d[1] = new sfc(a2, 0, 0);
        a2.d[2] = new sfc(a2, 0, 0);
        a2.d[3] = new sfc(a2, 0, 0);
        a2.d[4] = new sfc(a2, 0, 0);
        a2.d[5] = new sfc(a2, 44, 10);
        int n2 = 20;
        int n3 = 8;
        int n4 = 16;
        int n5 = 4;
        a2.d[0].p(-n2 / 2, -n4 / 2, -1.0f, n2, n4, 2, 0.0f);
        a2.d[0].a(0.0f, n5, 0.0f);
        a2.d[5].p(-n2 / 2 + 1, -n4 / 2 + 1, -1.0f, n2 - 2, n4 - 2, 1, 0.0f);
        a2.d[5].a(0.0f, n5, 0.0f);
        a2.d[1].p(-n2 / 2 + 2, -n3 - 1, -1.0f, n2 - 4, n3, 2, 0.0f);
        a2.d[1].a(-n2 / 2 + 1, n5, 0.0f);
        a2.d[2].p(-n2 / 2 + 2, -n3 - 1, -1.0f, n2 - 4, n3, 2, 0.0f);
        a2.d[2].a(n2 / 2 - 1, n5, 0.0f);
        a2.d[3].p(-n2 / 2 + 2, -n3 - 1, -1.0f, n2 - 4, n3, 2, 0.0f);
        a2.d[3].a(0.0f, n5, -n4 / 2 + 1);
        a2.d[4].p(-n2 / 2 + 2, -n3 - 1, -1.0f, n2 - 4, n3, 2, 0.0f);
        a2.d[4].a(0.0f, n5, n4 / 2 - 1);
        a2.d[0].j = 1.5707964f;
        a2.d[1].o = 4.712389f;
        a2.d[2].o = 1.5707964f;
        a2.d[3].o = (float)Math.PI;
        a2.d[5].j = -1.5707964f;
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        a9.d[5].la = 4.0f - a5;
        int n2 = 0;
        while (n2 < 6) {
            ar a9;
            a9.d[n2].y(a8);
            ++n2;
        }
    }
}

