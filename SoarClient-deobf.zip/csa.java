/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class csa
implements Callable<String> {
    final /* synthetic */ yyb d;

    csa(yyb a2) {
        csa a3;
        a3.d = a2;
    }

    public String a() throws Exception {
        csa a2;
        return cya.a(yyb.x(a2.d), yyb.j(a2.d), yyb.z(a2.d));
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        csa a2;
        return a2.a();
    }
}

