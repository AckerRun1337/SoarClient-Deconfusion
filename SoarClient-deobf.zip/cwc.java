/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class cwc
implements o<vi> {
    private int v;
    private int d;

    public cwc() {
        cwc a2;
    }

    public cwc(int a2, ihd a3) {
        cwc a4;
        a4.v = a2;
        a4.d = a3.y();
    }

    @Override
    public void p(io a2) throws IOException {
        a.v = a2.c();
        a.d = a2.p();
    }

    @Override
    public void a(io a2) throws IOException {
        cwc a3;
        a2.a(a3.v);
        a2.x(a3.d);
    }

    @Override
    public void a(vi a2) {
        cwc a3;
        a2.a(a3);
    }

    public int p() {
        cwc a2;
        return a2.v;
    }

    public int a() {
        cwc a2;
        return a2.d;
    }
}

