/*
 * Decompiled with CFR 0.152.
 */
public class adc
extends zk {
    protected adc(int a2, wmc a3, int a4) {
        super(a2, a3, a4, bic.z);
        adc a5;
        a5.a("fire");
    }

    @Override
    public int p(int a2) {
        return 10 + 20 * (a2 - 1);
    }

    @Override
    public int a(int a2) {
        adc a3;
        return super.p(a2) + 50;
    }

    @Override
    public int a() {
        return 2;
    }
}

