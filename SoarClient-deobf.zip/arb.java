/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;

public class arb
extends en {
    private /* synthetic */ fgb f;
    private /* synthetic */ fgb h;
    private /* synthetic */ oi z;
    private /* synthetic */ kk l;
    private /* synthetic */ boolean b;
    private /* synthetic */ boolean c;
    private /* synthetic */ boolean v;
    private /* synthetic */ boolean d;

    public arb() {
        arb a2;
        a2.l = new kk();
    }

    @Override
    public void m() {
        a.f = new fgb(0.0f);
        a.h = new fgb(0.0f);
        a.z = new qxb(1500, 255.0);
        a.b = true;
        a.c = true;
        a.v = false;
        a.d = false;
    }

    @Override
    public void a(int a2, int a3, float a4) {
        arb a5;
        frc.a(0.0f, 0.0f, mpa.o(), mpa.p(), 0.0f, trc.a(0), trc.a(90), trc.a(180), trc.a(270));
        if (!a5.v) {
            a5.l.a();
            a5.v = true;
        }
        if (a5.v) {
            if (a5.l.a(1000L)) {
                a5.b = false;
            }
            if (a5.l.a(5000L)) {
                a5.b = true;
            }
            if (a5.l.a(6000L)) {
                a5.c = false;
            }
            if (a5.l.a(10000L)) {
                a5.c = true;
            }
            if (a5.l.a(11000L)) {
                a5.z.a(fl.v);
            }
        }
        if (a5.z.a(fl.v)) {
            a5.d = true;
        }
        if (a5.d) {
            a5.w.a(new lkd());
            a5.d = false;
        }
        a5.f.a(a5.b ? 0 : 255, 5.0);
        a5.h.a(a5.c ? 0 : 255, 5.0);
        dnd.a(0.0f, 0.0f, mpa.o(), (float)mpa.p(), new Color(0, 0, 0, (int)a5.z.p()).getRGB());
        rxb.u.p("Welcome to SoarClient", mpa.o() / 2, (float)((double)(mpa.p() / 2) - rxb.u.a()), new Color(255, 255, 255, (int)a5.f.a()).getRGB());
        rxb.u.p("Let the setup begin!", mpa.o() / 2, (float)((double)(mpa.p() / 2) - rxb.u.a()), new Color(255, 255, 255, (int)a5.h.a()).getRGB());
    }
}

