/*
 * Decompiled with CFR 0.152.
 */
public class clb
extends zm {
    public clb(xga a2) {
        super(a2);
        clb a3;
        a3.y(a3.xa * 6.0f, a3.ua * 6.0f);
    }

    @Override
    public float o() {
        return 10.440001f;
    }

    @Override
    protected void ma() {
        clb a2;
        super.ma();
        a2.a(prc.l).a(100.0);
        a2.a(prc.v).a(0.5);
        a2.a(prc.d).a(50.0);
    }

    @Override
    public float a(tp a2) {
        clb a3;
        return a3.ib.a(a2) - 0.5f;
    }
}

