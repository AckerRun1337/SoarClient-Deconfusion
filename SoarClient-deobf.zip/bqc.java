/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

public class bqc
implements qc {
    private int[] c;
    private int v;
    private int d;

    public bqc() {
        bqc a2;
    }

    @Override
    public BufferedImage a(BufferedImage a2) {
        bqc a3;
        if (a2 == null) {
            return null;
        }
        a3.v = 64;
        a3.d = 64;
        int n2 = a2.getWidth();
        int n3 = a2.getHeight();
        int n4 = 1;
        while (a3.v < n2 || a3.d < n3) {
            a3.v *= 2;
            a3.d *= 2;
            n4 *= 2;
        }
        BufferedImage bufferedImage = new BufferedImage(a3.v, a3.d, 2);
        Graphics graphics = bufferedImage.getGraphics();
        graphics.drawImage(a2, 0, 0, null);
        if (a2.getHeight() == 32 * n4) {
            graphics.drawImage(bufferedImage, 24 * n4, 48 * n4, 20 * n4, 52 * n4, 4 * n4, 16 * n4, 8 * n4, 20 * n4, null);
            graphics.drawImage(bufferedImage, 28 * n4, 48 * n4, 24 * n4, 52 * n4, 8 * n4, 16 * n4, 12 * n4, 20 * n4, null);
            graphics.drawImage(bufferedImage, 20 * n4, 52 * n4, 16 * n4, 64 * n4, 8 * n4, 20 * n4, 12 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 24 * n4, 52 * n4, 20 * n4, 64 * n4, 4 * n4, 20 * n4, 8 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 28 * n4, 52 * n4, 24 * n4, 64 * n4, 0 * n4, 20 * n4, 4 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 32 * n4, 52 * n4, 28 * n4, 64 * n4, 12 * n4, 20 * n4, 16 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 40 * n4, 48 * n4, 36 * n4, 52 * n4, 44 * n4, 16 * n4, 48 * n4, 20 * n4, null);
            graphics.drawImage(bufferedImage, 44 * n4, 48 * n4, 40 * n4, 52 * n4, 48 * n4, 16 * n4, 52 * n4, 20 * n4, null);
            graphics.drawImage(bufferedImage, 36 * n4, 52 * n4, 32 * n4, 64 * n4, 48 * n4, 20 * n4, 52 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 40 * n4, 52 * n4, 36 * n4, 64 * n4, 44 * n4, 20 * n4, 48 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 44 * n4, 52 * n4, 40 * n4, 64 * n4, 40 * n4, 20 * n4, 44 * n4, 32 * n4, null);
            graphics.drawImage(bufferedImage, 48 * n4, 52 * n4, 44 * n4, 64 * n4, 52 * n4, 20 * n4, 56 * n4, 32 * n4, null);
        }
        graphics.dispose();
        a3.c = ((DataBufferInt)bufferedImage.getRaster().getDataBuffer()).getData();
        a3.a(0 * n4, 0 * n4, 32 * n4, 16 * n4);
        a3.p(32 * n4, 0 * n4, 64 * n4, 32 * n4);
        a3.a(0 * n4, 16 * n4, 64 * n4, 32 * n4);
        a3.p(0 * n4, 32 * n4, 16 * n4, 48 * n4);
        a3.p(16 * n4, 32 * n4, 40 * n4, 48 * n4);
        a3.p(40 * n4, 32 * n4, 56 * n4, 48 * n4);
        a3.p(0 * n4, 48 * n4, 16 * n4, 64 * n4);
        a3.a(16 * n4, 48 * n4, 48 * n4, 64 * n4);
        a3.p(48 * n4, 48 * n4, 64 * n4, 64 * n4);
        return bufferedImage;
    }

    @Override
    public void a() {
    }

    private /* synthetic */ void p(int a2, int a3, int a4, int a5) {
        bqc a6;
        if (!a6.a(a2, a3, a4, a5)) {
            int n2 = a2;
            while (n2 < a4) {
                int n3 = a3;
                while (n3 < a5) {
                    int n4 = n2 + n3 * a6.v;
                    a6.c[n4] = a6.c[n4] & 0xFFFFFF;
                    ++n3;
                }
                ++n2;
            }
        }
    }

    private /* synthetic */ void a(int a2, int a3, int a4, int a5) {
        int n2 = a2;
        while (n2 < a4) {
            int n3 = a3;
            while (n3 < a5) {
                bqc a6;
                int n4 = n2 + n3 * a6.v;
                a6.c[n4] = a6.c[n4] | 0xFF000000;
                ++n3;
            }
            ++n2;
        }
    }

    private /* synthetic */ boolean a(int a2, int a3, int a4, int a5) {
        int n2 = a2;
        while (n2 < a4) {
            int n3 = a3;
            while (n3 < a5) {
                bqc a6;
                int n4 = a6.c[n2 + n3 * a6.v];
                if ((n4 >> 24 & 0xFF) < 128) {
                    return true;
                }
                ++n3;
            }
            ++n2;
        }
        return false;
    }
}

