/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.util.concurrent.FutureCallback
 *  com.google.common.util.concurrent.Futures
 *  com.google.common.util.concurrent.ListenableFuture
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bq
implements Runnable {
    private static final Logger c = LogManager.getLogger();
    private final kf v;
    private final zwc d;

    public bq(kf a2) {
        a3(a2, null);
        bq a3;
    }

    public bq(kf a2, zwc a3) {
        bq a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public void run() {
        try {
            while (true) {
                bq a2;
                a2.p(a2.v.a());
            }
        }
        catch (InterruptedException interruptedException) {
            c.debug("Stopping due to interrupt");
            return;
        }
        catch (Throwable throwable) {
            hna hna2 = hna.a(throwable, "Batching chunks");
            oj.a().p(oj.a().a(hna2));
            return;
        }
    }

    protected void p(lja a2) throws InterruptedException {
        a2.a().lock();
        try {
            if (a2.a() != uqc.l) {
                if (!a2.a()) {
                    c.warn("Chunk render task was " + (Object)((Object)a2.a()) + " when I expected it to be pending; ignoring task");
                }
                return;
            }
            a2.a(uqc.b);
        }
        finally {
            a2.a().unlock();
        }
        rj rj2 = oj.a().a();
        if (rj2 == null) {
            a2.a();
        } else {
            Object object;
            bq a3;
            a2.a(a3.a());
            float f2 = (float)rj2.fb;
            float f3 = (float)rj2.zb + rj2.o();
            float f4 = (float)rj2.db;
            bma bma2 = a2.a();
            if (bma2 == bma.c) {
                a2.a().a(f2, f3, f4, a2);
            } else if (bma2 == bma.v) {
                a2.a().p(f2, f3, f4, a2);
            }
            a2.a().lock();
            try {
                if (a2.a() != uqc.b) {
                    if (!a2.a()) {
                        c.warn("Chunk render task was " + (Object)((Object)a2.a()) + " when I expected it to be compiling; aborting task");
                    }
                    a3.a(a2);
                    return;
                }
                a2.a(uqc.c);
            }
            finally {
                a2.a().unlock();
            }
            kub kub2 = a2.a();
            ArrayList arrayList = Lists.newArrayList();
            if (bma2 == bma.c) {
                hdc[] hdcArray = hdc.values();
                int n2 = hdcArray.length;
                int n3 = 0;
                while (n3 < n2) {
                    object = hdcArray[n3];
                    if (kub2.a((hdc)((Object)object))) {
                        arrayList.add(a3.v.a((hdc)((Object)object), a2.a().a((hdc)((Object)object)), a2.a(), kub2));
                    }
                    ++n3;
                }
            } else if (bma2 == bma.v) {
                arrayList.add(a3.v.a(hdc.c, a2.a().a(hdc.c), a2.a(), kub2));
            }
            object = Futures.allAsList((Iterable)arrayList);
            a2.a(new dt(a3, (ListenableFuture)object));
            Futures.addCallback((ListenableFuture)object, (FutureCallback)new il(a3, a2, kub2));
        }
    }

    private /* synthetic */ zwc a() throws InterruptedException {
        bq a2;
        return a2.d != null ? a2.d : a2.v.a();
    }

    private /* synthetic */ void a(lja a2) {
        bq a3;
        if (a3.d == null) {
            a3.v.a(a2.a());
        }
    }

    static /* synthetic */ void a(bq a2, lja a3) {
        a2.a(a3);
    }

    static /* synthetic */ Logger a() {
        return c;
    }
}

