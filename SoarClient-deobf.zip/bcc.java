/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bcc {
    private final int b;
    private ba c;
    private int v = 1;
    private int d;

    public bcc(int a2, yd a3) {
        a4(3, a2, a3);
        bcc a4;
    }

    public bcc(int a2, int a3, yd a4) {
        bcc a5;
        a5.b = a2;
        a5.v = a3;
        a5.c = a4.a();
    }

    public bcc(int a2, int a3, yd a4, int a5) {
        a6(a2, a3, a4);
        bcc a6;
        a6.c = a4.a(a5);
    }

    public int o() {
        bcc a2;
        return a2.v;
    }

    public ba a() {
        bcc a2;
        return a2.c;
    }

    private /* synthetic */ yd a() {
        bcc a2;
        return a2.c.a();
    }

    private /* synthetic */ int p() {
        bcc a2;
        return a2.c.a().o(a2.c);
    }

    public int a() {
        bcc a2;
        return a2.d;
    }

    public void a(int a2) {
        a.d = a2;
    }

    public String toString() {
        int n2;
        String string;
        bcc a2;
        if (a2.b >= 3) {
            wmc wmc2 = (wmc)yd.ma.p(a2.a());
            String string2 = string = wmc2 == null ? "null" : wmc2.toString();
            if (a2.v > 1) {
                string = String.valueOf(a2.v) + "*" + string;
            }
        } else {
            string = Integer.toString(yd.a(a2.a()));
            if (a2.v > 1) {
                string = String.valueOf(a2.v) + "x" + string;
            }
        }
        if ((n2 = a2.p()) > 0) {
            string = String.valueOf(string) + ":" + n2;
        }
        return string;
    }
}

