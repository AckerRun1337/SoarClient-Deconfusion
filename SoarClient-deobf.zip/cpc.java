/*
 * Decompiled with CFR 0.152.
 */
public class cpc
extends zk {
    protected cpc(int a2, wmc a3, int a4) {
        super(a2, a3, a4, bic.l);
        cpc a5;
        a5.a("digging");
    }

    @Override
    public int p(int a2) {
        return 1 + 10 * (a2 - 1);
    }

    @Override
    public int a(int a2) {
        cpc a3;
        return super.p(a2) + 50;
    }

    @Override
    public int a() {
        return 5;
    }

    @Override
    public boolean a(wfc a2) {
        cpc a3;
        return a2.a() == sxa.oc ? true : super.a(a2);
    }
}

