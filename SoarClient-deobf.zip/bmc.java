/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bmc {
    private final List<zxb> f = Lists.newArrayList();
    private final xi h;
    private int z;
    private int l;
    private int b;
    private boolean c;
    private boolean v;
    private String d;

    public bmc(xi a2) {
        bmc a3;
        a3.h = a2;
    }

    public void o() {
        bmc a2;
        a2.p();
        if (a2.h.ra()) {
            yd yd2 = a2.h.ib.a(new tp((double)a2.h.fb, a2.h.a().l, a2.h.db)).a();
            if (yd2 == cl.sh) {
                a2.d = "ladder";
            } else if (yd2 == cl.fc) {
                a2.d = "vines";
            }
        } else if (a2.h.w()) {
            a2.d = "water";
        }
    }

    public void a(sy a2, float a3, float a4) {
        bmc a5;
        a5.a();
        a5.o();
        zxb zxb2 = new zxb(a2, (int)a5.h.pa, a3, a4, a5.d, (float)a5.h.ka);
        a5.f.add(zxb2);
        a5.z = (int)a5.h.pa;
        a5.v = true;
        if (zxb2.a() && !a5.c && a5.h.g()) {
            a5.c = true;
            a5.b = a5.l = (int)a5.h.pa;
            a5.h.l();
        }
    }

    public ga a() {
        ga ga2;
        bmc a2;
        if (a2.f.size() == 0) {
            return new klb("death.attack.generic", a2.h.a());
        }
        zxb zxb2 = a2.a();
        zxb zxb3 = a2.f.get(a2.f.size() - 1);
        ga ga3 = zxb3.a();
        rj rj2 = zxb3.a().a();
        if (zxb2 != null && zxb3.a() == sy.x) {
            ga ga4 = zxb2.a();
            if (zxb2.a() != sy.x && zxb2.a() != sy.t) {
                if (!(ga4 == null || ga3 != null && ga4.equals(ga3))) {
                    wfc wfc2;
                    rj rj3 = zxb2.a().a();
                    wfc wfc3 = wfc2 = rj3 instanceof xi ? ((xi)rj3).a() : null;
                    ga2 = wfc2 != null && wfc2.j() ? new klb("death.fell.assist.item", a2.h.a(), ga4, wfc2.a()) : new klb("death.fell.assist", a2.h.a(), ga4);
                } else if (ga3 != null) {
                    wfc wfc4;
                    wfc wfc5 = wfc4 = rj2 instanceof xi ? ((xi)rj2).a() : null;
                    ga2 = wfc4 != null && wfc4.j() ? new klb("death.fell.finish.item", a2.h.a(), ga3, wfc4.a()) : new klb("death.fell.finish", a2.h.a(), ga3);
                } else {
                    ga2 = new klb("death.fell.killer", a2.h.a());
                }
            } else {
                ga2 = new klb("death.fell.accident." + a2.a(zxb2), a2.h.a());
            }
        } else {
            ga2 = zxb3.a().a(a2.h);
        }
        return ga2;
    }

    public xi p() {
        bmc a2;
        xi xi2 = null;
        pm pm2 = null;
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (zxb zxb2 : a2.f) {
            if (zxb2.a().a() instanceof pm && (pm2 == null || zxb2.p() > f3)) {
                f3 = zxb2.p();
                pm2 = (pm)zxb2.a().a();
            }
            if (!(zxb2.a().a() instanceof xi) || xi2 != null && !(zxb2.p() > f2)) continue;
            f2 = zxb2.p();
            xi2 = (xi)zxb2.a().a();
        }
        if (pm2 != null && f3 >= f2 / 3.0f) {
            return pm2;
        }
        return xi2;
    }

    private /* synthetic */ zxb a() {
        bmc a2;
        zxb zxb2 = null;
        zxb zxb3 = null;
        int n2 = 0;
        float f2 = 0.0f;
        int n3 = 0;
        while (n3 < a2.f.size()) {
            zxb zxb4;
            zxb zxb5 = a2.f.get(n3);
            zxb zxb6 = zxb4 = n3 > 0 ? a2.f.get(n3 - 1) : null;
            if ((zxb5.a() == sy.x || zxb5.a() == sy.t) && zxb5.a() > 0.0f && (zxb2 == null || zxb5.a() > f2)) {
                zxb2 = n3 > 0 ? zxb4 : zxb5;
                f2 = zxb5.a();
            }
            if (zxb5.a() != null && (zxb3 == null || zxb5.p() > (float)n2)) {
                zxb3 = zxb5;
            }
            ++n3;
        }
        if (f2 > 5.0f && zxb2 != null) {
            return zxb2;
        }
        if (n2 > 5 && zxb3 != null) {
            return zxb3;
        }
        return null;
    }

    private /* synthetic */ String a(zxb a2) {
        return a2.a() == null ? "generic" : a2.a();
    }

    public int a() {
        bmc a2;
        return a2.c ? (int)(a2.h.pa - a2.l) : a2.b - a2.l;
    }

    private /* synthetic */ void p() {
        a.d = null;
    }

    public void a() {
        bmc a2;
        int n2;
        int n3 = n2 = a2.c ? 300 : 100;
        if (a2.v && (!a2.h.g() || a2.h.pa - a2.z > n2)) {
            boolean bl2 = a2.c;
            a2.v = false;
            a2.c = false;
            a2.b = (int)a2.h.pa;
            if (bl2) {
                a2.h.o();
            }
            a2.f.clear();
        }
    }

    public xi a() {
        bmc a2;
        return a2.h;
    }
}

