/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aad
extends am {
    public aad() {
        super(etc.class, "lead_knot", 0.0f);
        aad a2;
    }

    @Override
    public qm a() {
        return new sua();
    }

    @Override
    public sfc a(qm a2, String a3) {
        if (!(a2 instanceof sua)) {
            return null;
        }
        sua sua2 = (sua)a2;
        return a3.equals("knot") ? sua2.d : null;
    }

    @Override
    public String[] a() {
        return new String[]{"knot"};
    }

    @Override
    public h a(qm a2, float a3) {
        gub gub2 = oj.a().a();
        cfa cfa2 = new cfa(gub2);
        if (!xe.nb.a()) {
            xfc.z("Field not found: RenderLeashKnot.leashKnotModel");
            return null;
        }
        xe.a((Object)cfa2, xe.nb, (Object)a2);
        cfa2.b = a3;
        return cfa2;
    }
}

