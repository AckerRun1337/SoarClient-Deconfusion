/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import org.lwjgl.input.Keyboard;

public class be
extends en {
    private qna b;
    private int c;
    private int v;
    private ff d;

    public be(qna a2) {
        be a3;
        a3.b = a2;
    }

    @Override
    public void m() {
        be a2;
        a2.r.clear();
        Keyboard.a(true);
        a2.d = new ff(0, n / 2 - 100, e / 4 + 120, xab.a("gui.done", new Object[0]));
        a2.r.add(a2.d);
        a2.b.a(false);
    }

    @Override
    public void y() {
        be a2;
        Keyboard.a(false);
        rmb rmb2 = a2.w.a();
        if (rmb2 != null) {
            rmb2.a(new zic(a2.b.a(), a2.b.z));
        }
        a2.b.a(true);
    }

    @Override
    public void z() {
        be a2;
        ++a2.c;
    }

    @Override
    protected void a(ff a2) throws IOException {
        if (a2.c && a2.b == 0) {
            be a3;
            a3.b.o();
            a3.w.a((en)null);
        }
    }

    @Override
    protected void a(char a2, int a3) throws IOException {
        be a4;
        if (a3 == 200) {
            a4.v = a4.v - 1 & 3;
        }
        if (a3 == 208 || a3 == 28 || a3 == 156) {
            a4.v = a4.v + 1 & 3;
        }
        String string = a4.b.z[a4.v].p();
        if (a3 == 14 && string.length() > 0) {
            string = string.substring(0, string.length() - 1);
        }
        if (wbd.a(a2) && a4.z.a(String.valueOf(string) + a2) <= 90) {
            string = String.valueOf(string) + a2;
        }
        a4.b.z[a4.v] = new gkb(string);
        if (a3 == 1) {
            a4.a(a4.d);
        }
    }

    @Override
    public void a(int a2, int a3, float a4) {
        be a5;
        a5.o();
        a5.p(a5.z, xab.a("sign.edit", new Object[0]), n / 2, 40, 0xFFFFFF);
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        ewa.m();
        ewa.p((float)(n / 2), 0.0f, 50.0f);
        float f2 = 93.75f;
        ewa.o(-f2, -f2, -f2);
        ewa.p(180.0f, 0.0f, 1.0f, 0.0f);
        yd yd2 = a5.b.a();
        if (yd2 == cl.ad) {
            float f3 = (float)(a5.b.y() * 360) / 16.0f;
            ewa.p(f3, 0.0f, 1.0f, 0.0f);
            ewa.p(0.0f, -1.0625f, 0.0f);
        } else {
            int n2 = a5.b.y();
            float f4 = 0.0f;
            if (n2 == 2) {
                f4 = 180.0f;
            }
            if (n2 == 4) {
                f4 = 90.0f;
            }
            if (n2 == 5) {
                f4 = -90.0f;
            }
            ewa.p(f4, 0.0f, 1.0f, 0.0f);
            ewa.p(0.0f, -1.0625f, 0.0f);
        }
        if (a5.c / 6 % 2 == 0) {
            a5.b.l = a5.v;
        }
        ffc.t.a(a5.b, -0.5, -0.75, -0.5, 0.0f);
        a5.b.l = -1;
        ewa.h();
        super.a(a2, a3, a4);
    }
}

