/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 */
import com.google.common.base.Objects;
import java.util.List;

public class cbb {
    private final sa c;
    private final List<ya> v;
    private final int d;

    public cbb(sa a2, List<ya> a3, int a4) {
        cbb a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    public ya a(int a2) {
        cbb a3;
        return a2 >= 0 && a2 < a3.v.size() ? (ya)Objects.firstNonNull((Object)a3.v.get(a2), (Object)bgb.z) : bgb.z;
    }

    public int a() {
        cbb a2;
        return a2.d;
    }
}

