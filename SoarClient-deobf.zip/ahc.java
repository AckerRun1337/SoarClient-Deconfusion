/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ahc {
    private ga b;
    private pfc c;
    private fyc v;
    private String d;

    public ahc() {
        ahc a2;
    }

    public ga a() {
        ahc a2;
        return a2.b;
    }

    public void a(ga a2) {
        a.b = a2;
    }

    public pfc a() {
        ahc a2;
        return a2.c;
    }

    public void a(pfc a2) {
        a.c = a2;
    }

    public fyc a() {
        ahc a2;
        return a2.v;
    }

    public void a(fyc a2) {
        a.v = a2;
    }

    public void a(String a2) {
        a.d = a2;
    }

    public String a() {
        ahc a2;
        return a2.d;
    }
}

