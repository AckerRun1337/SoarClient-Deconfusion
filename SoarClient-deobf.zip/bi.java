/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;

public class bi {
    private static final uh[] l = new uh[]{new uh(zqb.class, 40, 0), new uh(dbc.class, 5, 5), new uh(ynb.class, 20, 0), new uh(gmb.class, 20, 0), new uh(nlb.class, 10, 6), new uh(wtb.class, 5, 5), new uh(eid.class, 5, 5), new uh(ruc.class, 5, 4), new uh(jma.class, 5, 4), new sp(yrb.class, 10, 2), new wh(xg.class, 20, 1)};
    private static List<uh> b;
    private static Class<? extends hm> c;
    static int v;
    private static final oyb d;

    static {
        d = new oyb(null);
    }

    public bi() {
        bi a2;
    }

    public static void p() {
        wcb.a(jma.class, "SHCC");
        wcb.a(yl.class, "SHFC");
        wcb.a(ruc.class, "SH5C");
        wcb.a(ynb.class, "SHLT");
        wcb.a(yrb.class, "SHLi");
        wcb.a(xg.class, "SHPR");
        wcb.a(dbc.class, "SHPH");
        wcb.a(gmb.class, "SHRT");
        wcb.a(nlb.class, "SHRC");
        wcb.a(eid.class, "SHSD");
        wcb.a(sid.class, "SHStart");
        wcb.a(zqb.class, "SHS");
        wcb.a(wtb.class, "SHSSD");
    }

    public static void a() {
        b = Lists.newArrayList();
        uh[] uhArray = l;
        int n2 = l.length;
        int n3 = 0;
        while (n3 < n2) {
            uh uh2 = uhArray[n3];
            uh2.v = 0;
            b.add(uh2);
            ++n3;
        }
        c = null;
    }

    private static /* synthetic */ boolean a() {
        boolean bl2 = false;
        v = 0;
        for (uh uh2 : b) {
            if (uh2.d > 0 && uh2.v < uh2.d) {
                bl2 = true;
            }
            v += uh2.c;
        }
        return bl2;
    }

    private static /* synthetic */ hm a(Class<? extends hm> a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        hm hm2 = null;
        if (a2 == zqb.class) {
            hm2 = zqb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == dbc.class) {
            hm2 = dbc.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == ynb.class) {
            hm2 = ynb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == gmb.class) {
            hm2 = gmb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == nlb.class) {
            hm2 = nlb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == wtb.class) {
            hm2 = wtb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == eid.class) {
            hm2 = eid.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == ruc.class) {
            hm2 = ruc.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == jma.class) {
            hm2 = jma.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == yrb.class) {
            hm2 = yrb.a(a3, a4, a5, a6, a7, a8, a9);
        } else if (a2 == xg.class) {
            hm2 = xg.a(a3, a4, a5, a6, a7, a8, a9);
        }
        return hm2;
    }

    private static /* synthetic */ hm a(sid a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        if (!bi.a()) {
            return null;
        }
        if (c != null) {
            hm hm2 = bi.a(c, a3, a4, a5, a6, a7, a8, a9);
            c = null;
            if (hm2 != null) {
                return hm2;
            }
        }
        int n2 = 0;
        block0: while (n2 < 5) {
            ++n2;
            int n3 = a4.nextInt(v);
            for (uh uh2 : b) {
                if ((n3 -= uh2.c) >= 0) continue;
                if (!uh2.a(a9) || uh2 == a2.c) continue block0;
                hm hm3 = bi.a(uh2.b, a3, a4, a5, a6, a7, a8, a9);
                if (hm3 == null) continue;
                ++uh2.v;
                a2.c = uh2;
                if (!uh2.a()) {
                    b.remove(uh2);
                }
                return hm3;
            }
        }
        uxc uxc2 = yl.a(a3, a4, a5, a6, a7, a8);
        if (uxc2 != null && uxc2.z > 1) {
            return new yl(a9, a4, uxc2, a8);
        }
        return null;
    }

    private static /* synthetic */ ae p(sid a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        if (a9 > 50) {
            return null;
        }
        if (Math.abs(a5 - a2.a().h) <= 112 && Math.abs(a7 - a2.a().l) <= 112) {
            ae ae2 = bi.p(a2, a3, a4, a5, a6, a7, a8, a9 + 1);
            if (ae2 != null) {
                a3.add(ae2);
                a2.d.add(ae2);
            }
            return ae2;
        }
        return null;
    }

    static /* synthetic */ oyb a() {
        return d;
    }

    static /* synthetic */ Class a() {
        return c;
    }

    static /* synthetic */ void a(Class a2) {
        c = a2;
    }
}

