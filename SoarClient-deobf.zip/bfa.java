/*
 * Decompiled with CFR 0.152.
 */
public class bfa
extends ge {
    public bfa() {
        bfa a2;
        a2.h = 1;
        a2.a(md.t);
    }

    @Override
    public boolean a(wfc a2, pm a3, xi a4) {
        if (a4 instanceof bid) {
            bid bid2 = (bid)a4;
            if (!bid2.la() && !bid2.ga()) {
                bid2.r(true);
                bid2.ib.a(bid2, "mob.horse.leather", 0.5f, 1.0f);
                --a2.e;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean a(wfc a2, xi a3, xi a4) {
        bfa a5;
        a5.a(a2, null, a3);
        return true;
    }
}

