/*
 * Decompiled with CFR 0.152.
 */
public interface ab
extends ob {
    public gba a(mnb var1, pm var2);

    public String p();
}

