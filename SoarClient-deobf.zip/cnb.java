/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.Sets;
import java.util.Set;
import java.util.UUID;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cnb
extends zm {
    private static final UUID b = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
    private static final rob c = new rob(b, "Attacking speed boost", 0.15f, 0).a(false);
    private static final Set<yd> v = Sets.newIdentityHashSet();
    private boolean d;

    static {
        v.add(cl.ik);
        v.add(cl.zk);
        v.add(cl.bg);
        v.add(cl.pj);
        v.add(cl.dh);
        v.add(cl.kj);
        v.add(cl.uj);
        v.add(cl.vk);
        v.add(cl.hn);
        v.add(cl.fd);
        v.add(cl.cj);
        v.add(cl.cc);
        v.add(cl.gc);
        v.add(cl.yb);
    }

    public cnb(xga a2) {
        super(a2);
        cnb a3;
        a3.y(0.6f, 2.9f);
        a3.ja = 1.0f;
        a3.s.a(0, new nhd(a3));
        a3.s.a(2, new cwb(a3, 1.0, false));
        a3.s.a(7, new fva(a3, 1.0));
        a3.s.a(8, new yi(a3, pm.class, 8.0f));
        a3.s.a(8, new nia(a3));
        a3.s.a(10, new ytb(a3));
        a3.s.a(11, new nka(a3));
        a3.w.a(1, new kab((sj)a3, false, new Class[0]));
        a3.w.a(2, new wna(a3));
        a3.w.a(3, new iva<isc>(a3, isc.class, 10, true, false, new uq(a3)));
    }

    @Override
    protected void ma() {
        cnb a2;
        super.ma();
        a2.a(prc.l).a(40.0);
        a2.a(prc.v).a(0.3f);
        a2.a(prc.d).a(7.0);
        a2.a(prc.b).a(64.0);
    }

    @Override
    protected void v() {
        cnb a2;
        super.v();
        a2.y.p(16, new Short(0));
        a2.y.p(17, new Byte(0));
        a2.y.p(18, new Byte(0));
    }

    @Override
    public void p(dgb a2) {
        cnb a3;
        super.p(a2);
        ba ba2 = a3.a();
        a2.a("carried", (short)yd.a(ba2.a()));
        a2.a("carriedData", (short)ba2.a().o(ba2));
    }

    @Override
    public void o(dgb a2) {
        cnb a3;
        super.o(a2);
        ba ba2 = a2.a("carried", 8) ? yd.p(a2.a("carried")).a(a2.a("carriedData") & 0xFFFF) : yd.p(a2.a("carried")).a(a2.a("carriedData") & 0xFFFF);
        a3.a(ba2);
    }

    private /* synthetic */ boolean y(pm a2) {
        cnb a3;
        wfc wfc2 = a2.ob.l[3];
        if (wfc2 != null && wfc2.a() == ge.a(cl.cc)) {
            return false;
        }
        tta tta2 = a2.p(1.0f).a();
        tta tta3 = new tta(a3.fb - a2.fb, a3.a().l + (double)(a3.ua / 2.0f) - (a2.zb + (double)a2.o()), a3.db - a2.db);
        double d2 = tta3.a();
        double d3 = tta2.o(tta3 = tta3.a());
        return d3 > 1.0 - 0.025 / d2 ? a2.o(a3) : false;
    }

    @Override
    public float o() {
        return 2.55f;
    }

    @Override
    public void w() {
        cnb a2;
        if (a2.ib.f) {
            int n2 = 0;
            while (n2 < 2) {
                a2.ib.a(wra.j, a2.fb + (a2.oa.nextDouble() - 0.5) * (double)a2.xa, a2.zb + a2.oa.nextDouble() * (double)a2.ua - 0.25, a2.db + (a2.oa.nextDouble() - 0.5) * (double)a2.xa, (a2.oa.nextDouble() - 0.5) * 2.0, -a2.oa.nextDouble(), (a2.oa.nextDouble() - 0.5) * 2.0, new int[0]);
                ++n2;
            }
        }
        a2.j = false;
        super.w();
    }

    @Override
    protected void ba() {
        float f2;
        cnb a2;
        if (a2.b()) {
            a2.a(sy.q, 1.0f);
        }
        if (a2.la() && !a2.d && a2.oa.nextInt(100) == 0) {
            a2.q(false);
        }
        if (a2.ib.j() && (f2 = a2.a(1.0f)) > 0.5f && a2.ib.q(new tp(a2)) && a2.oa.nextFloat() * 30.0f < (f2 - 0.4f) * 2.0f) {
            a2.o((xi)null);
            a2.q(false);
            a2.d = false;
            a2.na();
        }
        super.ba();
    }

    protected boolean na() {
        cnb a2;
        double d2 = a2.fb + (a2.oa.nextDouble() - 0.5) * 64.0;
        double d3 = a2.zb + (double)(a2.oa.nextInt(64) - 32);
        double d4 = a2.db + (a2.oa.nextDouble() - 0.5) * 64.0;
        return a2.y(d2, d3, d4);
    }

    protected boolean z(rj a2) {
        cnb a3;
        tta tta2 = new tta(a3.fb - a2.fb, a3.a().l + (double)(a3.ua / 2.0f) - a2.zb + (double)a2.o(), a3.db - a2.db);
        tta2 = tta2.a();
        double d2 = 16.0;
        double d3 = a3.fb + (a3.oa.nextDouble() - 0.5) * 8.0 - tta2.c * d2;
        double d4 = a3.zb + (double)(a3.oa.nextInt(16) - 8) - tta2.v * d2;
        double d5 = a3.db + (a3.oa.nextDouble() - 0.5) * 8.0 - tta2.d * d2;
        return a3.y(d3, d4, d5);
    }

    protected boolean y(double a2, double a3, double a4) {
        int n2;
        cnb a5;
        double d2 = a5.fb;
        double d3 = a5.zb;
        double d4 = a5.db;
        a5.fb = a2;
        a5.zb = a3;
        a5.db = a4;
        boolean bl2 = false;
        tp tp2 = new tp(a5.fb, a5.zb, a5.db);
        if (a5.ib.l(tp2)) {
            n2 = 0;
            while (n2 == 0 && tp2.p() > 0) {
                tp tp3 = tp2.z();
                yd yd2 = a5.ib.a(tp3).a();
                if (yd2.a().z()) {
                    n2 = 1;
                    continue;
                }
                a5.zb -= 1.0;
                tp2 = tp3;
            }
            if (n2 != 0) {
                super.a(a5.fb, a5.zb, a5.db);
                if (a5.ib.p(a5, a5.a()).isEmpty() && !a5.ib.p(a5.a())) {
                    bl2 = true;
                }
            }
        }
        if (!bl2) {
            a5.z(d2, d3, d4);
            return false;
        }
        n2 = 128;
        int n3 = 0;
        while (n3 < n2) {
            double d5 = (double)n3 / ((double)n2 - 1.0);
            float f2 = (a5.oa.nextFloat() - 0.5f) * 0.2f;
            float f3 = (a5.oa.nextFloat() - 0.5f) * 0.2f;
            float f4 = (a5.oa.nextFloat() - 0.5f) * 0.2f;
            double d6 = d2 + (a5.fb - d2) * d5 + (a5.oa.nextDouble() - 0.5) * (double)a5.xa * 2.0;
            double d7 = d3 + (a5.zb - d3) * d5 + a5.oa.nextDouble() * (double)a5.ua;
            double d8 = d4 + (a5.db - d4) * d5 + (a5.oa.nextDouble() - 0.5) * (double)a5.xa * 2.0;
            a5.ib.a(wra.j, d6, d7, d8, (double)f2, (double)f3, (double)f4, new int[0]);
            ++n3;
        }
        a5.ib.a(d2, d3, d4, "mob.endermen.portal", 1.0f, 1.0f);
        a5.a("mob.endermen.portal", 1.0f, 1.0f);
        return true;
    }

    @Override
    protected String m() {
        cnb a2;
        return a2.la() ? "mob.endermen.scream" : "mob.endermen.idle";
    }

    @Override
    protected String h() {
        return "mob.endermen.hit";
    }

    @Override
    protected String p() {
        return "mob.endermen.death";
    }

    @Override
    protected ge a() {
        return sxa.bb;
    }

    @Override
    protected void a(boolean a2, int a3) {
        cnb a4;
        ge ge2 = a4.a();
        if (ge2 != null) {
            int n2 = a4.oa.nextInt(2 + a3);
            int n3 = 0;
            while (n3 < n2) {
                a4.a(ge2, 1);
                ++n3;
            }
        }
    }

    public void a(ba a2) {
        cnb a3;
        a3.y.a(16, Short.valueOf((short)(yd.y(a2) & 0xFFFF)));
    }

    public ba a() {
        cnb a2;
        return yd.p(a2.y.a(16) & 0xFFFF);
    }

    @Override
    public boolean a(sy a2, float a3) {
        cnb a4;
        if (a4.a(a2)) {
            return false;
        }
        if (a2.a() == null || !(a2.a() instanceof isc)) {
            if (!a4.ib.f) {
                a4.q(true);
            }
            if (a2 instanceof cp && a2.a() instanceof pm) {
                if (a2.a() instanceof xj && ((xj)a2.a()).oa.a()) {
                    a4.q(false);
                } else {
                    a4.d = true;
                }
            }
            if (a2 instanceof jx) {
                a4.d = false;
                int n2 = 0;
                while (n2 < 64) {
                    if (a4.na()) {
                        return true;
                    }
                    ++n2;
                }
                return false;
            }
        }
        boolean bl2 = super.a(a2, a3);
        if (a2.x() && a4.oa.nextInt(10) != 0) {
            a4.na();
        }
        return bl2;
    }

    public boolean la() {
        cnb a2;
        return a2.y.a(18) > 0;
    }

    public void q(boolean a2) {
        cnb a3;
        a3.y.a(18, Byte.valueOf((byte)(a2 ? 1 : 0)));
    }

    static /* synthetic */ rob a() {
        return c;
    }

    static /* synthetic */ boolean a(cnb a2, pm a3) {
        return a2.y(a3);
    }

    static /* synthetic */ void a(cnb a2, boolean a3) {
        a2.d = a3;
    }

    static /* synthetic */ Set a() {
        return v;
    }
}

