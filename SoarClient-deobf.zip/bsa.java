/*
 * Decompiled with CFR 0.152.
 */
import java.util.Properties;
import net.optifine.util.\u5c2d\u837b\u679a\u8f44\u67a0\u4faf\u7aea\u6e8c\u6a4b\u8d70\u932f\u77ef\u6749\u96e8\u626e\u515c\u92f3\u830e\u7984\u5de8\u6d66\u58a8\u5553\u9edb\u4f4e\u7a17\u4fb6\u5404\u970a\u6d45\u4e19\u6291\u67ff\u5446\u51b7\u50cd\u6ce1\u6f2c\u9084\u7d4c;
import net.optifine.util.\u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c;

public class bsa {
    private String g = null;
    private wmc k = null;
    private int x;
    private int[] t = null;
    private wmc[] p = null;
    private int[] s = null;
    private nk[] w = null;
    private grb i = null;
    private grb n = null;
    private boolean e = false;
    private ada r = null;
    public int[] f = null;
    public int h = 1;
    private zva[] z = null;
    private kja[] l = null;
    private Boolean b = null;
    private grb c = null;
    private grb v = null;
    private epc[] d = null;

    public bsa(Properties a2, String a3, wmc a4, int a5, String a6, lk a7) {
        String string;
        bsa a8;
        a8.g = a3;
        a8.k = a4;
        a8.x = a5;
        a8.t = a7.o(a6);
        a8.s = a7.o(a2.getProperty("weights." + a5));
        a8.w = a7.a(a2.getProperty("biomes." + a5));
        a8.i = a7.a(a2.getProperty("heights." + a5));
        if (a8.i == null) {
            a8.i = a8.a(a2, a5);
        }
        if ((string = a2.getProperty("health." + a5)) != null) {
            a8.e = string.contains("%");
            string = string.replace("%", "");
            a8.n = a7.a(string);
        }
        a8.r = a7.a("name", a2.getProperty("name." + a5));
        a8.z = a7.a(a2.getProperty("professions." + a5));
        a8.l = a7.a(a2.getProperty("collarColors." + a5), "collar color", lk.c);
        a8.b = a7.a(a2.getProperty("baby." + a5));
        a8.c = a7.a(a2.getProperty("moonPhase." + a5));
        a8.v = a7.a(a2.getProperty("dayTime." + a5));
        a8.d = a7.a(a2.getProperty("weather." + a5), "weather." + a5, (epc[])null);
    }

    private /* synthetic */ grb a(Properties a2, int a3) {
        String string = a2.getProperty("minHeight." + a3);
        String string2 = a2.getProperty("maxHeight." + a3);
        if (string == null && string2 == null) {
            return null;
        }
        int n2 = 0;
        if (string != null && (n2 = xfc.a(string, -1)) < 0) {
            xfc.z("Invalid minHeight: " + string);
            return null;
        }
        int n3 = 256;
        if (string2 != null && (n3 = xfc.a(string2, -1)) < 0) {
            xfc.z("Invalid maxHeight: " + string2);
            return null;
        }
        if (n3 < 0) {
            xfc.z("Invalid minHeight, maxHeight: " + string + ", " + string2);
            return null;
        }
        grb grb2 = new grb();
        grb2.a(new qoa(n2, n3));
        return grb2;
    }

    public boolean a(String a2) {
        bsa a3;
        if (a3.t != null && a3.t.length != 0) {
            int n2;
            if (a3.p != null) {
                return true;
            }
            a3.p = new wmc[a3.t.length];
            boolean bl2 = a3.g.startsWith("mcpatcher/mob/");
            wmc wmc2 = bpb.a(a3.k, bl2);
            if (wmc2 == null) {
                xfc.z("Invalid path: " + a3.k.p());
                return false;
            }
            int n3 = 0;
            while (n3 < a3.p.length) {
                n2 = a3.t[n3];
                if (n2 <= 1) {
                    a3.p[n3] = a3.k;
                } else {
                    wmc wmc3 = bpb.a(wmc2, n2);
                    if (wmc3 == null) {
                        xfc.z("Invalid path: " + a3.k.p());
                        return false;
                    }
                    if (!xfc.p(wmc3)) {
                        xfc.z("Texture not found: " + wmc3.p());
                        return false;
                    }
                    a3.p[n3] = wmc3;
                }
                ++n3;
            }
            if (a3.s != null) {
                if (a3.s.length > a3.p.length) {
                    xfc.z("More weights defined than skins, trimming weights: " + a2);
                    int[] nArray = new int[a3.p.length];
                    System.arraycopy(a3.s, 0, nArray, 0, nArray.length);
                    a3.s = nArray;
                }
                if (a3.s.length < a3.p.length) {
                    xfc.z("Less weights defined than skins, expanding weights: " + a2);
                    int[] nArray = new int[a3.p.length];
                    System.arraycopy(a3.s, 0, nArray, 0, a3.s.length);
                    n2 = \u5c2d\u837b\u679a\u8f44\u67a0\u4faf\u7aea\u6e8c\u6a4b\u8d70\u932f\u77ef\u6749\u96e8\u626e\u515c\u92f3\u830e\u7984\u5de8\u6d66\u58a8\u5553\u9edb\u4f4e\u7a17\u4fb6\u5404\u970a\u6d45\u4e19\u6291\u67ff\u5446\u51b7\u50cd\u6ce1\u6f2c\u9084\u7d4c.p(a3.s);
                    int n4 = a3.s.length;
                    while (n4 < nArray.length) {
                        nArray[n4] = n2;
                        ++n4;
                    }
                    a3.s = nArray;
                }
                a3.f = new int[a3.s.length];
                int n5 = 0;
                n2 = 0;
                while (n2 < a3.s.length) {
                    if (a3.s[n2] < 0) {
                        xfc.z("Invalid weight: " + a3.s[n2]);
                        return false;
                    }
                    a3.f[n2] = n5 += a3.s[n2];
                    ++n2;
                }
                a3.h = n5;
                if (a3.h <= 0) {
                    xfc.z("Invalid sum of all weights: " + n5);
                    a3.h = 1;
                }
            }
            if (a3.z == lk.b) {
                xfc.z("Invalid professions or careers: " + a2);
                return false;
            }
            if (a3.l == lk.c) {
                xfc.z("Invalid collar colors: " + a2);
                return false;
            }
            return true;
        }
        xfc.z("Invalid skins for rule: " + a3.x);
        return false;
    }

    public boolean a(u a2) {
        epc epc2;
        rj rj2;
        rj rj3;
        dj dj2;
        rj rj4;
        int n2;
        Object object;
        bsa a3;
        if (a3.w != null && !nqa.a(a2.a(), a3.w)) {
            return false;
        }
        if (a3.i != null && (object = a2.a()) != null && !a3.i.a(((vx)object).p())) {
            return false;
        }
        if (a3.n != null) {
            int n3 = a2.p();
            if (a3.e && (n2 = a2.a()) > 0) {
                n3 = (int)((double)(n3 * 100) / (double)n2);
            }
            if (!a3.n.a(n3)) {
                return false;
            }
        }
        if (a3.r != null && !a3.r.a((String)(object = a2.a()))) {
            return false;
        }
        if (a3.z != null && a2 instanceof ii && (rj4 = ((ii)(object = (ii)a2)).a()) instanceof tfa) {
            dj2 = (tfa)rj4;
            int n4 = ((tfa)dj2).e();
            int n5 = xe.a((Object)dj2, xe.ac, -1);
            if (n4 < 0 || n5 < 0) {
                return false;
            }
            boolean bl2 = false;
            int n6 = 0;
            while (n6 < a3.z.length) {
                zva zva2 = a3.z[n6];
                if (zva2.a(n4, n5)) {
                    bl2 = true;
                    break;
                }
                ++n6;
            }
            if (!bl2) {
                return false;
            }
        }
        if (a3.l != null && a2 instanceof ii && (rj3 = ((ii)(object = (ii)a2)).a()) instanceof ilc) {
            dj2 = (ilc)rj3;
            if (!((efb)dj2).na()) {
                return false;
            }
            kja kja2 = ((ilc)dj2).a();
            if (!xfc.p(kja2, a3.l)) {
                return false;
            }
        }
        if (a3.b != null && a2 instanceof ii && (rj2 = ((ii)(object = (ii)a2)).a()) instanceof dj && (dj2 = (dj)rj2).ga() != a3.b.booleanValue()) {
            return false;
        }
        if (a3.c != null && (object = xfc.a().ab) != null && !a3.c.a(n2 = ((xga)object).x())) {
            return false;
        }
        if (a3.v != null && (object = xfc.a().ab) != null && !a3.v.a(n2 = (int)((xga)object).a().y())) {
            return false;
        }
        return a3.d == null || (object = xfc.a().ab) == null || \u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c.a((Object[])a3.d, (Object)(epc2 = epc.a((xga)object, 0.0f)));
    }

    public wmc a(wmc a2, int a3) {
        bsa a4;
        if (a4.p != null && a4.p.length != 0) {
            int n2 = 0;
            if (a4.s == null) {
                n2 = a3 % a4.p.length;
            } else {
                int n3 = a3 % a4.h;
                int n4 = 0;
                while (n4 < a4.f.length) {
                    if (a4.f[n4] > n3) {
                        n2 = n4;
                        break;
                    }
                    ++n4;
                }
            }
            return a4.p[n2];
        }
        return a2;
    }
}

