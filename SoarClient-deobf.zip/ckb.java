/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class ckb
extends nk {
    private boolean c;
    private acc v = new acc();
    private era d = new era(4);

    public ckb(int a2, boolean a3) {
        super(a2);
        ckb a4;
        a4.c = a3;
        if (a3) {
            a4.q = cl.kn.a();
        }
        a4.e.clear();
    }

    @Override
    public void a(xga a2, Random a3, tp a4) {
        ckb a5;
        if (a5.c) {
            int n2;
            int n3;
            int n4 = 0;
            while (n4 < 3) {
                n3 = a3.nextInt(16) + 8;
                n2 = a3.nextInt(16) + 8;
                a5.v.a(a2, a3, a2.o(a4.a(n3, 0, n2)));
                ++n4;
            }
            n4 = 0;
            while (n4 < 2) {
                n3 = a3.nextInt(16) + 8;
                n2 = a3.nextInt(16) + 8;
                a5.d.a(a2, a3, a2.o(a4.a(n3, 0, n2)));
                ++n4;
            }
        }
        super.a(a2, a3, a4);
    }

    @Override
    public rg a(Random a2) {
        return new cs(false);
    }

    @Override
    protected nk p(int a2) {
        ckb a3;
        nk nk2 = new ckb(a2, true).a(0xD2FFFF, true).a(String.valueOf(a3.m) + " Spikes").p().a(0.0f, 0.5f).a(new yac(a3.x + 0.1f, a3.t + 0.1f));
        nk2.x = a3.x + 0.3f;
        nk2.t = a3.t + 0.4f;
        return nk2;
    }
}

