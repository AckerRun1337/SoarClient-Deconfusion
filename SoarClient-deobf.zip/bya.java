/*
 * Decompiled with CFR 0.152.
 */
public class bya
extends nk {
    public bya(int a2) {
        super(a2);
        bya a3;
        a3.n.clear();
        a3.e.clear();
        a3.r.clear();
        a3.f.clear();
        a3.n.add(new bz(lv.class, 50, 4, 4));
        a3.n.add(new bz(cda.class, 100, 4, 4));
        a3.n.add(new bz(oma.class, 1, 4, 4));
    }
}

