/*
 * Decompiled with CFR 0.152.
 */
import java.util.UUID;

public class cda
extends uea {
    private static final UUID l = UUID.fromString("49455A49-7EC5-45BA-B886-3B90B23A1718");
    private static final rob b = new rob(l, "Attacking speed boost", 0.05, 0).a(false);
    private int c;
    private int v;
    private UUID d;

    public cda(xga a2) {
        super(a2);
        cda a3;
        a3.m = true;
    }

    @Override
    public void p(xi a2) {
        cda a3;
        super.p(a2);
        if (a2 != null) {
            a3.d = a2.a();
        }
    }

    @Override
    protected void za() {
        cda a2;
        a2.w.a(1, new lya(a2));
        a2.w.a(2, new ild(a2));
    }

    @Override
    protected void ma() {
        cda a2;
        super.ma();
        a2.a(f).a(0.0);
        a2.a(prc.v).a(0.23f);
        a2.a(prc.d).a(5.0);
    }

    @Override
    public void n() {
        cda a2;
        super.n();
    }

    @Override
    protected void ba() {
        cda a2;
        pb pb2 = a2.a(prc.v);
        if (a2.bb()) {
            if (!a2.ga() && !pb2.a(b)) {
                pb2.p(b);
            }
            --a2.c;
        } else if (pb2.a(b)) {
            pb2.a(b);
        }
        if (a2.v > 0 && --a2.v == 0) {
            a2.a("mob.zombiepig.zpigangry", a2.d() * 2.0f, ((a2.oa.nextFloat() - a2.oa.nextFloat()) * 0.2f + 1.0f) * 1.8f);
        }
        if (a2.c > 0 && a2.d != null && a2.o() == null) {
            pm pm2 = a2.ib.a(a2.d);
            a2.p((xi)pm2);
            a2.ka = pm2;
            a2.ha = a2.q();
        }
        super.ba();
    }

    @Override
    public boolean ea() {
        cda a2;
        return a2.ib.a() != ncc.f;
    }

    @Override
    public boolean ca() {
        cda a2;
        return a2.ib.a(a2.a(), (rj)a2) && a2.ib.p(a2, a2.a()).isEmpty() && !a2.ib.p(a2.a());
    }

    @Override
    public void p(dgb a2) {
        cda a3;
        super.p(a2);
        a2.a("Anger", (short)a3.c);
        if (a3.d != null) {
            a2.a("HurtBy", a3.d.toString());
        } else {
            a2.a("HurtBy", "");
        }
    }

    @Override
    public void o(dgb a2) {
        cda a3;
        super.o(a2);
        a3.c = a2.a("Anger");
        String string = a2.a("HurtBy");
        if (string.length() > 0) {
            a3.d = UUID.fromString(string);
            pm pm2 = a3.ib.a(a3.d);
            a3.p((xi)pm2);
            if (pm2 != null) {
                a3.ka = pm2;
                a3.ha = a3.q();
            }
        }
    }

    @Override
    public boolean a(sy a2, float a3) {
        cda a4;
        if (a4.a(a2)) {
            return false;
        }
        rj rj2 = a2.a();
        if (rj2 instanceof pm) {
            a4.m(rj2);
        }
        return super.a(a2, a3);
    }

    private /* synthetic */ void m(rj a2) {
        cda a3;
        a3.c = 400 + a3.oa.nextInt(400);
        a3.v = a3.oa.nextInt(40);
        if (a2 instanceof xi) {
            a3.p((xi)a2);
        }
    }

    public boolean bb() {
        cda a2;
        return a2.c > 0;
    }

    @Override
    protected String m() {
        return "mob.zombiepig.zpig";
    }

    @Override
    protected String h() {
        return "mob.zombiepig.zpighurt";
    }

    @Override
    protected String p() {
        return "mob.zombiepig.zpigdeath";
    }

    @Override
    protected void a(boolean a2, int a3) {
        cda a4;
        int n2 = a4.oa.nextInt(2 + a3);
        int n3 = 0;
        while (n3 < n2) {
            a4.a(sxa.tb, 1);
            ++n3;
        }
        n2 = a4.oa.nextInt(2 + a3);
        n3 = 0;
        while (n3 < n2) {
            a4.a(sxa.db, 1);
            ++n3;
        }
    }

    @Override
    public boolean a(pm a2) {
        return false;
    }

    @Override
    protected void ka() {
        cda a2;
        a2.a(sxa.ve, 1);
    }

    @Override
    protected void p(th a2) {
        cda a3;
        a3.p(0, new wfc(sxa.ei));
    }

    @Override
    public bj a(th a2, bj a3) {
        cda a4;
        super.a(a2, a3);
        a4.r(false);
        return a3;
    }

    static /* synthetic */ void a(cda a2, rj a3) {
        a2.m(a3);
    }
}

