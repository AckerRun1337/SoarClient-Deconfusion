/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

public class cz
implements o<vi> {
    private int l;
    private int b;
    private int c;
    private int v;
    private int d;

    public cz() {
        cz a2;
    }

    public cz(rj a2) {
        cz a3;
        a3.l = a2.h();
        a3.b = smb.o(a2.fb * 32.0);
        a3.c = smb.o(a2.zb * 32.0);
        a3.v = smb.o(a2.db * 32.0);
        if (a2 instanceof gea) {
            a3.d = 1;
        }
    }

    @Override
    public void p(io a2) throws IOException {
        a.l = a2.c();
        a.d = a2.a();
        a.b = a2.y();
        a.c = a2.y();
        a.v = a2.y();
    }

    @Override
    public void a(io a2) throws IOException {
        cz a3;
        a2.a(a3.l);
        a2.x(a3.d);
        a2.y(a3.b);
        a2.y(a3.c);
        a2.y(a3.v);
    }

    @Override
    public void a(vi a2) {
        cz a3;
        a2.a(a3);
    }

    public int z() {
        cz a2;
        return a2.l;
    }

    public int y() {
        cz a2;
        return a2.b;
    }

    public int o() {
        cz a2;
        return a2.c;
    }

    public int p() {
        cz a2;
        return a2.v;
    }

    public int a() {
        cz a2;
        return a2.d;
    }
}

