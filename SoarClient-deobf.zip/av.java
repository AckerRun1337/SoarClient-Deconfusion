/*
 * Decompiled with CFR 0.152.
 */
import java.util.ArrayList;

public class av
extends ku {
    public av() {
        super("MainLobby", "soar/mods/quickplay/MainLobby.png");
        av a2;
    }

    @Override
    public void a() {
        av a2;
        ArrayList<tja> arrayList = new ArrayList<tja>();
        arrayList.add(new tja("Lobby", "/lobby main"));
        a2.a(arrayList);
    }
}

