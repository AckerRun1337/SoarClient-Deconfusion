/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cub
implements o<vi> {
    private int c;
    private int v;
    private wfc d;

    public cub() {
        cub a2;
    }

    public cub(int a2, int a3, wfc a4) {
        cub a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4 == null ? null : a4.a();
    }

    @Override
    public void p(io a2) throws IOException {
        a.c = a2.c();
        a.v = a2.a();
        a.d = a2.a();
    }

    @Override
    public void a(io a2) throws IOException {
        cub a3;
        a2.a(a3.c);
        a2.j(a3.v);
        a2.a(a3.d);
    }

    @Override
    public void a(vi a2) {
        cub a3;
        a2.a(a3);
    }

    public wfc a() {
        cub a2;
        return a2.d;
    }

    public int p() {
        cub a2;
        return a2.c;
    }

    public int a() {
        cub a2;
        return a2.v;
    }
}

