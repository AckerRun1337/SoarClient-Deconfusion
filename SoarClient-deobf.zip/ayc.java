/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Lists
 *  com.google.common.hash.Hashing
 *  com.google.common.io.Files
 *  com.google.common.util.concurrent.FutureCallback
 *  com.google.common.util.concurrent.Futures
 *  com.google.common.util.concurrent.ListenableFuture
 *  com.google.common.util.concurrent.SettableFuture
 *  org.apache.commons.io.FileUtils
 *  org.apache.commons.io.comparator.LastModifiedFileComparator
 *  org.apache.commons.io.filefilter.IOFileFilter
 *  org.apache.commons.io.filefilter.TrueFileFilter
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.hash.Hashing;
import com.google.common.io.Files;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ayc {
    private static final Logger n = LogManager.getLogger();
    private static final FileFilter e = new gyb();
    private final File r;
    public final pa f;
    private final File h;
    public final gn z;
    private pa l;
    private final ReentrantLock b = new ReentrantLock();
    private ListenableFuture<Object> c;
    private List<vob> v = Lists.newArrayList();
    public List<vob> d = Lists.newArrayList();

    public ayc(File a2, File a3, pa a4, gn a5, tib a6) {
        ayc a7;
        a7.r = a2;
        a7.h = a3;
        a7.f = a4;
        a7.z = a5;
        a7.y();
        a7.o();
        Iterator<String> iterator = a6.lo.iterator();
        block0: while (iterator.hasNext()) {
            String string = iterator.next();
            for (vob vob2 : a7.v) {
                if (!vob2.p().equals(string)) continue;
                if (vob2.a() == 1 || a6.zl.contains(vob2.p())) {
                    a7.d.add(vob2);
                    continue block0;
                }
                iterator.remove();
                n.warn("Removed selected resource pack {} because it's no longer compatible", new Object[]{vob2.p()});
            }
        }
    }

    private /* synthetic */ void y() {
        ayc a2;
        if (a2.r.exists()) {
            if (!(a2.r.isDirectory() || a2.r.delete() && a2.r.mkdirs())) {
                n.warn("Unable to recreate resourcepack folder, it exists but is not a directory: " + a2.r);
            }
        } else if (!a2.r.mkdirs()) {
            n.warn("Unable to create resourcepack folder: " + a2.r);
        }
    }

    private /* synthetic */ List<File> o() {
        ayc a2;
        return a2.r.isDirectory() ? Arrays.asList(a2.r.listFiles(e)) : Collections.emptyList();
    }

    public void o() {
        ayc a2;
        HashMap<Integer, vob> hashMap = new HashMap<Integer, vob>();
        for (vob vob2 : a2.p()) {
            hashMap.put(vob2.hashCode(), vob2);
        }
        LinkedHashSet<vob> linkedHashSet = new LinkedHashSet<vob>();
        for (File file : a2.o()) {
            ayc ayc2 = a2;
            ayc2.getClass();
            vob vob3 = new vob(ayc2, file, null);
            int n2 = vob3.hashCode();
            if (!hashMap.containsKey(n2)) {
                try {
                    vob3.p();
                    linkedHashSet.add(vob3);
                }
                catch (Exception exception) {
                    linkedHashSet.remove(vob3);
                }
                continue;
            }
            linkedHashSet.add((vob)hashMap.get(n2));
        }
        for (vob vob4 : hashMap.values()) {
            if (linkedHashSet.contains(vob4)) continue;
            vob4.a();
        }
        a2.v = new ArrayList<vob>(linkedHashSet);
    }

    public List<vob> p() {
        ayc a2;
        return ImmutableList.copyOf(a2.v);
    }

    public List<vob> a() {
        ayc a2;
        return ImmutableList.copyOf(a2.d);
    }

    public void a(List<vob> a2) {
        ayc a3;
        a3.d.clear();
        a3.d.addAll(a2);
    }

    public File a() {
        ayc a2;
        return a2.r;
    }

    public ListenableFuture<Object> a(String a2, String a3) {
        ayc a4;
        String string = a3.matches("^[a-f0-9]{40}$") ? a3 : "legacy";
        File file = new File(a4.h, string);
        a4.b.lock();
        try {
            ListenableFuture<Object> listenableFuture;
            ListenableFuture<Object> listenableFuture2;
            Object object;
            a4.a();
            if (file.exists() && a3.length() == 40) {
                block8: {
                    ListenableFuture<Object> listenableFuture3;
                    ListenableFuture<Object> listenableFuture4;
                    object = Hashing.sha1().hashBytes(Files.toByteArray((File)file)).toString();
                    if (!((String)object).equals(a3)) break block8;
                    ListenableFuture<Object> listenableFuture5 = listenableFuture4 = (listenableFuture3 = a4.a(file));
                    return listenableFuture5;
                }
                try {
                    n.warn("File " + file + " had wrong hash (expected " + a3 + ", found " + (String)object + "). Deleting it.");
                    FileUtils.deleteQuietly((File)file);
                }
                catch (IOException iOException) {
                    n.warn("File " + file + " couldn't be hashed. Deleting it.", (Throwable)iOException);
                    FileUtils.deleteQuietly((File)file);
                }
            }
            a4.p();
            object = new oba();
            Map<String, String> map = oj.a();
            oj oj2 = oj.a();
            Futures.getUnchecked(oj2.a(new rea(a4, oj2, (oba)object)));
            SettableFuture settableFuture = SettableFuture.create();
            a4.c = otc.a(file, a2, map, 0x3200000, (z)object, oj2.a());
            Futures.addCallback(a4.c, (FutureCallback)new czc(a4, file, settableFuture));
            ListenableFuture<Object> listenableFuture6 = listenableFuture2 = (listenableFuture = a4.c);
            return listenableFuture6;
        }
        finally {
            a4.b.unlock();
        }
    }

    private /* synthetic */ void p() {
        ayc a2;
        ArrayList arrayList = Lists.newArrayList((Iterable)FileUtils.listFiles((File)a2.h, (IOFileFilter)TrueFileFilter.TRUE, null));
        Collections.sort(arrayList, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        int n2 = 0;
        if (!a2.h.exists()) {
            a2.h.mkdirs();
        }
        for (File file : arrayList) {
            if (n2++ < 10) continue;
            n.info("Deleting old server resource pack " + file.getName());
            FileUtils.deleteQuietly((File)file);
        }
    }

    public ListenableFuture<Object> a(File a2) {
        a.l = new ogc(a2);
        return oj.a().a();
    }

    public pa a() {
        ayc a2;
        return a2.l;
    }

    public void a() {
        ayc a2;
        a2.b.lock();
        try {
            if (a2.c != null) {
                a2.c.cancel(true);
            }
            a2.c = null;
            if (a2.l != null) {
                a2.l = null;
                oj.a().a();
            }
        }
        finally {
            a2.b.unlock();
        }
    }
}

