/*
 * Decompiled with CFR 0.152.
 */
public class aqb
extends it {
    public aqb(ll<?> a2) {
        super(a2);
        aqb a3;
    }

    @Override
    protected void a() {
        a.e = new aqa(0.5f, 0.0f, true);
        a.r = new aqa(1.0f, 0.0f, true);
    }
}

