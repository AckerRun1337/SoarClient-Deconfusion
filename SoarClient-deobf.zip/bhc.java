/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 */
import com.google.common.base.Function;

public class bhc
extends uib {
    public bhc(yd a2, yd a3, Function<wfc, String> a4) {
        super(a2, a3, a4);
        bhc a5;
    }

    @Override
    public int a(wfc a2, int a3) {
        bhc a4;
        eed eed2 = eed.a(a2.y());
        return eed2 != eed.r && eed2 != eed.f ? super.a(a2, a3) : iwa.a(0.5, 1.0);
    }
}

