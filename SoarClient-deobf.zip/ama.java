/*
 * Decompiled with CFR 0.152.
 */
import java.lang.reflect.Constructor;
import net.optifine.util.\u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ama
implements ra {
    private jfa b = null;
    private Class[] c = null;
    private boolean v = false;
    private Constructor d = null;

    public ama(jfa a2, Class[] a3) {
        ama a4;
        a4.b = a2;
        a4.c = a3;
        jxb.a(a4);
    }

    public Constructor a() {
        ama a2;
        if (a2.v) {
            return a2.d;
        }
        a2.v = true;
        Class clazz = a2.b.a();
        if (clazz == null) {
            return null;
        }
        try {
            a2.d = ama.a(clazz, a2.c);
            if (a2.d == null) {
                xr.y("(Reflector) Constructor not present: " + clazz.getName() + ", params: " + \u7f6b\u6953\u73e0\u66fd\u4ffa\u75e9\u69cd\u6e08\u68a7\u5a41\u649a\u507d\u7a84\u66fd\u7701\u90a6\u91dd\u7a84\u5270\u6cc1\u633a\u4e09\u732b\u5305\u6253\u4e5f\u6c70\u98a8\u6b8a\u5fb3\u541b\u5352\u6c70\u5e3d\u745e\u86e4\u518d\u8a1f\u85af\u608c.a(a2.c));
            }
            if (a2.d != null) {
                a2.d.setAccessible(true);
            }
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return a2.d;
    }

    private static /* synthetic */ Constructor a(Class a2, Class[] a3) {
        Constructor<?>[] constructorArray = a2.getDeclaredConstructors();
        int n2 = 0;
        while (n2 < constructorArray.length) {
            Constructor<?> constructor = constructorArray[n2];
            Class[] classArray = constructor.getParameterTypes();
            if (xe.a(a3, classArray)) {
                return constructor;
            }
            ++n2;
        }
        return null;
    }

    public boolean a() {
        ama a2;
        return a2.v ? a2.d != null : a2.a() != null;
    }

    public void p() {
        a.v = true;
        a.d = null;
    }

    public Object a(Object ... a2) {
        ama a3;
        return xe.a(a3, a2);
    }

    @Override
    public void a() {
        ama a2;
        Constructor constructor = a2.a();
    }
}

