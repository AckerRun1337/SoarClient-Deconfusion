/*
 * Decompiled with CFR 0.152.
 */
import java.util.concurrent.Callable;

class cj
implements Callable<String> {
    private final /* synthetic */ nk d;

    cj(nk a2) {
        cj a3;
        a3.d = a2;
    }

    public String a() throws Exception {
        cj a2;
        return String.valueOf(a2.d);
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        cj a2;
        return a2.a();
    }
}

