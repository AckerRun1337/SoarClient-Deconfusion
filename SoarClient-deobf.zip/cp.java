/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cp
extends sy {
    protected rj v;
    private boolean d = false;

    public cp(String a2, rj a3) {
        super(a2);
        cp a4;
        a4.v = a3;
    }

    @Override
    public cp a() {
        cp a2;
        a2.d = true;
        return a2;
    }

    public boolean d() {
        cp a2;
        return a2.d;
    }

    @Override
    public rj a() {
        cp a2;
        return a2.v;
    }

    @Override
    public ga a(xi a2) {
        cp a3;
        wfc wfc2 = a3.v instanceof xi ? ((xi)a3.v).a() : null;
        String string = "death.attack." + (String)a3.d;
        String string2 = String.valueOf(string) + ".item";
        return wfc2 != null && wfc2.j() && bwa.a(string2) ? new klb(string2, a2.a(), a3.v.a(), wfc2.a()) : new klb(string, a2.a(), a3.v.a());
    }

    @Override
    public boolean o() {
        cp a2;
        return a2.v != null && a2.v instanceof xi && !(a2.v instanceof pm);
    }
}

