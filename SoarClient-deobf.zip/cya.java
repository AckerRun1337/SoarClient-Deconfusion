/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.concurrent.Callable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cya {
    private final hna b;
    private final String c;
    private final List<uzc> v = Lists.newArrayList();
    private StackTraceElement[] d = new StackTraceElement[0];

    public cya(hna a2, String a3) {
        cya a4;
        a4.b = a2;
        a4.c = a3;
    }

    public static String a(double a2, double a3, double a4) {
        return String.format("%.2f,%.2f,%.2f - %s", a2, a3, a4, cya.a(new tp(a2, a3, a4)));
    }

    public static String a(tp a2) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10 = a2.o();
        int n11 = a2.p();
        int n12 = a2.a();
        StringBuilder stringBuilder = new StringBuilder();
        try {
            stringBuilder.append(String.format("World: (%d,%d,%d)", n10, n11, n12));
        }
        catch (Throwable throwable) {
            stringBuilder.append("(Error finding world loc)");
        }
        stringBuilder.append(", ");
        try {
            int n13 = n10 >> 4;
            n9 = n12 >> 4;
            n8 = n10 & 0xF;
            n7 = n11 >> 4;
            n6 = n12 & 0xF;
            n5 = n13 << 4;
            n4 = n9 << 4;
            n3 = (n13 + 1 << 4) - 1;
            n2 = (n9 + 1 << 4) - 1;
            stringBuilder.append(String.format("Chunk: (at %d,%d,%d in %d,%d; contains blocks %d,0,%d to %d,255,%d)", n8, n7, n6, n13, n9, n5, n4, n3, n2));
        }
        catch (Throwable throwable) {
            stringBuilder.append("(Error finding chunk loc)");
        }
        stringBuilder.append(", ");
        try {
            int n14 = n10 >> 9;
            n9 = n12 >> 9;
            n8 = n14 << 5;
            n7 = n9 << 5;
            n6 = (n14 + 1 << 5) - 1;
            n5 = (n9 + 1 << 5) - 1;
            n4 = n14 << 9;
            n3 = n9 << 9;
            n2 = (n14 + 1 << 9) - 1;
            int n15 = (n9 + 1 << 9) - 1;
            stringBuilder.append(String.format("Region: (%d,%d; contains chunks %d,%d to %d,%d, blocks %d,0,%d to %d,255,%d)", n14, n9, n8, n7, n6, n5, n4, n3, n2, n15));
        }
        catch (Throwable throwable) {
            stringBuilder.append("(Error finding world loc)");
        }
        return stringBuilder.toString();
    }

    public void a(String a2, Callable<String> a3) {
        cya a4;
        try {
            a4.a(a2, a3.call());
        }
        catch (Throwable throwable) {
            a4.a(a2, throwable);
        }
    }

    public void a(String a2, Object a3) {
        cya a4;
        a4.v.add(new uzc(a2, a3));
    }

    public void a(String a2, Throwable a3) {
        cya a4;
        a4.a(a2, (Object)a3);
    }

    public int a(int a2) {
        cya a3;
        StackTraceElement[] stackTraceElementArray = Thread.currentThread().getStackTrace();
        if (stackTraceElementArray.length <= 0) {
            return 0;
        }
        a3.d = new StackTraceElement[stackTraceElementArray.length - 3 - a2];
        System.arraycopy(stackTraceElementArray, 3 + a2, a3.d, 0, a3.d.length);
        return a3.d.length;
    }

    public boolean a(StackTraceElement a2, StackTraceElement a3) {
        cya a4;
        if (a4.d.length != 0 && a2 != null) {
            StackTraceElement stackTraceElement = a4.d[0];
            if (stackTraceElement.isNativeMethod() == a2.isNativeMethod() && stackTraceElement.getClassName().equals(a2.getClassName()) && stackTraceElement.getFileName().equals(a2.getFileName()) && stackTraceElement.getMethodName().equals(a2.getMethodName())) {
                if (a3 != null != a4.d.length > 1) {
                    return false;
                }
                if (a3 != null && !a4.d[1].equals(a3)) {
                    return false;
                }
                a4.d[0] = a2;
                return true;
            }
            return false;
        }
        return false;
    }

    public void a(int a2) {
        cya a3;
        StackTraceElement[] stackTraceElementArray = new StackTraceElement[a3.d.length - a2];
        System.arraycopy(a3.d, 0, stackTraceElementArray, 0, stackTraceElementArray.length);
        a3.d = stackTraceElementArray;
    }

    public void a(StringBuilder a2) {
        cya a3;
        a2.append("-- ").append(a3.c).append(" --\n");
        a2.append("Details:");
        for (uzc object : a3.v) {
            a2.append("\n\t");
            a2.append(object.p());
            a2.append(": ");
            a2.append(object.a());
        }
        if (a3.d != null && a3.d.length > 0) {
            a2.append("\nStacktrace:");
            StackTraceElement[] stackTraceElementArray = a3.d;
            int n2 = a3.d.length;
            int n3 = 0;
            while (n3 < n2) {
                StackTraceElement stackTraceElement = stackTraceElementArray[n3];
                a2.append("\n\tat ");
                a2.append(stackTraceElement.toString());
                ++n3;
            }
        }
    }

    public StackTraceElement[] a() {
        cya a2;
        return a2.d;
    }

    public static void a(cya a2, tp a3, yd a4, int a5) {
        int n2 = yd.a(a4);
        a2.a("Block type", new qoc(n2, a4));
        a2.a("Block data value", new kgd(a5));
        a2.a("Block location", new cd(a3));
    }

    public static void a(cya a2, tp a3, ba a4) {
        a2.a("Block", new lfb(a4));
        a2.a("Block location", new zu(a3));
    }
}

