/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;

public class cra
extends ne<obb> {
    private static final Map<String, wmc> z = Maps.newHashMap();
    private static final wmc l = new wmc("textures/entity/horse/horse_white.png");
    private static final wmc b = new wmc("textures/entity/horse/mule.png");
    private static final wmc c = new wmc("textures/entity/horse/donkey.png");
    private static final wmc v = new wmc("textures/entity/horse/horse_zombie.png");
    private static final wmc d = new wmc("textures/entity/horse/horse_skeleton.png");

    public cra(gub a2, cna a3, float a4) {
        super(a2, a3, a4);
        cra a5;
    }

    @Override
    protected void a(obb a2, float a3) {
        cra a4;
        float f2 = 1.0f;
        int n2 = a2.v();
        if (n2 == 1) {
            f2 *= 0.87f;
        } else if (n2 == 2) {
            f2 *= 0.92f;
        }
        ewa.o(f2, f2, f2);
        super.a(a2, a3);
    }

    protected wmc p(obb a2) {
        cra a3;
        if (!a2.db()) {
            switch (a2.v()) {
                default: {
                    return l;
                }
                case 1: {
                    return c;
                }
                case 2: {
                    return b;
                }
                case 3: {
                    return v;
                }
                case 4: 
            }
            return d;
        }
        return a3.a(a2);
    }

    @Override
    private /* synthetic */ wmc a(obb a2) {
        String string = a2.o();
        if (!a2.hb()) {
            return null;
        }
        wmc wmc2 = z.get(string);
        if (wmc2 == null) {
            wmc2 = new wmc(string);
            oj.a().a().a(wmc2, new dtc(a2.a()));
            z.put(string, wmc2);
        }
        return wmc2;
    }
}

