/*
 * Decompiled with CFR 0.152.
 */
class bu
extends mi {
    private rva d;

    public bu(rva a2) {
        bu a3;
        a3.d = a2;
        a3.a(5);
    }

    @Override
    public boolean o() {
        return true;
    }

    @Override
    public void a() {
        bu a2;
        ((mzc)a2.d.a()).a(1.0);
    }
}

