/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bsb
extends eu
implements eb {
    public static final kcb<eed> c = kcb.a("variant", eed.class);
    public static final kcb<kva> v = kcb.a("half", kva.class);
    public static final kcb<hnd> d = an.d;

    public bsb() {
        super(dr.ta);
        bsb a2;
        a2.a(((lf)((Object)a2.c)).a().a(c, eed.n).a(v, kva.v).a(d, hnd.x));
        a2.a(0.0f);
        a2.a(ga);
        a2.a("doublePlant");
    }

    @Override
    public void a(cb a2, tp a3) {
        bsb a4;
        a4.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }

    public eed a(cb a2, tp a3) {
        bsb a4;
        ba ba2 = a2.a(a3);
        if (ba2.a() == a4) {
            ba2 = a4.a(ba2, a2, a3);
            return ba2.a(c);
        }
        return eed.f;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        bsb a4;
        return super.a(a2, a3) && a2.a(a3.j());
    }

    @Override
    public boolean p(xga a2, tp a3) {
        bsb a4;
        ba ba2 = a2.a(a3);
        if (ba2.a() != a4) {
            return true;
        }
        eed eed2 = a4.a(ba2, (cb)a2, a3).a(c);
        return eed2 == eed.f || eed2 == eed.r;
    }

    @Override
    protected void y(xga a2, tp a3, ba a4) {
        bsb a5;
        if (!a5.a(a2, a3, a4)) {
            bsb bsb2;
            boolean bl2 = a4.a(v) == kva.c;
            tp tp2 = bl2 ? a3 : a3.j();
            tp tp3 = bl2 ? a3.z() : a3;
            bsb bsb3 = bl2 ? a5 : a2.a(tp2).a();
            yd yd2 = bsb2 = bl2 ? a2.a(tp3).a() : a5;
            if (bsb3 == a5) {
                a2.a(tp2, cl.cd.a(), 2);
            }
            if (bsb2 == a5) {
                a2.a(tp3, cl.cd.a(), 3);
                if (!bl2) {
                    a5.a(a2, tp3, a4, 0);
                }
            }
        }
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4) {
        bsb a5;
        if (a4.a(v) == kva.c) {
            return a2.a(a3.z()).a() == a5;
        }
        ba ba2 = a2.a(a3.j());
        return ba2.a() == a5 && super.a(a2, a3, ba2);
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        bsb a5;
        if (a2.a(v) == kva.c) {
            return null;
        }
        eed eed2 = a2.a(c);
        return eed2 == eed.f ? null : (eed2 == eed.r ? (a3.nextInt(8) == 0 ? sxa.me : null) : ge.a(a5));
    }

    @Override
    public int p(ba a2) {
        return a2.a(v) != kva.c && a2.a(c) != eed.r ? a2.a(c).a() : 0;
    }

    @Override
    public int a(cb a2, tp a3, int a4) {
        bsb a5;
        eed eed2 = a5.a(a2, a3);
        return eed2 != eed.r && eed2 != eed.f ? 0xFFFFFF : zjd.o(a2, a3);
    }

    public void a(xga a2, tp a3, eed a4, int a5) {
        bsb a6;
        a2.a(a3, a6.a().a(v, kva.v).a(c, a4), a5);
        a2.a(a3.j(), a6.a().a(v, kva.c), a5);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, xi a5, wfc a6) {
        bsb a7;
        a2.a(a3.j(), a7.a().a(v, kva.c), 2);
    }

    @Override
    public void a(xga a2, pm a3, tp a4, ba a5, kv a6) {
        bsb a7;
        if (a2.f || a3.p() == null || a3.p().a() != sxa.oc || a5.a(v) != kva.v || !a7.a(a2, a4, a5, a3)) {
            super.a(a2, a3, a4, a5, a6);
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, pm a5) {
        bsb a6;
        if (a4.a(v) == kva.c) {
            if (a2.a(a3.z()).a() == a6) {
                if (!a5.y.b) {
                    ba ba2 = a2.a(a3.z());
                    eed eed2 = ba2.a(c);
                    if (eed2 != eed.f && eed2 != eed.r) {
                        a2.y(a3.z(), true);
                    } else if (!a2.f) {
                        if (a5.p() != null && a5.p().a() == sxa.oc) {
                            a6.a(a2, a3, ba2, a5);
                            a2.r(a3.z());
                        } else {
                            a2.y(a3.z(), true);
                        }
                    } else {
                        a2.r(a3.z());
                    }
                } else {
                    a2.r(a3.z());
                }
            }
        } else if (a5.y.b && a2.a(a3.j()).a() == a6) {
            a2.a(a3.j(), cl.cd.a(), 2);
        }
        super.a(a2, a3, a4, a5);
    }

    private /* synthetic */ boolean a(xga a2, tp a3, ba a4, pm a5) {
        bsb a6;
        eed eed2 = a4.a(c);
        if (eed2 != eed.f && eed2 != eed.r) {
            return false;
        }
        a5.p(hca.b[yd.a(a6)]);
        int n2 = (eed2 == eed.r ? flb.z : flb.l).a();
        bsb.a(a2, a3, new wfc(cl.kd, 2, n2));
        return true;
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        eed[] eedArray = eed.values();
        int n2 = eedArray.length;
        int n3 = 0;
        while (n3 < n2) {
            eed eed2 = eedArray[n3];
            a4.add(new wfc(a2, 1, eed2.a()));
            ++n3;
        }
    }

    @Override
    public int p(xga a2, tp a3) {
        bsb a4;
        return a4.a((cb)a2, a3).a();
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, boolean a5) {
        bsb a6;
        eed eed2 = a6.a((cb)a2, a3);
        return eed2 != eed.r && eed2 != eed.f;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4, ba a5) {
        return true;
    }

    @Override
    public void a(xga a2, Random a3, tp a4, ba a5) {
        bsb a6;
        bsb.a(a2, a4, new wfc(a6, 1, a6.a((cb)a2, a4).a()));
    }

    @Override
    public ba a(int a2) {
        bsb a3;
        return (a2 & 8) > 0 ? a3.a().a(v, kva.c) : a3.a().a(v, kva.v).a(c, eed.a(a2 & 7));
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        bsb a5;
        ba ba2;
        if (a2.a(v) == kva.c && (ba2 = a3.a(a4.z())).a() == a5) {
            a2 = a2.a(c, ba2.a(c));
        }
        return a2;
    }

    @Override
    public int o(ba a2) {
        return a2.a(v) == kva.c ? 8 | a2.a(d).y() : a2.a(c).a();
    }

    @Override
    protected lf p() {
        bsb a2;
        return new lf(a2, v, c, d);
    }

    @Override
    public cdb a() {
        return cdb.c;
    }
}

