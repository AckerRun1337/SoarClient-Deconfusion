/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cab
extends am {
    public cab() {
        a2("end_crystal");
        cab a2;
    }

    protected cab(String a2) {
        super(xla.class, a2, 0.5f);
        cab a3;
    }

    @Override
    public qm a() {
        return new ap(0.0f, true);
    }

    @Override
    public sfc a(qm a2, String a3) {
        if (!(a2 instanceof ap)) {
            return null;
        }
        ap ap2 = (ap)a2;
        return a3.equals("cube") ? (sfc)xe.a((Object)ap2, xe.yb, 0) : (a3.equals("glass") ? (sfc)xe.a((Object)ap2, xe.yb, 1) : (a3.equals("base") ? (sfc)xe.a((Object)ap2, xe.yb, 2) : null));
    }

    @Override
    public String[] a() {
        return new String[]{"cube", "glass", "base"};
    }

    @Override
    public h a(qm a2, float a3) {
        gub gub2 = oj.a().a();
        xk xk2 = gub2.p().get(xla.class);
        if (!(xk2 instanceof jib)) {
            xfc.z("Not an instance of RenderEnderCrystal: " + xk2);
            return null;
        }
        jib jib2 = (jib)xk2;
        if (!xe.pb.a()) {
            xfc.z("Field not found: RenderEnderCrystal.modelEnderCrystal");
            return null;
        }
        xe.a((Object)jib2, xe.pb, (Object)a2);
        jib2.b = a3;
        return jib2;
    }
}

