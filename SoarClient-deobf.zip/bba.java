/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bba {
    protected final float c;
    protected final float v;
    protected final float d;

    public bba(float a2, float a3, float a4) {
        bba a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    public bba(mxb a2) {
        bba a3;
        a3.c = a2.a(0);
        a3.v = a2.a(1);
        a3.d = a2.a(2);
    }

    public mxb a() {
        bba a2;
        mxb mxb2 = new mxb();
        mxb2.a(new idb(a2.c));
        mxb2.a(new idb(a2.v));
        mxb2.a(new idb(a2.d));
        return mxb2;
    }

    public boolean equals(Object a2) {
        bba a3;
        if (!(a2 instanceof bba)) {
            return false;
        }
        bba bba2 = (bba)a2;
        return a3.c == bba2.c && a3.v == bba2.v && a3.d == bba2.d;
    }

    public float o() {
        bba a2;
        return a2.c;
    }

    public float p() {
        bba a2;
        return a2.v;
    }

    public float a() {
        bba a2;
        return a2.d;
    }
}

