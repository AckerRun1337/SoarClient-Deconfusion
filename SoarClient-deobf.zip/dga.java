/*
 * Decompiled with CFR 0.152.
 */
public enum dga implements s
{
    x(1, "north_west"),
    t(2, "north"),
    p(3, "north_east"),
    s(4, "west"),
    w(5, "center"),
    i(6, "east"),
    n(7, "south_west"),
    e(8, "south"),
    r(9, "south_east"),
    f(10, "stem"),
    h(0, "all_inside"),
    z(14, "all_outside"),
    l(15, "all_stem");

    private static final dga[] b;
    private final int c;
    private final String v;

    static {
        b = new dga[16];
        dga[] dgaArray = dga.values();
        int n2 = dgaArray.length;
        int n3 = 0;
        while (n3 < n2) {
            dga dga2;
            dga.b[dga2.a()] = dga2 = dgaArray[n3];
            ++n3;
        }
    }

    private /* synthetic */ dga(String a2, int a3, int a4, String a5) {
        dga a6;
        a6.c = a4;
        a6.v = a5;
    }

    public int a() {
        dga a2;
        return a2.c;
    }

    public String toString() {
        dga a2;
        return a2.v;
    }

    public static dga a(int a2) {
        dga dga2;
        if (a2 < 0 || a2 >= b.length) {
            a2 = 0;
        }
        return (dga2 = b[a2]) == null ? b[0] : dga2;
    }

    @Override
    public String zpa() {
        dga a2;
        return a2.v;
    }
}

