/*
 * Decompiled with CFR 0.152.
 */
public class ckc
extends id {
    public float h;
    public float z;
    public float l;
    public float b;
    public float c = 1.0f;
    public int v;
    public boolean d;

    public ckc(xga a2) {
        super(a2);
        ckc a3;
        a3.y(0.4f, 0.7f);
        a3.v = a3.oa.nextInt(6000) + 6000;
        a3.s.a(0, new nhd(a3));
        a3.s.a(1, new zca(a3, 1.4));
        a3.s.a(2, new xic(a3, 1.0));
        a3.s.a(3, new hpc(a3, 1.0, sxa.me, false));
        a3.s.a(4, new eda(a3, 1.1));
        a3.s.a(5, new fva(a3, 1.0));
        a3.s.a(6, new yi(a3, pm.class, 6.0f));
        a3.s.a(7, new nia(a3));
    }

    @Override
    public float o() {
        ckc a2;
        return a2.ua;
    }

    @Override
    protected void ma() {
        ckc a2;
        super.ma();
        a2.a(prc.l).a(4.0);
        a2.a(prc.v).a(0.25);
    }

    @Override
    public void w() {
        ckc a2;
        super.w();
        a2.b = a2.h;
        a2.l = a2.z;
        a2.z = (float)((double)a2.z + (double)(a2.aa ? -1 : 4) * 0.3);
        a2.z = smb.a(a2.z, 0.0f, 1.0f);
        if (!a2.aa && a2.c < 1.0f) {
            a2.c = 1.0f;
        }
        a2.c = (float)((double)a2.c * 0.9);
        if (!a2.aa && a2.gb < 0.0) {
            a2.gb *= 0.6;
        }
        a2.h += a2.c * 2.0f;
        if (!(a2.ib.f || a2.ga() || a2.la() || --a2.v > 0)) {
            a2.a("mob.chicken.plop", 1.0f, (a2.oa.nextFloat() - a2.oa.nextFloat()) * 0.2f + 1.0f);
            a2.a(sxa.dc, 1);
            a2.v = a2.oa.nextInt(6000) + 6000;
        }
    }

    @Override
    public void a(float a2, float a3) {
    }

    @Override
    protected String m() {
        return "mob.chicken.say";
    }

    @Override
    protected String h() {
        return "mob.chicken.hurt";
    }

    @Override
    protected String p() {
        return "mob.chicken.hurt";
    }

    @Override
    protected void a(tp a2, yd a3) {
        ckc a4;
        a4.a("mob.chicken.step", 0.15f, 1.0f);
    }

    @Override
    protected ge a() {
        return sxa.gn;
    }

    @Override
    protected void a(boolean a2, int a3) {
        ckc a4;
        int n2 = a4.oa.nextInt(3) + a4.oa.nextInt(1 + a3);
        int n3 = 0;
        while (n3 < n2) {
            a4.a(sxa.gn, 1);
            ++n3;
        }
        if (a4.i()) {
            a4.a(sxa.yb, 1);
        } else {
            a4.a(sxa.ob, 1);
        }
    }

    @Override
    public ckc a(oe a2) {
        ckc a3;
        return new ckc(a3.ib);
    }

    @Override
    public boolean p(wfc a2) {
        return a2 != null && a2.a() == sxa.me;
    }

    @Override
    public void o(dgb a2) {
        ckc a3;
        super.o(a2);
        a3.d = a2.a("IsChickenJockey");
        if (a2.p("EggLayTime")) {
            a3.v = a2.a("EggLayTime");
        }
    }

    @Override
    protected int a(pm a2) {
        ckc a3;
        return a3.la() ? 10 : super.a(a2);
    }

    @Override
    public void p(dgb a2) {
        ckc a3;
        super.p(a2);
        a2.a("IsChickenJockey", a3.d);
        a2.a("EggLayTime", a3.v);
    }

    @Override
    protected boolean za() {
        ckc a2;
        return a2.la() && a2.lb == null;
    }

    @Override
    public void z() {
        ckc a2;
        super.z();
        float f2 = smb.z(a2.wa * (float)Math.PI / 180.0f);
        float f3 = smb.y(a2.wa * (float)Math.PI / 180.0f);
        float f4 = 0.1f;
        float f5 = 0.0f;
        a2.lb.z(a2.fb + (double)(f4 * f2), a2.zb + (double)(a2.ua * 0.5f) + a2.lb.z() + (double)f5, a2.db - (double)(f4 * f3));
        if (a2.lb instanceof xi) {
            ((xi)a2.lb).wa = a2.wa;
        }
    }

    public boolean la() {
        ckc a2;
        return a2.d;
    }

    public void r(boolean a2) {
        a.d = a2;
    }

    @Override
    public /* synthetic */ oe a(oe a2) {
        ckc a3;
        return a3.a(a2);
    }
}

