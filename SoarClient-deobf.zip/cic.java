/*
 * Decompiled with CFR 0.152.
 */
public class cic
extends ne<bid> {
    private static final wmc d = new wmc("textures/entity/pig/pig.png");

    public cic(gub a2, qm a3, float a4) {
        super(a2, a3, a4);
        cic a5;
        a5.p(new ay(a5));
    }

    @Override
    protected wmc a(bid a2) {
        return d;
    }
}

