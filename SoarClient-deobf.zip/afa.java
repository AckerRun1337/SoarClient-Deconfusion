/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.HashSet;

public class afa
extends sfa<Integer> {
    private final ImmutableSet<Integer> d;

    protected afa(String a2, int a3, int a4) {
        super(a2, Integer.class);
        afa a5;
        if (a3 < 0) {
            throw new IllegalArgumentException("Min value of " + a2 + " must be 0 or greater");
        }
        if (a4 <= a3) {
            throw new IllegalArgumentException("Max value of " + a2 + " must be greater than min (" + a3 + ")");
        }
        HashSet hashSet = Sets.newHashSet();
        int n2 = a3;
        while (n2 <= a4) {
            hashSet.add(n2);
            ++n2;
        }
        a5.d = ImmutableSet.copyOf((Collection)hashSet);
    }

    @Override
    public Collection<Integer> a() {
        afa a2;
        return a2.d;
    }

    @Override
    public boolean equals(Object a2) {
        afa a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 != null && a3.getClass() == a2.getClass()) {
            if (!super.equals(a2)) {
                return false;
            }
            afa afa2 = (afa)a2;
            return a3.d.equals(afa2.d);
        }
        return false;
    }

    @Override
    public int hashCode() {
        afa a2;
        int n2 = super.hashCode();
        n2 = 31 * n2 + a2.d.hashCode();
        return n2;
    }

    public static afa a(String a2, int a3, int a4) {
        return new afa(a2, a3, a4);
    }

    @Override
    public String a(Integer a2) {
        return a2.toString();
    }
}

