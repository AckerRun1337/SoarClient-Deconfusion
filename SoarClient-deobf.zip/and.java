/*
 * Decompiled with CFR 0.152.
 */
public class and
extends xf {
    private static final wmc e = new wmc("textures/gui/achievement/achievement_background.png");
    private oj r;
    private int f;
    private int h;
    private String z;
    private String l;
    private xzc b;
    private long c;
    private kp v;
    private boolean d;

    public and(oj a2) {
        and a3;
        a3.r = a2;
        a3.v = a2.a();
    }

    public void p(xzc a2) {
        a.z = xab.a("achievement.get", new Object[0]);
        a.l = a2.p().p();
        a.c = oj.a();
        a.b = a2;
        a.d = false;
    }

    public void a(xzc a2) {
        a.z = a2.p().p();
        a.l = a2.a();
        a.c = oj.a() + 2500L;
        a.b = a2;
        a.d = true;
    }

    private /* synthetic */ void o() {
        and a2;
        ewa.y(0, 0, a2.r.wc, a2.r.pc);
        ewa.z(5889);
        ewa.d();
        ewa.z(5888);
        ewa.d();
        a2.f = a2.r.wc;
        a2.h = a2.r.pc;
        oda oda2 = new oda(a2.r);
        a2.f = oda2.o();
        a2.h = oda2.p();
        ewa.j(256);
        ewa.z(5889);
        ewa.d();
        ewa.a(0.0, a2.f, a2.h, 0.0, 1000.0, 3000.0);
        ewa.z(5888);
        ewa.d();
        ewa.p(0.0f, 0.0f, -2000.0f);
    }

    public void p() {
        and a2;
        if (a2.b != null && a2.c != 0L && oj.a().ob != null) {
            double d2 = (double)(oj.a() - a2.c) / 3000.0;
            if (!a2.d) {
                if (d2 < 0.0 || d2 > 1.0) {
                    a2.c = 0L;
                    return;
                }
            } else if (d2 > 0.5) {
                d2 = 0.5;
            }
            a2.o();
            ewa.ua();
            ewa.p(false);
            double d3 = d2 * 2.0;
            if (d3 > 1.0) {
                d3 = 2.0 - d3;
            }
            d3 *= 4.0;
            if ((d3 = 1.0 - d3) < 0.0) {
                d3 = 0.0;
            }
            d3 *= d3;
            d3 *= d3;
            int n2 = a2.f - 160;
            int n3 = 0 - (int)(d3 * 36.0);
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            ewa.e();
            a2.r.a().p(e);
            ewa.ka();
            a2.a(n2, n3, 96, 202, 160, 32);
            if (a2.d) {
                a2.r.vb.a(a2.l, n2 + 30, n3 + 7, 120, -1);
            } else {
                a2.r.vb.a(a2.z, n2 + 30, n3 + 7, -256);
                a2.r.vb.a(a2.l, n2 + 30, n3 + 18, -1);
            }
            rcc.a();
            ewa.ka();
            ewa.r();
            ewa.xa();
            ewa.ra();
            a2.v.a(a2.b.v, n2 + 8, n3 + 8);
            ewa.ka();
            ewa.p(true);
            ewa.sa();
        }
    }

    public void a() {
        a.b = null;
        a.c = 0L;
    }
}

