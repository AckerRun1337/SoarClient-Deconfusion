/*
 * Decompiled with CFR 0.152.
 */
public class az {
    public byte[] v;
    public int d;

    public az() {
        az a2;
    }
}

