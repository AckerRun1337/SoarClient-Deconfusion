/*
 * Decompiled with CFR 0.152.
 */
final class bxc
implements aa {
    public xi v;
    public rj d;

    private /* synthetic */ bxc() {
        bxc a2;
    }

    @Override
    public void a(zk a2, int a3) {
        bxc a4;
        a2.a(a4.v, a4.d, a3);
    }

    /* synthetic */ bxc(bxc a2) {
        a3();
        bxc a3;
    }
}

