/*
 * Decompiled with CFR 0.152.
 */
class ajc
implements Runnable {
    final /* synthetic */ kf v;
    private final /* synthetic */ lja d;

    ajc(kf a2, lja a3) {
        ajc a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public void run() {
        ajc a2;
        kf.a(a2.v).remove(a2.d);
    }
}

