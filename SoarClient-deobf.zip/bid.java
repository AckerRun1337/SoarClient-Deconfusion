/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bid
extends id {
    private final oqc d;

    public bid(xga a2) {
        super(a2);
        bid a3;
        a3.y(0.9f, 0.9f);
        ((hsa)a3.a()).z(true);
        a3.s.a(0, new nhd(a3));
        a3.s.a(1, new zca(a3, 1.25));
        a3.d = new oqc(a3, 0.3f);
        a3.s.a(2, a3.d);
        a3.s.a(3, new xic(a3, 1.0));
        a3.s.a(4, new hpc(a3, 1.2, sxa.ja, false));
        a3.s.a(4, new hpc(a3, 1.2, sxa.ma, false));
        a3.s.a(5, new eda(a3, 1.1));
        a3.s.a(6, new fva(a3, 1.0));
        a3.s.a(7, new yi(a3, pm.class, 6.0f));
        a3.s.a(8, new nia(a3));
    }

    @Override
    protected void ma() {
        bid a2;
        super.ma();
        a2.a(prc.l).a(10.0);
        a2.a(prc.v).a(0.25);
    }

    @Override
    public boolean oa() {
        bid a2;
        wfc wfc2 = ((pm)a2.lb).a();
        return wfc2 != null && wfc2.a() == sxa.ja;
    }

    @Override
    protected void v() {
        bid a2;
        super.v();
        a2.y.p(16, (byte)0);
    }

    @Override
    public void p(dgb a2) {
        bid a3;
        super.p(a2);
        a2.a("Saddle", a3.la());
    }

    @Override
    public void o(dgb a2) {
        bid a3;
        super.o(a2);
        a3.r(a2.a("Saddle"));
    }

    @Override
    protected String m() {
        return "mob.pig.say";
    }

    @Override
    protected String h() {
        return "mob.pig.say";
    }

    @Override
    protected String p() {
        return "mob.pig.death";
    }

    @Override
    protected void a(tp a2, yd a3) {
        bid a4;
        a4.a("mob.pig.step", 0.15f, 1.0f);
    }

    @Override
    public boolean a(pm a2) {
        bid a3;
        if (super.a(a2)) {
            return true;
        }
        if (!a3.la() || a3.ib.f || a3.lb != null && a3.lb != a2) {
            return false;
        }
        a2.y(a3);
        return true;
    }

    @Override
    protected ge a() {
        bid a2;
        return a2.i() ? sxa.ul : sxa.ig;
    }

    @Override
    protected void a(boolean a2, int a3) {
        bid a4;
        int n2 = a4.oa.nextInt(3) + 1 + a4.oa.nextInt(1 + a3);
        int n3 = 0;
        while (n3 < n2) {
            if (a4.i()) {
                a4.a(sxa.ul, 1);
            } else {
                a4.a(sxa.ig, 1);
            }
            ++n3;
        }
        if (a4.la()) {
            a4.a(sxa.cj, 1);
        }
    }

    public boolean la() {
        bid a2;
        return (a2.y.a(16) & 1) != 0;
    }

    public void r(boolean a2) {
        bid a3;
        if (a2) {
            a3.y.a(16, Byte.valueOf((byte)1));
        } else {
            a3.y.a(16, Byte.valueOf((byte)0));
        }
    }

    @Override
    public void a(gea a2) {
        bid a3;
        if (!a3.ib.f && !a3.qa) {
            cda cda2 = new cda(a3.ib);
            cda2.p(0, new wfc(sxa.ei));
            cda2.p(a3.fb, a3.zb, a3.db, a3.nb, a3.rb);
            cda2.m(a3.wa());
            if (a3.p()) {
                cda2.a(a3.y());
                cda2.p(a3.x());
            }
            a3.ib.a(cda2);
            a3.g();
        }
    }

    @Override
    public void a(float a2, float a3) {
        bid a4;
        super.a(a2, a3);
        if (a2 > 5.0f && a4.lb instanceof pm) {
            ((pm)a4.lb).p(mv.g);
        }
    }

    @Override
    public bid a(oe a2) {
        bid a3;
        return new bid(a3.ib);
    }

    @Override
    public boolean p(wfc a2) {
        return a2 != null && a2.a() == sxa.ma;
    }

    public oqc a() {
        bid a2;
        return a2.d;
    }

    @Override
    public /* synthetic */ oe a(oe a2) {
        bid a3;
        return a3.a(a2);
    }
}

