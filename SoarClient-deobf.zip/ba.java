/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 */
import com.google.common.collect.ImmutableMap;
import java.util.Collection;

public interface ba {
    public Collection<gb> a();

    public <T extends Comparable<T>> T a(gb<T> var1);

    public <T extends Comparable<T>, V extends T> ba a(gb<T> var1, V var2);

    public <T extends Comparable<T>> ba a(gb<T> var1);

    public ImmutableMap<gb, Comparable> a();

    public yd a();
}

