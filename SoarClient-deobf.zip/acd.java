/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;

public class acd
extends ej {
    private static final List<ond> v = Lists.newArrayList((Object[])new ond[]{new ond(sxa.de, 0, 1, 3, 3), new ond(sxa.qi, 0, 1, 5, 10), new ond(sxa.ve, 0, 1, 3, 5), new ond(sxa.jm, 0, 1, 3, 15), new ond(sxa.cl, 0, 1, 3, 15), new ond(sxa.bg, 0, 1, 1, 5), new ond(sxa.om, 0, 1, 1, 5), new ond(sxa.uh, 0, 1, 1, 5), new ond(sxa.ko, 0, 1, 1, 5), new ond(sxa.eo, 0, 1, 1, 5), new ond(sxa.mo, 0, 1, 1, 5), new ond(ge.a(cl.mh), 0, 3, 7, 5), new ond(ge.a(cl.ce), 0, 3, 7, 5), new ond(sxa.cj, 0, 1, 1, 3), new ond(sxa.a, 0, 1, 1, 1), new ond(sxa.q, 0, 1, 1, 1), new ond(sxa.g, 0, 1, 1, 1)});
    private boolean d;

    public acd() {
        acd a2;
    }

    public acd(moa a2, int a3, Random a4, uxc a5, hnd a6) {
        super(a2, a3);
        acd a7;
        a7.c = a6;
        a7.b = a5;
    }

    public static acd a(moa a2, List<ae> a3, Random a4, int a5, int a6, int a7, hnd a8, int a9) {
        uxc uxc2 = uxc.a(a5, a6, a7, 0, 0, 0, 10, 6, 7, a8);
        return acd.a(uxc2) && ae.a(a3, uxc2) == null ? new acd(a2, a9, a4, uxc2, a8) : null;
    }

    @Override
    protected void p(dgb a2) {
        acd a3;
        super.p(a2);
        a2.a("Chest", a3.d);
    }

    @Override
    protected void a(dgb a2) {
        acd a3;
        super.a(a2);
        a3.d = a2.a("Chest");
    }

    @Override
    public boolean a(xga a2, Random a3, uxc a4) {
        acd a5;
        if (a5.b < 0) {
            a5.b = a5.a(a2, a4);
            if (a5.b < 0) {
                return true;
            }
            a5.b.a(0, a5.b - a5.b.c + 6 - 1, 0);
        }
        a5.a(a2, a4, 0, 1, 0, 9, 4, 6, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 0, 0, 0, 9, 0, 6, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 0, 4, 0, 9, 4, 6, cl.um.a(), cl.um.a(), false);
        a5.a(a2, a4, 0, 5, 0, 9, 5, 6, cl.jn.a(), cl.jn.a(), false);
        a5.a(a2, a4, 1, 5, 1, 8, 5, 5, cl.cd.a(), cl.cd.a(), false);
        a5.a(a2, a4, 1, 1, 0, 2, 3, 0, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 1, 0, 0, 4, 0, cl.ej.a(), cl.ej.a(), false);
        a5.a(a2, a4, 3, 1, 0, 3, 4, 0, cl.ej.a(), cl.ej.a(), false);
        a5.a(a2, a4, 0, 1, 6, 0, 4, 6, cl.ej.a(), cl.ej.a(), false);
        a5.p(a2, cl.yl.a(), 3, 3, 1, a4);
        a5.a(a2, a4, 3, 1, 2, 3, 3, 2, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 4, 1, 3, 5, 3, 3, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 0, 1, 1, 0, 3, 5, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 1, 1, 6, 5, 3, 6, cl.yl.a(), cl.yl.a(), false);
        a5.a(a2, a4, 5, 1, 0, 5, 3, 0, cl.if.a(), cl.if.a(), false);
        a5.a(a2, a4, 9, 1, 0, 9, 3, 0, cl.if.a(), cl.if.a(), false);
        a5.a(a2, a4, 6, 1, 4, 9, 4, 6, cl.um.a(), cl.um.a(), false);
        a5.p(a2, cl.ff.a(), 7, 1, 5, a4);
        a5.p(a2, cl.ff.a(), 8, 1, 5, a4);
        a5.p(a2, cl.mc.a(), 9, 2, 5, a4);
        a5.p(a2, cl.mc.a(), 9, 2, 4, a4);
        a5.a(a2, a4, 7, 2, 4, 8, 2, 5, cl.cd.a(), cl.cd.a(), false);
        a5.p(a2, cl.um.a(), 6, 1, 3, a4);
        a5.p(a2, cl.eo.a(), 6, 2, 3, a4);
        a5.p(a2, cl.eo.a(), 6, 3, 3, a4);
        a5.p(a2, cl.cg.a(), 8, 1, 1, a4);
        a5.p(a2, cl.xc.a(), 0, 2, 2, a4);
        a5.p(a2, cl.xc.a(), 0, 2, 4, a4);
        a5.p(a2, cl.xc.a(), 2, 2, 6, a4);
        a5.p(a2, cl.xc.a(), 4, 2, 6, a4);
        a5.p(a2, cl.if.a(), 2, 1, 4, a4);
        a5.p(a2, cl.ae.a(), 2, 2, 4, a4);
        a5.p(a2, cl.yl.a(), 1, 1, 5, a4);
        a5.p(a2, cl.ri.a(a5.a(cl.ri, 3)), 2, 1, 5, a4);
        a5.p(a2, cl.ri.a(a5.a(cl.ri, 1)), 1, 1, 4, a4);
        if (!a5.d && a4.a(new tp(a5.p(5, 5), a5.a(1), a5.a(5, 5)))) {
            a5.d = true;
            a5.a(a2, a4, a3, 5, 1, 5, v, 3 + a3.nextInt(6));
        }
        int n2 = 6;
        while (n2 <= 8) {
            if (a5.a(a2, n2, 0, -1, a4).a().a() == dr.ua && a5.a(a2, n2, -1, -1, a4).a().a() != dr.ua) {
                a5.p(a2, cl.ig.a(a5.a(cl.ig, 3)), n2, 0, -1, a4);
            }
            ++n2;
        }
        n2 = 0;
        while (n2 < 7) {
            int n3 = 0;
            while (n3 < 10) {
                a5.a(a2, n3, 6, n2, a4);
                a5.a(a2, cl.um.a(), n3, -1, n2, a4);
                ++n3;
            }
            ++n2;
        }
        a5.a(a2, a4, 7, 1, 1, 1);
        return true;
    }

    @Override
    protected int o(int a2, int a3) {
        return 3;
    }
}

