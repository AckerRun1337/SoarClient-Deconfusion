/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bbd
implements wi,
jo {
    private static final Logger l = LogManager.getLogger();
    private Map<kgb, dgb> b = new ConcurrentHashMap<kgb, dgb>();
    private Set<kgb> c = Collections.newSetFromMap(new ConcurrentHashMap());
    private final File v;
    private boolean d = false;

    public bbd(File a2) {
        bbd a3;
        a3.v = a2;
    }

    @Override
    public dsc a(xga a2, int a3, int a4) throws IOException {
        bbd a5;
        kgb kgb2 = new kgb(a3, a4);
        dgb dgb2 = a5.b.get(kgb2);
        if (dgb2 == null) {
            DataInputStream dataInputStream = gq.a(a5.v, a3, a4);
            if (dataInputStream == null) {
                return null;
            }
            dgb2 = mkc.a(dataInputStream);
        }
        return a5.a(a2, a3, a4, dgb2);
    }

    protected dsc a(xga a2, int a3, int a4, dgb a5) {
        bbd a6;
        if (!a5.a("Level", 10)) {
            l.error("Chunk file at " + a3 + "," + a4 + " is missing level data, skipping");
            return null;
        }
        ml ml2 = a5.a("Level");
        if (!((dgb)ml2).a("Sections", 9)) {
            l.error("Chunk file at " + a3 + "," + a4 + " is missing block data, skipping");
            return null;
        }
        dsc dsc2 = a6.a(a2, (dgb)ml2);
        if (!dsc2.o(a3, a4)) {
            l.error("Chunk file at " + a3 + "," + a4 + " is in the wrong location; relocating. (Expected " + a3 + ", " + a4 + ", got " + dsc2.p + ", " + dsc2.s + ")");
            ((dgb)ml2).a("xPos", a3);
            ((dgb)ml2).a("zPos", a4);
            dsc2 = a6.a(a2, (dgb)ml2);
        }
        return dsc2;
    }

    @Override
    public void p(xga a2, dsc a3) throws rwa, IOException {
        a2.p();
        try {
            bbd a4;
            dgb dgb2 = new dgb();
            dgb dgb3 = new dgb();
            dgb2.a("Level", dgb3);
            a4.a(a3, a2, dgb3);
            a4.p(a3.a(), dgb2);
        }
        catch (Exception exception) {
            l.error("Failed to save chunk", (Throwable)exception);
        }
    }

    protected void p(kgb a2, dgb a3) {
        bbd a4;
        if (!a4.c.contains(a2)) {
            a4.b.put(a2, a3);
        }
        llc.a().a(a4);
    }

    @Override
    public boolean a() {
        boolean bl2;
        bbd a2;
        if (a2.b.isEmpty()) {
            if (a2.d) {
                l.info("ThreadedAnvilChunkStorage ({}): All chunks are saved", new Object[]{a2.v.getName()});
            }
            return false;
        }
        kgb kgb2 = a2.b.keySet().iterator().next();
        try {
            a2.c.add(kgb2);
            dgb dgb2 = a2.b.remove(kgb2);
            if (dgb2 != null) {
                try {
                    a2.a(kgb2, dgb2);
                }
                catch (Exception exception) {
                    l.error("Failed to save chunk", (Throwable)exception);
                }
            }
            bl2 = true;
        }
        finally {
            a2.c.remove(kgb2);
        }
        return bl2;
    }

    private /* synthetic */ void a(kgb a2, dgb a3) throws IOException {
        bbd a4;
        DataOutputStream dataOutputStream = gq.a(a4.v, a2.c, a2.v);
        mkc.a(a3, (DataOutput)dataOutputStream);
        dataOutputStream.close();
    }

    @Override
    public void a(xga a2, dsc a3) throws IOException {
    }

    @Override
    public void p() {
    }

    @Override
    public void a() {
        try {
            a2.d = true;
            while (true) {
                bbd a2;
                if (a2.a()) continue;
            }
        }
        catch (Throwable throwable) {
            a2.d = false;
            throw throwable;
        }
    }

    private /* synthetic */ void a(dsc a2, xga a3, dgb a4) {
        Object object;
        dgb dgb2;
        Object object2;
        a4.a("V", (byte)1);
        a4.a("xPos", a2.p);
        a4.a("zPos", a2.s);
        a4.a("LastUpdate", a3.p());
        a4.a("HeightMap", a2.a());
        a4.a("TerrainPopulated", a2.p());
        a4.a("LightPopulated", a2.a());
        a4.a("InhabitedTime", a2.a());
        jvb[] jvbArray = a2.a();
        mxb mxb2 = new mxb();
        boolean bl2 = !a3.g.a();
        jvb[] jvbArray2 = jvbArray;
        int n2 = jvbArray.length;
        int n3 = 0;
        while (n3 < n2) {
            object2 = jvbArray2[n3];
            if (object2 != null) {
                dgb2 = new dgb();
                dgb2.a("Y", (byte)(((jvb)object2).p() >> 4 & 0xFF));
                object = new byte[((jvb)object2).a().length];
                iac object3 = new iac();
                Object object4 = null;
                int dgb3 = 0;
                while (dgb3 < ((jvb)object2).a().length) {
                    char c2 = ((jvb)object2).a()[dgb3];
                    int n4 = dgb3 & 0xF;
                    int n5 = dgb3 >> 8 & 0xF;
                    int n6 = dgb3 >> 4 & 0xF;
                    if (c2 >> 12 != 0) {
                        if (object4 == null) {
                            object4 = new iac();
                        }
                        ((iac)object4).a(n4, n5, n6, c2 >> 12);
                    }
                    object[dgb3] = (byte)(c2 >> 4 & 0xFF);
                    object3.a(n4, n5, n6, c2 & 0xF);
                    ++dgb3;
                }
                dgb2.a("Blocks", (byte[])object);
                dgb2.a("Data", object3.a());
                if (object4 != null) {
                    dgb2.a("Add", ((iac)object4).a());
                }
                dgb2.a("BlockLight", ((jvb)object2).p().a());
                if (bl2) {
                    dgb2.a("SkyLight", ((jvb)object2).a().a());
                } else {
                    dgb2.a("SkyLight", new byte[((jvb)object2).p().a().length]);
                }
                mxb2.a(dgb2);
            }
            ++n3;
        }
        a4.a("Sections", mxb2);
        a4.a("Biomes", a2.a());
        a2.a(false);
        object2 = new mxb();
        n3 = 0;
        while (n3 < a2.a().length) {
            for (rj rj2 : a2.a()[n3]) {
                if (!rj2.a(dgb2 = new dgb())) continue;
                a2.a(true);
                ((mxb)object2).a(dgb2);
            }
            ++n3;
        }
        a4.a("Entities", (ml)object2);
        mxb mxb3 = new mxb();
        for (kv kv2 : a2.a().values()) {
            dgb2 = new dgb();
            kv2.a(dgb2);
            mxb3.a(dgb2);
        }
        a4.a("TileEntities", mxb3);
        List<yob> list = a3.a(a2, false);
        if (list != null) {
            long l2 = a3.p();
            object = new mxb();
            for (yob yob2 : list) {
                dgb dgb3 = new dgb();
                wmc wmc2 = (wmc)yd.ma.p(yob2.a());
                dgb3.a("i", wmc2 == null ? "" : wmc2.toString());
                dgb3.a("x", yob2.b.o());
                dgb3.a("y", yob2.b.p());
                dgb3.a("z", yob2.b.a());
                dgb3.a("t", (int)(yob2.c - l2));
                dgb3.a("p", yob2.v);
                ((mxb)object).a(dgb3);
            }
            a4.a("TileTicks", (ml)object);
        }
    }

    private /* synthetic */ dsc a(xga a2, dgb a3) {
        mxb mxb2;
        mxb mxb3;
        Object object;
        Object object2;
        Object object3;
        Object object4;
        int n2;
        ml ml2;
        int n3 = a3.a("xPos");
        int n4 = a3.a("zPos");
        dsc dsc2 = new dsc(a2, n3, n4);
        dsc2.a(a3.a("HeightMap"));
        dsc2.y(a3.a("TerrainPopulated"));
        dsc2.o(a3.a("LightPopulated"));
        dsc2.a(a3.a("InhabitedTime"));
        mxb mxb4 = a3.a("Sections", 10);
        int n5 = 16;
        jvb[] jvbArray = new jvb[n5];
        boolean bl2 = !a2.g.a();
        int n6 = 0;
        while (n6 < mxb4.p()) {
            ml2 = mxb4.a(n6);
            n2 = ((dgb)ml2).a("Y");
            object4 = new jvb(n2 << 4, bl2);
            object3 = ((dgb)ml2).a("Blocks");
            object2 = new iac(((dgb)ml2).a("Data"));
            object = ((dgb)ml2).a("Add", 7) ? new iac(((dgb)ml2).a("Add")) : null;
            char[] cArray = new char[((byte[])object3).length];
            int n7 = 0;
            while (n7 < cArray.length) {
                int n8 = n7 & 0xF;
                int n9 = n7 >> 8 & 0xF;
                int n10 = n7 >> 4 & 0xF;
                int n11 = object != null ? ((iac)object).p(n8, n9, n10) : 0;
                cArray[n7] = (char)(n11 << 12 | (object3[n7] & 0xFF) << 4 | ((iac)object2).p(n8, n9, n10));
                ++n7;
            }
            ((jvb)object4).a(cArray);
            ((jvb)object4).p(new iac(((dgb)ml2).a("BlockLight")));
            if (bl2) {
                ((jvb)object4).a(new iac(((dgb)ml2).a("SkyLight")));
            }
            ((jvb)object4).a();
            jvbArray[n2] = object4;
            ++n6;
        }
        dsc2.a(jvbArray);
        if (a3.a("Biomes", 7)) {
            dsc2.a(a3.a("Biomes"));
        }
        if ((mxb3 = a3.a("Entities", 10)) != null) {
            int n12 = 0;
            while (n12 < mxb3.p()) {
                dgb dgb2 = mxb3.a(n12);
                object4 = pvb.a(dgb2, a2);
                dsc2.a(true);
                if (object4 != null) {
                    dsc2.p((rj)object4);
                    object3 = object4;
                    object2 = dgb2;
                    while (((dgb)object2).a("Riding", 10)) {
                        object = pvb.a((dgb)((dgb)object2).a("Riding"), a2);
                        if (object != null) {
                            dsc2.p((rj)object);
                            ((rj)object3).y((rj)object);
                        }
                        object3 = object;
                        object2 = ((dgb)object2).a("Riding");
                    }
                }
                ++n12;
            }
        }
        if ((ml2 = a3.a("TileEntities", 10)) != null) {
            n2 = 0;
            while (n2 < ((mxb)ml2).p()) {
                object4 = ((mxb)ml2).a(n2);
                object3 = kv.a((dgb)object4);
                if (object3 != null) {
                    dsc2.a((kv)object3);
                }
                ++n2;
            }
        }
        if (a3.a("TileTicks", 9) && (mxb2 = a3.a("TileTicks", 10)) != null) {
            int n13 = 0;
            while (n13 < mxb2.p()) {
                object3 = mxb2.a(n13);
                object2 = ((dgb)object3).a("i", 8) ? yd.p(((dgb)object3).a("i")) : yd.p(((dgb)object3).a("i"));
                a2.p(new tp(((dgb)object3).a("x"), ((dgb)object3).a("y"), ((dgb)object3).a("z")), (yd)object2, ((dgb)object3).a("t"), ((dgb)object3).a("p"));
                ++n13;
            }
        }
        return dsc2;
    }
}

