/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ax {
    private static final Pattern d = Pattern.compile("(?i)\\u00A7[0-9A-FK-OR]");

    public ax() {
        ax a2;
    }

    public static String a(int a2) {
        int n2 = a2 / 20;
        int n3 = n2 / 60;
        return (n2 %= 60) < 10 ? String.valueOf(n3) + ":0" + n2 : String.valueOf(n3) + ":" + n2;
    }

    public static String a(String a2) {
        return d.matcher(a2).replaceAll("");
    }

    public static boolean a(String a2) {
        return StringUtils.isEmpty((CharSequence)a2);
    }
}

