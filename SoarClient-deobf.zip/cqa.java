/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

public class cqa
extends yd {
    public static final ewc d = ewc.a("snowy");

    protected cqa() {
        super(dr.da, rpb.s);
        cqa a2;
        a2.a(a2.c.a().a(d, false));
        a2.a(true);
        a2.a(md.g);
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        yd yd2 = a3.a(a4.j()).a();
        return a2.a(d, yd2 == cl.kn || yd2 == cl.hd);
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        if (!a2.f) {
            if (a2.o(a3.j()) < 4 && a2.a(a3.j()).a().z() > 2) {
                a2.a(a3, cl.zk.a().a(teb.v, kd.r));
            } else if (a2.o(a3.j()) >= 9) {
                int n2 = 0;
                while (n2 < 4) {
                    tp tp2 = a3.a(a5.nextInt(3) - 1, a5.nextInt(5) - 3, a5.nextInt(3) - 1);
                    ba ba2 = a2.a(tp2);
                    yd yd2 = a2.a(tp2.j()).a();
                    if (ba2.a() == cl.zk && ba2.a(teb.v) == kd.r && a2.o(tp2.j()) >= 4 && yd2.z() <= 2) {
                        cqa a6;
                        a2.a(tp2, a6.a());
                    }
                    ++n2;
                }
            }
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4, Random a5) {
        cqa a6;
        super.a(a2, a3, a4, a5);
        if (a5.nextInt(10) == 0) {
            a2.a(wra.la, (float)a3.o() + a5.nextFloat(), (double)((float)a3.p() + 1.1f), (double)((float)a3.a() + a5.nextFloat()), 0.0, 0.0, 0.0, new int[0]);
        }
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return cl.zk.a(cl.zk.a().a(teb.v, kd.r), a3, a4);
    }

    @Override
    public int o(ba a2) {
        return 0;
    }

    @Override
    protected lf p() {
        cqa a2;
        return new lf(a2, d);
    }
}

