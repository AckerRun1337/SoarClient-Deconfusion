/*
 * Decompiled with CFR 0.152.
 */
import java.util.Map;

class br
implements ta {
    private final /* synthetic */ Map d;

    br(Map a2) {
        br a3;
        a3.d = a2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(dcc a2, wx a3) {
        br a4;
        Map map = a4.d;
        synchronized (map) {
            a4.d.put("Response", a3);
            a4.d.notifyAll();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(dcc a2, Exception a3) {
        br a4;
        Map map = a4.d;
        synchronized (map) {
            a4.d.put("Exception", a3);
            a4.d.notifyAll();
        }
    }
}

