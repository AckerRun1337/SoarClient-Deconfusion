/*
 * Decompiled with CFR 0.152.
 */
public class bn
extends qm {
    sfc[] v = new sfc[8];
    sfc d;

    public bn() {
        bn a2;
        int n2 = 0;
        while (n2 < a2.v.length) {
            int n3 = 0;
            int n4 = n2;
            if (n2 == 2) {
                n3 = 24;
                n4 = 10;
            } else if (n2 == 3) {
                n3 = 24;
                n4 = 19;
            }
            a2.v[n2] = new sfc(a2, n3, n4);
            a2.v[n2].a(-4.0f, 16 + n2, -4.0f, 8, 1, 8);
            ++n2;
        }
        a2.d = new sfc(a2, 0, 16);
        a2.d.a(-2.0f, 18.0f, -2.0f, 4, 4, 4);
    }

    @Override
    public void a(xi a2, float a3, float a4, float a5) {
        bn a6;
        oma oma2 = (oma)a2;
        float f2 = oma2.v + (oma2.c - oma2.v) * a5;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        int n2 = 0;
        while (n2 < a6.v.length) {
            a6.v[n2].la = (float)(-(4 - n2)) * f2 * 1.7f;
            ++n2;
        }
    }

    @Override
    public void a(rj a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        bn a9;
        a9.a(a3, a4, a5, a6, a7, a8, a2);
        a9.d.y(a8);
        int n2 = 0;
        while (n2 < a9.v.length) {
            a9.v[n2].y(a8);
            ++n2;
        }
    }
}

