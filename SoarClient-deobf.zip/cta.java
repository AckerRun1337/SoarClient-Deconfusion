/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cta
extends nx
implements Serializable {
    static final long d = 1733471895962736949L;

    public cta(double a2, double a3, double a4, double a5) {
        super(a2, a3, a4, a5);
        cta a6;
    }

    public cta(double[] a2) {
        super(a2);
        cta a3;
    }

    public cta(cta a2) {
        super(a2);
        cta a3;
    }

    public cta(yqb a2) {
        super(a2);
        cta a3;
    }

    public cta(cf a2) {
        super(a2);
        cta a3;
    }

    public cta(nx a2) {
        super(a2);
        cta a3;
    }

    public cta(dva a2) {
        super(a2.c, a2.v, a2.d, 1.0);
        cta a3;
    }

    public cta() {
        cta a2;
    }

    public final void a(dva a2) {
        a.b = a2.c;
        a.c = a2.v;
        a.v = a2.d;
        a.d = (long)1.0;
    }

    public final double y(cta a2) {
        cta a3;
        double d2 = a3.b - a2.b;
        double d3 = a3.c - a2.c;
        double d4 = a3.v - a2.v;
        long l2 = a3.d - a2.d;
        return d2 * d2 + d3 * d3 + d4 * d4 + l2 * l2;
    }

    public final double o(cta a2) {
        cta a3;
        double d2 = a3.b - a2.b;
        double d3 = a3.c - a2.c;
        double d4 = a3.v - a2.v;
        long l2 = a3.d - a2.d;
        return Math.sqrt(d2 * d2 + d3 * d3 + d4 * d4 + l2 * l2);
    }

    public final double p(cta a2) {
        cta a3;
        return Math.abs(a3.b - a2.b) + Math.abs(a3.c - a2.c) + Math.abs(a3.v - a2.v) + Math.abs((double)(a3.d - a2.d));
    }

    public final double a(cta a2) {
        cta a3;
        double d2 = Math.max(Math.abs(a3.b - a2.b), Math.abs(a3.c - a2.c));
        double d3 = Math.max(Math.abs(a3.v - a2.v), Math.abs((double)(a3.d - a2.d)));
        return Math.max(d2, d3);
    }

    public final void a(cta a2) {
        double d2 = 1.0 / a2.d;
        a.b = a2.b * d2;
        a.c = a2.c * d2;
        a.v = a2.v * d2;
        a.d = (long)1.0;
    }
}

