/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class buc {
    public static final buc x = new buc();
    public static float t = 0.0f;
    public static float p = 0.0f;
    public static float s = 0.0f;
    public static float w = 0.0f;
    public static float i = 0.0f;
    public static float n = 0.0f;
    public static float e = 0.0f;
    public static float r = 0.0f;
    public static float f = 0.0f;
    public final eea h;
    public final eea z;
    public final eea l;
    public final eea b;
    public final eea c;
    public final eea v;
    private static volatile /* synthetic */ int[] d;

    private /* synthetic */ buc() {
        a2(eea.b, eea.b, eea.b, eea.b, eea.b, eea.b);
        buc a2;
    }

    public buc(buc a2) {
        buc a3;
        a3.h = a2.h;
        a3.z = a2.z;
        a3.l = a2.l;
        a3.b = a2.b;
        a3.c = a2.c;
        a3.v = a2.v;
    }

    public buc(eea a2, eea a3, eea a4, eea a5, eea a6, eea a7) {
        buc a8;
        a8.h = a2;
        a8.z = a3;
        a8.l = a4;
        a8.b = a5;
        a8.c = a6;
        a8.v = a7;
    }

    public void a(unc a2) {
        buc a3;
        eea eea2 = a3.a(a2);
        if (eea2 != eea.b) {
            ewa.p(eea2.v.c + t, eea2.v.v + p, eea2.v.d + s);
            ewa.p(eea2.c.v + i, 0.0f, 1.0f, 0.0f);
            ewa.p(eea2.c.c + w, 1.0f, 0.0f, 0.0f);
            ewa.p(eea2.c.d + n, 0.0f, 0.0f, 1.0f);
            ewa.o(eea2.d.c + e, eea2.d.v + r, eea2.d.d + f);
        }
    }

    public eea a(unc a2) {
        switch (buc.a()[a2.ordinal()]) {
            case 2: {
                buc a3;
                return a3.h;
            }
            case 3: {
                buc a3;
                return a3.z;
            }
            case 4: {
                buc a3;
                return a3.l;
            }
            case 5: {
                buc a3;
                return a3.b;
            }
            case 6: {
                buc a3;
                return a3.c;
            }
            case 7: {
                buc a3;
                return a3.v;
            }
        }
        return eea.b;
    }

    public boolean a(unc a2) {
        buc a3;
        return !a3.a(a2).equals(eea.b);
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[unc.values().length];
        try {
            nArray[unc.z.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.v.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.c.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.b.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.l.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.f.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[unc.h.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

