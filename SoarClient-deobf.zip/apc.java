/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  paulscode.sound.SoundSystem
 *  paulscode.sound.SoundSystemConfig
 *  paulscode.sound.Source
 */
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.Source;

class apc
extends SoundSystem {
    final /* synthetic */ tt d;

    private /* synthetic */ apc(tt a2) {
        apc a3;
        a3.d = a2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean playing(String a2) {
        Object object = SoundSystemConfig.THREAD_SYNC;
        synchronized (object) {
            apc a3;
            block4: {
                if (a3.soundLibrary != null) break block4;
                return false;
            }
            Source source = (Source)a3.soundLibrary.getSources().get(a2);
            return source == null ? false : source.playing() || source.paused() || source.preLoad;
        }
    }

    /* synthetic */ apc(tt a2, apc a3) {
        a4(a2);
        apc a4;
    }
}

