/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.exception.ExceptionUtils
 */
import com.google.gson.JsonParseException;
import java.util.List;
import org.apache.commons.lang3.exception.ExceptionUtils;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aza
extends hf {
    public aza() {
        aza a2;
    }

    @Override
    public String a() {
        return "tellraw";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String a(j a2) {
        return "commands.tellraw.usage";
    }

    @Override
    public void a(j a2, String[] a3) throws tqa {
        if (a3.length < 2) {
            throw new xvb("commands.tellraw.usage", new Object[0]);
        }
        xj xj2 = aza.a(a2, a3[0]);
        String string = aza.a(a3, 1);
        try {
            ga ga2 = rs.a(string);
            ((rj)xj2).a(woc.a(a2, ga2, xj2));
        }
        catch (JsonParseException jsonParseException) {
            Throwable throwable = ExceptionUtils.getRootCause((Throwable)jsonParseException);
            throw new oub("commands.tellraw.jsonException", throwable == null ? "" : throwable.getMessage());
        }
    }

    @Override
    public List<String> a(j a2, String[] a3, tp a4) {
        return a3.length == 1 ? aza.a(a3, ccb.a().a()) : null;
    }

    @Override
    public boolean a(String[] a2, int a3) {
        return a3 == 0;
    }
}

