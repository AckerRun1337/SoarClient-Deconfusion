/*
 * Decompiled with CFR 0.152.
 */
final class cq
implements aa {
    public float v;
    public flc d;

    private /* synthetic */ cq() {
        cq a2;
    }

    @Override
    public void a(zk a2, int a3) {
        cq a4;
        a4.v += a2.a(a3, a4.d);
    }

    /* synthetic */ cq(cq a2) {
        a3();
        cq a3;
    }
}

