/*
 * Decompiled with CFR 0.152.
 */
public enum bic {
    i,
    n,
    e,
    r,
    f,
    h,
    z,
    l,
    b,
    c,
    v;


    private /* synthetic */ bic(String a2, int a3) {
        bic a4;
    }

    public boolean a(ge a2) {
        bic a3;
        if (a3 == i) {
            return true;
        }
        if (a3 == c && a2.x()) {
            return true;
        }
        if (a2 instanceof gwc) {
            if (a3 == n) {
                return true;
            }
            gwc gwc2 = (gwc)a2;
            return gwc2.b == 0 ? a3 == h : (gwc2.b == 2 ? a3 == r : (gwc2.b == 1 ? a3 == f : (gwc2.b == 3 ? a3 == e : false)));
        }
        return a2 instanceof oq ? a3 == z : (a2 instanceof kca ? a3 == l : (a2 instanceof oec ? a3 == v : (a2 instanceof eyc ? a3 == b : false)));
    }
}

