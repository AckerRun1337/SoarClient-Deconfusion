/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterables
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 */
import com.google.common.collect.Iterables;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class csc
extends kv {
    private int c;
    private int v;
    private GameProfile d = null;

    public csc() {
        csc a2;
    }

    @Override
    public void a(dgb a2) {
        csc a3;
        super.a(a2);
        a2.a("SkullType", (byte)(a3.c & 0xFF));
        a2.a("Rot", (byte)(a3.v & 0xFF));
        if (a3.d != null) {
            dgb dgb2 = new dgb();
            nvb.a(dgb2, a3.d);
            a2.a("Owner", dgb2);
        }
    }

    @Override
    public void p(dgb a2) {
        csc a3;
        super.p(a2);
        a3.c = a2.a("SkullType");
        a3.v = a2.a("Rot");
        if (a3.c == 3) {
            String string;
            if (a2.a("Owner", 10)) {
                a3.d = nvb.a((dgb)a2.a("Owner"));
            } else if (a2.a("ExtraType", 8) && !ax.a(string = a2.a("ExtraType"))) {
                a3.d = new GameProfile(null, string);
                a3.a();
            }
        }
    }

    public GameProfile a() {
        csc a2;
        return a2.d;
    }

    @Override
    public o a() {
        csc a2;
        dgb dgb2 = new dgb();
        a2.a(dgb2);
        return new cgc(a2.b, 4, dgb2);
    }

    public void p(int a2) {
        a.c = a2;
        a.d = null;
    }

    public void a(GameProfile a2) {
        csc a3;
        a3.c = 3;
        a3.d = a2;
        a3.a();
    }

    private /* synthetic */ void a() {
        csc a2;
        a2.d = csc.a(a2.d);
        a2.o();
    }

    public static GameProfile a(GameProfile a2) {
        if (a2 != null && !ax.a(a2.getName())) {
            if (a2.isComplete() && a2.getProperties().containsKey((Object)"textures")) {
                return a2;
            }
            if (ccb.a() == null) {
                return a2;
            }
            GameProfile gameProfile = ccb.a().a().a(a2.getName());
            if (gameProfile == null) {
                return a2;
            }
            Property property = (Property)Iterables.getFirst((Iterable)gameProfile.getProperties().get((Object)"textures"), null);
            if (property == null) {
                gameProfile = ccb.a().a().fillProfileProperties(gameProfile, true);
            }
            return gameProfile;
        }
        return a2;
    }

    public int p() {
        csc a2;
        return a2.c;
    }

    public int a() {
        csc a2;
        return a2.v;
    }

    public void a(int a2) {
        a.v = a2;
    }
}

