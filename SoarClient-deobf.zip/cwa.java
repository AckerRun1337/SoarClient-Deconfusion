/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cwa
extends es {
    protected cwa() {
        super(dr.na);
        cwa a2;
        a2.a(0.25f, 0.0f, 0.25f, 0.75f, 1.0f, 0.75f);
    }

    @Override
    public tca a(xga a2, tp a3, ba a4) {
        return null;
    }

    @Override
    public tca a(xga a2, tp a3) {
        cwa a4;
        a4.a((cb)a2, a3);
        return super.a(a2, a3);
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public boolean a(cb a2, tp a3) {
        return true;
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean z() {
        return true;
    }

    @Override
    public kv a(xga a2, int a3) {
        return new qna();
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return sxa.hh;
    }

    @Override
    public ge a(xga a2, tp a3) {
        return sxa.hh;
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, pm a5, hnd a6, float a7, float a8, float a9) {
        if (a2.f) {
            return true;
        }
        kv kv2 = a2.a(a3);
        return kv2 instanceof qna ? ((qna)kv2).a(a5) : false;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        cwa a4;
        return !a4.o(a2, a3) && super.a(a2, a3);
    }
}

