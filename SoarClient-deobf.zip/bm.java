/*
 * Decompiled with CFR 0.152.
 */
public class bm
extends yd {
    private boolean d;

    protected bm(dr a2, boolean a3) {
        a4(a2, a3, a2.a());
        bm a4;
    }

    protected bm(dr a2, boolean a3, rpb a4) {
        super(a2, a4);
        bm a5;
        a5.d = a3;
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public boolean p(cb a2, tp a3, hnd a4) {
        bm a5;
        ba ba2 = a2.a(a3);
        yd yd2 = ba2.a();
        if (a5 == cl.om || a5 == cl.e) {
            if (a2.a(a3.a(a4.z())) != ba2) {
                return true;
            }
            if (yd2 == a5) {
                return false;
            }
        }
        return !a5.d && yd2 == a5 ? false : super.p(a2, a3, a4);
    }
}

