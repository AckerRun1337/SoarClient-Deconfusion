/*
 * Decompiled with CFR 0.152.
 */
public interface ca {
    public void a(double var1, double var3, double var5, float var7, float var8);
}

