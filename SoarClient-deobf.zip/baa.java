/*
 * Decompiled with CFR 0.152.
 */
public class baa
extends bh {
    private /* synthetic */ int v;
    protected /* synthetic */ float d;

    public baa() {
        super("Bossbar", 0, gk.l);
        baa a2;
        a2.v = 13;
    }

    @fo
    public void a(psc a2) {
        baa a3;
        if (a3.g.sb instanceof qsa) {
            a3.z();
        } else {
            a3.j();
        }
        a3.x(182);
        a3.j(18);
    }

    private /* synthetic */ void j() {
        if (ppc.v != null && ppc.c > 0) {
            baa a2;
            a2.g.a().p(xf.v);
            --ppc.c;
            a2.g.a().p(xf.v);
            int n2 = 182;
            a2.g.a().p(xf.v);
            int n3 = (int)(ppc.b * (float)(n2 + 1));
            a2.a(a2.x(), a2.j() + a2.v, 0, 74, n2, 5);
            a2.a(a2.x(), a2.j() + a2.v, 0, 74, n2, 5);
            if (n3 > 0) {
                a2.a(a2.x(), a2.j() + a2.v, 0, 79, n3, 5);
            }
            a2.g.a().p(xf.v);
            String string = ppc.v;
            a2.k.a(string, (float)(91 - a2.k.a(string) / 2 + a2.x()), (float)(a2.j() - 10 + a2.v), 0xFFFFFF);
            ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
            a2.g.a().p(xf.v);
        }
    }

    private /* synthetic */ void z() {
        baa a2;
        a2.g.a().p(xf.v);
        --ppc.c;
        a2.g.a().p(xf.v);
        int n2 = 182;
        a2.g.a().p(xf.v);
        int n3 = (int)(ppc.b * (float)(n2 + 1));
        a2.a(a2.x(), a2.j() + a2.v + 1, 0, 74, n2, 5);
        a2.a(a2.x(), a2.j() + a2.v + 1, 0, 74, n2, 5);
        if (n3 > 0) {
            a2.a(a2.x(), a2.j() + a2.v + 1, 0, 79, n3, 5);
        }
        a2.g.a().p(xf.v);
        String string = "Bossbar";
        a2.k.a(string, (float)(91 - a2.k.a(string) / 2 + a2.x()), (float)(a2.j() - 10 + a2.v), 0xFFFFFF);
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        a2.g.a().p(xf.v);
    }

    public void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        baa a8;
        float f2 = 0.00390625f;
        float f3 = 0.00390625f;
        xlb xlb2 = xlb.a();
        krb krb2 = xlb2.a();
        krb2.a(7, ybd.i);
        krb2.a((double)(a2 + 0), (double)(a3 + a7), (double)a8.d).a((float)(a4 + 0) * f2, (float)(a5 + a7) * f3).z();
        krb2.a((double)(a2 + a6), (double)(a3 + a7), (double)a8.d).a((float)(a4 + a6) * f2, (float)(a5 + a7) * f3).z();
        krb2.a((double)(a2 + a6), (double)(a3 + 0), (double)a8.d).a((float)(a4 + a6) * f2, (float)(a5 + 0) * f3).z();
        krb2.a((double)(a2 + 0), (double)(a3 + 0), (double)a8.d).a((float)(a4 + 0) * f2, (float)(a5 + 0) * f3).z();
        xlb2.a();
    }
}

