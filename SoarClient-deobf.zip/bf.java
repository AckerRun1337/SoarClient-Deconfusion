/*
 * Decompiled with CFR 0.152.
 */
public class bf
extends yh {
    private static final wmc l = new wmc("textures/gui/container/hopper.png");
    private zb v;
    private zb d;

    public bf(mnb a2, zb a3) {
        super(new bmb(a2, a3, oj.a().ob));
        bf a4;
        a4.v = a2;
        a4.d = a3;
        a4.h = false;
        a4.oa = 133;
    }

    @Override
    protected void p(int a2, int a3) {
        bf a4;
        a4.z.a(a4.d.a().p(), 8, 6, 0x404040);
        a4.z.a(a4.v.a().p(), 8, a4.oa - 96 + 2, 0x404040);
    }

    @Override
    protected void a(float a2, int a3, int a4) {
        bf a5;
        ewa.a(1.0f, 1.0f, 1.0f, 1.0f);
        a5.w.a().p(l);
        int n2 = (n - a5.ta) / 2;
        int n3 = (e - a5.oa) / 2;
        a5.a(n2, n3, 0, 0, a5.ta, a5.oa);
    }
}

