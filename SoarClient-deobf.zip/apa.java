/*
 * Decompiled with CFR 0.152.
 */
class apa
extends mi {
    private rva c;
    private float v;
    private int d;

    public apa(rva a2) {
        apa a3;
        a3.c = a2;
        a3.a(2);
    }

    @Override
    public boolean o() {
        apa a2;
        return a2.c.y() == null && (a2.c.aa || a2.c.w() || a2.c.s());
    }

    @Override
    public void a() {
        apa a2;
        if (--a2.d <= 0) {
            a2.d = 40 + a2.c.a().nextInt(60);
            a2.v = a2.c.a().nextInt(360);
        }
        ((mzc)a2.c.a()).a(a2.v, false);
    }
}

