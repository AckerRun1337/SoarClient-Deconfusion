/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bec
extends es {
    public static final afa b = afa.a("legacy_data", 0, 15);
    public static final kcb<xxa> c = kcb.a("contents", xxa.class);
    private static volatile /* synthetic */ int[] v;
    private static volatile /* synthetic */ int[] d;

    public bec() {
        super(dr.u);
        bec a2;
        a2.a(((lf)((Object)a2.c)).a().a(c, xxa.o).a(b, 0));
        a2.p();
    }

    @Override
    public String p() {
        return bwa.p("item.flowerPot.name");
    }

    @Override
    public void p() {
        bec a2;
        a2.a(0.3125f, 0.0f, 0.3125f, 0.6875f, 0.375f, 0.6875f);
    }

    @Override
    public boolean m() {
        return false;
    }

    @Override
    public int o() {
        return 3;
    }

    @Override
    public boolean r() {
        return false;
    }

    @Override
    public int a(cb a2, tp a3, int a4) {
        ge ge2;
        kv kv2 = a2.a(a3);
        if (kv2 instanceof iyb && (ge2 = ((iyb)kv2).a()) instanceof iu) {
            return yd.a(ge2).a(a2, a3, a4);
        }
        return 0xFFFFFF;
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, pm a5, hnd a6, float a7, float a8, float a9) {
        wfc wfc2 = a5.ob.p();
        if (wfc2 != null && wfc2.a() instanceof iu) {
            bec a10;
            iyb iyb2 = a10.a(a2, a3);
            if (iyb2 == null) {
                return false;
            }
            if (iyb2.a() != null) {
                return false;
            }
            yd yd2 = yd.a(wfc2.a());
            if (!a10.a(yd2, wfc2.y())) {
                return false;
            }
            iyb2.a(wfc2.a(), wfc2.y());
            iyb2.o();
            a2.y(a3);
            a5.p(hca.i);
            if (!a5.y.b && --wfc2.e <= 0) {
                a5.ob.a(a5.ob.b, null);
            }
            return true;
        }
        return false;
    }

    private /* synthetic */ boolean a(yd a2, int a3) {
        return a2 != cl.dh && a2 != cl.kj && a2 != cl.fd && a2 != cl.uj && a2 != cl.vk && a2 != cl.ce && a2 != cl.rk ? a2 == cl.kd && a3 == flb.l.a() : true;
    }

    @Override
    public ge a(xga a2, tp a3) {
        bec a4;
        iyb iyb2 = a4.a(a2, a3);
        return iyb2 != null && iyb2.a() != null ? iyb2.a() : sxa.da;
    }

    @Override
    public int p(xga a2, tp a3) {
        bec a4;
        iyb iyb2 = a4.a(a2, a3);
        return iyb2 != null && iyb2.a() != null ? iyb2.a() : 0;
    }

    @Override
    public boolean o() {
        return true;
    }

    @Override
    public boolean a(xga a2, tp a3) {
        bec a4;
        return super.a(a2, a3) && xga.a(a2, a3.z());
    }

    @Override
    public void a(xga a2, tp a3, ba a4, yd a5) {
        if (!xga.a(a2, a3.z())) {
            bec a6;
            a6.a(a2, a3, a4, 0);
            a2.r(a3);
        }
    }

    @Override
    public void a(xga a2, tp a3, ba a4) {
        bec a5;
        iyb iyb2 = a5.a(a2, a3);
        if (iyb2 != null && iyb2.a() != null) {
            bec.a(a2, a3, new wfc(iyb2.a(), 1, iyb2.a()));
        }
        super.a(a2, a3, a4);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, pm a5) {
        iyb iyb2;
        bec a6;
        super.a(a2, a3, a4, a5);
        if (a5.y.b && (iyb2 = a6.a(a2, a3)) != null) {
            iyb2.a(null, 0);
        }
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return sxa.da;
    }

    private /* synthetic */ iyb a(xga a2, tp a3) {
        kv kv2 = a2.a(a3);
        return kv2 instanceof iyb ? (iyb)kv2 : null;
    }

    @Override
    public kv a(xga a2, int a3) {
        yd yd2;
        int n2 = 0;
        switch (a3) {
            case 1: {
                yd2 = cl.kj;
                n2 = elb.p.a();
                break;
            }
            case 2: {
                yd2 = cl.dh;
                break;
            }
            case 3: {
                yd2 = cl.ce;
                n2 = cfd.i.a();
                break;
            }
            case 4: {
                yd2 = cl.ce;
                n2 = cfd.n.a();
                break;
            }
            case 5: {
                yd2 = cl.ce;
                n2 = cfd.e.a();
                break;
            }
            case 6: {
                yd2 = cl.ce;
                n2 = cfd.r.a();
                break;
            }
            case 7: {
                yd2 = cl.vk;
                break;
            }
            case 8: {
                yd2 = cl.uj;
                break;
            }
            case 9: {
                yd2 = cl.fd;
                break;
            }
            case 10: {
                yd2 = cl.rk;
                break;
            }
            case 11: {
                yd2 = cl.kd;
                n2 = flb.l.a();
                break;
            }
            case 12: {
                yd2 = cl.ce;
                n2 = cfd.f.a();
                break;
            }
            case 13: {
                yd2 = cl.ce;
                n2 = cfd.h.a();
                break;
            }
            default: {
                yd2 = null;
            }
        }
        return new iyb(ge.a(yd2), n2);
    }

    @Override
    protected lf p() {
        bec a2;
        return new lf(a2, c, b);
    }

    @Override
    public int o(ba a2) {
        return a2.a(b);
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        iyb iyb2;
        ge ge2;
        xxa xxa2 = xxa.o;
        kv kv2 = a3.a(a4);
        if (kv2 instanceof iyb && (ge2 = (iyb2 = (iyb)kv2).a()) instanceof iu) {
            int n2 = iyb2.a();
            yd yd2 = yd.a(ge2);
            if (yd2 == cl.ce) {
                switch (bec.p()[cfd.a(n2).ordinal()]) {
                    case 1: {
                        xxa2 = xxa.w;
                        break;
                    }
                    case 2: {
                        xxa2 = xxa.i;
                        break;
                    }
                    case 3: {
                        xxa2 = xxa.n;
                        break;
                    }
                    case 4: {
                        xxa2 = xxa.e;
                        break;
                    }
                    case 5: {
                        xxa2 = xxa.r;
                        break;
                    }
                    case 6: {
                        xxa2 = xxa.f;
                        break;
                    }
                    default: {
                        xxa2 = xxa.o;
                        break;
                    }
                }
            } else if (yd2 == cl.kd) {
                switch (n2) {
                    case 0: {
                        xxa2 = xxa.l;
                        break;
                    }
                    case 2: {
                        xxa2 = xxa.b;
                        break;
                    }
                    default: {
                        xxa2 = xxa.o;
                        break;
                    }
                }
            } else if (yd2 == cl.dh) {
                xxa2 = xxa.s;
            } else if (yd2 == cl.kj) {
                switch (bec.a()[elb.a(wic.v, n2).ordinal()]) {
                    case 2: {
                        xxa2 = xxa.m;
                        break;
                    }
                    case 3: {
                        xxa2 = xxa.y;
                        break;
                    }
                    case 4: {
                        xxa2 = xxa.a;
                        break;
                    }
                    case 5: {
                        xxa2 = xxa.q;
                        break;
                    }
                    case 6: {
                        xxa2 = xxa.g;
                        break;
                    }
                    case 7: {
                        xxa2 = xxa.k;
                        break;
                    }
                    case 8: {
                        xxa2 = xxa.x;
                        break;
                    }
                    case 9: {
                        xxa2 = xxa.t;
                        break;
                    }
                    case 10: {
                        xxa2 = xxa.p;
                        break;
                    }
                    default: {
                        xxa2 = xxa.o;
                        break;
                    }
                }
            } else if (yd2 == cl.vk) {
                xxa2 = xxa.h;
            } else if (yd2 == cl.uj) {
                xxa2 = xxa.z;
            } else if (yd2 == cl.rk) {
                xxa2 = xxa.l;
            } else if (yd2 == cl.fd) {
                xxa2 = xxa.c;
            }
        }
        return a2.a(c, xxa2);
    }

    @Override
    public hdc a() {
        return hdc.b;
    }

    static /* synthetic */ int[] p() {
        if (v != null) {
            return v;
        }
        int[] nArray = new int[cfd.values().length];
        try {
            nArray[cfd.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[cfd.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[cfd.h.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[cfd.r.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[cfd.i.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[cfd.n.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        v = nArray;
        return nArray;
    }

    static /* synthetic */ int[] a() {
        if (d != null) {
            return d;
        }
        int[] nArray = new int[elb.values().length];
        try {
            nArray[elb.w.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.s.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.t.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.i.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.e.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.h.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.f.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.p.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.n.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[elb.r.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        d = nArray;
        return nArray;
    }
}

