/*
 * Decompiled with CFR 0.152.
 */
class apb
extends md {
    apb(int a2, String a3) {
        super(a2, a3);
        apb a4;
    }

    @Override
    public ge a() {
        return sxa.cl;
    }
}

