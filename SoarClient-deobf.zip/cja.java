/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class cja
implements Serializable,
Cloneable {
    static final long l = -8226727741811898211L;
    public byte b;
    public byte c;
    public byte v;
    public byte d;

    public cja(byte a2, byte a3, byte a4, byte a5) {
        cja a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    public cja(byte[] a2) {
        cja a3;
        a3.b = a2[0];
        a3.c = a2[1];
        a3.v = a2[2];
        a3.d = a2[3];
    }

    public cja(cja a2) {
        cja a3;
        a3.b = a2.b;
        a3.c = a2.c;
        a3.v = a2.v;
        a3.d = a2.d;
    }

    public cja() {
        cja a2;
        a2.b = 0;
        a2.c = 0;
        a2.v = 0;
        a2.d = 0;
    }

    public String toString() {
        cja a2;
        return "(" + (a2.b & 0xFF) + ", " + (a2.c & 0xFF) + ", " + (a2.v & 0xFF) + ", " + (a2.d & 0xFF) + ")";
    }

    public final void p(byte[] a2) {
        cja a3;
        a2[0] = a3.b;
        a2[1] = a3.c;
        a2[2] = a3.v;
        a2[3] = a3.d;
    }

    public final void p(cja a2) {
        cja a3;
        a2.b = a3.b;
        a2.c = a3.c;
        a2.v = a3.v;
        a2.d = a3.d;
    }

    public final void a(cja a2) {
        a.b = a2.b;
        a.c = a2.c;
        a.v = a2.v;
        a.d = a2.d;
    }

    public final void a(byte[] a2) {
        a.b = a2[0];
        a.c = a2[1];
        a.v = a2[2];
        a.d = a2[3];
    }

    public boolean a(cja a2) {
        try {
            cja a3;
            return a3.b == a2.b && a3.c == a2.c && a3.v == a2.v && a3.d == a2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean equals(Object a2) {
        try {
            cja a3;
            cja cja2 = (cja)a2;
            return a3.b == cja2.b && a3.c == cja2.c && a3.v == cja2.v && a3.d == cja2.d;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
        catch (ClassCastException classCastException) {
            return false;
        }
    }

    public int hashCode() {
        cja a2;
        return (a2.b & 0xFF) << 0 | (a2.c & 0xFF) << 8 | (a2.v & 0xFF) << 16 | (a2.d & 0xFF) << 24;
    }

    public Object clone() {
        try {
            cja a2;
            return super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
    }

    public final byte y() {
        cja a2;
        return a2.b;
    }

    public final void y(byte a2) {
        a.b = a2;
    }

    public final byte o() {
        cja a2;
        return a2.c;
    }

    public final void o(byte a2) {
        a.c = a2;
    }

    public final byte p() {
        cja a2;
        return a2.v;
    }

    public final void p(byte a2) {
        a.v = a2;
    }

    public final byte a() {
        cja a2;
        return a2.d;
    }

    public final void a(byte a2) {
        a.d = a2;
    }
}

