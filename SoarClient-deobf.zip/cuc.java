/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cuc
extends eu
implements eb {
    public static final afa c = afa.a("age", 0, 7);
    public static final iab v = iab.a("facing", new jla());
    private final yd d;

    protected cuc(yd a2) {
        cuc a3;
        a3.a(((lf)((Object)a3.c)).a().a(c, 0).a(v, hnd.k));
        a3.d = a2;
        a3.a(true);
        float f2 = 0.125f;
        a3.a(0.5f - f2, 0.0f, 0.5f - f2, 0.5f + f2, 0.25f, 0.5f + f2);
        a3.a((md)null);
    }

    @Override
    public ba a(ba a2, cb a3, tp a4) {
        a2 = a2.a(v, hnd.k);
        for (hnd hnd2 : wta.b) {
            cuc a5;
            if (a3.a(a4.a(hnd2)).a() != a5.d) continue;
            a2 = a2.a(v, hnd2);
            break;
        }
        return a2;
    }

    @Override
    protected boolean p(yd a2) {
        return a2 == cl.uh;
    }

    @Override
    public void p(xga a2, tp a3, ba a4, Random a5) {
        float f2;
        cuc a6;
        super.p(a2, a3, a4, a5);
        if (a2.o(a3.j()) >= 9 && a5.nextInt((int)(25.0f / (f2 = ut.a(a6, a2, a3))) + 1) == 0) {
            int n2 = a4.a(c);
            if (n2 < 7) {
                a4 = a4.a(c, n2 + 1);
                a2.a(a3, a4, 2);
            } else {
                Object object2;
                for (Object object2 : wta.b) {
                    if (a2.a(a3.a((hnd)object2)).a() != a6.d) continue;
                    return;
                }
                a3 = a3.a(wta.b.zpa(a5));
                object2 = a2.a(a3.z()).a();
                if (a2.a((tp)a3).a().z == dr.ua && (object2 == cl.uh || object2 == cl.zk || object2 == cl.ik)) {
                    a2.a(a3, a6.d.a());
                }
            }
        }
    }

    public void z(xga a2, tp a3, ba a4) {
        int n2 = a4.a(c) + smb.a(a2.q, 2, 5);
        a2.a(a3, a4.a(c, Math.min(7, n2)), 2);
    }

    @Override
    public int a(ba a2) {
        cuc a3;
        if (a2.a() != a3) {
            return super.a(a2);
        }
        int n2 = a2.a(c);
        int n3 = n2 * 32;
        int n4 = 255 - n2 * 8;
        int n5 = n2 * 4;
        return n3 << 16 | n4 << 8 | n5;
    }

    @Override
    public int a(cb a2, tp a3, int a4) {
        cuc a5;
        return a5.a(a2.a(a3));
    }

    @Override
    public void p() {
        cuc a2;
        float f2 = 0.125f;
        a2.a(0.5f - f2, 0.0f, 0.5f - f2, 0.5f + f2, 0.25f, 0.5f + f2);
    }

    @Override
    public void a(cb a2, tp a3) {
        cuc a4;
        a4.e = (float)(a2.a(a3).a(c) * 2 + 2) / 16.0f;
        float f2 = 0.125f;
        a4.a(0.5f - f2, 0.0f, 0.5f - f2, 0.5f + f2, (float)a4.e, 0.5f + f2);
    }

    @Override
    public void a(xga a2, tp a3, ba a4, float a5, int a6) {
        ge ge2;
        cuc a7;
        super.a(a2, a3, a4, a5, a6);
        if (!a2.f && (ge2 = a7.a()) != null) {
            int n2 = a4.a(c);
            int n3 = 0;
            while (n3 < 3) {
                if (a2.q.nextInt(15) <= n2) {
                    cuc.a(a2, a3, new wfc(ge2));
                }
                ++n3;
            }
        }
    }

    protected ge a() {
        cuc a2;
        return a2.d == cl.cc ? sxa.kb : (a2.d == cl.gc ? sxa.qb : null);
    }

    @Override
    public ge a(ba a2, Random a3, int a4) {
        return null;
    }

    @Override
    public ge a(xga a2, tp a3) {
        cuc a4;
        ge ge2 = a4.a();
        return ge2 != null ? ge2 : null;
    }

    @Override
    public boolean a(xga a2, tp a3, ba a4, boolean a5) {
        return a4.a(c) != 7;
    }

    @Override
    public boolean a(xga a2, Random a3, tp a4, ba a5) {
        return true;
    }

    @Override
    public void a(xga a2, Random a3, tp a4, ba a5) {
        cuc a6;
        a6.z(a2, a4, a5);
    }

    @Override
    public ba a(int a2) {
        cuc a3;
        return a3.a().a(c, a2);
    }

    @Override
    public int o(ba a2) {
        return a2.a(c);
    }

    @Override
    protected lf p() {
        cuc a2;
        return new lf(a2, c, v);
    }
}

