/*
 * Decompiled with CFR 0.152.
 */
public class dab
extends zya {
    public dab(yd a2) {
        super(a2, false);
        dab a3;
    }

    @Override
    public wfc p(wfc a2, xga a3, pm a4) {
        dab a5;
        lwa lwa2 = a5.a(a3, a4, true);
        if (lwa2 == null) {
            return a2;
        }
        if (lwa2.b == qgb.c) {
            tp tp2 = lwa2.a();
            if (!a3.a(a4, tp2)) {
                return a2;
            }
            if (!a4.a(tp2.a(lwa2.c), lwa2.c, a2)) {
                return a2;
            }
            tp tp3 = tp2.j();
            ba ba2 = a3.a(tp2);
            if (ba2.a().a() == dr.ca && ba2.a(yha.d) == 0 && a3.a(tp3)) {
                a3.a(tp3, cl.ub.a());
                if (!a4.y.b) {
                    --a2.e;
                }
                a4.p(hca.v[ge.a(a5)]);
            }
        }
        return a2;
    }

    @Override
    public int a(wfc a2, int a3) {
        return cl.ub.a(cl.ub.a(a2.y()));
    }
}

