/*
 * Decompiled with CFR 0.152.
 */
public interface ac {
    public void a(gu var1, qad var2);
}

