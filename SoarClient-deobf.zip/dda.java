/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dda
implements xa {
    private rhc l;
    private final tib b;
    private final ul c = new ul();
    private final to v = new to();
    private final fkb d = new fkb();

    public dda(rhc a2, tib a3) {
        dda a4;
        a4.l = a2;
        a4.b = a3;
    }

    public rhc a() {
        dda a2;
        return a2.l;
    }

    public void a(ba a2, tp a3, jqa a4, cb a5) {
        yd yd2 = a2.a();
        int n2 = yd2.o();
        if (n2 == 3) {
            dda a6;
            a2 = yd2.a(a2, a5, a3);
            na na2 = a6.l.a(a2);
            na na3 = new rda(na2, a4).a();
            a6.c.a(a5, na3, a2, a3, xlb.a().a());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a(ba a2, tp a3, cb a4, krb a5) {
        try {
            int n2 = a2.a().o();
            if (n2 == -1) {
                return false;
            }
            switch (n2) {
                case 1: {
                    dda a6;
                    return a6.d.a(a4, a2, a3, a5);
                }
                case 2: {
                    return false;
                }
                case 3: {
                    dda a6;
                    na na2 = a6.a(a2, a4, a3);
                    return a6.c.a(a4, na2, a2, a3, a5);
                }
            }
            return false;
        }
        catch (Throwable throwable) {
            hna hna2 = hna.a(throwable, "Tesselating block in world");
            cya cya2 = hna2.a("Block being tesselated");
            cya.a(cya2, a3, a2.a(), a2.a().o(a2));
            throw new yja(hna2);
        }
    }

    public ul a() {
        dda a2;
        return a2.c;
    }

    private /* synthetic */ na a(ba a2, tp a3) {
        dda a4;
        na na2 = a4.l.a(a2);
        if (a3 != null && a4.b.rk && na2 instanceof ln) {
            na2 = ((ln)na2).a(smb.a(a3));
        }
        return na2;
    }

    public na a(ba a2, cb a3, tp a4) {
        dda a5;
        yd yd2 = a2.a();
        if (a3.a() != rkb.f) {
            try {
                a2 = yd2.a(a2, a3, a4);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        na na2 = a5.l.a(a2);
        if (a4 != null && a5.b.rk && na2 instanceof ln) {
            na2 = ((ln)na2).a(smb.a(a4));
        }
        return na2;
    }

    public void a(ba a2, float a3) {
        int n2 = a2.a().o();
        if (n2 != -1) {
            switch (n2) {
                default: {
                    break;
                }
                case 2: {
                    dda a4;
                    a4.v.a(a2.a(), a3);
                    break;
                }
                case 3: {
                    dda a4;
                    na na2 = a4.a(a2, null);
                    a4.c.a(na2, a2, a3, true);
                }
            }
        }
    }

    public boolean a(yd a2, int a3) {
        if (a2 == null) {
            return false;
        }
        int n2 = a2.o();
        return n2 == 3 ? false : n2 == 2;
    }

    @Override
    public void a(fa a2) {
        dda a3;
        a3.d.a();
    }
}

