/*
 * Decompiled with CFR 0.152.
 */
public class cpb
implements p {
    public cpb() {
        cpb a2;
    }

    @Override
    public tf a(int a2, xga a3, double a4, double a5, double a6, double a7, double a8, double a9, int ... a10) {
        return new wwb(a3, a4, a5, a6, a7, a8, a9);
    }
}

