/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterators
 */
import com.google.common.collect.Iterators;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class bbb
extends TreeSet {
    private fha z = new fha();
    private int l = Integer.MIN_VALUE;
    private int b = Integer.MIN_VALUE;
    private int c = Integer.MIN_VALUE;
    private int v = Integer.MIN_VALUE;
    private static final int d = Integer.MIN_VALUE;

    public bbb(Set a2) {
        bbb a3;
        for (Object e2 : a2) {
            a3.add(e2);
        }
    }

    @Override
    public boolean contains(Object a2) {
        bbb a3;
        if (!(a2 instanceof yob)) {
            return false;
        }
        yob yob2 = (yob)a2;
        Set set = a3.a(yob2, false);
        return set == null ? false : set.contains(yob2);
    }

    @Override
    public boolean add(Object a2) {
        boolean bl2;
        bbb a3;
        if (!(a2 instanceof yob)) {
            return false;
        }
        yob yob2 = (yob)a2;
        if (yob2 == null) {
            return false;
        }
        Set set = a3.a(yob2, true);
        boolean bl3 = set.add(yob2);
        if (bl3 != (bl2 = super.add(a2))) {
            throw new IllegalStateException("Added: " + bl3 + ", addedParent: " + bl2);
        }
        return bl2;
    }

    @Override
    public boolean remove(Object a2) {
        boolean bl2;
        bbb a3;
        if (!(a2 instanceof yob)) {
            return false;
        }
        yob yob2 = (yob)a2;
        Set set = a3.a(yob2, false);
        if (set == null) {
            return false;
        }
        boolean bl3 = set.remove(yob2);
        if (bl3 != (bl2 = super.remove(yob2))) {
            throw new IllegalStateException("Added: " + bl3 + ", addedParent: " + bl2);
        }
        return bl2;
    }

    private /* synthetic */ Set a(yob a2, boolean a3) {
        bbb a4;
        if (a2 == null) {
            return null;
        }
        tp tp2 = a2.b;
        int n2 = tp2.o() >> 4;
        int n3 = tp2.a() >> 4;
        return a4.a(n2, n3, a3);
    }

    private /* synthetic */ Set a(int a2, int a3, boolean a4) {
        bbb a5;
        long l2 = kgb.a(a2, a3);
        HashSet hashSet = (HashSet)a5.z.p(l2);
        if (hashSet == null && a4) {
            hashSet = new HashSet();
            a5.z.a(l2, hashSet);
        }
        return hashSet;
    }

    @Override
    public Iterator iterator() {
        bbb a2;
        if (a2.l == Integer.MIN_VALUE) {
            return super.iterator();
        }
        if (a2.size() <= 0) {
            return Iterators.emptyIterator();
        }
        int n2 = a2.l >> 4;
        int n3 = a2.b >> 4;
        int n4 = a2.c >> 4;
        int n5 = a2.v >> 4;
        ArrayList arrayList = new ArrayList();
        int n6 = n2;
        while (n6 <= n4) {
            int n7 = n3;
            while (n7 <= n5) {
                Set set = a2.a(n6, n7, false);
                if (set != null) {
                    arrayList.add(set.iterator());
                }
                ++n7;
            }
            ++n6;
        }
        if (arrayList.size() <= 0) {
            return Iterators.emptyIterator();
        }
        if (arrayList.size() == 1) {
            return (Iterator)arrayList.get(0);
        }
        return Iterators.concat(arrayList.iterator());
    }

    public void a(int a2, int a3, int a4, int a5) {
        a.l = Math.min(a2, a4);
        a.b = Math.min(a3, a5);
        a.c = Math.max(a2, a4);
        a.v = Math.max(a3, a5);
    }

    public void a() {
        a.l = Integer.MIN_VALUE;
        a.b = Integer.MIN_VALUE;
        a.c = Integer.MIN_VALUE;
        a.v = Integer.MIN_VALUE;
    }
}

