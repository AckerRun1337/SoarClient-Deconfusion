/*
 * Decompiled with CFR 0.152.
 */
import java.util.Iterator;

class btc
implements Iterable {
    private final /* synthetic */ tp v;
    private final /* synthetic */ tp d;

    btc(tp a2, tp a3) {
        btc a4;
        a4.v = a2;
        a4.d = a3;
    }

    public Iterator iterator() {
        btc a2;
        return new xpa(a2, a2.v, a2.d);
    }
}

