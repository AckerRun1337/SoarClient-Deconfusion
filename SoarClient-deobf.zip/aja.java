/*
 * Decompiled with CFR 0.152.
 */
public class aja
extends dl {
    public /* synthetic */ o<?> d;

    public aja(o<?> a2) {
        aja a3;
        a3.d = a2;
    }

    public o<?> a() {
        aja a2;
        return a2.d;
    }

    public void a(o<?> a2) {
        a.d = a2;
    }
}

