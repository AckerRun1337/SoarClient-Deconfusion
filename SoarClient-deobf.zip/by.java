/*
 * Decompiled with CFR 0.152.
 */
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class by
extends yd {
    public static final kcb<ewb> b = kcb.a("variant", ewb.class);
    public static final int c = ewb.f.a();
    public static final int v = ewb.h.a();
    public static final int d = ewb.z.a();

    public by() {
        super(dr.ka);
        by a2;
        a2.a(a2.c.a().a(b, ewb.f));
        a2.a(md.g);
    }

    @Override
    public String p() {
        by a2;
        return bwa.p(String.valueOf(a2.a()) + "." + ewb.f.a() + ".name");
    }

    @Override
    public rpb a(ba a2) {
        return a2.a(b) == ewb.f ? rpb.p : rpb.h;
    }

    @Override
    public int p(ba a2) {
        return a2.a(b).a();
    }

    @Override
    public int o(ba a2) {
        return a2.a(b).a();
    }

    @Override
    protected lf p() {
        by a2;
        return new lf(a2, b);
    }

    @Override
    public ba a(int a2) {
        by a3;
        return a3.a().a(b, ewb.a(a2));
    }

    @Override
    public void a(ge a2, md a3, List<wfc> a4) {
        a4.add(new wfc(a2, 1, c));
        a4.add(new wfc(a2, 1, v));
        a4.add(new wfc(a2, 1, d));
    }
}

