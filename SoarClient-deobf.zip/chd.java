/*
 * Decompiled with CFR 0.152.
 */
import java.io.Serializable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class chd
extends jp
implements Serializable {
    static final long d = -7031930069184524614L;

    public chd(float a2, float a3, float a4) {
        super(a2, a3, a4);
        chd a5;
    }

    public chd(float[] a2) {
        super(a2);
        chd a3;
    }

    public chd(chd a2) {
        super(a2);
        chd a3;
    }

    public chd(tla a2) {
        super(a2);
        chd a3;
    }

    public chd(jp a2) {
        super(a2);
        chd a3;
    }

    public chd(dva a2) {
        super(a2);
        chd a3;
    }

    public chd() {
        chd a2;
    }

    public final float z() {
        chd a2;
        return a2.c * a2.c + a2.v * a2.v + a2.d * a2.d;
    }

    public final float y() {
        chd a2;
        return (float)Math.sqrt(a2.c * a2.c + a2.v * a2.v + a2.d * a2.d);
    }

    public final void a(chd a2, chd a3) {
        float f2 = a2.v * a3.d - a2.d * a3.v;
        float f3 = a3.c * a2.d - a3.d * a2.c;
        a.d = (long)(a2.c * a3.v - a2.v * a3.c);
        a.c = f2;
        a.v = f3;
    }

    public final float p(chd a2) {
        chd a3;
        return a3.c * a2.c + a3.v * a2.v + a3.d * a2.d;
    }

    public final void a(chd a2) {
        float f2 = (float)(1.0 / Math.sqrt(a2.c * a2.c + a2.v * a2.v + a2.d * a2.d));
        a.c = a2.c * f2;
        a.v = a2.v * f2;
        a.d = a2.d * f2;
    }

    public final void o() {
        chd a2;
        float f2 = (float)(1.0 / Math.sqrt(a2.c * a2.c + a2.v * a2.v + a2.d * a2.d));
        a2.c *= f2;
        a2.v *= f2;
        a2.d *= f2;
    }

    public final float a(chd a2) {
        chd a3;
        double d2 = a3.p(a2) / (a3.y() * a2.y());
        if (d2 < -1.0) {
            d2 = -1.0;
        }
        if (d2 > 1.0) {
            d2 = 1.0;
        }
        return (float)Math.acos(d2);
    }
}

