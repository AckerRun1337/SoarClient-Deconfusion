/*
 * Decompiled with CFR 0.152.
 */
public class bgc
extends ywa {
    public bgc() {
        bgc a2;
    }

    @Override
    public boolean g() {
        return false;
    }
}

