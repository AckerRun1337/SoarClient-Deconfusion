/*
 * Decompiled with CFR 0.152.
 */
class alb
extends Thread {
    final /* synthetic */ nnc d;

    alb(nnc a2, String a3) {
        alb a4;
        a4.d = a2;
        super(a3);
    }

    @Override
    public void run() {
        alb a2;
        nnc.a(a2.d).c();
    }
}

