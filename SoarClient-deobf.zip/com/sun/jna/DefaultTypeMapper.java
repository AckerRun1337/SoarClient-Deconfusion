/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeConverter;
import com.sun.jna.ToNativeConverter;
import com.sun.jna.TypeConverter;
import com.sun.jna.TypeMapper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class DefaultTypeMapper
implements TypeMapper {
    private List<Entry> v = new ArrayList<Entry>();
    private List<Entry> d = new ArrayList<Entry>();

    public DefaultTypeMapper() {
        DefaultTypeMapper a2;
    }

    private /* synthetic */ Class<?> a(Class<?> a2) {
        if (a2 == Boolean.class) {
            return Boolean.TYPE;
        }
        if (a2 == Boolean.TYPE) {
            return Boolean.class;
        }
        if (a2 == Byte.class) {
            return Byte.TYPE;
        }
        if (a2 == Byte.TYPE) {
            return Byte.class;
        }
        if (a2 == Character.class) {
            return Character.TYPE;
        }
        if (a2 == Character.TYPE) {
            return Character.class;
        }
        if (a2 == Short.class) {
            return Short.TYPE;
        }
        if (a2 == Short.TYPE) {
            return Short.class;
        }
        if (a2 == Integer.class) {
            return Integer.TYPE;
        }
        if (a2 == Integer.TYPE) {
            return Integer.class;
        }
        if (a2 == Long.class) {
            return Long.TYPE;
        }
        if (a2 == Long.TYPE) {
            return Long.class;
        }
        if (a2 == Float.class) {
            return Float.TYPE;
        }
        if (a2 == Float.TYPE) {
            return Float.class;
        }
        if (a2 == Double.class) {
            return Double.TYPE;
        }
        if (a2 == Double.TYPE) {
            return Double.class;
        }
        return null;
    }

    public void a(Class<?> a2, ToNativeConverter a3) {
        DefaultTypeMapper a4;
        a4.v.add(new Entry(a2, a3));
        Class<?> a5 = a4.a(a2);
        if (a5 != null) {
            a4.v.add(new Entry(a5, a3));
        }
    }

    public void a(Class<?> a2, FromNativeConverter a3) {
        DefaultTypeMapper a4;
        a4.d.add(new Entry(a2, a3));
        Class<?> a5 = a4.a(a2);
        if (a5 != null) {
            a4.d.add(new Entry(a5, a3));
        }
    }

    public void a(Class<?> a2, TypeConverter a3) {
        DefaultTypeMapper a4;
        a4.a(a2, (FromNativeConverter)a3);
        a4.a(a2, (ToNativeConverter)a3);
    }

    private /* synthetic */ Object a(Class<?> a2, Collection<? extends Entry> a3) {
        for (Entry entry : a3) {
            if (!entry.v.isAssignableFrom(a2)) continue;
            return entry.d;
        }
        return null;
    }

    @Override
    public FromNativeConverter a(Class<?> a2) {
        DefaultTypeMapper a3;
        return (FromNativeConverter)a3.a(a2, a3.d);
    }

    @Override
    public ToNativeConverter a(Class<?> a2) {
        DefaultTypeMapper a3;
        return (ToNativeConverter)a3.a(a2, a3.v);
    }

    private static class Entry {
        public Class<?> v;
        public Object d;

        public Entry(Class<?> a2, Object a3) {
            Entry a4;
            a4.v = a2;
            a4.d = a3;
        }
    }
}

