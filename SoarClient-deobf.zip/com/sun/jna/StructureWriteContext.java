/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Structure;
import com.sun.jna.ToNativeContext;
import java.lang.reflect.Field;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class StructureWriteContext
extends ToNativeContext {
    private Structure v;
    private Field d;

    StructureWriteContext(Structure a2, Field a3) {
        StructureWriteContext a4;
        a4.v = a2;
        a4.d = a3;
    }

    public Structure a() {
        StructureWriteContext a2;
        return a2.v;
    }

    public Field a() {
        StructureWriteContext a2;
        return a2.d;
    }
}

