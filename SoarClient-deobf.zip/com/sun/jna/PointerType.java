/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import com.sun.jna.NativeMapped;
import com.sun.jna.Pointer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class PointerType
implements NativeMapped {
    private Pointer d;

    protected PointerType() {
        PointerType a2;
        a2.d = Pointer.v;
    }

    protected PointerType(Pointer a2) {
        PointerType a3;
        a3.d = a2;
    }

    @Override
    public Class<?> a() {
        return Pointer.class;
    }

    @Override
    public Object a() {
        PointerType a2;
        return a2.a();
    }

    @Override
    public Pointer a() {
        PointerType a2;
        return a2.d;
    }

    public void a(Pointer a2) {
        a.d = a2;
    }

    @Override
    public Object a(Object a2, FromNativeContext a3) {
        PointerType a4;
        if (a2 == null) {
            return null;
        }
        try {
            PointerType a5 = (PointerType)a4.getClass().newInstance();
            a5.d = (Pointer)a2;
            return a5;
        }
        catch (InstantiationException a6) {
            throw new IllegalArgumentException("Can't instantiate " + a4.getClass());
        }
        catch (IllegalAccessException a7) {
            throw new IllegalArgumentException("Not allowed to instantiate " + a4.getClass());
        }
    }

    public int hashCode() {
        PointerType a2;
        return a2.d != null ? a2.d.hashCode() : 0;
    }

    public boolean equals(Object a2) {
        PointerType a3;
        if (a2 == a3) {
            return true;
        }
        if (a2 instanceof PointerType) {
            Object a4 = ((PointerType)a2).a();
            if (a3.d == null) {
                return a4 == null;
            }
            return a3.d.equals(a4);
        }
        return false;
    }

    public String toString() {
        PointerType a2;
        return a2.d == null ? "NULL" : a2.d.toString() + " (" + super.toString() + ")";
    }
}

