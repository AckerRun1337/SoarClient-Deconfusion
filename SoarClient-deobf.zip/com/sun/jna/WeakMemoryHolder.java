/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Memory;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.IdentityHashMap;

public class WeakMemoryHolder {
    ReferenceQueue<Object> v = new ReferenceQueue();
    IdentityHashMap<Reference<Object>, Memory> d = new IdentityHashMap();

    public WeakMemoryHolder() {
        WeakMemoryHolder a2;
    }

    public synchronized void a(Object a2, Memory a3) {
        WeakMemoryHolder a4;
        a4.a();
        WeakReference<Object> a5 = new WeakReference<Object>(a2, a4.v);
        a4.d.put(a5, a3);
    }

    public synchronized void a() {
        WeakMemoryHolder a2;
        Reference<Object> a3 = a2.v.poll();
        while (a3 != null) {
            a2.d.remove(a3);
            a3 = a2.v.poll();
        }
    }
}

