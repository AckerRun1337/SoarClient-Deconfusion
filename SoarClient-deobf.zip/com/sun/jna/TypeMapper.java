/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeConverter;
import com.sun.jna.ToNativeConverter;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface TypeMapper {
    public FromNativeConverter a(Class<?> var1);

    public ToNativeConverter a(Class<?> var1);
}

