/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.IntegerType;
import com.sun.jna.Native;

public class NativeLong
extends IntegerType {
    private static final long v = 1L;
    public static final int d = Native.fa;

    public NativeLong() {
        a2(0L);
        NativeLong a2;
    }

    public NativeLong(long a2) {
        a3(a2, false);
        NativeLong a3;
    }

    public NativeLong(long a2, boolean a3) {
        super(d, a2, a3);
        NativeLong a4;
    }
}

