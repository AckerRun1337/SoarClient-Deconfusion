/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import java.lang.reflect.Method;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CallbackParameterContext
extends FromNativeContext {
    private Method c;
    private Object[] v;
    private int d;

    CallbackParameterContext(Class<?> a2, Method a3, Object[] a4, int a5) {
        super(a2);
        CallbackParameterContext a6;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    public Method a() {
        CallbackParameterContext a2;
        return a2.c;
    }

    public Object[] a() {
        CallbackParameterContext a2;
        return a2.v;
    }

    public int a() {
        CallbackParameterContext a2;
        return a2.d;
    }
}

