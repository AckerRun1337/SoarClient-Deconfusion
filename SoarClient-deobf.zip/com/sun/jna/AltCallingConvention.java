/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

public interface AltCallingConvention {
}

