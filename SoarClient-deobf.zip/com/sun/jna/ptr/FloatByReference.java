/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class FloatByReference
extends ByReference {
    public FloatByReference() {
        a2(0.0f);
        FloatByReference a2;
    }

    public FloatByReference(float a2) {
        super(4);
        FloatByReference a3;
        a3.a(a2);
    }

    public void a(float a2) {
        FloatByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public float a() {
        FloatByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

