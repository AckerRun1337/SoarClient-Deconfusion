/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class NativeLongByReference
extends ByReference {
    public NativeLongByReference() {
        a2(new NativeLong(0L));
        NativeLongByReference a2;
    }

    public NativeLongByReference(NativeLong a2) {
        super(NativeLong.d);
        NativeLongByReference a3;
        a3.a(a2);
    }

    public void a(NativeLong a2) {
        NativeLongByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    @Override
    public NativeLong a() {
        NativeLongByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

