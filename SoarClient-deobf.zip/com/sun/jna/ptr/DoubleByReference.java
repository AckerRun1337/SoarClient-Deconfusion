/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class DoubleByReference
extends ByReference {
    public DoubleByReference() {
        a2(0.0);
        DoubleByReference a2;
    }

    public DoubleByReference(double a2) {
        super(8);
        DoubleByReference a3;
        a3.a(a2);
    }

    public void a(double a2) {
        DoubleByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public double a() {
        DoubleByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

