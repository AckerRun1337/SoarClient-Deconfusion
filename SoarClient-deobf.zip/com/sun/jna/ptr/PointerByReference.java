/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class PointerByReference
extends ByReference {
    public PointerByReference() {
        a2(null);
        PointerByReference a2;
    }

    public PointerByReference(Pointer a2) {
        super(Pointer.c);
        PointerByReference a3;
        a3.p(a2);
    }

    public void p(Pointer a2) {
        PointerByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public Pointer p() {
        PointerByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

