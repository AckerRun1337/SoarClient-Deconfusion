/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class IntByReference
extends ByReference {
    public IntByReference() {
        a2(0);
        IntByReference a2;
    }

    public IntByReference(int a2) {
        super(4);
        IntByReference a3;
        a3.a(a2);
    }

    public void a(int a2) {
        IntByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public int a() {
        IntByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

