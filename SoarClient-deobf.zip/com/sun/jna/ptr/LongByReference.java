/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class LongByReference
extends ByReference {
    public LongByReference() {
        a2(0L);
        LongByReference a2;
    }

    public LongByReference(long a2) {
        super(8);
        LongByReference a3;
        a3.a(a2);
    }

    public void a(long a2) {
        LongByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public long a() {
        LongByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

