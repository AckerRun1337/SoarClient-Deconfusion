/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class ByteByReference
extends ByReference {
    public ByteByReference() {
        a2(0);
        ByteByReference a2;
    }

    public ByteByReference(byte a2) {
        super(1);
        ByteByReference a3;
        a3.a(a2);
    }

    public void a(byte a2) {
        ByteByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public byte a() {
        ByteByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

