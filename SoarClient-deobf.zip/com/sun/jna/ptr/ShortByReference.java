/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.ptr;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class ShortByReference
extends ByReference {
    public ShortByReference() {
        a2(0);
        ShortByReference a2;
    }

    public ShortByReference(short a2) {
        super(2);
        ShortByReference a3;
        a3.a(a2);
    }

    public void a(short a2) {
        ShortByReference a3;
        ((Pointer)a3.a()).a(0L, a2);
    }

    public short a() {
        ShortByReference a2;
        return ((Pointer)a2.a()).a(0L);
    }
}

