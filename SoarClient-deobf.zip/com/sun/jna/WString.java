/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

public final class WString
implements CharSequence,
Comparable {
    private String d;

    public WString(String a2) {
        WString a3;
        if (a2 == null) {
            throw new NullPointerException("String initializer must be non-null");
        }
        a3.d = a2;
    }

    @Override
    public String toString() {
        WString a2;
        return a2.d;
    }

    public boolean equals(Object a2) {
        WString a3;
        return a2 instanceof WString && a3.toString().equals(a2.toString());
    }

    public int hashCode() {
        WString a2;
        return a2.toString().hashCode();
    }

    public int compareTo(Object a2) {
        WString a3;
        return a3.toString().compareTo(a2.toString());
    }

    @Override
    public int length() {
        WString a2;
        return a2.toString().length();
    }

    @Override
    public char charAt(int a2) {
        WString a3;
        return a3.toString().charAt(a2);
    }

    @Override
    public CharSequence subSequence(int a2, int a3) {
        WString a4;
        return a4.toString().subSequence(a2, a3);
    }
}

