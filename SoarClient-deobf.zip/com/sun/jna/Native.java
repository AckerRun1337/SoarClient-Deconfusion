/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;
import com.sun.jna.CallbackReference;
import com.sun.jna.CallbackThreadInitializer;
import com.sun.jna.FromNativeContext;
import com.sun.jna.FromNativeConverter;
import com.sun.jna.Function;
import com.sun.jna.IntegerType;
import com.sun.jna.JNIEnv;
import com.sun.jna.LastErrorException;
import com.sun.jna.Library;
import com.sun.jna.Memory;
import com.sun.jna.MethodResultContext;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.PointerType;
import com.sun.jna.Structure;
import com.sun.jna.ToNativeContext;
import com.sun.jna.ToNativeConverter;
import com.sun.jna.TypeMapper;
import com.sun.jna.Version;
import com.sun.jna.WString;
import java.awt.Component;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Window;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.WeakHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Native
implements Version {
    public static final String mb = Charset.defaultCharset().name();
    public static boolean gb = Boolean.getBoolean("jna.debug_load");
    public static boolean wb = Boolean.getBoolean("jna.debug_load.jna");
    static String nb = null;
    private static final Map<Class<?>, Map<String, Object>> rb = new WeakHashMap();
    private static final Map<Class<?>, Reference<?>> jb = new WeakHashMap();
    private static final String hb = "enclosing-library";
    private static final Callback.UncaughtExceptionHandler ra;
    private static Callback.UncaughtExceptionHandler aa;
    public static final int za;
    public static final int fa;
    public static final int wa;
    public static final int va;
    public static final int sa;
    private static final int ea = 0;
    private static final int qa = 1;
    private static final int xa = 2;
    private static final int ua = 3;
    private static final int da = 4;
    static final int ma;
    static final int na;
    private static final Object ka;
    static final String ha = "jna";
    private static Map<Class<?>, long[]> ya;
    private static Map<Class<?>, NativeLibrary> ca;
    static final int ga = 1;
    private static final int ja = -1;
    private static final int ia = 0;
    private static final int ta = 1;
    private static final int oa = 2;
    private static final int pa = 3;
    private static final int ba = 4;
    private static final int la = 5;
    private static final int u = 6;
    private static final int j = 7;
    private static final int o = 8;
    private static final int m = 9;
    private static final int y = 10;
    private static final int a = 11;
    private static final int q = 12;
    private static final int g = 13;
    private static final int k = 14;
    private static final int x = 15;
    private static final int t = 16;
    private static final int p = 17;
    private static final int s = 18;
    private static final int w = 19;
    private static final int i = 20;
    private static final int n = 21;
    private static final int e = 22;
    private static final int r = 23;
    private static final int f = 24;
    private static final int h = 25;
    private static final int z = 26;
    private static final int l = 27;
    static final int b = 1;
    static final int c = 2;
    private static final ThreadLocal<Memory> v;
    private static final Map<Thread, Pointer> d;

    @Deprecated
    public static float a(String a2) {
        return Float.parseFloat(a2.substring(0, a2.lastIndexOf(".")));
    }

    static boolean a(String a2, String a3) {
        String[] a4 = a2.split("\\.");
        String[] a5 = a3.split("\\.");
        if (a4.length < 3 || a5.length < 3) {
            return false;
        }
        int a6 = Integer.parseInt(a4[0]);
        int a7 = Integer.parseInt(a5[0]);
        int a8 = Integer.parseInt(a4[1]);
        int a9 = Integer.parseInt(a5[1]);
        if (a6 != a7) {
            return false;
        }
        return a8 <= a9;
    }

    private static /* synthetic */ void x() {
        CallbackReference.a();
        Memory.y();
        NativeLibrary.p();
        Native.o();
        nb = null;
        System.setProperty("jna.loaded", "false");
    }

    static boolean p(File a2) {
        if (a2.delete()) {
            return true;
        }
        Native.a(a2);
        return false;
    }

    private /* synthetic */ Native() {
        Native a2;
    }

    private static native /* synthetic */ void initIDs();

    public static synchronized native void setProtected(boolean var0);

    public static synchronized native boolean isProtected();

    @Deprecated
    public static void p(boolean a2) {
    }

    @Deprecated
    public static boolean a() {
        return true;
    }

    public static long a(Window a2) throws HeadlessException {
        return AWT.a(a2);
    }

    public static long a(Component a2) throws HeadlessException {
        return AWT.a(a2);
    }

    public static Pointer a(Window a2) throws HeadlessException {
        return new Pointer(AWT.a(a2));
    }

    public static Pointer a(Component a2) throws HeadlessException {
        return new Pointer(AWT.a(a2));
    }

    static native long getWindowHandle0(Component var0);

    public static Pointer a(Buffer a2) {
        long a3 = Native._getDirectBufferPointer(a2);
        return a3 == 0L ? null : new Pointer(a3);
    }

    private static native /* synthetic */ long _getDirectBufferPointer(Buffer var0);

    public static String a(byte[] a2) {
        return Native.a(a2, Native.a());
    }

    public static String a(byte[] a2, String a3) {
        int a4 = a2.length;
        for (int a5 = 0; a5 < a4; ++a5) {
            if (a2[a5] != 0) continue;
            a4 = a5;
            break;
        }
        if (a4 == 0) {
            return "";
        }
        if (a3 != null) {
            try {
                return new String(a2, 0, a4, a3);
            }
            catch (UnsupportedEncodingException a6) {
                System.err.println("JNA Warning: Encoding '" + a3 + "' is unsupported");
            }
        }
        System.err.println("JNA Warning: Decoding with fallback " + System.getProperty("file.encoding"));
        return new String(a2, 0, a4);
    }

    public static String a(char[] a2) {
        int a3 = a2.length;
        for (int a4 = 0; a4 < a3; ++a4) {
            if (a2[a4] != '\u0000') continue;
            a3 = a4;
            break;
        }
        if (a3 == 0) {
            return "";
        }
        return new String(a2, 0, a3);
    }

    public static List<String> a(char[] a2) {
        return Native.a(a2, 0, a2.length);
    }

    public static List<String> a(char[] a2, int a3, int a4) {
        ArrayList<String> a5 = new ArrayList<String>();
        int a6 = a3;
        int a7 = a3 + a4;
        for (int a8 = a3; a8 < a7; ++a8) {
            if (a2[a8] != '\u0000') continue;
            if (a6 == a8) {
                return a5;
            }
            String a9 = new String(a2, a6, a8 - a6);
            a5.add(a9);
            a6 = a8 + 1;
        }
        if (a6 < a7) {
            String a10 = new String(a2, a6, a7 - a6);
            a5.add(a10);
        }
        return a5;
    }

    public static <T> T a(Class<T> a2) {
        return Native.a(null, a2);
    }

    public static <T> T a(Class<T> a2, Map<String, ?> a3) {
        return Native.a(null, a2, a3);
    }

    public static <T> T a(String a2, Class<T> a3) {
        return Native.a(a2, a3, Collections.emptyMap());
    }

    public static <T> T a(String a2, Class<T> a3, Map<String, ?> a4) {
        if (!Library.class.isAssignableFrom(a3)) {
            throw new IllegalArgumentException("Interface (" + a3.getSimpleName() + ") of library=" + a2 + " does not extend " + Library.class.getSimpleName());
        }
        Library.Handler a5 = new Library.Handler(a2, a3, a4);
        ClassLoader a6 = a3.getClassLoader();
        Object a7 = Proxy.newProxyInstance(a6, new Class[]{a3}, (InvocationHandler)a5);
        Native.a(a3, a4, a7);
        return a3.cast(a7);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ void p(Class<?> a2) {
        Map<Class<?>, Reference<?>> map = jb;
        synchronized (map) {
            if (a2 != null && !jb.containsKey(a2)) {
                try {
                    Field[] a3 = a2.getFields();
                    for (int a4 = 0; a4 < a3.length; ++a4) {
                        Field a5 = a3[a4];
                        if (a5.getType() != a2 || !Modifier.isStatic(a5.getModifiers())) continue;
                        jb.put(a2, new WeakReference<Object>(a5.get(null)));
                        break;
                    }
                }
                catch (Exception a6) {
                    throw new IllegalArgumentException("Could not access instance of " + a2 + " (" + a6 + ")");
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static Class<?> o(Class<?> a2) {
        Class<?> a3;
        Class<?> a4;
        if (a2 == null) {
            return null;
        }
        Map<Class<?>, Reference<?>> map = jb;
        synchronized (map) {
            if (rb.containsKey(a2)) {
                Map<String, Object> a5 = rb.get(a2);
                Class a6 = (Class)a5.get(hb);
                if (a6 != null) {
                    return a6;
                }
                return a2;
            }
        }
        if (Library.class.isAssignableFrom(a2)) {
            return a2;
        }
        if (Callback.class.isAssignableFrom(a2)) {
            a2 = CallbackReference.a(a2);
        }
        if ((a4 = Native.o(a3 = a2.getDeclaringClass())) != null) {
            return a4;
        }
        return Native.o(a2.getSuperclass());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static Map<String, Object> a(Class<?> a2) {
        Map<String, Object> a3;
        Map<Class<?>, Reference<?>> map = jb;
        synchronized (map) {
            a3 = rb.get(a2);
            if (a3 != null) {
                return a3;
            }
        }
        Class<?> a4 = Native.o(a2);
        if (a4 != null) {
            Native.p(a4);
        } else {
            a4 = a2;
        }
        Map<Class<?>, Reference<?>> map2 = jb;
        synchronized (map2) {
            a3 = rb.get(a4);
            if (a3 != null) {
                rb.put(a2, a3);
                return a3;
            }
            try {
                Field a5 = a4.getField("OPTIONS");
                a5.setAccessible(true);
                a3 = (Map<String, Object>)a5.get(null);
                if (a3 == null) {
                    throw new IllegalStateException("Null options field");
                }
            }
            catch (NoSuchFieldException a6) {
                a3 = Collections.emptyMap();
            }
            catch (Exception a7) {
                throw new IllegalArgumentException("OPTIONS must be a public field of type java.util.Map (" + a7 + "): " + a4);
            }
            a3 = new HashMap<String, Object>(a3);
            if (!a3.containsKey("type-mapper")) {
                a3.put("type-mapper", Native.a(a4, "TYPE_MAPPER", TypeMapper.class));
            }
            if (!a3.containsKey("structure-alignment")) {
                a3.put("structure-alignment", Native.a(a4, "STRUCTURE_ALIGNMENT", Integer.class));
            }
            if (!a3.containsKey("string-encoding")) {
                a3.put("string-encoding", Native.a(a4, "STRING_ENCODING", String.class));
            }
            a3 = Native.a(a4, a3, null);
            if (a2 != a4) {
                rb.put(a2, a3);
            }
            return a3;
        }
    }

    private static /* synthetic */ Object a(Class<?> a2, String a3, Class<?> a4) {
        try {
            Field a5 = a2.getField(a3);
            a5.setAccessible(true);
            return a5.get(null);
        }
        catch (NoSuchFieldException a6) {
            return null;
        }
        catch (Exception a7) {
            throw new IllegalArgumentException(a3 + " must be a public field of type " + a4.getName() + " (" + a7 + "): " + a2);
        }
    }

    public static TypeMapper a(Class<?> a2) {
        Map<String, Object> a3 = Native.a(a2);
        return (TypeMapper)a3.get("type-mapper");
    }

    public static String p(Class<?> a2) {
        Map<String, Object> a3 = Native.a(a2);
        String a4 = (String)a3.get("string-encoding");
        return a4 != null ? a4 : Native.a();
    }

    public static String a() {
        return System.getProperty("jna.encoding", mb);
    }

    public static int p(Class<?> a2) {
        Integer a3 = (Integer)Native.a(a2).get("structure-alignment");
        return a3 == null ? 0 : a3;
    }

    static byte[] p(String a2) {
        return Native.p(a2, Native.a());
    }

    static byte[] p(String a2, String a3) {
        if (a3 != null) {
            try {
                return a2.getBytes(a3);
            }
            catch (UnsupportedEncodingException a4) {
                System.err.println("JNA Warning: Encoding '" + a3 + "' is unsupported");
            }
        }
        System.err.println("JNA Warning: Encoding with fallback " + System.getProperty("file.encoding"));
        return a2.getBytes();
    }

    public static byte[] a(String a2) {
        return Native.a(a2, Native.a());
    }

    public static byte[] a(String a2, String a3) {
        byte[] a4 = Native.p(a2, a3);
        byte[] a5 = new byte[a4.length + 1];
        System.arraycopy(a4, 0, a5, 0, a4.length);
        return a5;
    }

    public static char[] a(String a2) {
        char[] a3 = a2.toCharArray();
        char[] a4 = new char[a3.length + 1];
        System.arraycopy(a3, 0, a4, 0, a3.length);
        return a4;
    }

    private static /* synthetic */ void j() {
        if (!Boolean.getBoolean("jna.nounpack")) {
            try {
                Native.y();
            }
            catch (IOException a2) {
                System.err.println("JNA Warning: IOException removing temporary files: " + a2.getMessage());
            }
        }
        String a3 = System.getProperty("jna.boot.library.name", "jnidispatch");
        String a4 = System.getProperty("jna.boot.library.path");
        if (a4 != null) {
            StringTokenizer a5 = new StringTokenizer(a4, File.pathSeparator);
            while (a5.hasMoreTokens()) {
                String a6;
                String a7;
                String a8 = a5.nextToken();
                File a9 = new File(new File(a8), System.mapLibraryName(a3).replace(".dylib", ".jnilib"));
                String a10 = a9.getAbsolutePath();
                if (wb) {
                    System.out.println("Looking in " + a10);
                }
                if (a9.exists()) {
                    try {
                        if (wb) {
                            System.out.println("Trying " + a10);
                        }
                        System.setProperty("jnidispatch.path", a10);
                        System.load(a10);
                        nb = a10;
                        if (wb) {
                            System.out.println("Found jnidispatch at " + a10);
                        }
                        return;
                    }
                    catch (UnsatisfiedLinkError unsatisfiedLinkError) {
                        // empty catch block
                    }
                }
                if (!Platform.t()) continue;
                if (a10.endsWith("dylib")) {
                    a7 = "dylib";
                    a6 = "jnilib";
                } else {
                    a7 = "jnilib";
                    a6 = "dylib";
                }
                a10 = a10.substring(0, a10.lastIndexOf(a7)) + a6;
                if (wb) {
                    System.out.println("Looking in " + a10);
                }
                if (!new File(a10).exists()) continue;
                try {
                    if (wb) {
                        System.out.println("Trying " + a10);
                    }
                    System.setProperty("jnidispatch.path", a10);
                    System.load(a10);
                    nb = a10;
                    if (wb) {
                        System.out.println("Found jnidispatch at " + a10);
                    }
                    return;
                }
                catch (UnsatisfiedLinkError a11) {
                    System.err.println("File found at " + a10 + " but not loadable: " + a11.getMessage());
                }
            }
        }
        if (!Boolean.getBoolean("jna.nosys")) {
            try {
                if (wb) {
                    System.out.println("Trying (via loadLibrary) " + a3);
                }
                System.loadLibrary(a3);
                if (wb) {
                    System.out.println("Found jnidispatch on system path");
                }
                return;
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError) {
                // empty catch block
            }
        }
        if (Boolean.getBoolean("jna.noclasspath")) {
            throw new UnsatisfiedLinkError("Unable to locate JNA native support library");
        }
        Native.z();
    }

    private static /* synthetic */ void z() {
        try {
            String a2 = "/com/sun/jna/" + Platform.c + "/" + System.mapLibraryName("jnidispatch").replace(".dylib", ".jnilib");
            File a3 = Native.a(a2, Native.class.getClassLoader());
            if (a3 == null && a3 == null) {
                throw new UnsatisfiedLinkError("Could not find JNA native support");
            }
            if (wb) {
                System.out.println("Trying " + a3.getAbsolutePath());
            }
            System.setProperty("jnidispatch.path", a3.getAbsolutePath());
            System.load(a3.getAbsolutePath());
            nb = a3.getAbsolutePath();
            if (wb) {
                System.out.println("Found jnidispatch at " + nb);
            }
            if (Native.a(a3) && !Boolean.getBoolean("jnidispatch.preserve")) {
                Native.p(a3);
            }
        }
        catch (IOException a4) {
            throw new UnsatisfiedLinkError(a4.getMessage());
        }
    }

    static boolean a(File a2) {
        return a2.getName().startsWith(ha);
    }

    public static File a(String a2) throws IOException {
        return Native.a(a2, null);
    }

    public static File a(String a2, ClassLoader a3) throws IOException {
        URL a4;
        String a5;
        boolean a6;
        boolean bl2 = a6 = gb || wb && a2.indexOf("jnidispatch") != -1;
        if (a3 == null && (a3 = Thread.currentThread().getContextClassLoader()) == null) {
            a3 = Native.class.getClassLoader();
        }
        if (a6) {
            System.out.println("Looking in classpath from " + a3 + " for " + a2);
        }
        String a7 = a2.startsWith("/") ? a2 : NativeLibrary.a(a2);
        String string = a5 = a2.startsWith("/") ? a2 : Platform.c + "/" + a7;
        if (a5.startsWith("/")) {
            a5 = a5.substring(1);
        }
        if ((a4 = a3.getResource(a5)) == null && a5.startsWith(Platform.c)) {
            a4 = a3.getResource(a7);
        }
        if (a4 == null) {
            String a8 = System.getProperty("java.class.path");
            if (a3 instanceof URLClassLoader) {
                a8 = Arrays.asList(((URLClassLoader)a3).getURLs()).toString();
            }
            throw new IOException("Native library (" + a5 + ") not found in resource path (" + a8 + ")");
        }
        if (a6) {
            System.out.println("Found library resource at " + a4);
        }
        File a9 = null;
        if (a4.getProtocol().toLowerCase().equals("file")) {
            try {
                a9 = new File(new URI(a4.toString()));
            }
            catch (URISyntaxException a10) {
                a9 = new File(a4.getPath());
            }
            if (a6) {
                System.out.println("Looking in " + a9.getAbsolutePath());
            }
            if (!a9.exists()) {
                throw new IOException("File URL " + a4 + " could not be properly decoded");
            }
        } else if (!Boolean.getBoolean("jna.nounpack")) {
            InputStream a11 = a3.getResourceAsStream(a5);
            if (a11 == null) {
                throw new IOException("Can't obtain InputStream for " + a5);
            }
            FileOutputStream a12 = null;
            try {
                int a13;
                File a14 = Native.a();
                a9 = File.createTempFile(ha, Platform.e() ? ".dll" : null, a14);
                if (!Boolean.getBoolean("jnidispatch.preserve")) {
                    a9.deleteOnExit();
                }
                a12 = new FileOutputStream(a9);
                byte[] a15 = new byte[1024];
                while ((a13 = a11.read(a15, 0, a15.length)) > 0) {
                    a12.write(a15, 0, a13);
                }
            }
            catch (IOException a16) {
                throw new IOException("Failed to create temporary file for " + a2 + " library: " + a16.getMessage());
            }
            finally {
                try {
                    a11.close();
                }
                catch (IOException iOException) {}
                if (a12 != null) {
                    try {
                        a12.close();
                    }
                    catch (IOException iOException) {}
                }
            }
        }
        return a9;
    }

    private static native /* synthetic */ int sizeof(int var0);

    private static native /* synthetic */ String getNativeVersion();

    private static native /* synthetic */ String getAPIChecksum();

    public static native int getLastError();

    public static native void setLastError(int var0);

    public static Library a(final Library a2) {
        Class<?> a3 = a2.getClass();
        if (!Proxy.isProxyClass(a3)) {
            throw new IllegalArgumentException("Library must be a proxy class");
        }
        InvocationHandler a4 = Proxy.getInvocationHandler(a2);
        if (!(a4 instanceof Library.Handler)) {
            throw new IllegalArgumentException("Unrecognized proxy handler: " + a4);
        }
        final Library.Handler a5 = (Library.Handler)a4;
        InvocationHandler a6 = new InvocationHandler(){
            {
                3 a22;
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            @Override
            public Object invoke(Object a22, Method a3, Object[] a4) throws Throwable {
                3 a52;
                NativeLibrary nativeLibrary = a52.a5.a();
                synchronized (nativeLibrary) {
                    return a52.a5.invoke(a52.a2, a3, a4);
                }
            }
        };
        return (Library)Proxy.newProxyInstance(a3.getClassLoader(), a3.getInterfaces(), a6);
    }

    public static String a(String a2) {
        if (System.getProperty("javawebstart.version") == null) {
            return null;
        }
        try {
            ClassLoader a3 = Native.class.getClassLoader();
            Method a4 = AccessController.doPrivileged(new PrivilegedAction<Method>(){
                {
                    4 a2;
                }

                public Method a() {
                    try {
                        Method a2 = ClassLoader.class.getDeclaredMethod("findLibrary", String.class);
                        a2.setAccessible(true);
                        return a2;
                    }
                    catch (Exception a3) {
                        return null;
                    }
                }
            });
            String a5 = (String)a4.invoke(a3, a2);
            if (a5 != null) {
                return new File(a5).getParent();
            }
            return null;
        }
        catch (Exception a6) {
            return null;
        }
    }

    static void a(File a2) {
        try {
            File a3 = new File(a2.getParentFile(), a2.getName() + ".x");
            a3.createNewFile();
        }
        catch (IOException a4) {
            a4.printStackTrace();
        }
    }

    static File a() throws IOException {
        File a2;
        String a3 = System.getProperty("jna.tmpdir");
        if (a3 != null) {
            a2 = new File(a3);
            a2.mkdirs();
        } else {
            File a4 = new File(System.getProperty("java.io.tmpdir"));
            a2 = new File(a4, "jna-" + System.getProperty("user.name").hashCode());
            a2.mkdirs();
            if (!a2.exists() || !a2.canWrite()) {
                a2 = a4;
            }
        }
        if (!a2.exists()) {
            throw new IOException("JNA temporary directory '" + a2 + "' does not exist");
        }
        if (!a2.canWrite()) {
            throw new IOException("JNA temporary directory '" + a2 + "' is not writable");
        }
        return a2;
    }

    static void y() throws IOException {
        File a2 = Native.a();
        FilenameFilter a3 = new FilenameFilter(){
            {
                5 a2;
            }

            @Override
            public boolean accept(File a2, String a3) {
                return a3.endsWith(".x") && a3.startsWith(Native.ha);
            }
        };
        File[] a4 = a2.listFiles(a3);
        for (int a5 = 0; a4 != null && a5 < a4.length; ++a5) {
            File a6 = a4[a5];
            String a7 = a6.getName();
            a7 = a7.substring(0, a7.length() - 2);
            File a8 = new File(a6.getParentFile(), a7);
            if (a8.exists() && !a8.delete()) continue;
            a6.delete();
        }
    }

    public static int a(Class<?> a2, Object a3) {
        if (a2.isArray()) {
            int a4 = Array.getLength(a3);
            if (a4 > 0) {
                Object a5 = Array.get(a3, 0);
                return a4 * Native.a(a2.getComponentType(), a5);
            }
            throw new IllegalArgumentException("Arrays of length zero not allowed: " + a2);
        }
        if (Structure.class.isAssignableFrom(a2) && !Structure.ByReference.class.isAssignableFrom(a2)) {
            return Structure.a(a2, (Structure)a3);
        }
        try {
            return Native.a(a2);
        }
        catch (IllegalArgumentException a6) {
            throw new IllegalArgumentException("The type \"" + a2.getName() + "\" is not supported: " + a6.getMessage());
        }
    }

    public static int a(Class<?> a2) {
        if (NativeMapped.class.isAssignableFrom(a2)) {
            a2 = NativeMappedConverter.a(a2).a();
        }
        if (a2 == Boolean.TYPE || a2 == Boolean.class) {
            return 4;
        }
        if (a2 == Byte.TYPE || a2 == Byte.class) {
            return 1;
        }
        if (a2 == Short.TYPE || a2 == Short.class) {
            return 2;
        }
        if (a2 == Character.TYPE || a2 == Character.class) {
            return wa;
        }
        if (a2 == Integer.TYPE || a2 == Integer.class) {
            return 4;
        }
        if (a2 == Long.TYPE || a2 == Long.class) {
            return 8;
        }
        if (a2 == Float.TYPE || a2 == Float.class) {
            return 4;
        }
        if (a2 == Double.TYPE || a2 == Double.class) {
            return 8;
        }
        if (Structure.class.isAssignableFrom(a2)) {
            if (Structure.ByValue.class.isAssignableFrom(a2)) {
                return Structure.p(a2);
            }
            return za;
        }
        if (Pointer.class.isAssignableFrom(a2) || Platform.r && Buffers.a(a2) || Callback.class.isAssignableFrom(a2) || String.class == a2 || WString.class == a2) {
            return za;
        }
        throw new IllegalArgumentException("Native size for type \"" + a2.getName() + "\" is unknown");
    }

    public static boolean p(Class<?> a2) {
        if (Structure.class.isAssignableFrom(a2)) {
            return true;
        }
        try {
            return Native.a(a2) != 0;
        }
        catch (IllegalArgumentException a3) {
            return false;
        }
    }

    public static void a(Callback.UncaughtExceptionHandler a2) {
        aa = a2 == null ? ra : a2;
    }

    public static Callback.UncaughtExceptionHandler a() {
        return aa;
    }

    public static void a(String a2) {
        Native.a(Native.p(Native.a()), a2);
    }

    public static void a(NativeLibrary a2) {
        Native.a(Native.p(Native.a()), a2);
    }

    static Class<?> p(Class<?> a2) {
        Method[] a3;
        for (Method a4 : a3 = a2.getDeclaredMethods()) {
            if ((a4.getModifiers() & 0x100) == 0) continue;
            return a2;
        }
        int a5 = a2.getName().lastIndexOf("$");
        if (a5 != -1) {
            String a6 = a2.getName().substring(0, a5);
            try {
                return Native.p(Class.forName(a6, true, a2.getClassLoader()));
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
        }
        throw new IllegalArgumentException("Can't determine class with native methods from the current context (" + a2 + ")");
    }

    static Class<?> a() {
        Class<?>[] a2 = new SecurityManager(){
            {
                6 a2;
            }

            @Override
            public Class<?>[] getClassContext() {
                6 a2;
                return super.getClassContext();
            }
        }.getClassContext();
        if (a2 == null) {
            throw new IllegalStateException("The SecurityManager implementation on this platform is broken; you must explicitly provide the class to register");
        }
        if (a2.length < 4) {
            throw new IllegalStateException("This method must be called from the static initializer of a class");
        }
        return a2[3];
    }

    public static void a(Callback a2, CallbackThreadInitializer a3) {
        CallbackReference.a(a2, a3);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ void o() {
        Map<Class<?>, long[]> map = ya;
        synchronized (map) {
            for (Map.Entry<Class<?>, long[]> a2 : ya.entrySet()) {
                Native.unregister(a2.getKey(), a2.getValue());
            }
            ya.clear();
        }
    }

    public static void p() {
        Native.a(Native.p(Native.a()));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(Class<?> a2) {
        Map<Class<?>, long[]> map = ya;
        synchronized (map) {
            long[] a3 = ya.get(a2);
            if (a3 != null) {
                Native.unregister(a2, a3);
                ya.remove(a2);
                ca.remove(a2);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean a(Class<?> a2) {
        Map<Class<?>, long[]> map = ya;
        synchronized (map) {
            return ya.containsKey(a2);
        }
    }

    private static native /* synthetic */ void unregister(Class<?> var0, long[] var1);

    static String a(Class<?> a2) {
        if (a2.isArray()) {
            return "[" + Native.a(a2.getComponentType());
        }
        if (a2.isPrimitive()) {
            if (a2 == Void.TYPE) {
                return "V";
            }
            if (a2 == Boolean.TYPE) {
                return "Z";
            }
            if (a2 == Byte.TYPE) {
                return "B";
            }
            if (a2 == Short.TYPE) {
                return "S";
            }
            if (a2 == Character.TYPE) {
                return "C";
            }
            if (a2 == Integer.TYPE) {
                return "I";
            }
            if (a2 == Long.TYPE) {
                return "J";
            }
            if (a2 == Float.TYPE) {
                return "F";
            }
            if (a2 == Double.TYPE) {
                return "D";
            }
        }
        return "L" + Native.a(".", "/", a2.getName()) + ";";
    }

    static String a(String a2, String a3, String a4) {
        StringBuilder a5 = new StringBuilder();
        while (true) {
            int a6;
            if ((a6 = a4.indexOf(a2)) == -1) break;
            a5.append(a4.substring(0, a6));
            a5.append(a3);
            a4 = a4.substring(a6 + a2.length());
        }
        a5.append(a4);
        return a5.toString();
    }

    private static /* synthetic */ int a(Class<?> a2, TypeMapper a3, boolean a4) {
        Class<?> a5;
        if (a2 == Boolean.class) {
            a2 = Boolean.TYPE;
        } else if (a2 == Byte.class) {
            a2 = Byte.TYPE;
        } else if (a2 == Short.class) {
            a2 = Short.TYPE;
        } else if (a2 == Character.class) {
            a2 = Character.TYPE;
        } else if (a2 == Integer.class) {
            a2 = Integer.TYPE;
        } else if (a2 == Long.class) {
            a2 = Long.TYPE;
        } else if (a2 == Float.class) {
            a2 = Float.TYPE;
        } else if (a2 == Double.class) {
            a2 = Double.TYPE;
        } else if (a2 == Void.class) {
            a2 = Void.TYPE;
        }
        if (a3 != null) {
            a5 = a3.a(a2);
            ToNativeConverter a6 = a3.a(a2);
            if (a5 != null) {
                Class<?> a7 = a5.a();
                if (a7 == String.class) {
                    return 24;
                }
                if (a7 == WString.class) {
                    return 25;
                }
                return 23;
            }
            if (a6 != null) {
                Class<?> a8 = a6.a();
                if (a8 == String.class) {
                    return 24;
                }
                if (a8 == WString.class) {
                    return 25;
                }
                return 23;
            }
        }
        if (Pointer.class.isAssignableFrom(a2)) {
            return 1;
        }
        if (String.class == a2) {
            return 2;
        }
        if (WString.class.isAssignableFrom(a2)) {
            return 20;
        }
        if (Platform.r && Buffers.a(a2)) {
            return 5;
        }
        if (Structure.class.isAssignableFrom(a2)) {
            if (Structure.ByValue.class.isAssignableFrom(a2)) {
                return 4;
            }
            return 3;
        }
        if (a2.isArray()) {
            switch (a2.getName().charAt(1)) {
                case 'Z': {
                    return 13;
                }
                case 'B': {
                    return 6;
                }
                case 'S': {
                    return 7;
                }
                case 'C': {
                    return 8;
                }
                case 'I': {
                    return 9;
                }
                case 'J': {
                    return 10;
                }
                case 'F': {
                    return 11;
                }
                case 'D': {
                    return 12;
                }
            }
        }
        if (a2.isPrimitive()) {
            return a2 == Boolean.TYPE ? 14 : 0;
        }
        if (Callback.class.isAssignableFrom(a2)) {
            return 15;
        }
        if (IntegerType.class.isAssignableFrom(a2)) {
            return 21;
        }
        if (PointerType.class.isAssignableFrom(a2)) {
            return 22;
        }
        if (NativeMapped.class.isAssignableFrom(a2)) {
            a5 = NativeMappedConverter.a(a2).a();
            if (a5 == String.class) {
                return 18;
            }
            if (a5 == WString.class) {
                return 19;
            }
            return 17;
        }
        if (JNIEnv.class == a2) {
            return 27;
        }
        return a4 ? 26 : -1;
    }

    public static void a(Class<?> a2, String a3) {
        NativeLibrary a4 = NativeLibrary.a(a3, Collections.singletonMap("classloader", a2.getClassLoader()));
        Native.a(a2, a4);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - void declaration
     */
    public static void a(Class<?> a2, NativeLibrary a3) {
        Method[] a4 = a2.getDeclaredMethods();
        ArrayList<Method> a5 = new ArrayList<Method>();
        Map<String, Object> a6 = a3.a();
        TypeMapper a7 = (TypeMapper)a6.get("type-mapper");
        boolean a8 = Boolean.TRUE.equals(a6.get("allow-objects"));
        a6 = Native.a(a2, a6, null);
        for (Method method : a4) {
            if ((method.getModifiers() & 0x100) == 0) continue;
            a5.add(method);
        }
        long[] a10 = new long[a5.size()];
        for (int a11 = 0; a11 < a10.length; ++a11) {
            void var10_15;
            long a9;
            long a12;
            Method a15 = (Method)a5.get(a11);
            String string = "(";
            Class<?> a16 = a15.getReturnType();
            Class<?>[] a17 = a15.getParameterTypes();
            long[] a18 = new long[a17.length];
            long[] a19 = new long[a17.length];
            int[] a20 = new int[a17.length];
            ToNativeConverter[] a21 = new ToNativeConverter[a17.length];
            FromNativeConverter a22 = null;
            int a23 = Native.a(a16, a7, a8);
            boolean a24 = false;
            switch (a23) {
                case -1: {
                    throw new IllegalArgumentException(a16 + " is not a supported return type (in method " + a15.getName() + " in " + a2 + ")");
                }
                case 23: 
                case 24: 
                case 25: {
                    a22 = a7.a(a16);
                    a12 = Structure.FFIType.p(a16.isPrimitive() ? a16 : Pointer.class).d;
                    a9 = Structure.FFIType.p(a22.a()).d;
                    break;
                }
                case 17: 
                case 18: 
                case 19: 
                case 21: 
                case 22: {
                    long a14 = Structure.FFIType.p(Pointer.class).d;
                    a9 = Structure.FFIType.p(NativeMappedConverter.a(a16).a()).d;
                    break;
                }
                case 3: 
                case 26: {
                    long a13;
                    a12 = a13 = Structure.FFIType.p(Pointer.class).d;
                    break;
                }
                case 4: {
                    a12 = Structure.FFIType.p(Pointer.class).d;
                    a9 = Structure.FFIType.p(a16).d;
                    break;
                }
                default: {
                    a12 = a9 = Structure.FFIType.p(a16).d;
                }
            }
            block19: for (int a25 = 0; a25 < a17.length; ++a25) {
                int a26;
                Class<?> a122 = a17[a25];
                String string2 = (String)var10_15 + Native.a(a122);
                a20[a25] = a26 = Native.a(a122, a7, a8);
                if (a26 == -1) {
                    throw new IllegalArgumentException(a122 + " is not a supported argument type (in method " + a15.getName() + " in " + a2 + ")");
                }
                if (a26 == 17 || a26 == 18 || a26 == 19 || a26 == 21) {
                    a122 = NativeMappedConverter.a(a122).a();
                } else if (a26 == 23 || a26 == 24 || a26 == 25) {
                    a21[a25] = a7.a(a122);
                }
                switch (a26) {
                    case 4: 
                    case 17: 
                    case 18: 
                    case 19: 
                    case 21: 
                    case 22: {
                        a18[a25] = Structure.FFIType.p(a122).d;
                        a19[a25] = Structure.FFIType.p(Pointer.class).d;
                        continue block19;
                    }
                    case 23: 
                    case 24: 
                    case 25: {
                        a19[a25] = Structure.FFIType.p(a122.isPrimitive() ? a122 : Pointer.class).d;
                        a18[a25] = Structure.FFIType.p(a21[a25].a()).d;
                        continue block19;
                    }
                    case 0: {
                        a19[a25] = a18[a25] = Structure.FFIType.p(a122).d;
                        continue block19;
                    }
                    default: {
                        a19[a25] = a18[a25] = Structure.FFIType.p(Pointer.class).d;
                    }
                }
            }
            String string4 = (String)var10_15 + ")";
            string4 = string4 + Native.a(a16);
            Class<?>[] a27 = a15.getExceptionTypes();
            for (int a28 = 0; a28 < a27.length; ++a28) {
                if (!LastErrorException.class.isAssignableFrom(a27[a28])) continue;
                a24 = true;
                break;
            }
            Function a13 = a3.a(a15.getName(), a15);
            try {
                a10[a11] = Native.registerMethod(a2, a15.getName(), string4, a20, a19, a18, a23, a12, a9, a15, (long)a13.d, a13.a(), a24, a21, a22, a13.l);
                continue;
            }
            catch (NoSuchMethodError a29) {
                throw new UnsatisfiedLinkError("No method " + a15.getName() + " with signature " + string4 + " in " + a2);
            }
        }
        Map<Class<?>, long[]> map = ya;
        synchronized (map) {
            ya.put(a2, a10);
            ca.put(a2, a3);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ Map<String, Object> a(Class<?> a2, Map<String, ?> a3, Object a4) {
        HashMap<String, Object> a5 = new HashMap<String, Object>(a3);
        a5.put(hb, a2);
        Map<Class<?>, Reference<?>> map = jb;
        synchronized (map) {
            rb.put(a2, a5);
            if (a4 != null) {
                jb.put(a2, new WeakReference<Object>(a4));
            }
            if (!a2.isInterface() && Library.class.isAssignableFrom(a2)) {
                Class<?>[] a6;
                for (Class<?> a7 : a6 = a2.getInterfaces()) {
                    if (!Library.class.isAssignableFrom(a7)) continue;
                    Native.a(a7, a5, a4);
                    break;
                }
            }
        }
        return a5;
    }

    private static native /* synthetic */ long registerMethod(Class<?> var0, String var1, String var2, int[] var3, long[] var4, long[] var5, int var6, long var7, long var9, Method var11, long var12, int var14, boolean var15, ToNativeConverter[] var16, FromNativeConverter var17, String var18);

    private static /* synthetic */ NativeMapped a(Class<?> a2, Object a3) {
        return (NativeMapped)NativeMappedConverter.a(a2).a(a3, new FromNativeContext(a2));
    }

    private static /* synthetic */ NativeMapped a(Method a2, Object a3) {
        Class<?> a4 = a2.getReturnType();
        return (NativeMapped)NativeMappedConverter.a(a4).a(a3, new MethodResultContext(a4, null, null, a2));
    }

    private static /* synthetic */ Class<?> a(Class<?> a2) {
        return NativeMappedConverter.a(a2).a();
    }

    private static /* synthetic */ Object a(ToNativeConverter a2, Object a3) {
        return a2.a(a3, new ToNativeContext());
    }

    private static /* synthetic */ Object a(FromNativeConverter a2, Object a3, Method a4) {
        return a2.a(a3, new MethodResultContext(a4.getReturnType(), null, null, a4));
    }

    public static native long ffi_prep_cif(int var0, int var1, long var2, long var4);

    public static native void ffi_call(long var0, long var2, long var4, long var6);

    public static native long ffi_prep_closure(long var0, ffi_callback var2);

    public static native void ffi_free_closure(long var0);

    static native int initialize_ffi_type(long var0);

    public static void main(String[] a2) {
        String a3;
        String a4;
        String a5 = "Java Native Access (JNA)";
        String a6 = "4.5.1";
        String a7 = "4.5.1 (package information missing)";
        Package a8 = Native.class.getPackage();
        String string = a4 = a8 != null ? a8.getSpecificationTitle() : "Java Native Access (JNA)";
        if (a4 == null) {
            a4 = "Java Native Access (JNA)";
        }
        String string2 = a3 = a8 != null ? a8.getSpecificationVersion() : "4.5.1";
        if (a3 == null) {
            a3 = "4.5.1";
        }
        a4 = a4 + " API Version " + a3;
        System.out.println(a4);
        String string3 = a3 = a8 != null ? a8.getImplementationVersion() : "4.5.1 (package information missing)";
        if (a3 == null) {
            a3 = "4.5.1 (package information missing)";
        }
        System.out.println("Version: " + a3);
        System.out.println(" Native: " + Native.getNativeVersion() + " (" + Native.getAPIChecksum() + ")");
        System.out.println(" Prefix: " + Platform.c);
    }

    static synchronized native void freeNativeCallback(long var0);

    static synchronized native long createNativeCallback(Callback var0, Method var1, Class<?>[] var2, Class<?> var3, int var4, int var5, String var6);

    static native int invokeInt(Function var0, long var1, int var3, Object[] var4);

    static native long invokeLong(Function var0, long var1, int var3, Object[] var4);

    static native void invokeVoid(Function var0, long var1, int var3, Object[] var4);

    static native float invokeFloat(Function var0, long var1, int var3, Object[] var4);

    static native double invokeDouble(Function var0, long var1, int var3, Object[] var4);

    static native long invokePointer(Function var0, long var1, int var3, Object[] var4);

    private static native /* synthetic */ void invokeStructure(Function var0, long var1, int var3, Object[] var4, long var5, long var7);

    static Structure a(Function a2, long a3, int a4, Object[] a5, Structure a6) {
        Native.invokeStructure(a2, a3, a4, a5, a6.o().d, a6.p().d);
        return a6;
    }

    static native Object invokeObject(Function var0, long var1, int var3, Object[] var4);

    static long a(String a2) {
        return Native.open(a2, -1);
    }

    static native long open(String var0, int var1);

    static native void close(long var0);

    static native long findSymbol(long var0, String var2);

    static native long indexOf(Pointer var0, long var1, long var3, byte var5);

    static native void read(Pointer var0, long var1, long var3, byte[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, short[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, char[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, int[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, long[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, float[] var5, int var6, int var7);

    static native void read(Pointer var0, long var1, long var3, double[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, byte[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, short[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, char[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, int[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, long[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, float[] var5, int var6, int var7);

    static native void write(Pointer var0, long var1, long var3, double[] var5, int var6, int var7);

    static native byte getByte(Pointer var0, long var1, long var3);

    static native char getChar(Pointer var0, long var1, long var3);

    static native short getShort(Pointer var0, long var1, long var3);

    static native int getInt(Pointer var0, long var1, long var3);

    static native long getLong(Pointer var0, long var1, long var3);

    static native float getFloat(Pointer var0, long var1, long var3);

    static native double getDouble(Pointer var0, long var1, long var3);

    static Pointer a(long a2) {
        long a3 = Native._getPointer(a2);
        return a3 == 0L ? null : new Pointer(a3);
    }

    private static native /* synthetic */ long _getPointer(long var0);

    static native String getWideString(Pointer var0, long var1, long var3);

    static String a(Pointer a2, long a3) {
        return Native.a(a2, a3, Native.a());
    }

    static String a(Pointer a2, long a3, String a4) {
        byte[] a5 = Native.getStringBytes(a2, a2.d, a3);
        if (a4 != null) {
            try {
                return new String(a5, a4);
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                // empty catch block
            }
        }
        return new String(a5);
    }

    static native byte[] getStringBytes(Pointer var0, long var1, long var3);

    static native void setMemory(Pointer var0, long var1, long var3, long var5, byte var7);

    static native void setByte(Pointer var0, long var1, long var3, byte var5);

    static native void setShort(Pointer var0, long var1, long var3, short var5);

    static native void setChar(Pointer var0, long var1, long var3, char var5);

    static native void setInt(Pointer var0, long var1, long var3, int var5);

    static native void setLong(Pointer var0, long var1, long var3, long var5);

    static native void setFloat(Pointer var0, long var1, long var3, float var5);

    static native void setDouble(Pointer var0, long var1, long var3, double var5);

    static native void setPointer(Pointer var0, long var1, long var3, long var5);

    static native void setWideString(Pointer var0, long var1, long var3, String var5);

    static native ByteBuffer getDirectByteBuffer(Pointer var0, long var1, long var3, long var5);

    public static native long malloc(long var0);

    public static native void free(long var0);

    @Deprecated
    public static native ByteBuffer getDirectByteBuffer(long var0, long var2);

    public static void a(boolean a2) {
        Thread a3 = Thread.currentThread();
        if (a2) {
            d.remove(a3);
            Pointer a4 = v.get();
            Native.setDetachState(true, 0L);
        } else if (!d.containsKey(a3)) {
            Pointer a5 = v.get();
            d.put(a3, a5);
            Native.setDetachState(false, a5.d);
        }
    }

    static Pointer a(Thread a2) {
        return d.get(a2);
    }

    private static native /* synthetic */ void setDetachState(boolean var0, long var1);

    static {
        aa = ra = new Callback.UncaughtExceptionHandler(){
            {
                1 a2;
            }

            @Override
            public void a(Callback a2, Throwable a3) {
                System.err.println("JNA: Callback " + a2 + " threw the following exception:");
                a3.printStackTrace();
            }
        };
        Native.j();
        if (!Native.a("5.2.0", Native.getNativeVersion())) {
            String a2 = System.getProperty("line.separator");
            throw new Error(a2 + a2 + "There is an incompatible JNA native library installed on this system" + a2 + "Expected: " + "5.2.0" + a2 + "Found:    " + Native.getNativeVersion() + a2 + (nb != null ? "(at " + nb + ")" : System.getProperty("java.library.path")) + "." + a2 + "To resolve this issue you may do one of the following:" + a2 + " - remove or uninstall the offending library" + a2 + " - set the system property jna.nosys=true" + a2 + " - set jna.boot.library.path to include the path to the version of the " + a2 + "   jnidispatch library included with the JNA jar file you are using" + a2);
        }
        za = Native.sizeof(0);
        fa = Native.sizeof(1);
        wa = Native.sizeof(2);
        va = Native.sizeof(3);
        sa = Native.sizeof(4);
        Native.initIDs();
        if (Boolean.getBoolean("jna.protected")) {
            Native.setProtected(true);
        }
        ma = Platform.o() || Platform.e() || Platform.k() && (Platform.y() || Platform.z() || Platform.p()) || Platform.g() || Platform.v() ? 8 : fa;
        na = Platform.t() && Platform.z() ? 8 : ma;
        System.setProperty("jna.loaded", "true");
        ka = new Object(){
            {
                2 a2;
            }

            protected void finalize() {
                Native.x();
            }
        };
        ya = new WeakHashMap();
        ca = new WeakHashMap();
        v = new ThreadLocal<Memory>(){
            {
                7 a2;
            }

            protected Memory a() {
                Memory a2 = new Memory(4L);
                a2.p();
                return a2;
            }
        };
        d = Collections.synchronizedMap(new WeakHashMap());
    }

    private static class AWT {
        private /* synthetic */ AWT() {
            AWT a2;
        }

        static long a(Window a2) throws HeadlessException {
            return AWT.a((Object)a2);
        }

        static long a(Object a2) throws HeadlessException {
            if (GraphicsEnvironment.isHeadless()) {
                throw new HeadlessException("No native windows when headless");
            }
            Component a3 = (Component)a2;
            if (a3.isLightweight()) {
                throw new IllegalArgumentException("Component must be heavyweight");
            }
            if (!a3.isDisplayable()) {
                throw new IllegalStateException("Component must be displayable");
            }
            if (Platform.m() && System.getProperty("java.version").startsWith("1.4") && !a3.isVisible()) {
                throw new IllegalStateException("Component must be visible");
            }
            return Native.getWindowHandle0(a3);
        }
    }

    private static class Buffers {
        private /* synthetic */ Buffers() {
            Buffers a2;
        }

        static boolean a(Class<?> a2) {
            return Buffer.class.isAssignableFrom(a2);
        }
    }

    public static interface ffi_callback {
        public void a(long var1, long var3, long var5);
    }
}

