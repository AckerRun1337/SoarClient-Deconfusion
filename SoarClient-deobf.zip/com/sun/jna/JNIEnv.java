/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

public final class JNIEnv {
    public static final JNIEnv d = new JNIEnv();

    private /* synthetic */ JNIEnv() {
        JNIEnv a2;
    }
}

