/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Function;
import com.sun.jna.FunctionParameterContext;
import java.lang.reflect.Method;

public class MethodParameterContext
extends FunctionParameterContext {
    private Method d;

    MethodParameterContext(Function a2, Object[] a3, int a4, Method a5) {
        super(a2, a3, a4);
        MethodParameterContext a6;
        a6.d = a5;
    }

    public Method a() {
        MethodParameterContext a2;
        return a2.d;
    }
}

