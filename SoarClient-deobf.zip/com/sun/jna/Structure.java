/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;
import com.sun.jna.FromNativeContext;
import com.sun.jna.FromNativeConverter;
import com.sun.jna.Function;
import com.sun.jna.IntegerType;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.NativeString;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.StructureReadContext;
import com.sun.jna.StructureWriteContext;
import com.sun.jna.ToNativeContext;
import com.sun.jna.ToNativeConverter;
import com.sun.jna.TypeMapper;
import com.sun.jna.Union;
import com.sun.jna.WString;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.nio.Buffer;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class Structure {
    public static final int o = 0;
    public static final int m = 1;
    public static final int y = 2;
    public static final int a = 3;
    protected static final int q = -1;
    static final Map<Class<?>, LayoutInfo> g = new WeakHashMap();
    static final Map<Class<?>, List<String>> k = new WeakHashMap();
    private Pointer x;
    private int t = -1;
    private int p;
    private String s;
    private int w;
    private int i;
    private Map<String, StructField> n;
    private final Map<String, Object> e = new HashMap<String, Object>();
    private TypeMapper r;
    private long f;
    private boolean h = true;
    private boolean z = true;
    private Structure[] l;
    private boolean b;
    private static final ThreadLocal<Map<Pointer, Structure>> c = new ThreadLocal<Map<Pointer, Structure>>(){
        {
            1 a2;
        }

        protected synchronized Map<Pointer, Structure> a() {
            return new HashMap<Pointer, Structure>();
        }
    };
    private static final ThreadLocal<Set<Structure>> v = new ThreadLocal<Set<Structure>>(){
        {
            2 a2;
        }

        protected synchronized Set<Structure> a() {
            return new StructureSet();
        }
    };
    private static final Pointer d = new Pointer(0L){
        {
            3 a3;
        }

        @Override
        public Pointer a(long a2, long a3) {
            3 a4;
            return a4;
        }
    };

    protected Structure() {
        a2(0);
        Structure a2;
    }

    protected Structure(TypeMapper a2) {
        a3(null, 0, a2);
        Structure a3;
    }

    protected Structure(int a2) {
        a3(null, a2);
        Structure a3;
    }

    protected Structure(int a2, TypeMapper a3) {
        a4(null, a2, a3);
        Structure a4;
    }

    protected Structure(Pointer a2) {
        a3(a2, 0);
        Structure a3;
    }

    protected Structure(Pointer a2, int a3) {
        a4(a2, a3, null);
        Structure a4;
    }

    protected Structure(Pointer a2, int a3, TypeMapper a4) {
        Structure a5;
        a5.p(a3);
        a5.p(Native.p(a5.getClass()));
        a5.a(a4);
        a5.y();
        if (a2 != null) {
            a5.a(a2, 0, true);
        } else {
            a5.a(-1);
        }
        a5.o();
    }

    Map<String, StructField> p() {
        Structure a2;
        return a2.n;
    }

    TypeMapper a() {
        Structure a2;
        return a2.r;
    }

    private /* synthetic */ void a(TypeMapper a2) {
        Structure a3;
        if (a2 == null) {
            a2 = Native.a(a3.getClass());
        }
        a3.r = a2;
        a3.q();
    }

    private /* synthetic */ void q() {
        Structure a2;
        if (a2.t != -1) {
            a2.t = -1;
            if (a2.x instanceof AutoAllocated) {
                a2.x = null;
            }
            a2.d();
        }
    }

    protected void p(String a2) {
        a.s = a2;
    }

    protected String a() {
        Structure a2;
        return a2.s;
    }

    protected void p(int a2) {
        Structure a3;
        a3.p = a2;
        if (a2 == 0 && (a2 = Native.p(a3.getClass())) == 0) {
            a2 = Platform.e() ? 3 : 2;
        }
        a3.w = a2;
        a3.q();
    }

    protected Memory a(int a2) {
        return new AutoAllocated(a2);
    }

    protected void p(Pointer a2) {
        Structure a3;
        a3.a(a2, 0);
    }

    protected void a(Pointer a2, int a3) {
        Structure a4;
        a4.a(a2, a3, false);
    }

    void a(Pointer a2, int a3, boolean a4) {
        try {
            Structure a5;
            a5.e.clear();
            if (a5 instanceof ByValue && !a4) {
                byte[] a6 = new byte[a5.p()];
                a2.p(0L, a6, 0, a6.length);
                a5.x.a(0L, a6, 0, a6.length);
            } else {
                a5.x = a2.p(a3);
                if (a5.t == -1) {
                    a5.t = a5.a(false);
                }
                if (a5.t != -1) {
                    a5.x = a2.a((long)a3, (long)a5.t);
                }
            }
            a5.l = null;
            a5.b = false;
        }
        catch (IndexOutOfBoundsException a7) {
            throw new IllegalArgumentException("Structure exceeds provided memory bounds", a7);
        }
    }

    protected void d() {
        Structure a2;
        a2.z(false);
    }

    private /* synthetic */ void z(boolean a2) {
        Structure a3;
        if (a3.x == null) {
            a3.y(a2);
        } else if (a3.t == -1) {
            a3.t = a3.a(true, a2);
            if (!(a3.x instanceof AutoAllocated)) {
                try {
                    a3.x = a3.x.a(0L, (long)a3.t);
                }
                catch (IndexOutOfBoundsException a4) {
                    throw new IllegalArgumentException("Structure exceeds provided memory bounds", a4);
                }
            }
        }
    }

    protected void m() {
        Structure a2;
        a2.y(false);
    }

    private /* synthetic */ void y(boolean a2) {
        Structure a3;
        a3.a(a3.a(true, a2));
    }

    protected void a(int a2) {
        Structure a3;
        if (a2 == -1) {
            a2 = a3.a(false);
        } else if (a2 <= 0) {
            throw new IllegalArgumentException("Structure size must be greater than zero: " + a2);
        }
        if (a2 != -1) {
            if (a3.x == null || a3.x instanceof AutoAllocated) {
                a3.x = a3.a(a2);
            }
            a3.t = a2;
        }
    }

    public int p() {
        Structure a2;
        a2.d();
        return a2.t;
    }

    public void h() {
        Structure a2;
        a2.d();
        a2.x.a(a2.p());
    }

    public Pointer o() {
        Structure a2;
        a2.d();
        return a2.x;
    }

    static Set<Structure> a() {
        return v.get();
    }

    static Map<Pointer, Structure> a() {
        return c.get();
    }

    void x() {
        Structure a2;
        if (!a2.b) {
            a2.p();
        }
    }

    public void j() {
        Structure a2;
        if (a2.x == d) {
            return;
        }
        a2.b = true;
        a2.d();
        if (Structure.a().contains(a2)) {
            return;
        }
        Structure.a().add(a2);
        if (a2 instanceof ByReference) {
            Structure.a().put(a2.o(), a2);
        }
        try {
            for (StructField a3 : a2.p().values()) {
                a2.a(a3);
            }
        }
        finally {
            Structure.a().remove(a2);
            if (Structure.a().get(a2.o()) == a2) {
                Structure.a().remove(a2.o());
            }
        }
    }

    protected int a(String a2) {
        Structure a3;
        a3.d();
        StructField a4 = a3.p().get(a2);
        if (a4 == null) {
            throw new IllegalArgumentException("No such field: " + a2);
        }
        return a4.z;
    }

    public Object a(String a2) {
        Structure a3;
        a3.d();
        StructField a4 = a3.p().get(a2);
        if (a4 == null) {
            throw new IllegalArgumentException("No such field: " + a2);
        }
        return a3.a(a4);
    }

    Object a(Field a2) {
        Structure a3;
        try {
            return a2.get(a3);
        }
        catch (Exception a4) {
            throw new Error("Exception reading field '" + a2.getName() + "' in " + a3.getClass(), a4);
        }
    }

    void a(Field a2, Object a3) {
        Structure a4;
        a4.a(a2, a3, false);
    }

    private /* synthetic */ void a(Field a2, Object a3, boolean a4) {
        Structure a5;
        try {
            a2.set(a5, a3);
        }
        catch (IllegalAccessException a6) {
            int a7 = a2.getModifiers();
            if (Modifier.isFinal(a7)) {
                if (a4) {
                    throw new UnsupportedOperationException("This VM does not support Structures with final fields (field '" + a2.getName() + "' within " + a5.getClass() + ")", a6);
                }
                throw new UnsupportedOperationException("Attempt to write to read-only field '" + a2.getName() + "' within " + a5.getClass(), a6);
            }
            throw new Error("Unexpectedly unable to write to field '" + a2.getName() + "' within " + a5.getClass(), a6);
        }
    }

    static Structure a(Class<?> a2, Structure a3, Pointer a4) {
        if (a4 == null) {
            a3 = null;
        } else if (a3 == null || !a4.equals(a3.o())) {
            Structure a5 = Structure.a().get(a4);
            if (a5 != null && a2.equals(a5.getClass())) {
                a3 = a5;
                a3.p();
            } else {
                a3 = Structure.a(a2, a4);
                a3.x();
            }
        } else {
            a3.p();
        }
        return a3;
    }

    protected Object a(StructField a2) {
        Pointer a3;
        Structure a4;
        Object a5;
        int a6 = a2.z;
        Class<?> a7 = a2.r;
        FromNativeConverter a8 = a2.c;
        if (a8 != null) {
            a7 = a8.a();
        }
        Object object = a5 = Structure.class.isAssignableFrom(a7) || Callback.class.isAssignableFrom(a7) || Platform.r && Buffer.class.isAssignableFrom(a7) || Pointer.class.isAssignableFrom(a7) || NativeMapped.class.isAssignableFrom(a7) || a7.isArray() ? a4.a(a2.f) : null;
        Object a9 = a7 == String.class ? ((a3 = a4.x.a(a6)) == null ? null : a3.a(0L, a4.s)) : a4.x.a((long)a6, a7, a5);
        if (a8 != null) {
            a9 = a8.a(a9, a2.d);
            if (a5 != null && a5.equals(a9)) {
                a9 = a5;
            }
        }
        if (a7.equals(String.class) || a7.equals(WString.class)) {
            a4.e.put(a2.e + ".ptr", a4.x.a(a6));
            a4.e.put(a2.e + ".val", a9);
        }
        a4.a(a2.f, a9, true);
        return a9;
    }

    public void z() {
        Structure a2;
        if (a2.x == d) {
            return;
        }
        a2.d();
        if (a2 instanceof ByValue) {
            a2.p();
        }
        if (Structure.a().contains(a2)) {
            return;
        }
        Structure.a().add(a2);
        try {
            for (StructField a3 : a2.p().values()) {
                if (a3.l) continue;
                a2.a(a3);
            }
        }
        finally {
            Structure.a().remove(a2);
        }
    }

    public void a(String a2) {
        Structure a3;
        a3.d();
        StructField a4 = a3.p().get(a2);
        if (a4 == null) {
            throw new IllegalArgumentException("No such field: " + a2);
        }
        a3.a(a4);
    }

    public void a(String a2, Object a3) {
        Structure a4;
        a4.d();
        StructField a5 = a4.p().get(a2);
        if (a5 == null) {
            throw new IllegalArgumentException("No such field: " + a2);
        }
        a4.a(a5.f, a3);
        a4.a(a5);
    }

    protected void a(StructField a2) {
        CharSequence a3;
        Structure a4;
        if (a2.b) {
            return;
        }
        int a5 = a2.z;
        Object a6 = a4.a(a2.f);
        Class<?> a7 = a2.r;
        ToNativeConverter a8 = a2.v;
        if (a8 != null) {
            a6 = a8.a(a6, new StructureWriteContext(a4, a2.f));
            a7 = a8.a();
        }
        if (String.class == a7 || WString.class == a7) {
            boolean a9;
            boolean bl2 = a9 = a7 == WString.class;
            if (a6 != null) {
                if (a4.e.containsKey(a2.e + ".ptr") && a6.equals(a4.e.get(a2.e + ".val"))) {
                    return;
                }
                a3 = a9 ? new NativeString(a6.toString(), true) : new NativeString(a6.toString(), a4.s);
                a4.e.put(a2.e, a3);
                a6 = ((NativeString)a3).a();
            } else {
                a4.e.remove(a2.e);
            }
            a4.e.remove(a2.e + ".ptr");
            a4.e.remove(a2.e + ".val");
        }
        try {
            a4.x.p(a5, a6, a7);
        }
        catch (IllegalArgumentException a10) {
            a3 = "Structure field \"" + a2.e + "\" was declared as " + a2.r + (a2.r == a7 ? "" : " (native type " + a7 + ")") + ", which is not supported within a Structure";
            throw new IllegalArgumentException((String)a3, a10);
        }
    }

    protected abstract List<String> o();

    @Deprecated
    protected final void a(String[] a2) {
        throw new Error("This method is obsolete, use getFieldOrder() instead");
    }

    protected void a(List<Field> a2, List<String> a3) {
        block0: for (int a4 = 0; a4 < a3.size(); ++a4) {
            String a5 = a3.get(a4);
            for (int a6 = 0; a6 < a2.size(); ++a6) {
                Field a7 = a2.get(a6);
                if (!a5.equals(a7.getName())) continue;
                Collections.swap(a2, a4, a6);
                continue block0;
            }
        }
    }

    protected List<Field> p() {
        Structure a2;
        ArrayList<Field> a3 = new ArrayList<Field>();
        Class<?> a4 = a2.getClass();
        while (!a4.equals(Structure.class)) {
            ArrayList<Field> a5 = new ArrayList<Field>();
            Field[] a6 = a4.getDeclaredFields();
            for (int a7 = 0; a7 < a6.length; ++a7) {
                int a8 = a6[a7].getModifiers();
                if (Modifier.isStatic(a8) || !Modifier.isPublic(a8)) continue;
                a5.add(a6[a7]);
            }
            a3.addAll(0, a5);
            a4 = a4.getSuperclass();
        }
        return a3;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private /* synthetic */ List<String> a() {
        Structure a2;
        Class<?> a3 = a2.getClass();
        Map<Class<?>, List<String>> map = k;
        synchronized (map) {
            List<String> a4 = k.get(a3);
            if (a4 == null) {
                a4 = a2.o();
                k.put(a3, a4);
            }
            return a4;
        }
    }

    public static List<String> a(List<String> a2, String ... a3) {
        return Structure.a(a2, Arrays.asList(a3));
    }

    public static List<String> a(List<String> a2, List<String> a3) {
        ArrayList<String> a4 = new ArrayList<String>(a2.size() + a3.size());
        a4.addAll(a2);
        a4.addAll(a3);
        return Collections.unmodifiableList(a4);
    }

    public static List<String> a(String a2) {
        return Collections.unmodifiableList(Collections.singletonList(a2));
    }

    public static List<String> a(String ... a2) {
        return Collections.unmodifiableList(Arrays.asList(a2));
    }

    private static /* synthetic */ <T extends Comparable<T>> List<T> a(Collection<? extends T> a2) {
        ArrayList<? extends T> a3 = new ArrayList<T>(a2);
        Collections.sort(a3);
        return a3;
    }

    protected List<Field> a(boolean a2) {
        Structure a4;
        List<Field> a5 = a4.p();
        HashSet<String> a6 = new HashSet<String>();
        for (Field field : a5) {
            a6.add(field.getName());
        }
        List<String> a7 = a4.a();
        if (a7.size() != a5.size() && a5.size() > 1) {
            if (a2) {
                throw new Error("Structure.getFieldOrder() on " + a4.getClass() + " does not provide enough names [" + a7.size() + "] (" + Structure.a(a7) + ") to match declared fields [" + a5.size() + "] (" + Structure.a(a6) + ")");
            }
            return null;
        }
        HashSet<String> hashSet = new HashSet<String>(a7);
        if (!hashSet.equals(a6)) {
            throw new Error("Structure.getFieldOrder() on " + a4.getClass() + " returns names (" + Structure.a(a7) + ") which do not match declared field names (" + Structure.a(a6) + ")");
        }
        a4.a(a5, a7);
        return a5;
    }

    protected int a(boolean a2) {
        Structure a3;
        return a3.a(a2, false);
    }

    static int p(Class<?> a2) {
        return Structure.a(a2, null);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static int a(Class<?> a2, Structure a3) {
        int a4;
        LayoutInfo a5;
        Map<Class<?>, LayoutInfo> map = g;
        synchronized (map) {
            a5 = g.get(a2);
        }
        int n2 = a4 = a5 != null && !a5.v ? a5.h : -1;
        if (a4 == -1) {
            if (a3 == null) {
                a3 = Structure.a(a2, d);
            }
            a4 = a3.p();
        }
        return a4;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    int a(boolean a2, boolean a3) {
        LayoutInfo a4;
        Structure a5;
        int a6 = -1;
        Class<?> a7 = a5.getClass();
        Map<Class<?>, LayoutInfo> map = g;
        synchronized (map) {
            a4 = g.get(a7);
        }
        if (a4 == null || a5.p != a4.b || a5.r != a4.c) {
            a4 = a5.a(a2, a3);
        }
        if (a4 != null) {
            a5.i = a4.z;
            a5.n = a4.l;
            if (!a4.v) {
                map = g;
                synchronized (map) {
                    if (!g.containsKey(a7) || a5.p != 0 || a5.r != null) {
                        g.put(a7, a4);
                    }
                }
            }
            a6 = a4.h;
        }
        return a6;
    }

    private /* synthetic */ void a(String a2, Class<?> a3) {
        ToNativeConverter a4;
        Structure a5;
        if (a5.r != null && (a4 = a5.r.a(a3)) != null) {
            a5.a(a2, a4.a());
            return;
        }
        if (a3.isArray()) {
            a5.a(a2, a3.getComponentType());
        } else {
            try {
                a5.a(a3);
            }
            catch (IllegalArgumentException a6) {
                String a7 = "Invalid Structure field in " + a5.getClass() + ", field name '" + a2 + "' (" + a3 + "): " + a6.getMessage();
                throw new IllegalArgumentException(a7, a6);
            }
        }
    }

    private /* synthetic */ void y() {
        Structure a2;
        List<Field> a3 = a2.p();
        for (Field a4 : a3) {
            a2.a(a4.getName(), a4.getType());
        }
    }

    private /* synthetic */ LayoutInfo a(boolean a2, boolean a3) {
        Structure a4;
        int a5 = 0;
        List<Field> a6 = a4.a(a2);
        if (a6 == null) {
            return null;
        }
        LayoutInfo a7 = new LayoutInfo();
        a7.b = a4.p;
        a7.c = a4.r;
        boolean a8 = true;
        for (Field a9 : a6) {
            int a10 = a9.getModifiers();
            Class<?> a11 = a9.getType();
            if (a11.isArray()) {
                a7.v = true;
            }
            StructField a12 = new StructField();
            a12.l = Modifier.isVolatile(a10);
            a12.b = Modifier.isFinal(a10);
            if (a12.b) {
                if (!Platform.e) {
                    throw new IllegalArgumentException("This VM does not support read-only fields (field '" + a9.getName() + "' within " + a4.getClass() + ")");
                }
                a9.setAccessible(true);
            }
            a12.f = a9;
            a12.e = a9.getName();
            a12.r = a11;
            if (Callback.class.isAssignableFrom(a11) && !a11.isInterface()) {
                throw new IllegalArgumentException("Structure Callback field '" + a9.getName() + "' must be an interface");
            }
            if (a11.isArray() && Structure.class.equals(a11.getComponentType())) {
                String a13 = "Nested Structure arrays must use a derived Structure type so that the size of the elements can be determined";
                throw new IllegalArgumentException(a13);
            }
            int a14 = 1;
            if (Modifier.isPublic(a9.getModifiers())) {
                Object a15;
                ToNativeConverter a16;
                Object a17 = a4.a(a12.f);
                if (a17 == null && a11.isArray()) {
                    if (a2) {
                        throw new IllegalStateException("Array fields must be initialized");
                    }
                    return null;
                }
                Class<Object> a18 = a11;
                if (NativeMapped.class.isAssignableFrom(a11)) {
                    a16 = NativeMappedConverter.a(a11);
                    a18 = ((NativeMappedConverter)a16).a();
                    a12.v = a16;
                    a12.c = a16;
                    a12.d = new StructureReadContext(a4, a9);
                } else if (a4.r != null) {
                    a16 = a4.r.a(a11);
                    a15 = a4.r.a(a11);
                    if (a16 != null && a15 != null) {
                        a18 = (a17 = a16.a(a17, new StructureWriteContext(a4, a12.f))) != null ? a17.getClass() : Pointer.class;
                        a12.v = a16;
                        a12.c = a15;
                        a12.d = new StructureReadContext(a4, a9);
                    } else if (a16 != null || a15 != null) {
                        String a19 = "Structures require bidirectional type conversion for " + a11;
                        throw new IllegalArgumentException(a19);
                    }
                }
                if (a17 == null) {
                    a17 = a4.a(a12.f, a11);
                }
                try {
                    a12.h = a4.a(a18, a17);
                    a14 = a4.a(a18, a17, a8);
                }
                catch (IllegalArgumentException a20) {
                    if (!a2 && a4.r == null) {
                        return null;
                    }
                    a15 = "Invalid Structure field in " + a4.getClass() + ", field name '" + a12.e + "' (" + a12.r + "): " + a20.getMessage();
                    throw new IllegalArgumentException((String)a15, a20);
                }
                if (a14 == 0) {
                    throw new Error("Field alignment is zero for field '" + a12.e + "' within " + a4.getClass());
                }
                a7.z = Math.max(a7.z, a14);
                if (a5 % a14 != 0) {
                    a5 += a14 - a5 % a14;
                }
                if (a4 instanceof Union) {
                    a12.z = 0;
                    a5 = Math.max(a5, a12.h);
                } else {
                    a12.z = a5;
                    a5 += a12.h;
                }
                a7.l.put(a12.e, a12);
                if (a7.d == null || ((LayoutInfo)a7).d.h < a12.h || ((LayoutInfo)a7).d.h == a12.h && Structure.class.isAssignableFrom(a12.r)) {
                    a7.d = a12;
                }
            }
            a8 = false;
        }
        if (a5 > 0) {
            int a21 = a4.a(a5, a7.z);
            if (a4 instanceof ByValue && !a3) {
                a4.p();
            }
            a7.h = a21;
            return a7;
        }
        throw new IllegalArgumentException("Structure " + a4.getClass() + " has unknown or zero size (ensure all fields are public)");
    }

    private /* synthetic */ void o() {
        Structure a2;
        List<Field> a3 = a2.p();
        for (Field a4 : a3) {
            try {
                Object a5 = a4.get(a2);
                if (a5 != null) continue;
                a2.a(a4, a4.getType());
            }
            catch (Exception a6) {
                throw new Error("Exception reading field '" + a4.getName() + "' in " + a2.getClass(), a6);
            }
        }
    }

    private /* synthetic */ Object a(Field a2, Class<?> a3) {
        Structure a4;
        Object a5 = null;
        if (Structure.class.isAssignableFrom(a3) && !ByReference.class.isAssignableFrom(a3)) {
            try {
                a5 = Structure.a(a3, d);
                a4.a(a2, a5);
            }
            catch (IllegalArgumentException a6) {
                String a7 = "Can't determine size of nested structure";
                throw new IllegalArgumentException(a7, a6);
            }
        } else if (NativeMapped.class.isAssignableFrom(a3)) {
            NativeMappedConverter a8 = NativeMappedConverter.a(a3);
            a5 = a8.a();
            a4.a(a2, a5);
        }
        return a5;
    }

    private /* synthetic */ int a(int a2) {
        Structure a3;
        return a3.a(a2, a3.i);
    }

    private /* synthetic */ int a(int a2, int a3) {
        Structure a4;
        if (a4.w != 1 && a2 % a3 != 0) {
            a2 += a3 - a2 % a3;
        }
        return a2;
    }

    protected int a() {
        Structure a2;
        if (a2.t == -1) {
            a2.a(true);
        }
        return a2.i;
    }

    protected int a(Class<?> a2, Object a3, boolean a4) {
        Structure a5;
        int a6 = 1;
        if (NativeMapped.class.isAssignableFrom(a2)) {
            NativeMappedConverter a7 = NativeMappedConverter.a(a2);
            a2 = a7.a();
            a3 = a7.a(a3, new ToNativeContext());
        }
        int a8 = Native.a(a2, a3);
        if (a2.isPrimitive() || Long.class == a2 || Integer.class == a2 || Short.class == a2 || Character.class == a2 || Byte.class == a2 || Boolean.class == a2 || Float.class == a2 || Double.class == a2) {
            a6 = a8;
        } else if (Pointer.class.isAssignableFrom(a2) && !Function.class.isAssignableFrom(a2) || Platform.r && Buffer.class.isAssignableFrom(a2) || Callback.class.isAssignableFrom(a2) || WString.class == a2 || String.class == a2) {
            a6 = Pointer.c;
        } else if (Structure.class.isAssignableFrom(a2)) {
            if (ByReference.class.isAssignableFrom(a2)) {
                a6 = Pointer.c;
            } else {
                if (a3 == null) {
                    a3 = Structure.a(a2, d);
                }
                a6 = ((Structure)a3).a();
            }
        } else if (a2.isArray()) {
            a6 = a5.a(a2.getComponentType(), null, a4);
        } else {
            throw new IllegalArgumentException("Type " + a2 + " has unknown native alignment");
        }
        if (a5.w == 1) {
            a6 = 1;
        } else if (a5.w == 3) {
            a6 = Math.min(8, a6);
        } else if (a5.w == 2) {
            if (!(a4 && Platform.t() && Platform.z())) {
                a6 = Math.min(Native.ma, a6);
            }
            if (!a4 && Platform.g() && (a2 == Double.TYPE || a2 == Double.class)) {
                a6 = 4;
            }
        }
        return a6;
    }

    public String toString() {
        Structure a2;
        return a2.a(Boolean.getBoolean("jna.dump_memory"));
    }

    public String a(boolean a2) {
        Structure a3;
        return a3.a(0, true, a2);
    }

    private /* synthetic */ String a(Class<?> a2) {
        String a3 = a2.getName();
        int a4 = a3.lastIndexOf(".");
        return a3.substring(a4 + 1);
    }

    private /* synthetic */ String a(int a2, boolean a3, boolean a4) {
        Object a5;
        Structure a6;
        a6.d();
        String a7 = System.getProperty("line.separator");
        String a8 = a6.a(a6.getClass()) + "(" + a6.o() + ")";
        if (!(a6.o() instanceof Memory)) {
            a8 = a8 + " (" + a6.p() + " bytes)";
        }
        String a9 = "";
        for (int a10 = 0; a10 < a2; ++a10) {
            a9 = a9 + "  ";
        }
        String a11 = a7;
        if (!a3) {
            a11 = "...}";
        } else {
            Iterator<StructField> a12 = a6.p().values().iterator();
            while (a12.hasNext()) {
                a5 = a12.next();
                Object a13 = a6.a(((StructField)a5).f);
                String a14 = a6.a(((StructField)a5).r);
                String a15 = "";
                a11 = a11 + a9;
                if (((StructField)a5).r.isArray() && a13 != null) {
                    a14 = a6.a(((StructField)a5).r.getComponentType());
                    a15 = "[" + Array.getLength(a13) + "]";
                }
                a11 = a11 + String.format("  %s %s%s@0x%X", a14, ((StructField)a5).e, a15, ((StructField)a5).z);
                if (a13 instanceof Structure) {
                    a13 = ((Structure)a13).a(a2 + 1, !(a13 instanceof ByReference), a4);
                }
                a11 = a11 + "=";
                a11 = a13 instanceof Long ? a11 + String.format("0x%08X", (Long)a13) : (a13 instanceof Integer ? a11 + String.format("0x%04X", (Integer)a13) : (a13 instanceof Short ? a11 + String.format("0x%02X", (Short)a13) : (a13 instanceof Byte ? a11 + String.format("0x%01X", (Byte)a13) : a11 + String.valueOf(a13).trim())));
                a11 = a11 + a7;
                if (a12.hasNext()) continue;
                a11 = a11 + a9 + "}";
            }
        }
        if (a2 == 0 && a4) {
            int a16 = 4;
            a11 = a11 + a7 + "memory dump" + a7;
            a5 = a6.o().a(0L, a6.p());
            for (int a17 = 0; a17 < ((Object)a5).length; ++a17) {
                if (a17 % 4 == 0) {
                    a11 = a11 + "[";
                }
                if (a5[a17] >= 0 && a5[a17] < 16) {
                    a11 = a11 + "0";
                }
                a11 = a11 + Integer.toHexString(a5[a17] & 0xFF);
                if (a17 % 4 != 3 || a17 >= ((Object)a5).length - 1) continue;
                a11 = a11 + "]" + a7;
            }
            a11 = a11 + "]";
        }
        return a8 + " {" + a11;
    }

    public Structure[] a(Structure[] a2) {
        int a3;
        Structure a4;
        a4.d();
        if (a4.x instanceof AutoAllocated) {
            Memory a5 = (Memory)a4.x;
            a3 = a2.length * a4.p();
            if (a5.a() < (long)a3) {
                a4.p(a4.a(a3));
            }
        }
        a2[0] = a4;
        int a6 = a4.p();
        for (a3 = 1; a3 < a2.length; ++a3) {
            a2[a3] = Structure.a(a4.getClass(), a4.x.a((long)(a3 * a6), (long)a6));
            a2[a3].x();
        }
        if (!(a4 instanceof ByValue)) {
            a4.l = a2;
        }
        return a2;
    }

    public Structure[] a(int a2) {
        Structure a3;
        return a3.a((Structure[])Array.newInstance(a3.getClass(), a2));
    }

    private /* synthetic */ Class<?> a() {
        Structure a2;
        if ((a2 instanceof ByReference || a2 instanceof ByValue) && Structure.class.isAssignableFrom(a2.getClass().getSuperclass())) {
            return a2.getClass().getSuperclass();
        }
        return a2.getClass();
    }

    public boolean a(Structure a2) {
        Structure a3;
        return a3.a(a2, false);
    }

    public boolean a(Structure a2, boolean a3) {
        byte[] a4;
        byte[] a5;
        Structure a6;
        if (a3) {
            a2.o().a(a2.p());
            a2.z();
            a6.o().a(a6.p());
            a6.z();
        }
        if ((a5 = a2.o().a(0L, a2.p())).length == (a4 = a6.o().a(0L, a6.p())).length) {
            for (int a7 = 0; a7 < a5.length; ++a7) {
                if (a5[a7] == a4[a7]) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    public boolean equals(Object a2) {
        Structure a3;
        return a2 instanceof Structure && a2.getClass() == a3.getClass() && ((Structure)a2).o().equals(a3.o());
    }

    public int hashCode() {
        Structure a2;
        Pointer a3 = a2.o();
        if (a3 != null) {
            return a2.o().hashCode();
        }
        return a2.getClass().hashCode();
    }

    protected void a(Pointer a2) {
        a.f = a2.d;
    }

    Pointer a(StructField a2) {
        ToNativeConverter a3;
        Structure a4;
        Class<?> a5 = a2.r;
        Object a6 = a4.a(a2.f);
        if (a4.r != null && (a3 = a4.r.a(a5)) != null) {
            a5 = a3.a();
            a6 = a3.a(a6, new ToNativeContext());
        }
        return FFIType.p(a6, a5);
    }

    Pointer p() {
        Structure a2;
        Pointer a3 = Structure.a(a2);
        a2.a(a3);
        return a3;
    }

    public void o(boolean a2) {
        Structure a3;
        a3.p(a2);
        a3.a(a2);
    }

    public void p(boolean a2) {
        a.h = a2;
    }

    public boolean p() {
        Structure a2;
        return a2.h;
    }

    public void a(boolean a2) {
        a.z = a2;
    }

    public boolean a() {
        Structure a2;
        return a2.z;
    }

    static Pointer a(Object a2) {
        return FFIType.p(a2);
    }

    private static /* synthetic */ Structure a(Class<?> a2, long a3) {
        try {
            Structure a4 = Structure.a(a2, a3 == 0L ? d : new Pointer(a3));
            if (a3 != 0L) {
                a4.x();
            }
            return a4;
        }
        catch (Throwable a5) {
            System.err.println("JNA: Error creating structure: " + a5);
            return null;
        }
    }

    public static Structure a(Class<?> a2, Pointer a3) throws IllegalArgumentException {
        try {
            Constructor<?> a4 = a2.getConstructor(Pointer.class);
            return (Structure)a4.newInstance(a3);
        }
        catch (NoSuchMethodException a4) {
        }
        catch (SecurityException a4) {
        }
        catch (InstantiationException a5) {
            String a6 = "Can't instantiate " + a2;
            throw new IllegalArgumentException(a6, a5);
        }
        catch (IllegalAccessException a7) {
            String a8 = "Instantiation of " + a2 + " (Pointer) not allowed, is it public?";
            throw new IllegalArgumentException(a8, a7);
        }
        catch (InvocationTargetException a9) {
            String a10 = "Exception thrown while instantiating an instance of " + a2;
            a9.printStackTrace();
            throw new IllegalArgumentException(a10, a9);
        }
        Structure a11 = Structure.a(a2);
        if (a3 != d) {
            a11.p(a3);
        }
        return a11;
    }

    public static Structure a(Class<?> a2) throws IllegalArgumentException {
        try {
            Structure a3 = (Structure)a2.newInstance();
            if (a3 instanceof ByValue) {
                a3.m();
            }
            return a3;
        }
        catch (InstantiationException a4) {
            String a5 = "Can't instantiate " + a2;
            throw new IllegalArgumentException(a5, a4);
        }
        catch (IllegalAccessException a6) {
            String a7 = "Instantiation of " + a2 + " not allowed, is it public?";
            throw new IllegalArgumentException(a7, a6);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    StructField a() {
        LayoutInfo a2;
        Map<Class<?>, LayoutInfo> map = g;
        synchronized (map) {
            Structure a3;
            a2 = g.get(a3.getClass());
        }
        if (a2 != null) {
            return a2.d;
        }
        return null;
    }

    private static /* synthetic */ void o(Structure[] a2) {
        if (ByReference[].class.isAssignableFrom(a2.getClass())) {
            return;
        }
        Pointer a3 = a2[0].o();
        int a4 = a2[0].p();
        for (int a5 = 1; a5 < a2.length; ++a5) {
            if (a2[a5].o().d == a3.d + (long)(a4 * a5)) continue;
            String a6 = "Structure array elements must use contiguous memory (bad backing address at Structure array index " + a5 + ")";
            throw new IllegalArgumentException(a6);
        }
    }

    public static void p(Structure[] a2) {
        Structure.o(a2);
        if (a2[0].l == a2) {
            a2[0].p();
        } else {
            for (int a3 = 0; a3 < a2.length; ++a3) {
                if (a2[a3] == null) continue;
                a2[a3].p();
            }
        }
    }

    public void p() {
        Structure a2;
        if (a2.p()) {
            a2.j();
            if (a2.l != null) {
                for (int a3 = 1; a3 < a2.l.length; ++a3) {
                    a2.l[a3].p();
                }
            }
        }
    }

    public static void a(Structure[] a2) {
        Structure.o(a2);
        if (a2[0].l == a2) {
            a2[0].a();
        } else {
            for (int a3 = 0; a3 < a2.length; ++a3) {
                if (a2[a3] == null) continue;
                a2[a3].a();
            }
        }
    }

    public void a() {
        Structure a2;
        if (a2.a()) {
            a2.z();
            if (a2.l != null) {
                for (int a3 = 1; a3 < a2.l.length; ++a3) {
                    a2.l[a3].a();
                }
            }
        }
    }

    protected int a(Class<?> a2) {
        Structure a3;
        return a3.a(a2, null);
    }

    protected int a(Class<?> a2, Object a3) {
        return Native.a(a2, a3);
    }

    static void a(Class<?> a2) {
        Structure.a(a2, d);
    }

    private static class AutoAllocated
    extends Memory {
        public AutoAllocated(int a2) {
            super(a2);
            AutoAllocated a3;
            super.p();
        }

        @Override
        public String toString() {
            AutoAllocated a2;
            return "auto-" + super.toString();
        }
    }

    static class FFIType
    extends Structure {
        private static final Map<Object, Object> z = new WeakHashMap<Object, Object>();
        private static final int l = 13;
        public size_t b;
        public short c;
        public short v = (short)13;
        public Pointer d;

        private /* synthetic */ FFIType(Structure a2) {
            Pointer[] a3;
            FFIType a4;
            a2.z(true);
            if (a2 instanceof Union) {
                StructField a5 = ((Union)a2).a();
                a3 = new Pointer[]{FFIType.p(a2.a(a5.f), a5.r), null};
            } else {
                a3 = new Pointer[a2.p().size() + 1];
                int a6 = 0;
                for (StructField a7 : a2.p().values()) {
                    a3[a6++] = a2.a(a7);
                }
            }
            a4.a(a3);
        }

        private /* synthetic */ FFIType(Object a2, Class<?> a3) {
            FFIType a4;
            int a5 = Array.getLength(a2);
            Pointer[] a6 = new Pointer[a5 + 1];
            Pointer a7 = FFIType.p(null, a3.getComponentType());
            for (int a8 = 0; a8 < a5; ++a8) {
                a6[a8] = a7;
            }
            a4.a(a6);
        }

        @Override
        protected List<String> o() {
            return Arrays.asList("size", "alignment", "type", "elements");
        }

        private /* synthetic */ void a(Pointer[] a2) {
            FFIType a3;
            a3.d = new Memory(Pointer.c * a2.length);
            a3.d.a(0L, a2, 0, a2.length);
            a3.z();
        }

        static Pointer p(Object a2) {
            if (a2 == null) {
                return FFITypes.d;
            }
            if (a2 instanceof Class) {
                return FFIType.p(null, (Class)a2);
            }
            return FFIType.p(a2, a2.getClass());
        }

        private static /* synthetic */ Pointer p(Object a2, Class<?> a3) {
            ToNativeConverter a4;
            TypeMapper a5 = Native.a(a3);
            if (a5 != null && (a4 = a5.a(a3)) != null) {
                a3 = a4.a();
            }
            Map<Object, Object> map = z;
            synchronized (map) {
                Object a6 = z.get(a3);
                if (a6 instanceof Pointer) {
                    return (Pointer)a6;
                }
                if (a6 instanceof FFIType) {
                    return ((FFIType)a6).o();
                }
                if (Platform.r && Buffer.class.isAssignableFrom(a3) || Callback.class.isAssignableFrom(a3)) {
                    z.put(a3, FFITypes.d);
                    return FFITypes.d;
                }
                if (Structure.class.isAssignableFrom(a3)) {
                    if (a2 == null) {
                        a2 = FFIType.a(a3, d);
                    }
                    if (ByReference.class.isAssignableFrom(a3)) {
                        z.put(a3, FFITypes.d);
                        return FFITypes.d;
                    }
                    FFIType a7 = new FFIType((Structure)a2);
                    z.put(a3, a7);
                    return a7.o();
                }
                if (NativeMapped.class.isAssignableFrom(a3)) {
                    NativeMappedConverter a8 = NativeMappedConverter.a(a3);
                    return FFIType.p(a8.a(a2, new ToNativeContext()), a8.a());
                }
                if (a3.isArray()) {
                    FFIType a9 = new FFIType(a2, a3);
                    z.put(a2, a9);
                    return a9.o();
                }
                throw new IllegalArgumentException("Unsupported type " + a3);
            }
        }

        static {
            if (Native.za == 0) {
                throw new Error("Native library not initialized");
            }
            if (FFITypes.w == null) {
                throw new Error("FFI types not initialized");
            }
            z.put(Void.TYPE, FFITypes.w);
            z.put(Void.class, FFITypes.w);
            z.put(Float.TYPE, FFITypes.i);
            z.put(Float.class, FFITypes.i);
            z.put(Double.TYPE, FFITypes.n);
            z.put(Double.class, FFITypes.n);
            z.put(Long.TYPE, FFITypes.v);
            z.put(Long.class, FFITypes.v);
            z.put(Integer.TYPE, FFITypes.b);
            z.put(Integer.class, FFITypes.b);
            z.put(Short.TYPE, FFITypes.z);
            z.put(Short.class, FFITypes.z);
            Pointer a2 = Native.wa == 2 ? FFITypes.h : FFITypes.l;
            z.put(Character.TYPE, a2);
            z.put(Character.class, a2);
            z.put(Byte.TYPE, FFITypes.f);
            z.put(Byte.class, FFITypes.f);
            z.put(Pointer.class, FFITypes.d);
            z.put(String.class, FFITypes.d);
            z.put(WString.class, FFITypes.d);
            z.put(Boolean.TYPE, FFITypes.l);
            z.put(Boolean.class, FFITypes.l);
        }

        private static class FFITypes {
            private static Pointer w;
            private static Pointer i;
            private static Pointer n;
            private static Pointer e;
            private static Pointer r;
            private static Pointer f;
            private static Pointer h;
            private static Pointer z;
            private static Pointer l;
            private static Pointer b;
            private static Pointer c;
            private static Pointer v;
            private static Pointer d;

            private /* synthetic */ FFITypes() {
                FFITypes a2;
            }
        }

        public static class size_t
        extends IntegerType {
            private static final long d = 1L;

            public size_t() {
                a2(0L);
                size_t a2;
            }

            public size_t(long a2) {
                super(Native.va, a2);
                size_t a3;
            }
        }
    }

    protected static class StructField {
        public String e;
        public Class<?> r;
        public Field f;
        public int h = -1;
        public int z = -1;
        public boolean l;
        public boolean b;
        public FromNativeConverter c;
        public ToNativeConverter v;
        public FromNativeContext d;

        protected StructField() {
            StructField a2;
        }

        public String toString() {
            StructField a2;
            return a2.e + "@" + a2.z + "[" + a2.h + "] (" + a2.r + ")";
        }
    }

    private static class LayoutInfo {
        private int h = -1;
        private int z = 1;
        private final Map<String, StructField> l = Collections.synchronizedMap(new LinkedHashMap());
        private int b = 0;
        private TypeMapper c;
        private boolean v;
        private StructField d;

        private /* synthetic */ LayoutInfo() {
            LayoutInfo a2;
        }
    }

    static class StructureSet
    extends AbstractCollection<Structure>
    implements Set<Structure> {
        Structure[] v;
        private int d;

        StructureSet() {
            StructureSet a2;
        }

        private /* synthetic */ void a(int a2) {
            StructureSet a3;
            if (a3.v == null) {
                a3.v = new Structure[a2 * 3 / 2];
            } else if (a3.v.length < a2) {
                Structure[] a4 = new Structure[a2 * 3 / 2];
                System.arraycopy(a3.v, 0, a4, 0, a3.v.length);
                a3.v = a4;
            }
        }

        public Structure[] a() {
            StructureSet a2;
            return a2.v;
        }

        @Override
        public int size() {
            StructureSet a2;
            return a2.d;
        }

        @Override
        public boolean contains(Object a2) {
            StructureSet a3;
            return a3.a((Structure)a2) != -1;
        }

        public boolean a(Structure a2) {
            StructureSet a3;
            if (!a3.contains(a2)) {
                a3.a(a3.d + 1);
                a3.v[a3.d++] = a2;
            }
            return true;
        }

        private /* synthetic */ int a(Structure a2) {
            StructureSet a3;
            for (int a4 = 0; a4 < a3.d; ++a4) {
                Structure a5 = a3.v[a4];
                if (a2 != a5 && (a2.getClass() != a5.getClass() || a2.p() != a5.p() || !a2.o().equals(a5.o()))) continue;
                return a4;
            }
            return -1;
        }

        @Override
        public boolean remove(Object a2) {
            StructureSet a3;
            int a4 = a3.a((Structure)a2);
            if (a4 != -1) {
                if (--a3.d >= 0) {
                    a3.v[a4] = a3.v[a3.d];
                    a3.v[a3.d] = null;
                }
                return true;
            }
            return false;
        }

        @Override
        public Iterator<Structure> iterator() {
            StructureSet a2;
            Structure[] a3 = new Structure[a2.d];
            if (a2.d > 0) {
                System.arraycopy(a2.v, 0, a3, 0, a2.d);
            }
            return Arrays.asList(a3).iterator();
        }
    }

    public static interface ByReference {
    }

    public static interface ByValue {
    }
}

