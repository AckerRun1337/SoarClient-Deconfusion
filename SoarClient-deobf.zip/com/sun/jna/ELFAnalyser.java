/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class ELFAnalyser {
    private static final byte[] w = new byte[]{127, 69, 76, 70};
    private static final int i = 1024;
    private static final int n = 512;
    private static final int e = 2;
    private static final int r = 40;
    private static final int f = 2;
    private final String h;
    private boolean z = false;
    private boolean l = false;
    private boolean b = false;
    private boolean c = false;
    private boolean v = false;
    private boolean d = false;

    public static ELFAnalyser a(String a2) throws IOException {
        ELFAnalyser a3 = new ELFAnalyser(a2);
        a3.a();
        return a3;
    }

    public boolean j() {
        ELFAnalyser a2;
        return a2.z;
    }

    public boolean z() {
        ELFAnalyser a2;
        return a2.l;
    }

    public boolean y() {
        ELFAnalyser a2;
        return a2.b;
    }

    public String a() {
        ELFAnalyser a2;
        return a2.h;
    }

    public boolean o() {
        ELFAnalyser a2;
        return a2.c;
    }

    public boolean p() {
        ELFAnalyser a2;
        return a2.v;
    }

    public boolean a() {
        ELFAnalyser a2;
        return a2.d;
    }

    private /* synthetic */ ELFAnalyser(String a2) {
        ELFAnalyser a3;
        a3.h = a2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private /* synthetic */ void a() throws IOException {
        ELFAnalyser a2;
        RandomAccessFile a3 = new RandomAccessFile(a2.h, "r");
        try {
            if (a3.length() > 4L) {
                byte[] a4 = new byte[4];
                a3.seek(0L);
                a3.read(a4);
                if (Arrays.equals(a4, w)) {
                    a2.z = true;
                }
            }
            if (!a2.z) {
                return;
            }
            a3.seek(4L);
            byte a5 = a3.readByte();
            a2.l = a5 == 2;
            a3.seek(0L);
            ByteBuffer a6 = ByteBuffer.allocate(a2.l ? 64 : 52);
            a3.getChannel().read(a6, 0L);
            a2.b = a6.get(5) == 2;
            a6.order(a2.b ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN);
            boolean bl2 = a2.d = a6.get(18) == 40;
            if (a2.d) {
                int a7 = a6.getInt(a2.l ? 48 : 36);
                a2.c = (a7 & 0x400) == 1024;
                a2.v = !a2.c;
            }
        }
        finally {
            try {
                a3.close();
            }
            catch (IOException a4) {}
        }
    }
}

