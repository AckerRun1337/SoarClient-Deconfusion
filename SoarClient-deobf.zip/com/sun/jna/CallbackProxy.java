/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;

public interface CallbackProxy
extends Callback {
    public Object a(Object[] var1);

    public Class<?>[] a();

    public Class<?> a();
}

