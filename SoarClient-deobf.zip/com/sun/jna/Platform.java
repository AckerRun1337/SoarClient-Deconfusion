/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.ELFAnalyser;
import com.sun.jna.Native;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Platform {
    public static final int m = -1;
    public static final int y = 0;
    public static final int a = 1;
    public static final int q = 2;
    public static final int g = 3;
    public static final int k = 4;
    public static final int x = 5;
    public static final int t = 6;
    public static final int p = 7;
    public static final int s = 8;
    public static final int w = 9;
    public static final int i = 10;
    public static final int n = 11;
    public static final boolean e;
    public static final boolean r;
    public static final boolean f;
    public static final boolean h;
    public static final String z;
    public static final String l;
    public static final boolean b;
    public static final String c;
    private static final int v;
    public static final String d;

    private /* synthetic */ Platform() {
        Platform a2;
    }

    public static final int a() {
        return v;
    }

    public static final boolean t() {
        return v == 0;
    }

    public static final boolean v() {
        return v == 8;
    }

    public static final boolean k() {
        return v == 1;
    }

    public static final boolean g() {
        return v == 7;
    }

    public static final boolean n() {
        return Platform.g();
    }

    public static final boolean i() {
        return v == 6;
    }

    public static final boolean e() {
        return v == 2 || v == 6;
    }

    public static final boolean c() {
        return v == 3;
    }

    public static final boolean f() {
        return v == 4;
    }

    public static final boolean l() {
        return v == 5;
    }

    public static final boolean r() {
        return v == 11;
    }

    public static final boolean q() {
        return v == 9;
    }

    public static final boolean d() {
        return v == 10;
    }

    public static final boolean m() {
        return !Platform.e() && !Platform.t();
    }

    public static final boolean h() {
        return !Platform.i() || !"J9".equals(System.getProperty("java.vm.name"));
    }

    public static final boolean x() {
        String a2 = System.getProperty("sun.arch.data.model", System.getProperty("com.ibm.vm.bitmode"));
        if (a2 != null) {
            return "64".equals(a2);
        }
        if ("x86-64".equals(d) || "ia64".equals(d) || "ppc64".equals(d) || "ppc64le".equals(d) || "sparcv9".equals(d) || "mips64".equals(d) || "mips64el".equals(d) || "amd64".equals(d)) {
            return true;
        }
        return Native.za == 8;
    }

    public static final boolean j() {
        return d.startsWith("x86");
    }

    public static final boolean z() {
        return d.startsWith("ppc");
    }

    public static final boolean y() {
        return d.startsWith("arm");
    }

    public static final boolean o() {
        return d.startsWith("sparc");
    }

    public static final boolean p() {
        return d.equals("mips") || d.equals("mips64") || d.equals("mipsel") || d.equals("mips64el");
    }

    static String a(String a2, int a3) {
        if ("powerpc".equals(a2 = a2.toLowerCase().trim())) {
            a2 = "ppc";
        } else if ("powerpc64".equals(a2)) {
            a2 = "ppc64";
        } else if ("i386".equals(a2) || "i686".equals(a2)) {
            a2 = "x86";
        } else if ("x86_64".equals(a2) || "amd64".equals(a2)) {
            a2 = "x86-64";
        }
        if ("ppc64".equals(a2) && "little".equals(System.getProperty("sun.cpu.endian"))) {
            a2 = "ppc64le";
        }
        if ("arm".equals(a2) && a3 == 1 && Platform.a()) {
            a2 = "armel";
        }
        return a2;
    }

    static boolean a() {
        try {
            File a2 = new File("/proc/self/exe");
            if (a2.exists()) {
                ELFAnalyser a3 = ELFAnalyser.a(a2.getCanonicalPath());
                return a3.p();
            }
        }
        catch (IOException a4) {
            Logger.getLogger(Platform.class.getName()).log(Level.INFO, "Failed to read '/proc/self/exe' or the target binary.", a4);
        }
        catch (SecurityException a5) {
            Logger.getLogger(Platform.class.getName()).log(Level.INFO, "SecurityException while analysing '/proc/self/exe' or the target binary.", a5);
        }
        return false;
    }

    static String a() {
        String a2 = System.getProperty("jna.prefix");
        if (a2 != null) {
            return a2;
        }
        return Platform.a(Platform.a(), System.getProperty("os.arch"), System.getProperty("os.name"));
    }

    static String a(int a2, String a3, String a4) {
        String a5;
        a3 = Platform.a(a3, a2);
        switch (a2) {
            case 8: {
                if (a3.startsWith("arm")) {
                    a3 = "arm";
                }
                a5 = "android-" + a3;
                break;
            }
            case 2: {
                a5 = "win32-" + a3;
                break;
            }
            case 6: {
                a5 = "w32ce-" + a3;
                break;
            }
            case 0: {
                a5 = "darwin";
                break;
            }
            case 1: {
                a5 = "linux-" + a3;
                break;
            }
            case 3: {
                a5 = "sunos-" + a3;
                break;
            }
            case 4: {
                a5 = "freebsd-" + a3;
                break;
            }
            case 5: {
                a5 = "openbsd-" + a3;
                break;
            }
            case 11: {
                a5 = "netbsd-" + a3;
                break;
            }
            case 10: {
                a5 = "kfreebsd-" + a3;
                break;
            }
            default: {
                a5 = a4.toLowerCase();
                int a6 = a5.indexOf(" ");
                if (a6 != -1) {
                    a5 = a5.substring(0, a6);
                }
                a5 = a5 + "-" + a3;
            }
        }
        return a5;
    }

    static {
        String a2 = System.getProperty("os.name");
        if (a2.startsWith("Linux")) {
            if ("dalvik".equals(System.getProperty("java.vm.name").toLowerCase())) {
                v = 8;
                System.setProperty("jna.nounpack", "true");
            } else {
                v = 1;
            }
        } else {
            v = a2.startsWith("AIX") ? 7 : (a2.startsWith("Mac") || a2.startsWith("Darwin") ? 0 : (a2.startsWith("Windows CE") ? 6 : (a2.startsWith("Windows") ? 2 : (a2.startsWith("Solaris") || a2.startsWith("SunOS") ? 3 : (a2.startsWith("FreeBSD") ? 4 : (a2.startsWith("OpenBSD") ? 5 : (a2.equalsIgnoreCase("gnu") ? 9 : (a2.equalsIgnoreCase("gnu/kfreebsd") ? 10 : (a2.equalsIgnoreCase("netbsd") ? 11 : -1)))))))));
        }
        boolean a3 = false;
        try {
            Class.forName("java.nio.Buffer");
            a3 = true;
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
        f = v != 6 && v != 8 && v != 7;
        h = f && v != 0;
        r = a3;
        boolean bl2 = e = v != 6;
        String string = v == 2 ? "msvcrt" : (l = v == 6 ? "coredll" : "c");
        z = v == 2 ? "msvcrt" : (v == 6 ? "coredll" : "m");
        b = v == 2;
        d = Platform.a(System.getProperty("os.arch"), v);
        c = Platform.a();
    }
}

