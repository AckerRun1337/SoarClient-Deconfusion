/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import com.sun.jna.Structure;
import java.lang.reflect.Field;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class StructureReadContext
extends FromNativeContext {
    private Structure v;
    private Field d;

    StructureReadContext(Structure a2, Field a3) {
        super(a3.getType());
        StructureReadContext a4;
        a4.v = a2;
        a4.d = a3;
    }

    public Structure a() {
        StructureReadContext a2;
        return a2.v;
    }

    public Field a() {
        StructureReadContext a2;
        return a2.d;
    }
}

