/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Platform;

public class LastErrorException
extends RuntimeException {
    private static final long v = 1L;
    private int d;

    private static /* synthetic */ String a(int a2) {
        return Platform.e() ? "GetLastError() returned " + a2 : "errno was " + a2;
    }

    private static /* synthetic */ String a(String a2) {
        try {
            return LastErrorException.a(Integer.parseInt(a2));
        }
        catch (NumberFormatException a3) {
            return a2;
        }
    }

    public int a() {
        LastErrorException a2;
        return a2.d;
    }

    public LastErrorException(String a2) {
        super(LastErrorException.a(a2.trim()));
        LastErrorException a3;
        try {
            if (a2.startsWith("[")) {
                a2 = a2.substring(1, a2.indexOf("]"));
            }
            a3.d = Integer.parseInt(a2);
        }
        catch (NumberFormatException a4) {
            a3.d = -1;
        }
    }

    public LastErrorException(int a2) {
        a3(a2, LastErrorException.a(a2));
        LastErrorException a3;
    }

    protected LastErrorException(int a2, String a3) {
        super(a3);
        LastErrorException a4;
        a4.d = a2;
    }
}

