/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Function;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.NativeString;
import com.sun.jna.Pointer;
import com.sun.jna.WString;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringArray
extends Memory
implements Function.PostCallRead {
    private String c;
    private List<NativeString> v = new ArrayList<NativeString>();
    private Object[] d;

    public StringArray(String[] a2) {
        a3(a2, false);
        StringArray a3;
    }

    public StringArray(String[] a2, boolean a3) {
        a4((Object[])a2, a3 ? "--WIDE-STRING--" : Native.a());
        StringArray a4;
    }

    public StringArray(String[] a2, String a3) {
        a4((Object[])a2, a3);
        StringArray a4;
    }

    public StringArray(WString[] a2) {
        a3(a2, "--WIDE-STRING--");
        StringArray a3;
    }

    private /* synthetic */ StringArray(Object[] a2, String a3) {
        super((a2.length + 1) * Pointer.c);
        StringArray a4;
        a4.d = a2;
        a4.c = a3;
        for (int a5 = 0; a5 < a2.length; ++a5) {
            Pointer a6 = null;
            if (a2[a5] != null) {
                NativeString a7 = new NativeString(a2[a5].toString(), a3);
                a4.v.add(a7);
                a6 = a7.a();
            }
            a4.a((long)(Pointer.c * a5), a6);
        }
        a4.a((long)(Pointer.c * a2.length), (Pointer)null);
    }

    @Override
    public void a() {
        StringArray a2;
        boolean a3 = a2.d instanceof WString[];
        boolean a4 = "--WIDE-STRING--".equals(a2.c);
        for (int a5 = 0; a5 < a2.d.length; ++a5) {
            Pointer a6 = a2.a((long)(a5 * Pointer.c));
            CharSequence a7 = null;
            if (a6 != null) {
                String string = a7 = a4 ? a6.p(0L) : a6.a(0L, a2.c);
                if (a3) {
                    a7 = new WString((String)a7);
                }
            }
            a2.d[a5] = a7;
        }
    }

    @Override
    public String toString() {
        StringArray a2;
        boolean a3 = "--WIDE-STRING--".equals(a2.c);
        String a4 = a3 ? "const wchar_t*[]" : "const char*[]";
        a4 = a4 + Arrays.asList(a2.d);
        return a4;
    }
}

