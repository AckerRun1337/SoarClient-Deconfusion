/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Function;
import com.sun.jna.FunctionMapper;
import com.sun.jna.LastErrorException;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class NativeLibrary {
    private long n;
    private final String e;
    private final String r;
    private final Map<String, Function> f = new HashMap<String, Function>();
    final int h;
    private String z;
    final Map<String, ?> l;
    private static final Map<String, Reference<NativeLibrary>> b = new HashMap<String, Reference<NativeLibrary>>();
    private static final Map<String, List<String>> c = Collections.synchronizedMap(new HashMap());
    private static final List<String> v = new ArrayList<String>();
    private static final int d = -1;

    private static /* synthetic */ String a(String a2, int a3, String a4) {
        return a2 + "|" + a3 + "|" + a4;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private /* synthetic */ NativeLibrary(String a2, String a3, long a4, Map<String, ?> a5) {
        int a6;
        NativeLibrary a7;
        a7.e = a7.p(a2);
        a7.r = a3;
        a7.n = a4;
        Object a8 = a5.get("calling-convention");
        a7.h = a6 = a8 instanceof Number ? ((Number)a8).intValue() : 0;
        a7.l = a5;
        a7.z = (String)a5.get("string-encoding");
        if (a7.z == null) {
            a7.z = Native.a();
        }
        if (Platform.e() && "kernel32".equals(a7.e.toLowerCase())) {
            Map<String, Function> map = a7.f;
            synchronized (map) {
                Function a9 = new Function(a7, "GetLastError", 63, a7.z){
                    {
                        1 a7;
                        super(a3, a4, a5, a6);
                    }

                    @Override
                    Object a(Object[] a2, Class<?> a3, boolean a4, int a5) {
                        return Native.getLastError();
                    }

                    @Override
                    Object a(Method a2, Class<?>[] a3, Class<?> a4, Object[] a5, Map<String, ?> a6) {
                        return Native.getLastError();
                    }
                };
                a7.f.put(NativeLibrary.a("GetLastError", a7.h, a7.z), a9);
            }
        }
    }

    private static /* synthetic */ int a(Map<String, ?> a2) {
        Object a3 = a2.get("open-flags");
        if (a3 instanceof Number) {
            return ((Number)a3).intValue();
        }
        return -1;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ NativeLibrary p(String a2, Map<String, ?> a3) {
        long a4;
        String a5;
        block51: {
            List<String> a6;
            if (Native.gb) {
                System.out.println("Looking for library '" + a2 + "'");
            }
            boolean a7 = new File(a2).isAbsolute();
            ArrayList<String> a8 = new ArrayList<String>();
            int a9 = NativeLibrary.a(a3);
            String a10 = Native.a(a2);
            if (a10 != null) {
                if (Native.gb) {
                    System.out.println("Adding web start path " + a10);
                }
                a8.add(a10);
            }
            if ((a6 = c.get(a2)) != null) {
                List<String> list = a6;
                synchronized (list) {
                    a8.addAll(0, a6);
                }
            }
            if (Native.gb) {
                System.out.println("Adding paths from jna.library.path: " + System.getProperty("jna.library.path"));
            }
            a8.addAll(NativeLibrary.a("jna.library.path"));
            a5 = NativeLibrary.p(a2, a8);
            a4 = 0L;
            try {
                if (Native.gb) {
                    System.out.println("Trying " + a5);
                }
                a4 = Native.open(a5, a9);
            }
            catch (UnsatisfiedLinkError a11) {
                if (Native.gb) {
                    System.out.println("Adding system paths: " + v);
                }
                a8.addAll(v);
            }
            try {
                if (a4 == 0L) {
                    a5 = NativeLibrary.p(a2, a8);
                    if (Native.gb) {
                        System.out.println("Trying " + a5);
                    }
                    if ((a4 = Native.open(a5, a9)) == 0L) {
                        throw new UnsatisfiedLinkError("Failed to load library '" + a2 + "'");
                    }
                }
            }
            catch (UnsatisfiedLinkError a12) {
                if (Platform.v()) {
                    try {
                        if (Native.gb) {
                            System.out.println("Preload (via System.loadLibrary) " + a2);
                        }
                        System.loadLibrary(a2);
                        a4 = Native.open(a5, a9);
                    }
                    catch (UnsatisfiedLinkError a13) {
                        a12 = a13;
                    }
                } else if (Platform.k() || Platform.f()) {
                    if (Native.gb) {
                        System.out.println("Looking for version variants");
                    }
                    if ((a5 = NativeLibrary.a(a2, a8)) != null) {
                        if (Native.gb) {
                            System.out.println("Trying " + a5);
                        }
                        try {
                            a4 = Native.open(a5, a9);
                        }
                        catch (UnsatisfiedLinkError a14) {
                            a12 = a14;
                        }
                    }
                } else if (Platform.t() && !a2.endsWith(".dylib")) {
                    if (Native.gb) {
                        System.out.println("Looking for matching frameworks");
                    }
                    if ((a5 = NativeLibrary.o(a2)) != null) {
                        try {
                            if (Native.gb) {
                                System.out.println("Trying " + a5);
                            }
                            a4 = Native.open(a5, a9);
                        }
                        catch (UnsatisfiedLinkError a15) {
                            a12 = a15;
                        }
                    }
                } else if (Platform.e() && !a7) {
                    if (Native.gb) {
                        System.out.println("Looking for lib- prefix");
                    }
                    if ((a5 = NativeLibrary.p("lib" + a2, a8)) != null) {
                        if (Native.gb) {
                            System.out.println("Trying " + a5);
                        }
                        try {
                            a4 = Native.open(a5, a9);
                        }
                        catch (UnsatisfiedLinkError a16) {
                            a12 = a16;
                        }
                    }
                }
                if (a4 == 0L) {
                    try {
                        File a17 = Native.a(a2, (ClassLoader)a3.get("classloader"));
                        try {
                            a4 = Native.open(a17.getAbsolutePath(), a9);
                            a5 = a17.getAbsolutePath();
                        }
                        finally {
                            if (Native.a(a17)) {
                                Native.p(a17);
                            }
                        }
                    }
                    catch (IOException a18) {
                        a12 = new UnsatisfiedLinkError(a18.getMessage());
                    }
                }
                if (a4 != 0L) break block51;
                throw new UnsatisfiedLinkError("Unable to load library '" + a2 + "': " + a12.getMessage());
            }
        }
        if (Native.gb) {
            System.out.println("Found library '" + a2 + "' at " + a5);
        }
        return new NativeLibrary(a2, a5, a4, a3);
    }

    static String o(String a2) {
        File a3 = new File(a2);
        if (a3.isAbsolute()) {
            if (a2.indexOf(".framework") != -1 && a3.exists()) {
                return a3.getAbsolutePath();
            }
            if ((a3 = new File(new File(a3.getParentFile(), a3.getName() + ".framework"), a3.getName())).exists()) {
                return a3.getAbsolutePath();
            }
        } else {
            String[] a4 = new String[]{System.getProperty("user.home"), "", "/System"};
            String a5 = a2.indexOf(".framework") == -1 ? a2 + ".framework/" + a2 : a2;
            for (int a6 = 0; a6 < a4.length; ++a6) {
                String a7 = a4[a6] + "/Library/Frameworks/" + a5;
                if (!new File(a7).exists()) continue;
                return a7;
            }
        }
        return null;
    }

    private /* synthetic */ String p(String a2) {
        String a3;
        int a4;
        String a5 = a2;
        String a6 = "---";
        String a7 = NativeLibrary.a("---");
        int a8 = a7.indexOf("---");
        if (a8 > 0 && a5.startsWith(a7.substring(0, a8))) {
            a5 = a5.substring(a8);
        }
        if ((a4 = a5.indexOf(a3 = a7.substring(a8 + "---".length()))) != -1) {
            a5 = a5.substring(0, a4);
        }
        return a5;
    }

    public static final NativeLibrary a(String a2) {
        return NativeLibrary.a(a2, Collections.emptyMap());
    }

    public static final NativeLibrary a(String a2, ClassLoader a3) {
        return NativeLibrary.a(a2, Collections.singletonMap("classloader", a3));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static final NativeLibrary a(String a2, Map<String, ?> a3) {
        HashMap a4 = new HashMap(a3);
        if (a4.get("calling-convention") == null) {
            a4.put("calling-convention", 0);
        }
        if ((Platform.k() || Platform.f() || Platform.g()) && Platform.l.equals(a2)) {
            a2 = null;
        }
        Map<String, Reference<NativeLibrary>> map = b;
        synchronized (map) {
            NativeLibrary a5;
            Reference<NativeLibrary> a6 = b.get(a2 + a4);
            NativeLibrary nativeLibrary = a5 = a6 != null ? a6.get() : null;
            if (a5 == null) {
                a5 = a2 == null ? new NativeLibrary("<process>", null, Native.open(null, NativeLibrary.a(a4)), a4) : NativeLibrary.p(a2, a4);
                a6 = new WeakReference<NativeLibrary>(a5);
                b.put(a5.p() + a4, a6);
                File a7 = a5.a();
                if (a7 != null) {
                    b.put(a7.getAbsolutePath() + a4, a6);
                    b.put(a7.getName() + a4, a6);
                }
            }
            return a5;
        }
    }

    public static final synchronized NativeLibrary a() {
        return NativeLibrary.a(null);
    }

    public static final synchronized NativeLibrary a(Map<String, ?> a2) {
        return NativeLibrary.a(null, a2);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static final void a(String a2, String a3) {
        Map<String, List<String>> map = c;
        synchronized (map) {
            List<String> a4 = c.get(a2);
            if (a4 == null) {
                a4 = Collections.synchronizedList(new ArrayList());
                c.put(a2, a4);
            }
            a4.add(a3);
        }
    }

    public Function a(String a2) {
        NativeLibrary a3;
        return a3.a(a2, a3.h);
    }

    Function a(String a2, Method a3) {
        String a4;
        NativeLibrary a5;
        FunctionMapper a6 = (FunctionMapper)a5.l.get("function-mapper");
        if (a6 != null) {
            a2 = a6.a(a5, a3);
        }
        if (a2.startsWith(a4 = System.getProperty("jna.profiler.prefix", "$$YJP$$"))) {
            a2 = a2.substring(a4.length());
        }
        int a7 = a5.h;
        Class<?>[] a8 = a3.getExceptionTypes();
        for (int a9 = 0; a9 < a8.length; ++a9) {
            if (!LastErrorException.class.isAssignableFrom(a8[a9])) continue;
            a7 |= 0x40;
        }
        return a5.a(a2, a7);
    }

    public Function a(String a2, int a3) {
        NativeLibrary a4;
        return a4.a(a2, a3, a4.z);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Function a(String a2, int a3, String a4) {
        NativeLibrary a5;
        if (a2 == null) {
            throw new NullPointerException("Function name may not be null");
        }
        Map<String, Function> map = a5.f;
        synchronized (map) {
            String a6 = NativeLibrary.a(a2, a3, a4);
            Function a7 = a5.f.get(a6);
            if (a7 == null) {
                a7 = new Function(a5, a2, a3, a4);
                a5.f.put(a6, a7);
            }
            return a7;
        }
    }

    public Map<String, ?> a() {
        NativeLibrary a2;
        return a2.l;
    }

    public Pointer a(String a2) {
        try {
            NativeLibrary a3;
            return new Pointer(a3.a(a2));
        }
        catch (UnsatisfiedLinkError a4) {
            throw new UnsatisfiedLinkError("Error looking up '" + a2 + "': " + a4.getMessage());
        }
    }

    long a(String a2) {
        NativeLibrary a3;
        if (a3.n == 0L) {
            throw new UnsatisfiedLinkError("Library has been unloaded");
        }
        return Native.findSymbol(a3.n, a2);
    }

    public String toString() {
        NativeLibrary a2;
        return "Native Library <" + a2.r + "@" + a2.n + ">";
    }

    public String p() {
        NativeLibrary a2;
        return a2.e;
    }

    public File a() {
        NativeLibrary a2;
        if (a2.r == null) {
            return null;
        }
        return new File(a2.r);
    }

    protected void finalize() {
        NativeLibrary a2;
        a2.a();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - void declaration
     */
    static void p() {
        void a2;
        Map<String, Reference<NativeLibrary>> map = b;
        synchronized (map) {
            LinkedHashSet<Reference<NativeLibrary>> a22 = new LinkedHashSet<Reference<NativeLibrary>>(b.values());
        }
        for (Reference reference : a2) {
            NativeLibrary a4 = (NativeLibrary)reference.get();
            if (a4 == null) continue;
            a4.a();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a() {
        NativeLibrary a2;
        HashSet a3 = new HashSet();
        Object object = b;
        synchronized (object) {
            for (Map.Entry<String, Reference<NativeLibrary>> a4 : b.entrySet()) {
                Reference<NativeLibrary> a5 = a4.getValue();
                if (a5.get() != a2) continue;
                a3.add(a4.getKey());
            }
            for (Map.Entry<String, Reference<NativeLibrary>> a4 : a3) {
                b.remove(a4);
            }
        }
        object = a2;
        synchronized (object) {
            if (a2.n != 0L) {
                Native.close(a2.n);
                a2.n = 0L;
            }
        }
    }

    private static /* synthetic */ List<String> a(String a2) {
        String a3 = System.getProperty(a2, "");
        if ("".equals(a3)) {
            return Collections.emptyList();
        }
        StringTokenizer a4 = new StringTokenizer(a3, File.pathSeparator);
        ArrayList<String> a5 = new ArrayList<String>();
        while (a4.hasMoreTokens()) {
            String a6 = a4.nextToken();
            if ("".equals(a6)) continue;
            a5.add(a6);
        }
        return a5;
    }

    private static /* synthetic */ String p(String a2, List<String> a3) {
        if (new File(a2).isAbsolute()) {
            return a2;
        }
        String a4 = NativeLibrary.a(a2);
        for (String a5 : a3) {
            File a6 = new File(a5, a4);
            if (a6.exists()) {
                return a6.getAbsolutePath();
            }
            if (!Platform.t() || !a4.endsWith(".dylib") || !(a6 = new File(a5, a4.substring(0, a4.lastIndexOf(".dylib")) + ".jnilib")).exists()) continue;
            return a6.getAbsolutePath();
        }
        return a4;
    }

    static String a(String a2) {
        if (Platform.t()) {
            if (a2.startsWith("lib") && (a2.endsWith(".dylib") || a2.endsWith(".jnilib"))) {
                return a2;
            }
            String a3 = System.mapLibraryName(a2);
            if (a3.endsWith(".jnilib")) {
                return a3.substring(0, a3.lastIndexOf(".jnilib")) + ".dylib";
            }
            return a3;
        }
        if (Platform.k() || Platform.f() ? NativeLibrary.p(a2) || a2.endsWith(".so") : (Platform.g() ? a2.startsWith("lib") : Platform.e() && (a2.endsWith(".drv") || a2.endsWith(".dll")))) {
            return a2;
        }
        return System.mapLibraryName(a2);
    }

    private static /* synthetic */ boolean p(String a2) {
        int a3;
        if (a2.startsWith("lib") && (a3 = a2.lastIndexOf(".so.")) != -1 && a3 + 4 < a2.length()) {
            for (int a4 = a3 + 4; a4 < a2.length(); ++a4) {
                char a5 = a2.charAt(a4);
                if (Character.isDigit(a5) || a5 == '.') continue;
                return false;
            }
            return true;
        }
        return false;
    }

    static String a(final String a2, List<String> a3) {
        Object a4;
        File a5 = new File(a2);
        if (a5.isAbsolute()) {
            a3 = Arrays.asList(a5.getParent());
        }
        FilenameFilter a6 = new FilenameFilter(){
            {
                2 a22;
            }

            @Override
            public boolean accept(File a22, String a3) {
                2 a4;
                return (a3.startsWith("lib" + a4.a2 + ".so") || a3.startsWith(a4.a2 + ".so") && a4.a2.startsWith("lib")) && NativeLibrary.p(a3);
            }
        };
        LinkedList<File> a7 = new LinkedList<File>();
        for (String a8 : a3) {
            a4 = new File(a8).listFiles(a6);
            if (a4 == null || ((File[])a4).length <= 0) continue;
            a7.addAll(Arrays.asList(a4));
        }
        double a9 = -1.0;
        a4 = null;
        for (File a10 : a7) {
            String a11 = a10.getAbsolutePath();
            String a12 = a11.substring(a11.lastIndexOf(".so.") + 4);
            double a13 = NativeLibrary.a(a12);
            if (!(a13 > a9)) continue;
            a9 = a13;
            a4 = a11;
        }
        return a4;
    }

    static double a(String a2) {
        double a3 = 0.0;
        double a4 = 1.0;
        int a5 = a2.indexOf(".");
        while (a2 != null) {
            String a6;
            if (a5 != -1) {
                a6 = a2.substring(0, a5);
                a2 = a2.substring(a5 + 1);
                a5 = a2.indexOf(".");
            } else {
                a6 = a2;
                a2 = null;
            }
            try {
                a3 += (double)Integer.parseInt(a6) / a4;
            }
            catch (NumberFormatException a7) {
                return 0.0;
            }
            a4 *= 100.0;
        }
        return a3;
    }

    private static /* synthetic */ String a() {
        String a2 = Platform.d;
        String a3 = Platform.d() ? "-kfreebsd" : (Platform.q() ? "" : "-linux");
        String a4 = "-gnu";
        if (Platform.j()) {
            a2 = Platform.x() ? "x86_64" : "i386";
        } else if (Platform.z()) {
            a2 = Platform.x() ? "powerpc64" : "powerpc";
        } else if (Platform.y()) {
            a2 = "arm";
            a4 = "-gnueabi";
        } else if (Platform.d.equals("mips64el")) {
            a4 = "-gnuabi64";
        }
        return a2 + a3 + a4;
    }

    private static /* synthetic */ ArrayList<String> a() {
        ArrayList<String> a2 = new ArrayList<String>();
        try {
            Process a3 = Runtime.getRuntime().exec("/sbin/ldconfig -p");
            BufferedReader a4 = new BufferedReader(new InputStreamReader(a3.getInputStream()));
            String a5 = "";
            while ((a5 = a4.readLine()) != null) {
                String a6;
                int a7 = a5.indexOf(" => ");
                int a8 = a5.lastIndexOf(47);
                if (a7 == -1 || a8 == -1 || a7 >= a8 || a2.contains(a6 = a5.substring(a7 + 4, a8))) continue;
                a2.add(a6);
            }
            a4.close();
        }
        catch (Exception exception) {
            // empty catch block
        }
        return a2;
    }

    static {
        if (Native.za == 0) {
            throw new Error("Native library not initialized");
        }
        String a2 = Native.a("jnidispatch");
        if (a2 != null) {
            v.add(a2);
        }
        if (System.getProperty("jna.platform.library.path") == null && !Platform.e()) {
            Object a3;
            String a4 = "";
            String a5 = "";
            String a6 = "";
            if (Platform.k() || Platform.c() || Platform.f() || Platform.d()) {
                a6 = (Platform.c() ? "/" : "") + Pointer.c * 8;
            }
            String[] a7 = new String[]{"/usr/lib" + a6, "/lib" + a6, "/usr/lib", "/lib"};
            if (Platform.k() || Platform.d() || Platform.q()) {
                a3 = NativeLibrary.a();
                a7 = new String[]{"/usr/lib/" + (String)a3, "/lib/" + (String)a3, "/usr/lib" + a6, "/lib" + a6, "/usr/lib", "/lib"};
            }
            if (Platform.k()) {
                a3 = NativeLibrary.a();
                for (int a8 = a7.length - 1; 0 <= a8; --a8) {
                    int a9 = ((ArrayList)a3).indexOf(a7[a8]);
                    if (a9 != -1) {
                        ((ArrayList)a3).remove(a9);
                    }
                    ((ArrayList)a3).add(0, a7[a8]);
                }
                a7 = ((ArrayList)a3).toArray(new String[((ArrayList)a3).size()]);
            }
            for (int a10 = 0; a10 < a7.length; ++a10) {
                File a11 = new File(a7[a10]);
                if (!a11.exists() || !a11.isDirectory()) continue;
                a4 = a4 + a5 + a7[a10];
                a5 = File.pathSeparator;
            }
            if (!"".equals(a4)) {
                System.setProperty("jna.platform.library.path", a4);
            }
        }
        v.addAll(NativeLibrary.a("jna.platform.library.path"));
    }
}

