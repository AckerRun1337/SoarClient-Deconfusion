/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import com.sun.jna.Function;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class FunctionResultContext
extends FromNativeContext {
    private Function v;
    private Object[] d;

    FunctionResultContext(Class<?> a2, Function a3, Object[] a4) {
        super(a2);
        FunctionResultContext a5;
        a5.v = a3;
        a5.d = a4;
    }

    public Function a() {
        FunctionResultContext a2;
        return a2.v;
    }

    public Object[] a() {
        FunctionResultContext a2;
        return a2.d;
    }
}

