/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Function;
import com.sun.jna.ToNativeContext;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class FunctionParameterContext
extends ToNativeContext {
    private Function c;
    private Object[] v;
    private int d;

    FunctionParameterContext(Function a2, Object[] a3, int a4) {
        FunctionParameterContext a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    public Function a() {
        FunctionParameterContext a2;
        return a2.c;
    }

    public Object[] a() {
        FunctionParameterContext a2;
        return a2.v;
    }

    public int a() {
        FunctionParameterContext a2;
        return a2.d;
    }
}

