/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public interface Callback {
    public static final String v = "callback";
    public static final List<String> d = Collections.unmodifiableList(Arrays.asList("hashCode", "equals", "toString"));

    public static interface UncaughtExceptionHandler {
        public void a(Callback var1, Throwable var2);
    }
}

