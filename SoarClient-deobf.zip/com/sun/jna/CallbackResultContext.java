/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.ToNativeContext;
import java.lang.reflect.Method;

public class CallbackResultContext
extends ToNativeContext {
    private Method d;

    CallbackResultContext(Method a2) {
        CallbackResultContext a3;
        a3.d = a2;
    }

    public Method a() {
        CallbackResultContext a2;
        return a2.d;
    }
}

