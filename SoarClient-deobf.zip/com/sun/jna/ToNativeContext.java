/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

public class ToNativeContext {
    ToNativeContext() {
        ToNativeContext a2;
    }
}

