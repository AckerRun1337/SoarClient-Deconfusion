/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

interface Version {
    public static final String v = "4.5.1";
    public static final String d = "5.2.0";
}

