/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import java.lang.reflect.Method;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
abstract class VarArgsChecker {
    private /* synthetic */ VarArgsChecker() {
        VarArgsChecker a2;
    }

    static VarArgsChecker a() {
        try {
            Method a2 = Method.class.getMethod("isVarArgs", new Class[0]);
            if (a2 != null) {
                return new RealVarArgsChecker();
            }
            return new NoVarArgsChecker();
        }
        catch (NoSuchMethodException a3) {
            return new NoVarArgsChecker();
        }
        catch (SecurityException a4) {
            return new NoVarArgsChecker();
        }
    }

    abstract boolean a(Method var1);

    abstract int a(Method var1);

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    private static final class NoVarArgsChecker
    extends VarArgsChecker {
        private /* synthetic */ NoVarArgsChecker() {
            NoVarArgsChecker a2;
        }

        @Override
        boolean a(Method a2) {
            return false;
        }

        @Override
        int a(Method a2) {
            return 0;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    private static final class RealVarArgsChecker
    extends VarArgsChecker {
        private /* synthetic */ RealVarArgsChecker() {
            RealVarArgsChecker a2;
        }

        @Override
        boolean a(Method a2) {
            return a2.isVarArgs();
        }

        @Override
        int a(Method a2) {
            return a2.isVarArgs() ? a2.getParameterTypes().length - 1 : 0;
        }
    }
}

