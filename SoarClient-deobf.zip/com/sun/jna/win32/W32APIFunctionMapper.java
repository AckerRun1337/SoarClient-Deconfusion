/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.win32;

import com.sun.jna.FunctionMapper;
import com.sun.jna.NativeLibrary;
import java.lang.reflect.Method;

public class W32APIFunctionMapper
implements FunctionMapper {
    public static final FunctionMapper c = new W32APIFunctionMapper(true);
    public static final FunctionMapper v = new W32APIFunctionMapper(false);
    private final String d;

    protected W32APIFunctionMapper(boolean a2) {
        W32APIFunctionMapper a3;
        a3.d = a2 ? "W" : "A";
    }

    @Override
    public String a(NativeLibrary a2, Method a3) {
        String a4 = a3.getName();
        if (!a4.endsWith("W") && !a4.endsWith("A")) {
            try {
                W32APIFunctionMapper a5;
                a4 = a2.a(a4 + a5.d, 63).a();
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError) {
                // empty catch block
            }
        }
        return a4;
    }
}

