/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback
extends Callback {
    public static final int d = 16;
}

