/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.win32;

import com.sun.jna.DefaultTypeMapper;
import com.sun.jna.FromNativeContext;
import com.sun.jna.StringArray;
import com.sun.jna.ToNativeContext;
import com.sun.jna.ToNativeConverter;
import com.sun.jna.TypeConverter;
import com.sun.jna.TypeMapper;
import com.sun.jna.WString;

public class W32APITypeMapper
extends DefaultTypeMapper {
    public static final TypeMapper c = new W32APITypeMapper(true);
    public static final TypeMapper v = new W32APITypeMapper(false);
    public static final TypeMapper d = Boolean.getBoolean("w32.ascii") ? v : c;

    protected W32APITypeMapper(boolean a2) {
        TypeConverter a3;
        W32APITypeMapper a4;
        if (a2) {
            a3 = new TypeConverter(){
                {
                    1 a3;
                }

                @Override
                public Object a(Object a2, ToNativeContext a3) {
                    if (a2 == null) {
                        return null;
                    }
                    if (a2 instanceof String[]) {
                        return new StringArray((String[])a2, true);
                    }
                    return new WString(a2.toString());
                }

                @Override
                public Object a(Object a2, FromNativeContext a3) {
                    if (a2 == null) {
                        return null;
                    }
                    return a2.toString();
                }

                @Override
                public Class<?> a() {
                    return WString.class;
                }
            };
            a4.a(String.class, a3);
            a4.a(String[].class, (ToNativeConverter)a3);
        }
        a3 = new TypeConverter(){
            {
                2 a3;
            }

            @Override
            public Object a(Object a2, ToNativeContext a3) {
                return Boolean.TRUE.equals(a2) ? 1 : 0;
            }

            @Override
            public Object a(Object a2, FromNativeContext a3) {
                return (Integer)a2 != 0 ? Boolean.TRUE : Boolean.FALSE;
            }

            @Override
            public Class<?> a() {
                return Integer.class;
            }
        };
        a4.a(Boolean.class, a3);
    }
}

