/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.win32;

import com.sun.jna.win32.StdCallLibrary;
import com.sun.jna.win32.W32APIFunctionMapper;
import com.sun.jna.win32.W32APITypeMapper;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public interface W32APIOptions
extends StdCallLibrary {
    public static final Map<String, Object> c = Collections.unmodifiableMap(new HashMap<String, Object>(){
        private static final long d = 1L;
        {
            1 a2;
            a2.put("type-mapper", W32APITypeMapper.c);
            a2.put("function-mapper", W32APIFunctionMapper.c);
        }
    });
    public static final Map<String, Object> v = Collections.unmodifiableMap(new HashMap<String, Object>(){
        private static final long d = 1L;
        {
            2 a2;
            a2.put("type-mapper", W32APITypeMapper.v);
            a2.put("function-mapper", W32APIFunctionMapper.v);
        }
    });
    public static final Map<String, Object> d = Boolean.getBoolean("w32.ascii") ? v : c;
}

