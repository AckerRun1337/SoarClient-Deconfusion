/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna.win32;

import com.sun.jna.Function;
import com.sun.jna.FunctionMapper;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.Pointer;
import java.lang.reflect.Method;

public class StdCallFunctionMapper
implements FunctionMapper {
    public StdCallFunctionMapper() {
        StdCallFunctionMapper a2;
    }

    protected int a(Class<?> a2) {
        if (NativeMapped.class.isAssignableFrom(a2)) {
            a2 = NativeMappedConverter.a(a2).a();
        }
        if (a2.isArray()) {
            return Pointer.c;
        }
        try {
            return Native.a(a2);
        }
        catch (IllegalArgumentException a3) {
            throw new IllegalArgumentException("Unknown native stack allocation size for " + a2);
        }
    }

    @Override
    public String a(NativeLibrary a2, Method a3) {
        Class<?>[] a4;
        String a5 = a3.getName();
        int a6 = 0;
        for (Class<?> clazz : a4 = a3.getParameterTypes()) {
            StdCallFunctionMapper a8;
            a6 += a8.a(clazz);
        }
        String a9 = a5 + "@" + a6;
        int a10 = 63;
        try {
            Function a11 = a2.a(a9, a10);
            a5 = a11.a();
        }
        catch (UnsatisfiedLinkError a12) {
            try {
                Function function = a2.a("_" + a9, a10);
                a5 = function.a();
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError) {
                // empty catch block
            }
        }
        return a5;
    }
}

