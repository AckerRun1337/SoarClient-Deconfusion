/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import com.sun.jna.NativeMapped;
import com.sun.jna.Pointer;
import com.sun.jna.ToNativeContext;
import com.sun.jna.TypeConverter;
import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.util.Map;
import java.util.WeakHashMap;

public class NativeMappedConverter
implements TypeConverter {
    private static final Map<Class<?>, Reference<NativeMappedConverter>> b = new WeakHashMap();
    private final Class<?> c;
    private final Class<?> v;
    private final NativeMapped d;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static NativeMappedConverter a(Class<?> a2) {
        Map<Class<?>, Reference<NativeMappedConverter>> map = b;
        synchronized (map) {
            NativeMappedConverter a3;
            Reference<NativeMappedConverter> a4 = b.get(a2);
            NativeMappedConverter nativeMappedConverter = a3 = a4 != null ? a4.get() : null;
            if (a3 == null) {
                a3 = new NativeMappedConverter(a2);
                b.put(a2, new SoftReference<NativeMappedConverter>(a3));
            }
            return a3;
        }
    }

    public NativeMappedConverter(Class<?> a2) {
        NativeMappedConverter a3;
        if (!NativeMapped.class.isAssignableFrom(a2)) {
            throw new IllegalArgumentException("Type must derive from " + NativeMapped.class);
        }
        a3.c = a2;
        a3.d = a3.a();
        a3.v = a3.d.a();
    }

    public NativeMapped a() {
        NativeMappedConverter a2;
        try {
            return (NativeMapped)a2.c.newInstance();
        }
        catch (InstantiationException a3) {
            String a4 = "Can't create an instance of " + a2.c + ", requires a no-arg constructor: " + a3;
            throw new IllegalArgumentException(a4);
        }
        catch (IllegalAccessException a5) {
            String a6 = "Not allowed to create an instance of " + a2.c + ", requires a public, no-arg constructor: " + a5;
            throw new IllegalArgumentException(a6);
        }
    }

    @Override
    public Object a(Object a2, FromNativeContext a3) {
        NativeMappedConverter a4;
        return a4.d.a(a2, a3);
    }

    @Override
    public Class<?> a() {
        NativeMappedConverter a2;
        return a2.v;
    }

    @Override
    public Object a(Object a2, ToNativeContext a3) {
        if (a2 == null) {
            NativeMappedConverter a4;
            if (Pointer.class.isAssignableFrom(a4.v)) {
                return null;
            }
            a2 = a4.a();
        }
        return ((NativeMapped)a2).a();
    }
}

