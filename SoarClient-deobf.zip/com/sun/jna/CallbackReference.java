/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.AltCallingConvention;
import com.sun.jna.Callback;
import com.sun.jna.CallbackParameterContext;
import com.sun.jna.CallbackProxy;
import com.sun.jna.CallbackResultContext;
import com.sun.jna.CallbackThreadInitializer;
import com.sun.jna.FromNativeConverter;
import com.sun.jna.Function;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.NativeString;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.StringArray;
import com.sun.jna.Structure;
import com.sun.jna.ToNativeConverter;
import com.sun.jna.TypeMapper;
import com.sun.jna.WString;
import com.sun.jna.win32.DLLCallback;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CallbackReference
extends WeakReference<Callback> {
    static final Map<Callback, CallbackReference> i = new WeakHashMap<Callback, CallbackReference>();
    static final Map<Callback, CallbackReference> n = new WeakHashMap<Callback, CallbackReference>();
    static final Map<Pointer, Reference<Callback>> e = new WeakHashMap<Pointer, Reference<Callback>>();
    static final Map<Object, Object> r = new WeakHashMap<Object, Object>();
    private static final Map<CallbackReference, Reference<CallbackReference>> f = Collections.synchronizedMap(new WeakHashMap());
    private static final Method h;
    private static final Map<Callback, CallbackThreadInitializer> z;
    Pointer l;
    Pointer b;
    CallbackProxy c;
    Method v;
    int d;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static CallbackThreadInitializer a(Callback a2, CallbackThreadInitializer a3) {
        Map<Callback, CallbackThreadInitializer> map = z;
        synchronized (map) {
            if (a3 != null) {
                return z.put(a2, a3);
            }
            return z.remove(a2);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ ThreadGroup a(Callback a2, AttachOptions a3) {
        CallbackThreadInitializer a4 = null;
        if (a2 instanceof DefaultCallbackProxy) {
            a2 = ((DefaultCallbackProxy)a2).a();
        }
        Map<Callback, CallbackThreadInitializer> map = z;
        synchronized (map) {
            a4 = z.get(a2);
        }
        ThreadGroup a5 = null;
        if (a4 != null) {
            a5 = a4.a(a2);
            a3.d = a4.a(a2);
            a3.c = a4.p(a2);
            a3.v = a4.a(a2);
            a3.z();
        }
        return a5;
    }

    public static Callback a(Class<?> a2, Pointer a3) {
        return CallbackReference.a(a2, a3, false);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ Callback a(Class<?> a2, Pointer a3, boolean a4) {
        if (a3 == null) {
            return null;
        }
        if (!a2.isInterface()) {
            throw new IllegalArgumentException("Callback type must be an interface");
        }
        Map<Callback, CallbackReference> a5 = a4 ? n : i;
        Map<Pointer, Reference<Callback>> map = e;
        synchronized (map) {
            Callback a6 = null;
            Reference<Callback> a7 = e.get(a3);
            if (a7 != null) {
                a6 = a7.get();
                if (a6 != null && !a2.isAssignableFrom(a6.getClass())) {
                    throw new IllegalStateException("Pointer " + a3 + " already mapped to " + a6 + ".\nNative code may be re-using a default function pointer, in which case you may need to use a common Callback class wherever the function pointer is reused.");
                }
                return a6;
            }
            int a8 = AltCallingConvention.class.isAssignableFrom(a2) ? 63 : 0;
            HashMap<String, Object> a9 = new HashMap<String, Object>(Native.a(a2));
            a9.put("invoking-method", CallbackReference.a(a2));
            NativeFunctionHandler a10 = new NativeFunctionHandler(a3, a8, a9);
            a6 = (Callback)Proxy.newProxyInstance(a2.getClassLoader(), new Class[]{a2}, (InvocationHandler)a10);
            a5.remove(a6);
            e.put(a3, new WeakReference<Callback>(a6));
            return a6;
        }
    }

    private /* synthetic */ CallbackReference(Callback a2, int a3, boolean a4) {
        super(a2);
        Object a5;
        CallbackReference a6;
        TypeMapper a7 = Native.a(a2.getClass());
        a6.d = a3;
        boolean a8 = Platform.z();
        if (a4) {
            a5 = CallbackReference.a(CallbackReference.a(a2.getClass()));
            Class<?>[] a9 = ((Method)a5).getParameterTypes();
            for (int a10 = 0; a10 < a9.length; ++a10) {
                if (a8 && (a9[a10] == Float.TYPE || a9[a10] == Double.TYPE)) {
                    a4 = false;
                    break;
                }
                if (a7 == null || a7.a(a9[a10]) == null) continue;
                a4 = false;
                break;
            }
            if (a7 != null && a7.a(((Method)a5).getReturnType()) != null) {
                a4 = false;
            }
        }
        a5 = Native.p(a2.getClass());
        long a11 = 0L;
        if (a4) {
            a6.v = CallbackReference.a(CallbackReference.a(a2.getClass()));
            Class<?>[] a12 = a6.v.getParameterTypes();
            Class<?> a13 = a6.v.getReturnType();
            int a14 = 1;
            if (a2 instanceof DLLCallback) {
                a14 |= 2;
            }
            a11 = Native.createNativeCallback(a2, a6.v, a12, a13, a3, a14, (String)a5);
        } else {
            int a15;
            Object a16;
            a6.c = a2 instanceof CallbackProxy ? (CallbackProxy)a2 : a6.new DefaultCallbackProxy(CallbackReference.a(CallbackReference.a(a2.getClass())), a7, (String)a5);
            Class<?>[] a17 = a6.c.a();
            Class<?> a18 = a6.c.a();
            if (a7 != null) {
                for (int a19 = 0; a19 < a17.length; ++a19) {
                    a16 = a7.a(a17[a19]);
                    if (a16 == null) continue;
                    a17[a19] = a16.a();
                }
                ToNativeConverter a20 = a7.a(a18);
                if (a20 != null) {
                    a18 = a20.a();
                }
            }
            for (a15 = 0; a15 < a17.length; ++a15) {
                a17[a15] = a6.p(a17[a15]);
                if (CallbackReference.a(a17[a15])) continue;
                a16 = "Callback argument " + a17[a15] + " requires custom type conversion";
                throw new IllegalArgumentException((String)a16);
            }
            if (!CallbackReference.a(a18 = a6.p(a18))) {
                String a21 = "Callback return type " + a18 + " requires custom type conversion";
                throw new IllegalArgumentException(a21);
            }
            a15 = a2 instanceof DLLCallback ? 2 : 0;
            a11 = Native.createNativeCallback(a6.c, h, a17, a18, a3, a15, (String)a5);
        }
        a6.l = a11 != 0L ? new Pointer(a11) : null;
        f.put(a6, new WeakReference<CallbackReference>(a6));
    }

    private /* synthetic */ Class<?> p(Class<?> a2) {
        if (Structure.class.isAssignableFrom(a2)) {
            Structure.a(a2);
            if (!Structure.ByValue.class.isAssignableFrom(a2)) {
                return Pointer.class;
            }
        } else {
            if (NativeMapped.class.isAssignableFrom(a2)) {
                return NativeMappedConverter.a(a2).a();
            }
            if (a2 == String.class || a2 == WString.class || a2 == String[].class || a2 == WString[].class || Callback.class.isAssignableFrom(a2)) {
                return Pointer.class;
            }
        }
        return a2;
    }

    private static /* synthetic */ Method a(Method a2) {
        if (a2.getParameterTypes().length > 256) {
            String a3 = "Method signature exceeds the maximum parameter count: " + a2;
            throw new UnsupportedOperationException(a3);
        }
        return a2;
    }

    static Class<?> a(Class<?> a2) {
        if (!Callback.class.isAssignableFrom(a2)) {
            throw new IllegalArgumentException(a2.getName() + " is not derived from com.sun.jna.Callback");
        }
        if (a2.isInterface()) {
            return a2;
        }
        Class<?>[] a3 = a2.getInterfaces();
        for (int a4 = 0; a4 < a3.length; ++a4) {
            if (!Callback.class.isAssignableFrom(a3[a4])) continue;
            try {
                CallbackReference.a(a3[a4]);
                return a3[a4];
            }
            catch (IllegalArgumentException a5) {
                break;
            }
        }
        if (Callback.class.isAssignableFrom(a2.getSuperclass())) {
            return CallbackReference.a(a2.getSuperclass());
        }
        return a2;
    }

    private static /* synthetic */ Method a(Class<?> a2) {
        Method[] a3 = a2.getDeclaredMethods();
        Method[] a4 = a2.getMethods();
        HashSet<Method> a5 = new HashSet<Method>(Arrays.asList(a3));
        a5.retainAll(Arrays.asList(a4));
        Method[] a6 = a5.iterator();
        while (a6.hasNext()) {
            Method a7 = (Method)a6.next();
            if (!Callback.d.contains(a7.getName())) continue;
            a6.remove();
        }
        a6 = a5.toArray(new Method[a5.size()]);
        if (a6.length == 1) {
            return CallbackReference.a(a6[0]);
        }
        for (int a8 = 0; a8 < a6.length; ++a8) {
            Method a9 = a6[a8];
            if (!"callback".equals(a9.getName())) continue;
            return CallbackReference.a(a9);
        }
        String a10 = "Callback must implement a single public method, or one public method named 'callback'";
        throw new IllegalArgumentException(a10);
    }

    private /* synthetic */ void a(int a2) {
        CallbackReference a3;
        a3.l.a((long)Pointer.c, a2);
    }

    public Pointer a() {
        CallbackReference a2;
        if (a2.b == null) {
            a2.b = a2.l.a(0L);
        }
        return a2.b;
    }

    protected void finalize() {
        CallbackReference a2;
        a2.p();
    }

    protected synchronized void p() {
        CallbackReference a2;
        if (a2.l != null) {
            try {
                Native.freeNativeCallback(a2.l.d);
            }
            finally {
                a2.l.d = 0L;
                a2.l = null;
                f.remove(a2);
            }
        }
    }

    static void a() {
        LinkedList<CallbackReference> a2 = new LinkedList<CallbackReference>(f.keySet());
        for (CallbackReference a3 : a2) {
            a3.p();
        }
    }

    private /* synthetic */ Callback a() {
        CallbackReference a2;
        return (Callback)a2.get();
    }

    private static /* synthetic */ Pointer p(Callback a2) {
        InvocationHandler a3;
        if (Proxy.isProxyClass(a2.getClass()) && (a3 = Proxy.getInvocationHandler(a2)) instanceof NativeFunctionHandler) {
            return ((NativeFunctionHandler)a3).a();
        }
        return null;
    }

    public static Pointer a(Callback a2) {
        return CallbackReference.a(a2, false);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static /* synthetic */ Pointer a(Callback a2, boolean a3) {
        Pointer a4 = null;
        if (a2 == null) {
            return null;
        }
        a4 = CallbackReference.p(a2);
        if (a4 != null) {
            return a4;
        }
        Map<String, Object> a5 = Native.a(a2.getClass());
        int a6 = a2 instanceof AltCallingConvention ? 63 : (a5 != null && a5.containsKey("calling-convention") ? (Integer)a5.get("calling-convention") : 0);
        Map<Callback, CallbackReference> a7 = a3 ? n : i;
        Map<Pointer, Reference<Callback>> map = e;
        synchronized (map) {
            CallbackReference a8 = a7.get(a2);
            if (a8 == null) {
                a8 = new CallbackReference(a2, a6, a3);
                a7.put(a2, a8);
                e.put(a8.a(), new WeakReference<Callback>(a2));
                if (z.containsKey(a2)) {
                    a8.a(1);
                }
            }
            return a8.a();
        }
    }

    private static /* synthetic */ boolean a(Class<?> a2) {
        return a2 == Void.TYPE || a2 == Void.class || a2 == Boolean.TYPE || a2 == Boolean.class || a2 == Byte.TYPE || a2 == Byte.class || a2 == Short.TYPE || a2 == Short.class || a2 == Character.TYPE || a2 == Character.class || a2 == Integer.TYPE || a2 == Integer.class || a2 == Long.TYPE || a2 == Long.class || a2 == Float.TYPE || a2 == Float.class || a2 == Double.TYPE || a2 == Double.class || Structure.ByValue.class.isAssignableFrom(a2) && Structure.class.isAssignableFrom(a2) || Pointer.class.isAssignableFrom(a2);
    }

    private static /* synthetic */ Pointer p(Object a2, boolean a3) {
        if (a2 != null) {
            NativeString a4 = new NativeString(a2.toString(), a3);
            r.put(a2, a4);
            return a4.a();
        }
        return null;
    }

    static {
        try {
            h = CallbackProxy.class.getMethod("callback", Object[].class);
        }
        catch (Exception a2) {
            throw new Error("Error looking up CallbackProxy.callback() method");
        }
        z = new WeakHashMap<Callback, CallbackThreadInitializer>();
    }

    private static class NativeFunctionHandler
    implements InvocationHandler {
        private final Function v;
        private final Map<String, ?> d;

        public NativeFunctionHandler(Pointer a2, int a3, Map<String, ?> a4) {
            NativeFunctionHandler a5;
            a5.d = a4;
            a5.v = new Function(a2, a3, (String)a4.get("string-encoding"));
        }

        @Override
        public Object invoke(Object a2, Method a3, Object[] a4) throws Throwable {
            NativeFunctionHandler a5;
            if (Library.Handler.f.equals(a3)) {
                String a6 = "Proxy interface to " + a5.v;
                Method a7 = (Method)a5.d.get("invoking-method");
                Class<?> a8 = CallbackReference.a(a7.getDeclaringClass());
                a6 = a6 + " (" + a8.getName() + ")";
                return a6;
            }
            if (Library.Handler.h.equals(a3)) {
                return a5.hashCode();
            }
            if (Library.Handler.z.equals(a3)) {
                Object a9 = a4[0];
                if (a9 != null && Proxy.isProxyClass(a9.getClass())) {
                    return Function.a(Proxy.getInvocationHandler(a9) == a5);
                }
                return Boolean.FALSE;
            }
            if (Function.a(a3)) {
                a4 = Function.a(a4);
            }
            return a5.v.a(a3.getReturnType(), a4, a5.d);
        }

        public Pointer a() {
            NativeFunctionHandler a2;
            return a2.v;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    private class DefaultCallbackProxy
    implements CallbackProxy {
        private final Method z;
        private ToNativeConverter l;
        private final FromNativeConverter[] b;
        private final String c;

        public DefaultCallbackProxy(Method a2, TypeMapper a3, String a4) {
            DefaultCallbackProxy a5;
            a5.z = a2;
            a5.c = a4;
            Class<?>[] a6 = a2.getParameterTypes();
            Class<?> a7 = a2.getReturnType();
            a5.b = new FromNativeConverter[a6.length];
            if (NativeMapped.class.isAssignableFrom(a7)) {
                a5.l = NativeMappedConverter.a(a7);
            } else if (a3 != null) {
                a5.l = a3.a(a7);
            }
            for (int a8 = 0; a8 < a5.b.length; ++a8) {
                if (NativeMapped.class.isAssignableFrom(a6[a8])) {
                    a5.b[a8] = new NativeMappedConverter(a6[a8]);
                    continue;
                }
                if (a3 == null) continue;
                a5.b[a8] = a3.a(a6[a8]);
            }
            if (!a2.isAccessible()) {
                try {
                    a2.setAccessible(true);
                }
                catch (SecurityException a9) {
                    throw new IllegalArgumentException("Callback method is inaccessible, make sure the interface is public: " + a2);
                }
            }
        }

        public Callback a() {
            DefaultCallbackProxy a2;
            return a2.CallbackReference.this.a();
        }

        private /* synthetic */ Object p(Object[] a2) {
            Object a3;
            DefaultCallbackProxy a4;
            Class<?>[] a5 = a4.z.getParameterTypes();
            Object[] a6 = new Object[a2.length];
            for (int a7 = 0; a7 < a2.length; ++a7) {
                a3 = a5[a7];
                Object a8 = a2[a7];
                if (a4.b[a7] != null) {
                    CallbackParameterContext a9 = new CallbackParameterContext((Class<?>)a3, a4.z, a2, a7);
                    a6[a7] = a4.b[a7].a(a8, a9);
                    continue;
                }
                a6[a7] = a4.a(a8, (Class<?>)a3);
            }
            Object a10 = null;
            a3 = a4.a();
            if (a3 != null) {
                try {
                    a10 = a4.a(a4.z.invoke(a3, a6));
                }
                catch (IllegalArgumentException a11) {
                    Native.a().a((Callback)a3, a11);
                }
                catch (IllegalAccessException a12) {
                    Native.a().a((Callback)a3, a12);
                }
                catch (InvocationTargetException a13) {
                    Native.a().a((Callback)a3, a13.getTargetException());
                }
            }
            for (int a14 = 0; a14 < a6.length; ++a14) {
                if (!(a6[a14] instanceof Structure) || a6[a14] instanceof Structure.ByValue) continue;
                ((Structure)a6[a14]).a();
            }
            return a10;
        }

        @Override
        public Object a(Object[] a2) {
            DefaultCallbackProxy a3;
            try {
                return a3.p(a2);
            }
            catch (Throwable a4) {
                Native.a().a(a3.a(), a4);
                return null;
            }
        }

        private /* synthetic */ Object a(Object a2, Class<?> a3) {
            if (a2 instanceof Pointer) {
                DefaultCallbackProxy a4;
                if (a3 == String.class) {
                    a2 = ((Pointer)a2).a(0L, a4.c);
                } else if (a3 == WString.class) {
                    a2 = new WString(((Pointer)a2).p(0L));
                } else if (a3 == String[].class) {
                    a2 = ((Pointer)a2).a(0L, a4.c);
                } else if (a3 == WString[].class) {
                    a2 = ((Pointer)a2).a(0L);
                } else if (Callback.class.isAssignableFrom(a3)) {
                    a2 = CallbackReference.a(a3, (Pointer)a2);
                } else if (Structure.class.isAssignableFrom(a3)) {
                    if (Structure.ByValue.class.isAssignableFrom(a3)) {
                        Structure a5 = Structure.a(a3);
                        byte[] a6 = new byte[a5.p()];
                        ((Pointer)a2).p(0L, a6, 0, a6.length);
                        a5.o().a(0L, a6, 0, a6.length);
                        a5.j();
                        a2 = a5;
                    } else {
                        Structure a7 = Structure.a(a3, (Pointer)a2);
                        a7.x();
                        a2 = a7;
                    }
                }
            } else if ((Boolean.TYPE == a3 || Boolean.class == a3) && a2 instanceof Number) {
                a2 = Function.a(((Number)a2).intValue() != 0);
            }
            return a2;
        }

        private /* synthetic */ Object a(Object a2) {
            DefaultCallbackProxy a3;
            if (a3.l != null) {
                a2 = a3.l.a(a2, new CallbackResultContext(a3.z));
            }
            if (a2 == null) {
                return null;
            }
            Class<?> a4 = a2.getClass();
            if (Structure.class.isAssignableFrom(a4)) {
                if (Structure.ByValue.class.isAssignableFrom(a4)) {
                    return a2;
                }
                return ((Structure)a2).o();
            }
            if (a4 == Boolean.TYPE || a4 == Boolean.class) {
                return Boolean.TRUE.equals(a2) ? Function.r : Function.f;
            }
            if (a4 == String.class || a4 == WString.class) {
                return CallbackReference.p(a2, a4 == WString.class);
            }
            if (a4 == String[].class || a4 == WString.class) {
                StringArray a5 = a4 == String[].class ? new StringArray((String[])a2, a3.c) : new StringArray((WString[])a2);
                r.put(a2, a5);
                return a5;
            }
            if (Callback.class.isAssignableFrom(a4)) {
                return CallbackReference.a((Callback)a2);
            }
            return a2;
        }

        @Override
        public Class<?>[] a() {
            DefaultCallbackProxy a2;
            return a2.z.getParameterTypes();
        }

        @Override
        public Class<?> a() {
            DefaultCallbackProxy a2;
            return a2.z.getReturnType();
        }
    }

    static class AttachOptions
    extends Structure {
        public static final List<String> b = AttachOptions.a("daemon", "detach", "name");
        public boolean c;
        public boolean v;
        public String d;

        AttachOptions() {
            AttachOptions a2;
            a2.p("utf8");
        }

        @Override
        protected List<String> o() {
            return b;
        }
    }
}

