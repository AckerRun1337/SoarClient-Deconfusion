/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.WeakMemoryHolder;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;
import java.util.WeakHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Memory
extends Pointer {
    private static final Map<Memory, Reference<Memory>> b = Collections.synchronizedMap(new WeakHashMap());
    private static final WeakMemoryHolder c = new WeakMemoryHolder();
    protected long v;

    public static void z() {
        c.a();
    }

    public static void y() {
        LinkedList<Memory> a2 = new LinkedList<Memory>(b.keySet());
        for (Memory a3 : a2) {
            a3.o();
        }
    }

    public Memory(long a2) {
        Memory a3;
        a3.v = a2;
        if (a2 <= 0L) {
            throw new IllegalArgumentException("Allocation size must be greater than zero");
        }
        a3.d = Memory.p(a2);
        if (a3.d == 0L) {
            throw new OutOfMemoryError("Cannot allocate " + a2 + " bytes");
        }
        b.put(a3, new WeakReference<Memory>(a3));
    }

    protected Memory() {
        Memory a2;
    }

    @Override
    public Pointer p(long a2) {
        Memory a3;
        return a3.a(a2, a3.a() - a2);
    }

    @Override
    public Pointer a(long a2, long a3) {
        Memory a4;
        a4.p(a2, a3);
        return a4.new SharedMemory(a2, a3);
    }

    @Override
    public Memory a(int a2) {
        if (a2 <= 0) {
            throw new IllegalArgumentException("Byte boundary must be positive: " + a2);
        }
        for (int a3 = 0; a3 < 32; ++a3) {
            Memory a4;
            if (a2 != 1 << a3) continue;
            long a5 = (long)a2 - 1L ^ 0xFFFFFFFFFFFFFFFFL;
            if ((a4.d & a5) != a4.d) {
                long a6 = a4.d + (long)a2 - 1L & a5;
                long a7 = a4.d + a4.v - a6;
                if (a7 <= 0L) {
                    throw new IllegalArgumentException("Insufficient memory to align to the requested boundary");
                }
                return (Memory)a4.a(a6 - a4.d, a7);
            }
            return a4;
        }
        throw new IllegalArgumentException("Byte boundary must be a power of two");
    }

    protected void finalize() {
        Memory a2;
        a2.o();
    }

    protected synchronized void o() {
        Memory a2;
        try {
            Memory.p(a2.d);
        }
        finally {
            b.remove(a2);
            a2.d = 0L;
        }
    }

    public void p() {
        Memory a2;
        a2.a(a2.v);
    }

    public boolean a() {
        Memory a2;
        return a2.d != 0L;
    }

    public long a() {
        Memory a2;
        return a2.v;
    }

    protected void p(long a2, long a3) {
        Memory a4;
        if (a2 < 0L) {
            throw new IndexOutOfBoundsException("Invalid offset: " + a2);
        }
        if (a2 + a3 > a4.v) {
            String a5 = "Bounds exceeds available space : size=" + a4.v + ", offset=" + (a2 + a3);
            throw new IndexOutOfBoundsException(a5);
        }
    }

    @Override
    public void p(long a2, byte[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 1L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, short[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 2L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, char[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 2L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, int[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 4L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, long[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 8L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, float[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 4L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void p(long a2, double[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 8L);
        super.p(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, byte[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 1L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, short[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 2L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, char[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 2L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, int[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 4L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, long[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 8L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, float[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 4L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public void a(long a2, double[] a3, int a4, int a5) {
        Memory a6;
        a6.p(a2, (long)a5 * 8L);
        super.a(a2, a3, a4, a5);
    }

    @Override
    public byte a(long a2) {
        Memory a3;
        a3.p(a2, 1L);
        return super.a(a2);
    }

    @Override
    public char a(long a2) {
        Memory a3;
        a3.p(a2, 1L);
        return super.a(a2);
    }

    @Override
    public short a(long a2) {
        Memory a3;
        a3.p(a2, 2L);
        return super.a(a2);
    }

    @Override
    public int a(long a2) {
        Memory a3;
        a3.p(a2, 4L);
        return super.a(a2);
    }

    @Override
    public long a(long a2) {
        Memory a3;
        a3.p(a2, 8L);
        return super.a(a2);
    }

    @Override
    public float a(long a2) {
        Memory a3;
        a3.p(a2, 4L);
        return super.a(a2);
    }

    @Override
    public double a(long a2) {
        Memory a3;
        a3.p(a2, 8L);
        return super.a(a2);
    }

    @Override
    public Pointer a(long a2) {
        Memory a3;
        a3.p(a2, (long)Pointer.c);
        return super.a(a2);
    }

    @Override
    public ByteBuffer a(long a2, long a3) {
        Memory a4;
        a4.p(a2, a3);
        ByteBuffer a5 = super.a(a2, a3);
        c.a(a5, a4);
        return a5;
    }

    @Override
    public String a(long a2, String a3) {
        Memory a4;
        a4.p(a2, 0L);
        return super.a(a2, a3);
    }

    @Override
    public String p(long a2) {
        Memory a3;
        a3.p(a2, 0L);
        return super.p(a2);
    }

    @Override
    public void a(long a2, byte a3) {
        Memory a4;
        a4.p(a2, 1L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, char a3) {
        Memory a4;
        a4.p(a2, (long)Native.wa);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, short a3) {
        Memory a4;
        a4.p(a2, 2L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, int a3) {
        Memory a4;
        a4.p(a2, 4L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, long a3) {
        Memory a4;
        a4.p(a2, 8L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, float a3) {
        Memory a4;
        a4.p(a2, 4L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, double a3) {
        Memory a4;
        a4.p(a2, 8L);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, Pointer a3) {
        Memory a4;
        a4.p(a2, (long)Pointer.c);
        super.a(a2, a3);
    }

    @Override
    public void a(long a2, String a3, String a4) {
        Memory a5;
        a5.p(a2, (long)Native.p(a3, a4).length + 1L);
        super.a(a2, a3, a4);
    }

    @Override
    public void p(long a2, String a3) {
        Memory a4;
        a4.p(a2, ((long)a3.length() + 1L) * (long)Native.wa);
        super.p(a2, a3);
    }

    @Override
    public String toString() {
        Memory a2;
        return "allocated@0x" + Long.toHexString(a2.d) + " (" + a2.v + " bytes)";
    }

    protected static void p(long a2) {
        if (a2 != 0L) {
            Native.free(a2);
        }
    }

    protected static long p(long a2) {
        return Native.malloc(a2);
    }

    public String a() {
        Memory a2;
        return a2.a(0L, (int)a2.a());
    }

    private class SharedMemory
    extends Memory {
        public SharedMemory(long a2, long a3) {
            SharedMemory a4;
            a4.v = a3;
            a4.Memory.this = (Memory)(a4.Memory.this.d + a2);
        }

        @Override
        protected void o() {
            a.Memory.this = (Memory)0L;
        }

        @Override
        protected void p(long a2, long a3) {
            SharedMemory a4;
            a4.Memory.this.p((long)(a4.Memory.this - a4.Memory.this.d + a2), a3);
        }

        @Override
        public String toString() {
            SharedMemory a2;
            return super.toString() + " (shared from " + a2.Memory.this.toString() + ")";
        }
    }
}

