/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.AltCallingConvention;
import com.sun.jna.Function;
import com.sun.jna.InvocationMapper;
import com.sun.jna.NativeLibrary;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

public interface Library {
    public static final String r = "type-mapper";
    public static final String f = "function-mapper";
    public static final String h = "invocation-mapper";
    public static final String z = "structure-alignment";
    public static final String l = "string-encoding";
    public static final String b = "allow-objects";
    public static final String c = "calling-convention";
    public static final String v = "open-flags";
    public static final String d = "classloader";

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class Handler
    implements InvocationHandler {
        static final Method f;
        static final Method h;
        static final Method z;
        private final NativeLibrary l;
        private final Class<?> b;
        private final Map<String, Object> c;
        private final InvocationMapper v;
        private final Map<Method, FunctionInfo> d = new WeakHashMap<Method, FunctionInfo>();

        public Handler(String a2, Class<?> a3, Map<String, ?> a4) {
            int a5;
            Handler a6;
            if (a2 != null && "".equals(a2.trim())) {
                throw new IllegalArgumentException("Invalid library name \"" + a2 + "\"");
            }
            if (!a3.isInterface()) {
                throw new IllegalArgumentException(a2 + " does not implement an interface: " + a3.getName());
            }
            a6.b = a3;
            a6.c = new HashMap(a4);
            int n2 = a5 = AltCallingConvention.class.isAssignableFrom(a3) ? 63 : 0;
            if (a6.c.get(Library.c) == null) {
                a6.c.put(Library.c, a5);
            }
            if (a6.c.get(Library.d) == null) {
                a6.c.put(Library.d, a3.getClassLoader());
            }
            a6.l = NativeLibrary.a(a2, a6.c);
            a6.v = (InvocationMapper)a6.c.get(Library.h);
        }

        public NativeLibrary a() {
            Handler a2;
            return a2.l;
        }

        public String a() {
            Handler a2;
            return a2.l.p();
        }

        public Class<?> a() {
            Handler a2;
            return a2.b;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        @Override
        public Object invoke(Object a2, Method a3, Object[] a4) throws Throwable {
            Handler a5;
            if (f.equals(a3)) {
                return "Proxy interface to " + a5.l;
            }
            if (h.equals(a3)) {
                return a5.hashCode();
            }
            if (z.equals(a3)) {
                Object a6 = a4[0];
                if (a6 != null && Proxy.isProxyClass(a6.getClass())) {
                    return Function.a(Proxy.getInvocationHandler(a6) == a5);
                }
                return Boolean.FALSE;
            }
            FunctionInfo a7 = a5.d.get(a3);
            if (a7 == null) {
                Map<Method, FunctionInfo> map = a5.d;
                synchronized (map) {
                    a7 = a5.d.get(a3);
                    if (a7 == null) {
                        boolean a8 = Function.a(a3);
                        InvocationHandler a9 = null;
                        if (a5.v != null) {
                            a9 = a5.v.a(a5.l, a3);
                        }
                        Function a10 = null;
                        Class<?>[] a11 = null;
                        HashMap<String, Object> a12 = null;
                        if (a9 == null) {
                            a10 = a5.l.a(a3.getName(), a3);
                            a11 = a3.getParameterTypes();
                            a12 = new HashMap<String, Object>(a5.c);
                            a12.put("invoking-method", a3);
                        }
                        a7 = new FunctionInfo(a9, a10, a11, a8, a12);
                        a5.d.put(a3, a7);
                    }
                }
            }
            if (a7.c) {
                a4 = Function.a(a4);
            }
            if (a7.l != null) {
                return a7.l.invoke(a2, a3, a4);
            }
            return a7.b.a(a3, a7.d, a3.getReturnType(), a4, a7.v);
        }

        static {
            try {
                f = Object.class.getMethod("toString", new Class[0]);
                h = Object.class.getMethod("hashCode", new Class[0]);
                z = Object.class.getMethod("equals", Object.class);
            }
            catch (Exception a2) {
                throw new Error("Error retrieving Object.toString() method");
            }
        }

        private static final class FunctionInfo {
            final InvocationHandler l;
            final Function b;
            final boolean c;
            final Map<String, ?> v;
            final Class<?>[] d;

            FunctionInfo(InvocationHandler a2, Function a3, Class<?>[] a4, boolean a5, Map<String, ?> a6) {
                FunctionInfo a7;
                a7.l = a2;
                a7.b = a3;
                a7.c = a5;
                a7.v = a6;
                a7.d = a4;
            }
        }
    }
}

