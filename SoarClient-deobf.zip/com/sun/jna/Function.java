/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;
import com.sun.jna.CallbackReference;
import com.sun.jna.FunctionParameterContext;
import com.sun.jna.FunctionResultContext;
import com.sun.jna.Memory;
import com.sun.jna.MethodParameterContext;
import com.sun.jna.MethodResultContext;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.NativeString;
import com.sun.jna.Pointer;
import com.sun.jna.StringArray;
import com.sun.jna.Structure;
import com.sun.jna.ToNativeContext;
import com.sun.jna.TypeMapper;
import com.sun.jna.VarArgsChecker;
import com.sun.jna.WString;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Function
extends Pointer {
    public static final int p = 256;
    public static final int s = 0;
    public static final int w = 63;
    private static final int i = 63;
    public static final int n = 64;
    public static final int e = 384;
    static final Integer r = -1;
    static final Integer f = 0;
    private NativeLibrary h;
    private final String z;
    final String l;
    final int b;
    final Map<String, ?> c;
    static final String v = "invoking-method";
    private static final VarArgsChecker d = VarArgsChecker.a();

    public static Function a(String a2, String a3) {
        return NativeLibrary.a(a2).a(a3);
    }

    public static Function a(String a2, String a3, int a4) {
        return NativeLibrary.a(a2).a(a3, a4, null);
    }

    public static Function a(String a2, String a3, int a4, String a5) {
        return NativeLibrary.a(a2).a(a3, a4, a5);
    }

    public static Function a(Pointer a2) {
        return Function.a(a2, 0, null);
    }

    public static Function a(Pointer a2, int a3) {
        return Function.a(a2, a3, null);
    }

    public static Function a(Pointer a2, int a3, String a4) {
        return new Function(a2, a3, a4);
    }

    Function(NativeLibrary a2, String a3, int a4, String a5) {
        Function a6;
        a6.a(a4 & 0x3F);
        if (a3 == null) {
            throw new NullPointerException("Function name must not be null");
        }
        a6.h = a2;
        a6.z = a3;
        a6.b = a4;
        a6.c = a2.l;
        a6.l = a5 != null ? a5 : Native.a();
        try {
            a6.d = (VarArgsChecker)a2.a(a3);
        }
        catch (UnsatisfiedLinkError a7) {
            throw new UnsatisfiedLinkError("Error looking up function '" + a3 + "': " + a7.getMessage());
        }
    }

    Function(Pointer a2, int a3, String a4) {
        Function a5;
        a5.a(a3 & 0x3F);
        if (a2 == null || a2.d == 0L) {
            throw new NullPointerException("Function address may not be null");
        }
        a5.z = a2.toString();
        a5.b = a3;
        a5.d = (VarArgsChecker)a2.d;
        a5.c = Collections.EMPTY_MAP;
        a5.l = a4 != null ? a4 : Native.a();
    }

    private /* synthetic */ void a(int a2) throws IllegalArgumentException {
        if ((a2 & 0x3F) != a2) {
            throw new IllegalArgumentException("Unrecognized calling convention: " + a2);
        }
    }

    public String a() {
        Function a2;
        return a2.z;
    }

    public int a() {
        Function a2;
        return a2.b & 0x3F;
    }

    public Object a(Class<?> a2, Object[] a3) {
        Function a4;
        return a4.a(a2, a3, a4.c);
    }

    public Object a(Class<?> a2, Object[] a3, Map<String, ?> a4) {
        Function a5;
        Method a6 = (Method)a4.get(v);
        Class<?>[] a7 = a6 != null ? a6.getParameterTypes() : null;
        return a5.a(a6, a7, a2, a3, a4);
    }

    Object a(Method a2, Class<?>[] a3, Class<?> a4, Object[] a5, Map<String, ?> a6) {
        Object a7;
        Function a8;
        Object a9;
        Object[] a10 = new Object[]{};
        if (a5 != null) {
            if (a5.length > 256) {
                throw new UnsupportedOperationException("Maximum argument count is 256");
            }
            a10 = new Object[a5.length];
            System.arraycopy(a5, 0, a10, 0, a10.length);
        }
        TypeMapper a11 = (TypeMapper)a6.get("type-mapper");
        boolean a12 = Boolean.TRUE.equals(a6.get("allow-objects"));
        boolean a13 = a10.length > 0 && a2 != null ? Function.a(a2) : false;
        int a14 = a10.length > 0 && a2 != null ? Function.a(a2) : 0;
        for (int a15 = 0; a15 < a10.length; ++a15) {
            a9 = a2 != null ? (a13 && a15 >= a3.length - 1 ? a3[a3.length - 1].getComponentType() : a3[a15]) : null;
            a10[a15] = a8.a(a10, a15, a2, a11, a12, (Class<?>)a9);
        }
        Class<?> a16 = a4;
        a9 = null;
        if (NativeMapped.class.isAssignableFrom(a4)) {
            a9 = a7 = NativeMappedConverter.a(a4);
            a16 = ((NativeMappedConverter)a7).a();
        } else if (a11 != null && (a9 = a11.a(a4)) != null) {
            a16 = a9.a();
        }
        a7 = a8.a(a10, a16, a12, a14);
        if (a9 != null) {
            FunctionResultContext a17 = a2 != null ? new MethodResultContext(a4, a8, a5, a2) : new FunctionResultContext(a4, a8, a5);
            a7 = a9.a(a7, a17);
        }
        if (a5 != null) {
            for (int a18 = 0; a18 < a5.length; ++a18) {
                Object a19 = a5[a18];
                if (a19 == null) continue;
                if (a19 instanceof Structure) {
                    if (a19 instanceof Structure.ByValue) continue;
                    ((Structure)a19).p();
                    continue;
                }
                if (a10[a18] instanceof PostCallRead) {
                    ((PostCallRead)a10[a18]).a();
                    if (!(a10[a18] instanceof PointerArray)) continue;
                    PointerArray a20 = (PointerArray)a10[a18];
                    if (!Structure.ByReference[].class.isAssignableFrom(a19.getClass())) continue;
                    Class<?> a21 = a19.getClass().getComponentType();
                    Structure[] a22 = (Structure[])a19;
                    for (int a23 = 0; a23 < a22.length; ++a23) {
                        Pointer a24 = a20.a((long)(Pointer.c * a23));
                        a22[a23] = Structure.a(a21, a22[a23], a24);
                    }
                    continue;
                }
                if (!Structure[].class.isAssignableFrom(a19.getClass())) continue;
                Structure.p((Structure[])a19);
            }
        }
        return a7;
    }

    Object a(Object[] a2, Class<?> a3, boolean a4) {
        Function a5;
        return a5.a(a2, a3, a4, 0);
    }

    Object a(Object[] a2, Class<?> a3, boolean a4, int a5) {
        Function a6;
        Object a7 = null;
        int a8 = a6.b | (a5 & 3) << 7;
        if (a3 == null || a3 == Void.TYPE || a3 == Void.class) {
            Native.invokeVoid(a6, (long)a6.d, a8, a2);
            a7 = null;
        } else if (a3 == Boolean.TYPE || a3 == Boolean.class) {
            a7 = Function.a(Native.invokeInt(a6, (long)a6.d, a8, a2) != 0);
        } else if (a3 == Byte.TYPE || a3 == Byte.class) {
            a7 = (byte)Native.invokeInt(a6, (long)a6.d, a8, a2);
        } else if (a3 == Short.TYPE || a3 == Short.class) {
            a7 = (short)Native.invokeInt(a6, (long)a6.d, a8, a2);
        } else if (a3 == Character.TYPE || a3 == Character.class) {
            a7 = Character.valueOf((char)Native.invokeInt(a6, (long)a6.d, a8, a2));
        } else if (a3 == Integer.TYPE || a3 == Integer.class) {
            a7 = Native.invokeInt(a6, (long)a6.d, a8, a2);
        } else if (a3 == Long.TYPE || a3 == Long.class) {
            a7 = Native.invokeLong(a6, (long)a6.d, a8, a2);
        } else if (a3 == Float.TYPE || a3 == Float.class) {
            a7 = Float.valueOf(Native.invokeFloat(a6, (long)a6.d, a8, a2));
        } else if (a3 == Double.TYPE || a3 == Double.class) {
            a7 = Native.invokeDouble(a6, (long)a6.d, a8, a2);
        } else if (a3 == String.class) {
            a7 = a6.a(a8, a2, false);
        } else if (a3 == WString.class) {
            String a9 = a6.a(a8, a2, true);
            if (a9 != null) {
                a7 = new WString(a9);
            }
        } else {
            if (Pointer.class.isAssignableFrom(a3)) {
                return a6.a(a8, a2);
            }
            if (Structure.class.isAssignableFrom(a3)) {
                if (Structure.ByValue.class.isAssignableFrom(a3)) {
                    Structure a10 = Native.a(a6, (long)a6.d, a8, a2, Structure.a(a3));
                    a10.p();
                    a7 = a10;
                } else {
                    a7 = a6.a(a8, a2);
                    if (a7 != null) {
                        Structure a11 = Structure.a(a3, (Pointer)a7);
                        a11.x();
                        a7 = a11;
                    }
                }
            } else if (Callback.class.isAssignableFrom(a3)) {
                a7 = a6.a(a8, a2);
                if (a7 != null) {
                    a7 = CallbackReference.a(a3, (Pointer)a7);
                }
            } else if (a3 == String[].class) {
                Pointer a12 = a6.a(a8, a2);
                if (a12 != null) {
                    a7 = a12.a(0L, a6.l);
                }
            } else if (a3 == WString[].class) {
                Pointer a13 = a6.a(a8, a2);
                if (a13 != null) {
                    String[] a14 = a13.a(0L);
                    WString[] a15 = new WString[a14.length];
                    for (int a16 = 0; a16 < a14.length; ++a16) {
                        a15[a16] = new WString(a14[a16]);
                    }
                    a7 = a15;
                }
            } else if (a3 == Pointer[].class) {
                Pointer a17 = a6.a(a8, a2);
                if (a17 != null) {
                    a7 = a17.a(0L);
                }
            } else if (a4) {
                a7 = Native.invokeObject(a6, (long)a6.d, a8, a2);
                if (a7 != null && !a3.isAssignableFrom(a7.getClass())) {
                    throw new ClassCastException("Return type " + a3 + " does not match result " + a7.getClass());
                }
            } else {
                throw new IllegalArgumentException("Unsupported return type " + a3 + " in function " + a6.a());
            }
        }
        return a7;
    }

    private /* synthetic */ Pointer a(int a2, Object[] a3) {
        Function a4;
        long a5 = Native.invokePointer(a4, (long)a4.d, a2, a3);
        return a5 == 0L ? null : new Pointer(a5);
    }

    private /* synthetic */ Object a(Object[] a2, int a3, Method a4, TypeMapper a5, boolean a6, Class<?> a7) {
        Object a8;
        Function a9;
        Structure[] a10;
        Class<?> a11;
        Object a12 = a2[a3];
        if (a12 != null) {
            a11 = a12.getClass();
            a10 = null;
            if (NativeMapped.class.isAssignableFrom(a11)) {
                a10 = NativeMappedConverter.a(a11);
            } else if (a5 != null) {
                a10 = a5.a(a11);
            }
            if (a10 != null) {
                a8 = a4 != null ? new MethodParameterContext(a9, a2, a3, a4) : new FunctionParameterContext(a9, a2, a3);
                a12 = a10.a(a12, (ToNativeContext)a8);
            }
        }
        if (a12 == null || a9.a(a12.getClass())) {
            return a12;
        }
        a11 = a12.getClass();
        if (a12 instanceof Structure) {
            a10 = (Structure)a12;
            a10.a();
            if (a10 instanceof Structure.ByValue) {
                a8 = a10.getClass();
                if (a4 != null) {
                    Class<?>[] a13 = a4.getParameterTypes();
                    if (d.a(a4)) {
                        if (a3 < a13.length - 1) {
                            a8 = a13[a3];
                        } else {
                            Class<?> a14 = a13[a13.length - 1].getComponentType();
                            if (a14 != Object.class) {
                                a8 = a14;
                            }
                        }
                    } else {
                        a8 = a13[a3];
                    }
                }
                if (Structure.ByValue.class.isAssignableFrom((Class<?>)a8)) {
                    return a10;
                }
            }
            return a10.o();
        }
        if (a12 instanceof Callback) {
            return CallbackReference.a((Callback)a12);
        }
        if (a12 instanceof String) {
            return new NativeString((String)a12, false).a();
        }
        if (a12 instanceof WString) {
            return new NativeString(a12.toString(), true).a();
        }
        if (a12 instanceof Boolean) {
            return Boolean.TRUE.equals(a12) ? r : f;
        }
        if (String[].class == a11) {
            return new StringArray((String[])a12, a9.l);
        }
        if (WString[].class == a11) {
            return new StringArray((WString[])a12);
        }
        if (Pointer[].class == a11) {
            return new PointerArray((Pointer[])a12);
        }
        if (NativeMapped[].class.isAssignableFrom(a11)) {
            return new NativeMappedArray((NativeMapped[])a12);
        }
        if (Structure[].class.isAssignableFrom(a11)) {
            a10 = (Structure[])a12;
            a8 = a11.getComponentType();
            boolean a15 = Structure.ByReference.class.isAssignableFrom((Class<?>)a8);
            if (a7 != null && !Structure.ByReference[].class.isAssignableFrom(a7)) {
                if (a15) {
                    throw new IllegalArgumentException("Function " + a9.a() + " declared Structure[] at parameter " + a3 + " but array of " + a8 + " was passed");
                }
                for (int a16 = 0; a16 < a10.length; ++a16) {
                    if (!(a10[a16] instanceof Structure.ByReference)) continue;
                    throw new IllegalArgumentException("Function " + a9.a() + " declared Structure[] at parameter " + a3 + " but element " + a16 + " is of Structure.ByReference type");
                }
            }
            if (a15) {
                Structure.a(a10);
                Pointer[] a17 = new Pointer[a10.length + 1];
                for (int a18 = 0; a18 < a10.length; ++a18) {
                    a17[a18] = a10[a18] != null ? a10[a18].o() : null;
                }
                return new PointerArray(a17);
            }
            if (a10.length == 0) {
                throw new IllegalArgumentException("Structure array must have non-zero length");
            }
            if (a10[0] == null) {
                Structure.a(a8).a(a10);
                return a10[0].o();
            }
            Structure.a(a10);
            return a10[0].o();
        }
        if (a11.isArray()) {
            throw new IllegalArgumentException("Unsupported array argument type: " + a11.getComponentType());
        }
        if (a6) {
            return a12;
        }
        if (!Native.p(a12.getClass())) {
            throw new IllegalArgumentException("Unsupported argument type " + a12.getClass().getName() + " at parameter " + a3 + " of function " + a9.a());
        }
        return a12;
    }

    private /* synthetic */ boolean a(Class<?> a2) {
        return a2.isArray() && a2.getComponentType().isPrimitive();
    }

    public void p(Object[] a2) {
        Function a3;
        a3.a(Void.class, a2);
    }

    private /* synthetic */ String a(int a2, Object[] a3, boolean a4) {
        Function a5;
        Pointer a6 = a5.a(a2, a3);
        String a7 = null;
        if (a6 != null) {
            a7 = a4 ? a6.p(0L) : a6.a(0L, a5.l);
        }
        return a7;
    }

    @Override
    public String toString() {
        Function a2;
        if (a2.h != null) {
            return "native function " + a2.z + "(" + a2.h.p() + ")@0x" + Long.toHexString((long)a2.d);
        }
        return "native function@0x" + Long.toHexString((long)a2.d);
    }

    public Object a(Object[] a2) {
        Function a3;
        return a3.a(Object.class, a2);
    }

    public Pointer a(Object[] a2) {
        Function a3;
        return (Pointer)a3.a(Pointer.class, a2);
    }

    public String a(Object[] a2, boolean a3) {
        Function a4;
        Object a5 = a4.a(a3 ? WString.class : String.class, a2);
        return a5 != null ? a5.toString() : null;
    }

    public int a(Object[] a2) {
        Function a3;
        return (Integer)a3.a(Integer.class, a2);
    }

    public long a(Object[] a2) {
        Function a3;
        return (Long)a3.a(Long.class, a2);
    }

    public float a(Object[] a2) {
        Function a3;
        return ((Float)a3.a(Float.class, a2)).floatValue();
    }

    public double a(Object[] a2) {
        Function a3;
        return (Double)a3.a(Double.class, a2);
    }

    public void a(Object[] a2) {
        Function a3;
        a3.a(Void.class, a2);
    }

    @Override
    public boolean equals(Object a2) {
        Function a3;
        if (a2 == a3) {
            return true;
        }
        if (a2 == null) {
            return false;
        }
        if (a2.getClass() == a3.getClass()) {
            Function a4 = (Function)a2;
            return a4.b == a3.b && a4.c.equals(a3.c) && a4.d == a3.d;
        }
        return false;
    }

    @Override
    public int hashCode() {
        Function a2;
        return a2.b + a2.c.hashCode() + super.hashCode();
    }

    static Object[] a(Object[] a2) {
        if (a2 != null && a2.length > 0) {
            Class<?> a3;
            Object a4 = a2[a2.length - 1];
            Class<?> clazz = a3 = a4 != null ? a4.getClass() : null;
            if (a3 != null && a3.isArray()) {
                Object[] a5 = (Object[])a4;
                for (int a6 = 0; a6 < a5.length; ++a6) {
                    if (!(a5[a6] instanceof Float)) continue;
                    a5[a6] = (double)((Float)a5[a6]).floatValue();
                }
                Object[] a7 = new Object[a2.length + a5.length];
                System.arraycopy(a2, 0, a7, 0, a2.length - 1);
                System.arraycopy(a5, 0, a7, a2.length - 1, a5.length);
                a7[a7.length - 1] = null;
                a2 = a7;
            }
        }
        return a2;
    }

    static boolean a(Method a2) {
        return d.a(a2);
    }

    static int a(Method a2) {
        return d.a(a2);
    }

    static Boolean a(boolean a2) {
        return a2 ? Boolean.TRUE : Boolean.FALSE;
    }

    private static class PointerArray
    extends Memory
    implements PostCallRead {
        private final Pointer[] d;

        public PointerArray(Pointer[] a2) {
            super(Pointer.c * (a2.length + 1));
            PointerArray a3;
            a3.d = a2;
            for (int a4 = 0; a4 < a2.length; ++a4) {
                a3.a((long)(a4 * Pointer.c), a2[a4]);
            }
            a3.a((long)(Pointer.c * a2.length), (Pointer)null);
        }

        @Override
        public void a() {
            PointerArray a2;
            a2.p(0L, a2.d, 0, a2.d.length);
        }
    }

    private static class NativeMappedArray
    extends Memory
    implements PostCallRead {
        private final NativeMapped[] d;

        public NativeMappedArray(NativeMapped[] a2) {
            super(Native.a(a2.getClass(), (Object)a2));
            NativeMappedArray a3;
            a3.d = a2;
            a3.p(0L, a3.d, a3.d.getClass());
        }

        @Override
        public void a() {
            NativeMappedArray a2;
            a2.a(0L, a2.d.getClass(), a2.d);
        }
    }

    public static interface PostCallRead {
        public void a();
    }
}

