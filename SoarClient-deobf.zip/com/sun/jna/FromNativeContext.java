/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

public class FromNativeContext {
    private Class<?> d;

    FromNativeContext(Class<?> a2) {
        FromNativeContext a3;
        a3.d = a2;
    }

    public Class<?> a() {
        FromNativeContext a2;
        return a2.d;
    }
}

