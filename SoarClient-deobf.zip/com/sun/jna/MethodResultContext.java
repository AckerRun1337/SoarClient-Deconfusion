/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Function;
import com.sun.jna.FunctionResultContext;
import java.lang.reflect.Method;

public class MethodResultContext
extends FunctionResultContext {
    private final Method d;

    MethodResultContext(Class<?> a2, Function a3, Object[] a4, Method a5) {
        super(a2, a3, a4);
        MethodResultContext a6;
        a6.d = a5;
    }

    public Method a() {
        MethodResultContext a2;
        return a2.d;
    }
}

