/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.TypeMapper;
import com.sun.jna.WString;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class Union
extends Structure {
    private Structure.StructField d;

    protected Union() {
        Union a2;
    }

    protected Union(Pointer a2) {
        super(a2);
        Union a3;
    }

    protected Union(Pointer a2, int a3) {
        super(a2, a3);
        Union a4;
    }

    protected Union(TypeMapper a2) {
        super(a2);
        Union a3;
    }

    protected Union(Pointer a2, int a3, TypeMapper a4) {
        super(a2, a3, a4);
        Union a5;
    }

    @Override
    protected List<String> o() {
        Union a2;
        List<Field> a3 = a2.p();
        ArrayList<String> a4 = new ArrayList<String>(a3.size());
        for (Field a5 : a3) {
            a4.add(a5.getName());
        }
        return a4;
    }

    public void p(Class<?> a2) {
        Union a3;
        a3.d();
        for (Structure.StructField a4 : a3.p().values()) {
            if (a4.r != a2) continue;
            a3.d = a4;
            return;
        }
        throw new IllegalArgumentException("No field of type " + a2 + " in " + a3);
    }

    public void o(String a2) {
        Union a3;
        a3.d();
        Structure.StructField a4 = a3.p().get(a2);
        if (a4 == null) {
            throw new IllegalArgumentException("No field named " + a2 + " in " + a3);
        }
        a3.d = a4;
    }

    @Override
    public Object a(String a2) {
        Union a3;
        a3.d();
        a3.o(a2);
        return super.a(a2);
    }

    @Override
    public void a(String a2) {
        Union a3;
        a3.d();
        a3.o(a2);
        super.a(a2);
    }

    @Override
    public void a(String a2, Object a3) {
        Union a4;
        a4.d();
        a4.o(a2);
        super.a(a2, a3);
    }

    public Object a(Class<?> a2) {
        Union a3;
        a3.d();
        for (Structure.StructField a4 : a3.p().values()) {
            if (a4.r != a2) continue;
            a3.d = a4;
            a3.j();
            return a3.a(a3.d.f);
        }
        throw new IllegalArgumentException("No field of type " + a2 + " in " + a3);
    }

    public Object a(Object a2) {
        Union a3;
        Structure.StructField a4 = a3.a(a2.getClass());
        if (a4 != null) {
            a3.d = a4;
            a3.a(a4.f, a2);
            return a3;
        }
        throw new IllegalArgumentException("No field of type " + a2.getClass() + " in " + a3);
    }

    private /* synthetic */ Structure.StructField a(Class<?> a2) {
        Union a3;
        a3.d();
        for (Structure.StructField a4 : a3.p().values()) {
            if (!a4.r.isAssignableFrom(a2)) continue;
            return a4;
        }
        return null;
    }

    @Override
    protected void a(Structure.StructField a2) {
        Union a3;
        if (a2 == a3.d) {
            super.a(a2);
        }
    }

    @Override
    protected Object a(Structure.StructField a2) {
        Union a3;
        if (a2 == a3.d || !Structure.class.isAssignableFrom(a2.r) && !String.class.isAssignableFrom(a2.r) && !WString.class.isAssignableFrom(a2.r)) {
            return super.a(a2);
        }
        return null;
    }

    @Override
    protected int a(Class<?> a2, Object a3, boolean a4) {
        Union a5;
        return super.a(a2, a3, true);
    }
}

