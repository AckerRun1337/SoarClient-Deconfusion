/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;
import com.sun.jna.CallbackReference;
import com.sun.jna.FromNativeContext;
import com.sun.jna.Function;
import com.sun.jna.Native;
import com.sun.jna.NativeLong;
import com.sun.jna.NativeMapped;
import com.sun.jna.NativeMappedConverter;
import com.sun.jna.Platform;
import com.sun.jna.Structure;
import com.sun.jna.ToNativeContext;
import com.sun.jna.WString;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Array;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Pointer {
    public static final int c = Native.za;
    public static final Pointer v;
    protected long d;

    public static final Pointer o(long a2) {
        return new Opaque(a2);
    }

    public static final Pointer a(int a2) {
        return new Opaque((long)a2 & 0xFFFFFFFFFFFFFFFFL);
    }

    Pointer() {
        Pointer a2;
    }

    public Pointer(long a2) {
        Pointer a3;
        a3.d = a2;
    }

    public Pointer p(long a2) {
        Pointer a3;
        return a3.a(a2, 0L);
    }

    public Pointer a(long a2, long a3) {
        Pointer a4;
        if (a2 == 0L) {
            return a4;
        }
        return new Pointer(a4.d + a2);
    }

    public void a(long a2) {
        Pointer a3;
        a3.a(0L, a2, (byte)0);
    }

    public boolean equals(Object a2) {
        Pointer a3;
        if (a2 == a3) {
            return true;
        }
        if (a2 == null) {
            return false;
        }
        return a2 instanceof Pointer && ((Pointer)a2).d == a3.d;
    }

    public int hashCode() {
        Pointer a2;
        return (int)((a2.d >>> 32) + (a2.d & 0xFFFFFFFFFFFFFFFFL));
    }

    public long a(long a2, byte a3) {
        Pointer a4;
        return Native.indexOf(a4, a4.d, a2, a3);
    }

    public void p(long a2, byte[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, short[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, char[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, int[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, long[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, float[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, double[] a3, int a4, int a5) {
        Pointer a6;
        Native.read(a6, a6.d, a2, a3, a4, a5);
    }

    public void p(long a2, Pointer[] a3, int a4, int a5) {
        for (int a6 = 0; a6 < a5; ++a6) {
            Pointer a7;
            Pointer a8 = a7.a(a2 + (long)(a6 * c));
            Pointer a9 = a3[a6 + a4];
            if (a9 != null && a8 != null && a8.d == a9.d) continue;
            a3[a6 + a4] = a8;
        }
    }

    public void a(long a2, byte[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, short[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, char[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, int[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, long[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, float[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, double[] a3, int a4, int a5) {
        Pointer a6;
        Native.write(a6, a6.d, a2, a3, a4, a5);
    }

    public void a(long a2, Pointer[] a3, int a4, int a5) {
        for (int a6 = 0; a6 < a5; ++a6) {
            Pointer a7;
            a7.a(a2 + (long)(a6 * c), a3[a4 + a6]);
        }
    }

    Object a(long a2, Class<?> a3, Object a4) {
        Pointer a5;
        Object a6 = null;
        if (Structure.class.isAssignableFrom(a3)) {
            Structure a7 = (Structure)a4;
            if (Structure.ByReference.class.isAssignableFrom(a3)) {
                a7 = Structure.a(a3, a7, a5.a(a2));
            } else {
                a7.a(a5, (int)a2, true);
                a7.j();
            }
            a6 = a7;
        } else if (a3 == Boolean.TYPE || a3 == Boolean.class) {
            a6 = Function.a(a5.a(a2) != 0);
        } else if (a3 == Byte.TYPE || a3 == Byte.class) {
            a6 = a5.a(a2);
        } else if (a3 == Short.TYPE || a3 == Short.class) {
            a6 = a5.a(a2);
        } else if (a3 == Character.TYPE || a3 == Character.class) {
            a6 = Character.valueOf(a5.a(a2));
        } else if (a3 == Integer.TYPE || a3 == Integer.class) {
            a6 = a5.a(a2);
        } else if (a3 == Long.TYPE || a3 == Long.class) {
            a6 = a5.a(a2);
        } else if (a3 == Float.TYPE || a3 == Float.class) {
            a6 = Float.valueOf(a5.a(a2));
        } else if (a3 == Double.TYPE || a3 == Double.class) {
            a6 = a5.a(a2);
        } else if (Pointer.class.isAssignableFrom(a3)) {
            Pointer a8 = a5.a(a2);
            if (a8 != null) {
                Pointer a9;
                Pointer pointer = a9 = a4 instanceof Pointer ? (Pointer)a4 : null;
                a6 = a9 == null || a8.d != a9.d ? a8 : a9;
            }
        } else if (a3 == String.class) {
            Pointer a10 = a5.a(a2);
            a6 = a10 != null ? a10.a(0L) : null;
        } else if (a3 == WString.class) {
            Pointer a11 = a5.a(a2);
            a6 = a11 != null ? new WString(a11.p(0L)) : null;
        } else if (Callback.class.isAssignableFrom(a3)) {
            Pointer a12 = a5.a(a2);
            if (a12 == null) {
                a6 = null;
            } else {
                Callback a13 = (Callback)a4;
                Pointer a14 = CallbackReference.a(a13);
                if (!a12.equals(a14)) {
                    a13 = CallbackReference.a(a3, a12);
                }
                a6 = a13;
            }
        } else if (Platform.r && Buffer.class.isAssignableFrom(a3)) {
            Pointer a15 = a5.a(a2);
            if (a15 == null) {
                a6 = null;
            } else {
                Pointer a16;
                Pointer pointer = a16 = a4 == null ? null : Native.a((Buffer)a4);
                if (a16 == null || !a16.equals(a15)) {
                    throw new IllegalStateException("Can't autogenerate a direct buffer on memory read");
                }
                a6 = a4;
            }
        } else if (NativeMapped.class.isAssignableFrom(a3)) {
            NativeMapped a17 = (NativeMapped)a4;
            if (a17 != null) {
                Object a18 = a5.a(a2, (Class<?>)a17.a(), (Object)null);
                a6 = a17.a(a18, new FromNativeContext(a3));
                if (a17.equals(a6)) {
                    a6 = a17;
                }
            } else {
                NativeMappedConverter a19 = NativeMappedConverter.a(a3);
                Object a20 = a5.a(a2, a19.a(), (Object)null);
                a6 = a19.a(a20, new FromNativeContext(a3));
            }
        } else if (a3.isArray()) {
            a6 = a4;
            if (a6 == null) {
                throw new IllegalStateException("Need an initialized array");
            }
            a5.o(a2, a6, a3.getComponentType());
        } else {
            throw new IllegalArgumentException("Reading \"" + a3 + "\" from memory is not supported");
        }
        return a6;
    }

    private /* synthetic */ void o(long a2, Object a3, Class<?> a4) {
        Pointer a5;
        int a6 = 0;
        a6 = Array.getLength(a3);
        Object a7 = a3;
        if (a4 == Byte.TYPE) {
            a5.p(a2, (byte[])a7, 0, a6);
        } else if (a4 == Short.TYPE) {
            a5.p(a2, (short[])a7, 0, a6);
        } else if (a4 == Character.TYPE) {
            a5.p(a2, (char[])a7, 0, a6);
        } else if (a4 == Integer.TYPE) {
            a5.p(a2, (int[])a7, 0, a6);
        } else if (a4 == Long.TYPE) {
            a5.p(a2, (long[])a7, 0, a6);
        } else if (a4 == Float.TYPE) {
            a5.p(a2, (float[])a7, 0, a6);
        } else if (a4 == Double.TYPE) {
            a5.p(a2, (double[])a7, 0, a6);
        } else if (Pointer.class.isAssignableFrom(a4)) {
            a5.p(a2, (Pointer[])a7, 0, a6);
        } else if (Structure.class.isAssignableFrom(a4)) {
            Structure[] a8 = (Structure[])a7;
            if (Structure.ByReference.class.isAssignableFrom(a4)) {
                Pointer[] a9 = a5.a(a2, a8.length);
                for (int a10 = 0; a10 < a8.length; ++a10) {
                    a8[a10] = Structure.a(a4, a8[a10], a9[a10]);
                }
            } else {
                Structure a11 = a8[0];
                if (a11 == null) {
                    a11 = Structure.a(a4, a5.p(a2));
                    a11.x();
                    a8[0] = a11;
                } else {
                    a11.a(a5, (int)a2, true);
                    a11.j();
                }
                Structure[] a12 = a11.a(a8.length);
                for (int a13 = 1; a13 < a8.length; ++a13) {
                    if (a8[a13] == null) {
                        a8[a13] = a12[a13];
                        continue;
                    }
                    a8[a13].a(a5, (int)(a2 + (long)(a13 * a8[a13].p())), true);
                    a8[a13].j();
                }
            }
        } else if (NativeMapped.class.isAssignableFrom(a4)) {
            NativeMapped[] a14 = (NativeMapped[])a7;
            NativeMappedConverter a15 = NativeMappedConverter.a(a4);
            int a16 = Native.a(a7.getClass(), a7) / a14.length;
            for (int a17 = 0; a17 < a14.length; ++a17) {
                Object a18 = a5.a(a2 + (long)(a16 * a17), a15.a(), a14[a17]);
                a14[a17] = (NativeMapped)a15.a(a18, new FromNativeContext(a4));
            }
        } else {
            throw new IllegalArgumentException("Reading array of " + a4 + " from memory not supported");
        }
    }

    public byte a(long a2) {
        Pointer a3;
        return Native.getByte(a3, a3.d, a2);
    }

    public char a(long a2) {
        Pointer a3;
        return Native.getChar(a3, a3.d, a2);
    }

    public short a(long a2) {
        Pointer a3;
        return Native.getShort(a3, a3.d, a2);
    }

    public int a(long a2) {
        Pointer a3;
        return Native.getInt(a3, a3.d, a2);
    }

    public long a(long a2) {
        Pointer a3;
        return Native.getLong(a3, a3.d, a2);
    }

    public NativeLong a(long a2) {
        Pointer a3;
        return new NativeLong(NativeLong.d == 8 ? a3.a(a2) : (long)a3.a(a2));
    }

    public float a(long a2) {
        Pointer a3;
        return Native.getFloat(a3, a3.d, a2);
    }

    public double a(long a2) {
        Pointer a3;
        return Native.getDouble(a3, a3.d, a2);
    }

    public Pointer a(long a2) {
        Pointer a3;
        return Native.a(a3.d + a2);
    }

    public ByteBuffer a(long a2, long a3) {
        Pointer a4;
        return Native.getDirectByteBuffer(a4, a4.d, a2, a3).order(ByteOrder.nativeOrder());
    }

    @Deprecated
    public String a(long a2, boolean a3) {
        Pointer a4;
        return a3 ? a4.p(a2) : a4.a(a2);
    }

    public String p(long a2) {
        Pointer a3;
        return Native.getWideString(a3, a3.d, a2);
    }

    public String a(long a2) {
        Pointer a3;
        return a3.a(a2, Native.a());
    }

    public String a(long a2, String a3) {
        Pointer a4;
        return Native.a(a4, a2, a3);
    }

    public byte[] a(long a2, int a3) {
        Pointer a4;
        byte[] a5 = new byte[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public char[] a(long a2, int a3) {
        Pointer a4;
        char[] a5 = new char[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public short[] a(long a2, int a3) {
        Pointer a4;
        short[] a5 = new short[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public int[] a(long a2, int a3) {
        Pointer a4;
        int[] a5 = new int[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public long[] a(long a2, int a3) {
        Pointer a4;
        long[] a5 = new long[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public float[] a(long a2, int a3) {
        Pointer a4;
        float[] a5 = new float[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public double[] a(long a2, int a3) {
        Pointer a4;
        double[] a5 = new double[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public Pointer[] a(long a2) {
        Pointer a3;
        ArrayList<Pointer> a4 = new ArrayList<Pointer>();
        int a5 = 0;
        Pointer a6 = a3.a(a2);
        while (a6 != null) {
            a4.add(a6);
            a6 = a3.a(a2 + (long)(a5 += c));
        }
        return a4.toArray(new Pointer[a4.size()]);
    }

    public Pointer[] a(long a2, int a3) {
        Pointer a4;
        Pointer[] a5 = new Pointer[a3];
        a4.p(a2, a5, 0, a3);
        return a5;
    }

    public String[] p(long a2) {
        Pointer a3;
        return a3.a(a2, -1, Native.a());
    }

    public String[] a(long a2, String a3) {
        Pointer a4;
        return a4.a(a2, -1, a3);
    }

    public String[] p(long a2, int a3) {
        Pointer a4;
        return a4.a(a2, a3, Native.a());
    }

    @Deprecated
    public String[] a(long a2, boolean a3) {
        Pointer a4;
        return a4.a(a2, -1, a3);
    }

    public String[] a(long a2) {
        Pointer a3;
        return a3.a(a2, -1);
    }

    public String[] a(long a2, int a3) {
        Pointer a4;
        return a4.a(a2, a3, "--WIDE-STRING--");
    }

    @Deprecated
    public String[] a(long a2, int a3, boolean a4) {
        Pointer a5;
        return a5.a(a2, a3, a4 ? "--WIDE-STRING--" : Native.a());
    }

    public String[] a(long a2, int a3, String a4) {
        Pointer a5;
        ArrayList<String> a6 = new ArrayList<String>();
        int a7 = 0;
        if (a3 != -1) {
            Pointer a8 = a5.a(a2 + (long)a7);
            int a9 = 0;
            while (a9++ < a3) {
                String a10 = a8 == null ? null : ("--WIDE-STRING--".equals(a4) ? a8.p(0L) : a8.a(0L, a4));
                a6.add(a10);
                if (a9 >= a3) continue;
                a8 = a5.a(a2 + (long)(a7 += c));
            }
        } else {
            Pointer a11;
            while ((a11 = a5.a(a2 + (long)a7)) != null) {
                String a12 = a11 == null ? null : ("--WIDE-STRING--".equals(a4) ? a11.p(0L) : a11.a(0L, a4));
                a6.add(a12);
                a7 += c;
            }
        }
        return a6.toArray(new String[a6.size()]);
    }

    void p(long a2, Object a3, Class<?> a4) {
        Pointer a5;
        if (a4 == Boolean.TYPE || a4 == Boolean.class) {
            a5.a(a2, Boolean.TRUE.equals(a3) ? -1 : 0);
        } else if (a4 == Byte.TYPE || a4 == Byte.class) {
            a5.a(a2, a3 == null ? (byte)0 : (Byte)a3);
        } else if (a4 == Short.TYPE || a4 == Short.class) {
            a5.a(a2, a3 == null ? (short)0 : (Short)a3);
        } else if (a4 == Character.TYPE || a4 == Character.class) {
            a5.a(a2, a3 == null ? (char)'\u0000' : ((Character)a3).charValue());
        } else if (a4 == Integer.TYPE || a4 == Integer.class) {
            a5.a(a2, a3 == null ? 0 : (Integer)a3);
        } else if (a4 == Long.TYPE || a4 == Long.class) {
            a5.a(a2, a3 == null ? 0L : (Long)a3);
        } else if (a4 == Float.TYPE || a4 == Float.class) {
            a5.a(a2, a3 == null ? 0.0f : ((Float)a3).floatValue());
        } else if (a4 == Double.TYPE || a4 == Double.class) {
            a5.a(a2, a3 == null ? 0.0 : (Double)a3);
        } else if (a4 == Pointer.class) {
            a5.a(a2, (Pointer)a3);
        } else if (a4 == String.class) {
            a5.a(a2, (Pointer)a3);
        } else if (a4 == WString.class) {
            a5.a(a2, (Pointer)a3);
        } else if (Structure.class.isAssignableFrom(a4)) {
            Structure a6 = (Structure)a3;
            if (Structure.ByReference.class.isAssignableFrom(a4)) {
                a5.a(a2, a6 == null ? null : a6.o());
                if (a6 != null) {
                    a6.a();
                }
            } else {
                a6.a(a5, (int)a2, true);
                a6.z();
            }
        } else if (Callback.class.isAssignableFrom(a4)) {
            a5.a(a2, CallbackReference.a((Callback)a3));
        } else if (Platform.r && Buffer.class.isAssignableFrom(a4)) {
            Pointer a7 = a3 == null ? null : Native.a((Buffer)a3);
            a5.a(a2, a7);
        } else if (NativeMapped.class.isAssignableFrom(a4)) {
            NativeMappedConverter a8 = NativeMappedConverter.a(a4);
            Class<?> a9 = a8.a();
            a5.p(a2, a8.a(a3, new ToNativeContext()), a9);
        } else if (a4.isArray()) {
            a5.a(a2, a3, a4.getComponentType());
        } else {
            throw new IllegalArgumentException("Writing " + a4 + " to memory is not supported");
        }
    }

    private /* synthetic */ void a(long a2, Object a3, Class<?> a4) {
        Pointer a5;
        if (a4 == Byte.TYPE) {
            byte[] a6 = (byte[])a3;
            a5.a(a2, a6, 0, a6.length);
        } else if (a4 == Short.TYPE) {
            short[] a7 = (short[])a3;
            a5.a(a2, a7, 0, a7.length);
        } else if (a4 == Character.TYPE) {
            char[] a8 = (char[])a3;
            a5.a(a2, a8, 0, a8.length);
        } else if (a4 == Integer.TYPE) {
            int[] a9 = (int[])a3;
            a5.a(a2, a9, 0, a9.length);
        } else if (a4 == Long.TYPE) {
            long[] a10 = (long[])a3;
            a5.a(a2, a10, 0, a10.length);
        } else if (a4 == Float.TYPE) {
            float[] a11 = (float[])a3;
            a5.a(a2, a11, 0, a11.length);
        } else if (a4 == Double.TYPE) {
            double[] a12 = (double[])a3;
            a5.a(a2, a12, 0, a12.length);
        } else if (Pointer.class.isAssignableFrom(a4)) {
            Pointer[] a13 = (Pointer[])a3;
            a5.a(a2, a13, 0, a13.length);
        } else if (Structure.class.isAssignableFrom(a4)) {
            Structure[] a14 = (Structure[])a3;
            if (Structure.ByReference.class.isAssignableFrom(a4)) {
                Pointer[] a15 = new Pointer[a14.length];
                for (int a16 = 0; a16 < a14.length; ++a16) {
                    if (a14[a16] == null) {
                        a15[a16] = null;
                        continue;
                    }
                    a15[a16] = a14[a16].o();
                    a14[a16].z();
                }
                a5.a(a2, a15, 0, a15.length);
            } else {
                Structure a17 = a14[0];
                if (a17 == null) {
                    a14[0] = a17 = Structure.a(a4, a5.p(a2));
                } else {
                    a17.a(a5, (int)a2, true);
                }
                a17.z();
                Structure[] a18 = a17.a(a14.length);
                for (int a19 = 1; a19 < a14.length; ++a19) {
                    if (a14[a19] == null) {
                        a14[a19] = a18[a19];
                    } else {
                        a14[a19].a(a5, (int)(a2 + (long)(a19 * a14[a19].p())), true);
                    }
                    a14[a19].z();
                }
            }
        } else if (NativeMapped.class.isAssignableFrom(a4)) {
            NativeMapped[] a20 = (NativeMapped[])a3;
            NativeMappedConverter a21 = NativeMappedConverter.a(a4);
            Class<?> a22 = a21.a();
            int a23 = Native.a(a3.getClass(), a3) / a20.length;
            for (int a24 = 0; a24 < a20.length; ++a24) {
                Object a25 = a21.a((Object)a20[a24], new ToNativeContext());
                a5.p(a2 + (long)(a24 * a23), a25, a22);
            }
        } else {
            throw new IllegalArgumentException("Writing array of " + a4 + " to memory not supported");
        }
    }

    public void a(long a2, long a3, byte a4) {
        Pointer a5;
        Native.setMemory(a5, a5.d, a2, a3, a4);
    }

    public void a(long a2, byte a3) {
        Pointer a4;
        Native.setByte(a4, a4.d, a2, a3);
    }

    public void a(long a2, short a3) {
        Pointer a4;
        Native.setShort(a4, a4.d, a2, a3);
    }

    public void a(long a2, char a3) {
        Pointer a4;
        Native.setChar(a4, a4.d, a2, a3);
    }

    public void a(long a2, int a3) {
        Pointer a4;
        Native.setInt(a4, a4.d, a2, a3);
    }

    public void a(long a2, long a3) {
        Pointer a4;
        Native.setLong(a4, a4.d, a2, a3);
    }

    public void a(long a2, NativeLong a3) {
        Pointer a4;
        if (NativeLong.d == 8) {
            a4.a(a2, a3.longValue());
        } else {
            a4.a(a2, a3.intValue());
        }
    }

    public void a(long a2, float a3) {
        Pointer a4;
        Native.setFloat(a4, a4.d, a2, a3);
    }

    public void a(long a2, double a3) {
        Pointer a4;
        Native.setDouble(a4, a4.d, a2, a3);
    }

    public void a(long a2, Pointer a3) {
        Pointer a4;
        Native.setPointer(a4, a4.d, a2, a3 != null ? a3.d : 0L);
    }

    @Deprecated
    public void a(long a2, String a3, boolean a4) {
        Pointer a5;
        if (a4) {
            a5.p(a2, a3);
        } else {
            a5.a(a2, a3);
        }
    }

    public void p(long a2, String a3) {
        Pointer a4;
        Native.setWideString(a4, a4.d, a2, a3);
    }

    public void a(long a2, WString a3) {
        Pointer a4;
        a4.p(a2, a3 == null ? null : a3.toString());
    }

    public void a(long a2, String a3) {
        Pointer a4;
        a4.a(a2, a3, Native.a());
    }

    public void a(long a2, String a3, String a4) {
        Pointer a5;
        byte[] a6 = Native.p(a3, a4);
        a5.a(a2, a6, 0, a6.length);
        a5.a(a2 + (long)a6.length, (byte)0);
    }

    public String a(long a2, int a3) {
        int a4 = 4;
        String a5 = "memory dump";
        StringWriter a6 = new StringWriter("memory dump".length() + 2 + a3 * 2 + a3 / 4 * 4);
        PrintWriter a7 = new PrintWriter(a6);
        a7.println("memory dump");
        for (int a8 = 0; a8 < a3; ++a8) {
            Pointer a9;
            byte a10 = a9.a(a2 + (long)a8);
            if (a8 % 4 == 0) {
                a7.print("[");
            }
            if (a10 >= 0 && a10 < 16) {
                a7.print("0");
            }
            a7.print(Integer.toHexString(a10 & 0xFF));
            if (a8 % 4 != 3 || a8 >= a3 - 1) continue;
            a7.println("]");
        }
        if (a6.getBuffer().charAt(a6.getBuffer().length() - 2) != ']') {
            a7.println("]");
        }
        return a6.toString();
    }

    public String toString() {
        Pointer a2;
        return "native@0x" + Long.toHexString(a2.d);
    }

    public static long a(Pointer a2) {
        return a2 == null ? 0L : a2.d;
    }

    public static void a(Pointer a2, long a3) {
        a2.d = a3;
    }

    static {
        if (c == 0) {
            throw new Error("Native library not initialized");
        }
        v = null;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    private static class Opaque
    extends Pointer {
        private final String d;

        private /* synthetic */ Opaque(long a2) {
            super(a2);
            Opaque a3;
            a3.d = "This pointer is opaque: " + a3;
        }

        @Override
        public Pointer a(long a2, long a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public long a(long a2, byte a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void p(long a2, byte[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, char[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, short[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, int[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, long[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, float[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, double[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void p(long a2, Pointer[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, byte[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, char[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, short[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, int[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, long[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, float[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, double[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public void a(long a2, Pointer[] a3, int a4, int a5) {
            Opaque a6;
            throw new UnsupportedOperationException(a6.d);
        }

        @Override
        public ByteBuffer a(long a2, long a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public byte a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public char a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public short a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public int a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public long a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public float a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public double a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public Pointer a(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public String a(long a2, String a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public String p(long a2) {
            Opaque a3;
            throw new UnsupportedOperationException(a3.d);
        }

        @Override
        public void a(long a2, byte a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, char a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, short a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, int a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, long a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, float a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, double a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, Pointer a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, String a3, String a4) {
            Opaque a5;
            throw new UnsupportedOperationException(a5.d);
        }

        @Override
        public void p(long a2, String a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public void a(long a2, long a3, byte a4) {
            Opaque a5;
            throw new UnsupportedOperationException(a5.d);
        }

        @Override
        public String a(long a2, int a3) {
            Opaque a4;
            throw new UnsupportedOperationException(a4.d);
        }

        @Override
        public String toString() {
            Opaque a2;
            return "const@0x" + Long.toHexString((long)a2.d);
        }
    }
}

