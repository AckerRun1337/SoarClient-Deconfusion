/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Callback;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CallbackThreadInitializer {
    private boolean b;
    private boolean c;
    private String v;
    private ThreadGroup d;

    public CallbackThreadInitializer() {
        a2(true);
        CallbackThreadInitializer a2;
    }

    public CallbackThreadInitializer(boolean a2) {
        a3(a2, false);
        CallbackThreadInitializer a3;
    }

    public CallbackThreadInitializer(boolean a2, boolean a3) {
        a4(a2, a3, null);
        CallbackThreadInitializer a4;
    }

    public CallbackThreadInitializer(boolean a2, boolean a3, String a4) {
        a5(a2, a3, a4, null);
        CallbackThreadInitializer a5;
    }

    public CallbackThreadInitializer(boolean a2, boolean a3, String a4, ThreadGroup a5) {
        CallbackThreadInitializer a6;
        a6.b = a2;
        a6.c = a3;
        a6.v = a4;
        a6.d = a5;
    }

    public String a(Callback a2) {
        CallbackThreadInitializer a3;
        return a3.v;
    }

    public ThreadGroup a(Callback a2) {
        CallbackThreadInitializer a3;
        return a3.d;
    }

    public boolean p(Callback a2) {
        CallbackThreadInitializer a3;
        return a3.b;
    }

    public boolean a(Callback a2) {
        CallbackThreadInitializer a3;
        return a3.c;
    }
}

