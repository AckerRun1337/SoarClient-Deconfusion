/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.WString;
import java.nio.CharBuffer;

class NativeString
implements CharSequence,
Comparable {
    static final String c = "--WIDE-STRING--";
    private Pointer v;
    private String d;

    public NativeString(String a2) {
        a3(a2, Native.a());
        NativeString a3;
    }

    public NativeString(String a2, boolean a3) {
        a4(a2, a3 ? c : Native.a());
        NativeString a4;
    }

    public NativeString(WString a2) {
        a3(a2.toString(), c);
        NativeString a3;
    }

    public NativeString(String a2, String a3) {
        NativeString a4;
        if (a2 == null) {
            throw new NullPointerException("String must not be null");
        }
        a4.d = a3;
        if (c.equals(a4.d)) {
            int a5 = (a2.length() + 1) * Native.wa;
            a4.v = a4.new StringMemory(a5);
            a4.v.p(0L, a2);
        } else {
            byte[] a6 = Native.p(a2, a3);
            a4.v = a4.new StringMemory(a6.length + 1);
            a4.v.a(0L, a6, 0, a6.length);
            a4.v.a((long)a6.length, (byte)0);
        }
    }

    public int hashCode() {
        NativeString a2;
        return a2.toString().hashCode();
    }

    public boolean equals(Object a2) {
        if (a2 instanceof CharSequence) {
            NativeString a3;
            return a3.compareTo(a2) == 0;
        }
        return false;
    }

    @Override
    public String toString() {
        NativeString a2;
        boolean a3 = c.equals(a2.d);
        String a4 = a3 ? "const wchar_t*" : "const char*";
        a4 = a4 + "(" + (a3 ? a2.v.p(0L) : a2.v.a(0L, a2.d)) + ")";
        return a4;
    }

    public Pointer a() {
        NativeString a2;
        return a2.v;
    }

    @Override
    public char charAt(int a2) {
        NativeString a3;
        return a3.toString().charAt(a2);
    }

    @Override
    public int length() {
        NativeString a2;
        return a2.toString().length();
    }

    @Override
    public CharSequence subSequence(int a2, int a3) {
        NativeString a4;
        return CharBuffer.wrap(a4.toString()).subSequence(a2, a3);
    }

    public int compareTo(Object a2) {
        NativeString a3;
        if (a2 == null) {
            return 1;
        }
        return a3.toString().compareTo(a2.toString());
    }

    private class StringMemory
    extends Memory {
        public StringMemory(long a2) {
            StringMemory a3;
            super(a2);
        }

        @Override
        public String toString() {
            StringMemory a2;
            return a2.NativeString.this.toString();
        }
    }
}

