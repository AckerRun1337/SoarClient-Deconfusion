/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.FromNativeContext;
import com.sun.jna.NativeMapped;

public abstract class IntegerType
extends Number
implements NativeMapped {
    private static final long l = 1L;
    private int b;
    private Number c;
    private boolean v;
    private long d;

    public IntegerType(int a2) {
        a3(a2, 0L, false);
        IntegerType a3;
    }

    public IntegerType(int a2, boolean a3) {
        a4(a2, 0L, a3);
        IntegerType a4;
    }

    public IntegerType(int a2, long a3) {
        a4(a2, a3, false);
        IntegerType a4;
    }

    public IntegerType(int a2, long a3, boolean a4) {
        IntegerType a5;
        a5.b = a2;
        a5.v = a4;
        a5.a(a3);
    }

    public void a(long a2) {
        IntegerType a3;
        long a4 = a2;
        a3.d = a2;
        switch (a3.b) {
            case 1: {
                if (a3.v) {
                    a3.d = a2 & 0xFFL;
                }
                a4 = (byte)a2;
                a3.c = (byte)a2;
                break;
            }
            case 2: {
                if (a3.v) {
                    a3.d = a2 & 0xFFFFL;
                }
                a4 = (short)a2;
                a3.c = (short)a2;
                break;
            }
            case 4: {
                if (a3.v) {
                    a3.d = a2 & 0xFFFFFFFFL;
                }
                a4 = (int)a2;
                a3.c = (int)a2;
                break;
            }
            case 8: {
                a3.c = a2;
                break;
            }
            default: {
                throw new IllegalArgumentException("Unsupported size: " + a3.b);
            }
        }
        if (a3.b < 8) {
            long a5 = (1L << a3.b * 8) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
            if (a2 < 0L && a4 != a2 || a2 >= 0L && (a5 & a2) != 0L) {
                throw new IllegalArgumentException("Argument value 0x" + Long.toHexString(a2) + " exceeds native capacity (" + a3.b + " bytes) mask=0x" + Long.toHexString(a5));
            }
        }
    }

    @Override
    public Object a() {
        IntegerType a2;
        return a2.c;
    }

    @Override
    public Object a(Object a2, FromNativeContext a3) {
        IntegerType a4;
        long a5 = a2 == null ? 0L : ((Number)a2).longValue();
        try {
            IntegerType a6 = (IntegerType)a4.getClass().newInstance();
            a6.a(a5);
            return a6;
        }
        catch (InstantiationException a7) {
            throw new IllegalArgumentException("Can't instantiate " + a4.getClass());
        }
        catch (IllegalAccessException a8) {
            throw new IllegalArgumentException("Not allowed to instantiate " + a4.getClass());
        }
    }

    @Override
    public Class<?> a() {
        IntegerType a2;
        return a2.c.getClass();
    }

    @Override
    public int intValue() {
        IntegerType a2;
        return (int)a2.d;
    }

    @Override
    public long longValue() {
        IntegerType a2;
        return a2.d;
    }

    @Override
    public float floatValue() {
        IntegerType a2;
        return a2.c.floatValue();
    }

    @Override
    public double doubleValue() {
        IntegerType a2;
        return a2.c.doubleValue();
    }

    public boolean equals(Object a2) {
        IntegerType a3;
        return a2 instanceof IntegerType && a3.c.equals(((IntegerType)a2).c);
    }

    public String toString() {
        IntegerType a2;
        return a2.c.toString();
    }

    public int hashCode() {
        IntegerType a2;
        return a2.c.hashCode();
    }

    public static <T extends IntegerType> int a(T a2, T a3) {
        if (a2 == a3) {
            return 0;
        }
        if (a2 == null) {
            return 1;
        }
        if (a3 == null) {
            return -1;
        }
        return IntegerType.a(a2.longValue(), a3.longValue());
    }

    public static int a(IntegerType a2, long a3) {
        if (a2 == null) {
            return 1;
        }
        return IntegerType.a(a2.longValue(), a3);
    }

    public static final int a(long a2, long a3) {
        if (a2 == a3) {
            return 0;
        }
        if (a2 < a3) {
            return -1;
        }
        return 1;
    }
}

