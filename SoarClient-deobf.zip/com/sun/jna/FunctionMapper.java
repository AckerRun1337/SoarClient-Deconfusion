/*
 * Decompiled with CFR 0.152.
 */
package com.sun.jna;

import com.sun.jna.NativeLibrary;
import java.lang.reflect.Method;

public interface FunctionMapper {
    public String a(NativeLibrary var1, Method var2);
}

