/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.internal.LazilyParsedNumber;
import java.math.BigDecimal;
import java.math.BigInteger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JsonPrimitive
extends JsonElement {
    private final Object d;

    public JsonPrimitive(Boolean a2) {
        JsonPrimitive a3;
        a3.d = $Gson$Preconditions.a(a2);
    }

    public JsonPrimitive(Number a2) {
        JsonPrimitive a3;
        a3.d = $Gson$Preconditions.a(a2);
    }

    public JsonPrimitive(String a2) {
        JsonPrimitive a3;
        a3.d = $Gson$Preconditions.a(a2);
    }

    public JsonPrimitive(Character a2) {
        JsonPrimitive a3;
        a3.d = $Gson$Preconditions.a(a2).toString();
    }

    public JsonPrimitive p() {
        JsonPrimitive a2;
        return a2;
    }

    public boolean h() {
        JsonPrimitive a2;
        return a2.d instanceof Boolean;
    }

    @Override
    public boolean a() {
        JsonPrimitive a2;
        if (a2.h()) {
            return (Boolean)a2.d;
        }
        return Boolean.parseBoolean(a2.a());
    }

    public boolean x() {
        JsonPrimitive a2;
        return a2.d instanceof Number;
    }

    @Override
    public Number a() {
        JsonPrimitive a2;
        return a2.d instanceof String ? new LazilyParsedNumber((String)a2.d) : (Number)a2.d;
    }

    public boolean j() {
        JsonPrimitive a2;
        return a2.d instanceof String;
    }

    @Override
    public String a() {
        JsonPrimitive a2;
        if (a2.x()) {
            return a2.a().toString();
        }
        if (a2.h()) {
            return ((Boolean)a2.d).toString();
        }
        return (String)a2.d;
    }

    @Override
    public double a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().doubleValue() : Double.parseDouble(a2.a());
    }

    @Override
    public BigDecimal a() {
        JsonPrimitive a2;
        return a2.d instanceof BigDecimal ? (BigDecimal)a2.d : new BigDecimal(a2.d.toString());
    }

    @Override
    public BigInteger a() {
        JsonPrimitive a2;
        return a2.d instanceof BigInteger ? (BigInteger)a2.d : new BigInteger(a2.d.toString());
    }

    @Override
    public float a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().floatValue() : Float.parseFloat(a2.a());
    }

    @Override
    public long a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().longValue() : Long.parseLong(a2.a());
    }

    @Override
    public short a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().shortValue() : Short.parseShort(a2.a());
    }

    @Override
    public int a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().intValue() : Integer.parseInt(a2.a());
    }

    @Override
    public byte a() {
        JsonPrimitive a2;
        return a2.x() ? a2.a().byteValue() : Byte.parseByte(a2.a());
    }

    @Override
    public char a() {
        JsonPrimitive a2;
        return a2.a().charAt(0);
    }

    public int hashCode() {
        JsonPrimitive a2;
        if (a2.d == null) {
            return 31;
        }
        if (JsonPrimitive.a(a2)) {
            long a3 = a2.a().longValue();
            return (int)(a3 ^ a3 >>> 32);
        }
        if (a2.d instanceof Number) {
            long a4 = Double.doubleToLongBits(a2.a().doubleValue());
            return (int)(a4 ^ a4 >>> 32);
        }
        return a2.d.hashCode();
    }

    public boolean equals(Object a2) {
        JsonPrimitive a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 == null || a3.getClass() != a2.getClass()) {
            return false;
        }
        JsonPrimitive a4 = (JsonPrimitive)a2;
        if (a3.d == null) {
            return a4.d == null;
        }
        if (JsonPrimitive.a(a3) && JsonPrimitive.a(a4)) {
            return a3.a().longValue() == a4.a().longValue();
        }
        if (a3.d instanceof Number && a4.d instanceof Number) {
            double a5;
            double a6 = a3.a().doubleValue();
            return a6 == (a5 = a4.a().doubleValue()) || Double.isNaN(a6) && Double.isNaN(a5);
        }
        return a3.d.equals(a4.d);
    }

    private static /* synthetic */ boolean a(JsonPrimitive a2) {
        if (a2.d instanceof Number) {
            Number a3 = (Number)a2.d;
            return a3 instanceof BigInteger || a3 instanceof Long || a3 instanceof Integer || a3 instanceof Short || a3 instanceof Byte;
        }
        return false;
    }
}

