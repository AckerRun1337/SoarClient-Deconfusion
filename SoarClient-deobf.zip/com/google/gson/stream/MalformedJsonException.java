/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.stream;

import java.io.IOException;

public final class MalformedJsonException
extends IOException {
    private static final long d = 1L;

    public MalformedJsonException(String a2) {
        super(a2);
        MalformedJsonException a3;
    }

    public MalformedJsonException(String a2, Throwable a3) {
        super(a2);
        MalformedJsonException a4;
        a4.initCause(a3);
    }

    public MalformedJsonException(Throwable a2) {
        MalformedJsonException a3;
        a3.initCause(a2);
    }
}

