/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.stream;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class JsonWriter
implements Closeable,
Flushable {
    private static final String[] n = new String[128];
    private static final String[] e;
    private final Writer r;
    private int[] f = new int[32];
    private int h = 0;
    private String z;
    private String l;
    private boolean b;
    private boolean c;
    private String v;
    private boolean d;

    public JsonWriter(Writer a2) {
        JsonWriter a3;
        a3.p(6);
        a3.l = ":";
        a3.d = true;
        if (a2 == null) {
            throw new NullPointerException("out == null");
        }
        a3.r = a2;
    }

    public final void p(String a2) {
        if (a2.length() == 0) {
            a.z = null;
            a.l = ":";
        } else {
            a.z = a2;
            a.l = ": ";
        }
    }

    public final void o(boolean a2) {
        a.b = a2;
    }

    public boolean o() {
        JsonWriter a2;
        return a2.b;
    }

    public final void p(boolean a2) {
        a.c = a2;
    }

    public final boolean p() {
        JsonWriter a2;
        return a2.c;
    }

    public final void a(boolean a2) {
        a.d = a2;
    }

    public final boolean a() {
        JsonWriter a2;
        return a2.d;
    }

    public JsonWriter z() throws IOException {
        JsonWriter a2;
        a2.y();
        return a2.a(1, '[');
    }

    public JsonWriter y() throws IOException {
        JsonWriter a2;
        return a2.a(1, 2, ']');
    }

    public JsonWriter o() throws IOException {
        JsonWriter a2;
        a2.y();
        return a2.a(3, '{');
    }

    public JsonWriter p() throws IOException {
        JsonWriter a2;
        return a2.a(3, 5, '}');
    }

    private /* synthetic */ JsonWriter a(int a2, char a3) throws IOException {
        JsonWriter a4;
        a4.a();
        a4.p(a2);
        a4.r.write(a3);
        return a4;
    }

    private /* synthetic */ JsonWriter a(int a2, int a3, char a4) throws IOException {
        JsonWriter a5;
        int a6 = a5.a();
        if (a6 != a3 && a6 != a2) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (a5.v != null) {
            throw new IllegalStateException("Dangling name: " + a5.v);
        }
        --a5.h;
        if (a6 == a3) {
            a5.o();
        }
        a5.r.write(a4);
        return a5;
    }

    private /* synthetic */ void p(int a2) {
        JsonWriter a3;
        if (a3.h == a3.f.length) {
            a3.f = Arrays.copyOf(a3.f, a3.h * 2);
        }
        a3.f[a3.h++] = a2;
    }

    private /* synthetic */ int a() {
        JsonWriter a2;
        if (a2.h == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        return a2.f[a2.h - 1];
    }

    private /* synthetic */ void a(int a2) {
        a.f[a.h - 1] = a2;
    }

    public JsonWriter o(String a2) throws IOException {
        JsonWriter a3;
        if (a2 == null) {
            throw new NullPointerException("name == null");
        }
        if (a3.v != null) {
            throw new IllegalStateException();
        }
        if (a3.h == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        a3.v = a2;
        return a3;
    }

    private /* synthetic */ void y() throws IOException {
        JsonWriter a2;
        if (a2.v != null) {
            a2.p();
            a2.a(a2.v);
            a2.v = null;
        }
    }

    public JsonWriter p(String a2) throws IOException {
        JsonWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.y();
        a3.a();
        a3.a(a2);
        return a3;
    }

    public JsonWriter a(String a2) throws IOException {
        JsonWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.y();
        a3.a();
        a3.r.append(a2);
        return a3;
    }

    public JsonWriter a() throws IOException {
        JsonWriter a2;
        if (a2.v != null) {
            if (a2.d) {
                a2.y();
            } else {
                a2.v = null;
                return a2;
            }
        }
        a2.a();
        a2.r.write("null");
        return a2;
    }

    public JsonWriter a(boolean a2) throws IOException {
        JsonWriter a3;
        a3.y();
        a3.a();
        a3.r.write(a2 ? "true" : "false");
        return a3;
    }

    public JsonWriter a(Boolean a2) throws IOException {
        JsonWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.y();
        a3.a();
        a3.r.write(a2 != false ? "true" : "false");
        return a3;
    }

    public JsonWriter a(double a2) throws IOException {
        JsonWriter a3;
        a3.y();
        if (!a3.b && (Double.isNaN(a2) || Double.isInfinite(a2))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + a2);
        }
        a3.a();
        a3.r.append(Double.toString(a2));
        return a3;
    }

    public JsonWriter a(long a2) throws IOException {
        JsonWriter a3;
        a3.y();
        a3.a();
        a3.r.write(Long.toString(a2));
        return a3;
    }

    public JsonWriter a(Number a2) throws IOException {
        JsonWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.y();
        String a4 = a2.toString();
        if (!a3.b && (a4.equals("-Infinity") || a4.equals("Infinity") || a4.equals("NaN"))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + a2);
        }
        a3.a();
        a3.r.append(a4);
        return a3;
    }

    @Override
    public void flush() throws IOException {
        JsonWriter a2;
        if (a2.h == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        a2.r.flush();
    }

    @Override
    public void close() throws IOException {
        JsonWriter a2;
        a2.r.close();
        int a3 = a2.h;
        if (a3 > 1 || a3 == 1 && a2.f[a3 - 1] != 7) {
            throw new IOException("Incomplete document");
        }
        a2.h = 0;
    }

    private /* synthetic */ void a(String a2) throws IOException {
        JsonWriter a3;
        String[] a4 = a3.c ? e : n;
        a3.r.write(34);
        int a5 = 0;
        int a6 = a2.length();
        for (int a7 = 0; a7 < a6; ++a7) {
            String a8;
            char a9 = a2.charAt(a7);
            if (a9 < '\u0080') {
                a8 = a4[a9];
                if (a8 == null) {
                    continue;
                }
            } else if (a9 == '\u2028') {
                a8 = "\\u2028";
            } else {
                if (a9 != '\u2029') continue;
                a8 = "\\u2029";
            }
            if (a5 < a7) {
                a3.r.write(a2, a5, a7 - a5);
            }
            a3.r.write(a8);
            a5 = a7 + 1;
        }
        if (a5 < a6) {
            a3.r.write(a2, a5, a6 - a5);
        }
        a3.r.write(34);
    }

    private /* synthetic */ void o() throws IOException {
        JsonWriter a2;
        if (a2.z == null) {
            return;
        }
        a2.r.write(10);
        int a3 = a2.h;
        for (int a4 = 1; a4 < a3; ++a4) {
            a2.r.write(a2.z);
        }
    }

    private /* synthetic */ void p() throws IOException {
        JsonWriter a2;
        int a3 = a2.a();
        if (a3 == 5) {
            a2.r.write(44);
        } else if (a3 != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        a2.o();
        a2.a(4);
    }

    private /* synthetic */ void a() throws IOException {
        JsonWriter a2;
        switch (a2.a()) {
            case 7: {
                if (!a2.b) {
                    throw new IllegalStateException("JSON must have only one top-level value.");
                }
            }
            case 6: {
                a2.a(7);
                break;
            }
            case 1: {
                a2.a(2);
                a2.o();
                break;
            }
            case 2: {
                a2.r.append(',');
                a2.o();
                break;
            }
            case 4: {
                a2.r.append(a2.l);
                a2.a(5);
                break;
            }
            default: {
                throw new IllegalStateException("Nesting problem.");
            }
        }
    }

    static {
        for (int a2 = 0; a2 <= 31; ++a2) {
            JsonWriter.n[a2] = String.format("\\u%04x", a2);
        }
        JsonWriter.n[34] = "\\\"";
        JsonWriter.n[92] = "\\\\";
        JsonWriter.n[9] = "\\t";
        JsonWriter.n[8] = "\\b";
        JsonWriter.n[10] = "\\n";
        JsonWriter.n[13] = "\\r";
        JsonWriter.n[12] = "\\f";
        e = (String[])n.clone();
        JsonWriter.e[60] = "\\u003c";
        JsonWriter.e[62] = "\\u003e";
        JsonWriter.e[38] = "\\u0026";
        JsonWriter.e[61] = "\\u003d";
        JsonWriter.e[39] = "\\u0027";
    }
}

