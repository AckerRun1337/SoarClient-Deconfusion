/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.stream;

final class JsonScope {
    static final int f = 1;
    static final int h = 2;
    static final int z = 3;
    static final int l = 4;
    static final int b = 5;
    static final int c = 6;
    static final int v = 7;
    static final int d = 8;

    JsonScope() {
        JsonScope a2;
    }
}

