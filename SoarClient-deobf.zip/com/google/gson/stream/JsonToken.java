/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.stream;

public enum JsonToken {
    n,
    e,
    r,
    f,
    h,
    z,
    l,
    b,
    c,
    v;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private /* synthetic */ JsonToken() {
        JsonToken a2;
    }
}

