/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.stream;

import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.bind.JsonTreeReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class JsonReader
implements Closeable {
    private static final char[] xa = ")]}'\n".toCharArray();
    private static final long ua = -922337203685477580L;
    private static final int da = 0;
    private static final int ma = 1;
    private static final int na = 2;
    private static final int ka = 3;
    private static final int ha = 4;
    private static final int ya = 5;
    private static final int ca = 6;
    private static final int ga = 7;
    private static final int ja = 8;
    private static final int ia = 9;
    private static final int ta = 10;
    private static final int oa = 11;
    private static final int pa = 12;
    private static final int ba = 13;
    private static final int la = 14;
    private static final int u = 15;
    private static final int j = 16;
    private static final int o = 17;
    private static final int m = 0;
    private static final int y = 1;
    private static final int a = 2;
    private static final int q = 3;
    private static final int g = 4;
    private static final int k = 5;
    private static final int x = 6;
    private static final int t = 7;
    private final Reader p;
    private boolean s = false;
    private final char[] w = new char[1024];
    private int i = 0;
    private int n = 0;
    private int e = 0;
    private int r = 0;
    int f = 0;
    private long h;
    private int z;
    private String l;
    private int[] b = new int[32];
    private int c = 0;
    private String[] v;
    private int[] d;

    public JsonReader(Reader a2) {
        JsonReader a3;
        a3.b[a3.c++] = 6;
        a3.v = new String[32];
        a3.d = new int[32];
        if (a2 == null) {
            throw new NullPointerException("in == null");
        }
        a3.p = a2;
    }

    public final void a(boolean a2) {
        a.s = a2;
    }

    public final boolean o() {
        JsonReader a2;
        return a2.s;
    }

    public void d() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 != 3) {
            throw new IllegalStateException("Expected BEGIN_ARRAY but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.a(1);
        a2.d[a2.c - 1] = 0;
        a2.f = 0;
    }

    public void m() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 4) {
            --a2.c;
        } else {
            throw new IllegalStateException("Expected END_ARRAY but was " + (Object)((Object)a2.a()) + a2.p());
        }
        int n2 = a2.c - 1;
        a2.d[n2] = a2.d[n2] + 1;
        a2.f = 0;
    }

    public void h() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 != 1) {
            throw new IllegalStateException("Expected BEGIN_OBJECT but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.a(3);
        a2.f = 0;
    }

    public void x() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 2) {
            --a2.c;
        } else {
            throw new IllegalStateException("Expected END_OBJECT but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.v[a2.c] = null;
        int n2 = a2.c - 1;
        a2.d[n2] = a2.d[n2] + 1;
        a2.f = 0;
    }

    public boolean p() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        return a3 != 2 && a3 != 4;
    }

    public JsonToken a() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        switch (a3) {
            case 1: {
                return JsonToken.r;
            }
            case 2: {
                return JsonToken.f;
            }
            case 3: {
                return JsonToken.n;
            }
            case 4: {
                return JsonToken.e;
            }
            case 12: 
            case 13: 
            case 14: {
                return JsonToken.h;
            }
            case 5: 
            case 6: {
                return JsonToken.b;
            }
            case 7: {
                return JsonToken.c;
            }
            case 8: 
            case 9: 
            case 10: 
            case 11: {
                return JsonToken.z;
            }
            case 15: 
            case 16: {
                return JsonToken.l;
            }
            case 17: {
                return JsonToken.v;
            }
        }
        throw new AssertionError();
    }

    int y() throws IOException {
        int a2;
        int a3;
        JsonReader a4;
        block45: {
            block47: {
                block46: {
                    block44: {
                        a3 = a4.b[a4.c - 1];
                        if (a3 != 1) break block44;
                        a4.b[a4.c - 1] = 2;
                        break block45;
                    }
                    if (a3 != 2) break block46;
                    a2 = a4.a(true);
                    switch (a2) {
                        case 93: {
                            a4.f = 4;
                            return 4;
                        }
                        case 59: {
                            a4.o();
                        }
                        case 44: {
                            break;
                        }
                        default: {
                            throw a4.a("Unterminated array");
                        }
                    }
                    break block45;
                }
                if (a3 == 3 || a3 == 5) {
                    int a5;
                    a4.b[a4.c - 1] = 4;
                    if (a3 == 5) {
                        a5 = a4.a(true);
                        switch (a5) {
                            case 125: {
                                a4.f = 2;
                                return 2;
                            }
                            case 59: {
                                a4.o();
                            }
                            case 44: {
                                break;
                            }
                            default: {
                                throw a4.a("Unterminated object");
                            }
                        }
                    }
                    a5 = a4.a(true);
                    switch (a5) {
                        case 34: {
                            a4.f = 13;
                            return 13;
                        }
                        case 39: {
                            a4.o();
                            a4.f = 12;
                            return 12;
                        }
                        case 125: {
                            if (a3 != 5) {
                                a4.f = 2;
                                return 2;
                            }
                            throw a4.a("Expected name");
                        }
                    }
                    a4.o();
                    --a4.i;
                    if (a4.a((char)a5)) {
                        a4.f = 14;
                        return 14;
                    }
                    throw a4.a("Expected name");
                }
                if (a3 != 4) break block47;
                a4.b[a4.c - 1] = 5;
                a2 = a4.a(true);
                switch (a2) {
                    case 58: {
                        break;
                    }
                    case 61: {
                        a4.o();
                        if ((a4.i < a4.n || a4.a(1)) && a4.w[a4.i] == '>') {
                            ++a4.i;
                            break;
                        }
                        break block45;
                    }
                    default: {
                        throw a4.a("Expected ':'");
                    }
                }
                break block45;
            }
            if (a3 == 6) {
                if (a4.s) {
                    a4.a();
                }
                a4.b[a4.c - 1] = 7;
            } else if (a3 == 7) {
                a2 = a4.a(false);
                if (a2 == -1) {
                    a4.f = 17;
                    return 17;
                }
                a4.o();
                --a4.i;
            } else if (a3 == 8) {
                throw new IllegalStateException("JsonReader is closed");
            }
        }
        a2 = a4.a(true);
        switch (a2) {
            case 93: {
                if (a3 == 1) {
                    a4.f = 4;
                    return 4;
                }
            }
            case 44: 
            case 59: {
                if (a3 == 1 || a3 == 2) {
                    a4.o();
                    --a4.i;
                    a4.f = 7;
                    return 7;
                }
                throw a4.a("Unexpected value");
            }
            case 39: {
                a4.o();
                a4.f = 8;
                return 8;
            }
            case 34: {
                a4.f = 9;
                return 9;
            }
            case 91: {
                a4.f = 3;
                return 3;
            }
            case 123: {
                a4.f = 1;
                return 1;
            }
        }
        --a4.i;
        int a6 = a4.o();
        if (a6 != 0) {
            return a6;
        }
        a6 = a4.p();
        if (a6 != 0) {
            return a6;
        }
        if (!a4.a(a4.w[a4.i])) {
            throw a4.a("Expected value");
        }
        a4.o();
        a4.f = 10;
        return 10;
    }

    private /* synthetic */ int o() throws IOException {
        int a2;
        String a3;
        String a4;
        JsonReader a5;
        char a6 = a5.w[a5.i];
        if (a6 == 't' || a6 == 'T') {
            a4 = "true";
            a3 = "TRUE";
            a2 = 5;
        } else if (a6 == 'f' || a6 == 'F') {
            a4 = "false";
            a3 = "FALSE";
            a2 = 6;
        } else if (a6 == 'n' || a6 == 'N') {
            a4 = "null";
            a3 = "NULL";
            a2 = 7;
        } else {
            return 0;
        }
        int a7 = a4.length();
        for (int a8 = 1; a8 < a7; ++a8) {
            if (a5.i + a8 >= a5.n && !a5.a(a8 + 1)) {
                return 0;
            }
            a6 = a5.w[a5.i + a8];
            if (a6 == a4.charAt(a8) || a6 == a3.charAt(a8)) continue;
            return 0;
        }
        if ((a5.i + a7 < a5.n || a5.a(a7 + 1)) && a5.a(a5.w[a5.i + a7])) {
            return 0;
        }
        a5.i += a7;
        a5.f = a2;
        return a5.f;
    }

    private /* synthetic */ int p() throws IOException {
        JsonReader a2;
        char[] a3 = a2.w;
        int a4 = a2.i;
        int a5 = a2.n;
        long a6 = 0L;
        boolean a7 = false;
        boolean a8 = true;
        int a9 = 0;
        int a10 = 0;
        block6: while (true) {
            if (a4 + a10 == a5) {
                if (a10 == a3.length) {
                    return 0;
                }
                if (!a2.a(a10 + 1)) break;
                a4 = a2.i;
                a5 = a2.n;
            }
            char a11 = a3[a4 + a10];
            switch (a11) {
                case '-': {
                    if (a9 == 0) {
                        a7 = true;
                        a9 = 1;
                        break;
                    }
                    if (a9 == 5) {
                        a9 = 6;
                        break;
                    }
                    return 0;
                }
                case '+': {
                    if (a9 == 5) {
                        a9 = 6;
                        break;
                    }
                    return 0;
                }
                case 'E': 
                case 'e': {
                    if (a9 == 2 || a9 == 4) {
                        a9 = 5;
                        break;
                    }
                    return 0;
                }
                case '.': {
                    if (a9 == 2) {
                        a9 = 3;
                        break;
                    }
                    return 0;
                }
                default: {
                    if (a11 < '0' || a11 > '9') {
                        if (!a2.a(a11)) break block6;
                        return 0;
                    }
                    if (a9 == 1 || a9 == 0) {
                        a6 = -(a11 - 48);
                        a9 = 2;
                        break;
                    }
                    if (a9 == 2) {
                        if (a6 == 0L) {
                            return 0;
                        }
                        long a12 = a6 * 10L - (long)(a11 - 48);
                        a8 &= a6 > -922337203685477580L || a6 == -922337203685477580L && a12 < a6;
                        a6 = a12;
                        break;
                    }
                    if (a9 == 3) {
                        a9 = 4;
                        break;
                    }
                    if (a9 != 5 && a9 != 6) break;
                    a9 = 7;
                }
            }
            ++a10;
        }
        if (!(a9 != 2 || !a8 || a6 == Long.MIN_VALUE && !a7 || a6 == 0L && a7)) {
            a2.h = a7 ? a6 : -a6;
            a2.i += a10;
            a2.f = 15;
            return 15;
        }
        if (a9 == 2 || a9 == 4 || a9 == 7) {
            a2.z = a10;
            a2.f = 16;
            return 16;
        }
        return 0;
    }

    private /* synthetic */ boolean a(char a2) throws IOException {
        switch (a2) {
            case '#': 
            case '/': 
            case ';': 
            case '=': 
            case '\\': {
                JsonReader a3;
                a3.o();
            }
            case '\t': 
            case '\n': 
            case '\f': 
            case '\r': 
            case ' ': 
            case ',': 
            case ':': 
            case '[': 
            case ']': 
            case '{': 
            case '}': {
                return false;
            }
        }
        return true;
    }

    public String z() throws IOException {
        String a2;
        JsonReader a3;
        int a4 = a3.f;
        if (a4 == 0) {
            a4 = a3.y();
        }
        if (a4 == 14) {
            a2 = a3.o();
        } else if (a4 == 12) {
            a2 = a3.a('\'');
        } else if (a4 == 13) {
            a2 = a3.a('\"');
        } else {
            throw new IllegalStateException("Expected a name but was " + (Object)((Object)a3.a()) + a3.p());
        }
        a3.f = 0;
        a3.v[a3.c - 1] = a2;
        return a2;
    }

    public String y() throws IOException {
        String a2;
        JsonReader a3;
        int a4 = a3.f;
        if (a4 == 0) {
            a4 = a3.y();
        }
        if (a4 == 10) {
            a2 = a3.o();
        } else if (a4 == 8) {
            a2 = a3.a('\'');
        } else if (a4 == 9) {
            a2 = a3.a('\"');
        } else if (a4 == 11) {
            a2 = a3.l;
            a3.l = null;
        } else if (a4 == 15) {
            a2 = Long.toString(a3.h);
        } else if (a4 == 16) {
            a2 = new String(a3.w, a3.i, a3.z);
            a3.i += a3.z;
        } else {
            throw new IllegalStateException("Expected a string but was " + (Object)((Object)a3.a()) + a3.p());
        }
        a3.f = 0;
        int n2 = a3.c - 1;
        a3.d[n2] = a3.d[n2] + 1;
        return a2;
    }

    public boolean a() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 5) {
            a2.f = 0;
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
            return true;
        }
        if (a3 == 6) {
            a2.f = 0;
            int n3 = a2.c - 1;
            a2.d[n3] = a2.d[n3] + 1;
            return false;
        }
        throw new IllegalStateException("Expected a boolean but was " + (Object)((Object)a2.a()) + a2.p());
    }

    public void j() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 != 7) {
            throw new IllegalStateException("Expected null but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.f = 0;
        int n2 = a2.c - 1;
        a2.d[n2] = a2.d[n2] + 1;
    }

    public double a() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 15) {
            a2.f = 0;
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
            return a2.h;
        }
        if (a3 == 16) {
            a2.l = new String(a2.w, a2.i, a2.z);
            a2.i += a2.z;
        } else if (a3 == 8 || a3 == 9) {
            a2.l = a2.a(a3 == 8 ? (char)'\'' : '\"');
        } else if (a3 == 10) {
            a2.l = a2.o();
        } else if (a3 != 11) {
            throw new IllegalStateException("Expected a double but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.f = 11;
        double a4 = Double.parseDouble(a2.l);
        if (!a2.s && (Double.isNaN(a4) || Double.isInfinite(a4))) {
            throw new MalformedJsonException("JSON forbids NaN and infinities: " + a4 + a2.p());
        }
        a2.l = null;
        a2.f = 0;
        int n3 = a2.c - 1;
        a2.d[n3] = a2.d[n3] + 1;
        return a4;
    }

    public long a() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 15) {
            a2.f = 0;
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
            return a2.h;
        }
        if (a3 == 16) {
            a2.l = new String(a2.w, a2.i, a2.z);
            a2.i += a2.z;
        } else if (a3 == 8 || a3 == 9 || a3 == 10) {
            a2.l = a3 == 10 ? a2.o() : a2.a(a3 == 8 ? (char)'\'' : '\"');
            try {
                long a4 = Long.parseLong(a2.l);
                a2.f = 0;
                int n3 = a2.c - 1;
                a2.d[n3] = a2.d[n3] + 1;
                return a4;
            }
            catch (NumberFormatException a4) {}
        } else {
            throw new IllegalStateException("Expected a long but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.f = 11;
        double a5 = Double.parseDouble(a2.l);
        long a6 = (long)a5;
        if ((double)a6 != a5) {
            throw new NumberFormatException("Expected a long but was " + a2.l + a2.p());
        }
        a2.l = null;
        a2.f = 0;
        int n4 = a2.c - 1;
        a2.d[n4] = a2.d[n4] + 1;
        return a6;
    }

    private /* synthetic */ String a(char a2) throws IOException {
        JsonReader a3;
        char[] a4 = a3.w;
        StringBuilder a5 = null;
        do {
            int a6;
            int a7 = a3.i;
            int a8 = a3.n;
            int a9 = a7;
            while (a7 < a8) {
                int a10;
                if ((a6 = a4[a7++]) == a2) {
                    a3.i = a7;
                    a10 = a7 - a9 - 1;
                    if (a5 == null) {
                        return new String(a4, a9, a10);
                    }
                    a5.append(a4, a9, a10);
                    return a5.toString();
                }
                if (a6 == 92) {
                    a3.i = a7;
                    a10 = a7 - a9 - 1;
                    if (a5 == null) {
                        int a11 = (a10 + 1) * 2;
                        a5 = new StringBuilder(Math.max(a11, 16));
                    }
                    a5.append(a4, a9, a10);
                    a5.append(a3.a());
                    a7 = a3.i;
                    a8 = a3.n;
                    a9 = a7;
                    continue;
                }
                if (a6 != 10) continue;
                ++a3.e;
                a3.r = a7;
            }
            if (a5 == null) {
                a6 = (a7 - a9) * 2;
                a5 = new StringBuilder(Math.max(a6, 16));
            }
            a5.append(a4, a9, a7 - a9);
            a3.i = a7;
        } while (a3.a(1));
        throw a3.a("Unterminated string");
    }

    private /* synthetic */ String o() throws IOException {
        JsonReader a2;
        StringBuilder a3 = null;
        int a4 = 0;
        block4: while (true) {
            if (a2.i + a4 < a2.n) {
                switch (a2.w[a2.i + a4]) {
                    case '#': 
                    case '/': 
                    case ';': 
                    case '=': 
                    case '\\': {
                        a2.o();
                    }
                    case '\t': 
                    case '\n': 
                    case '\f': 
                    case '\r': 
                    case ' ': 
                    case ',': 
                    case ':': 
                    case '[': 
                    case ']': 
                    case '{': 
                    case '}': {
                        break block4;
                    }
                    default: {
                        ++a4;
                        break;
                    }
                }
                continue;
            }
            if (a4 < a2.w.length) {
                if (!a2.a(a4 + 1)) break;
                continue;
            }
            if (a3 == null) {
                a3 = new StringBuilder(Math.max(a4, 16));
            }
            a3.append(a2.w, a2.i, a4);
            a2.i += a4;
            a4 = 0;
            if (!a2.a(1)) break;
        }
        String a5 = null == a3 ? new String(a2.w, a2.i, a4) : a3.append(a2.w, a2.i, a4).toString();
        a2.i += a4;
        return a5;
    }

    private /* synthetic */ void a(char a2) throws IOException {
        JsonReader a3;
        char[] a4 = a3.w;
        do {
            int a5 = a3.i;
            int a6 = a3.n;
            while (a5 < a6) {
                char a7;
                if ((a7 = a4[a5++]) == a2) {
                    a3.i = a5;
                    return;
                }
                if (a7 == '\\') {
                    a3.i = a5;
                    a3.a();
                    a5 = a3.i;
                    a6 = a3.n;
                    continue;
                }
                if (a7 != '\n') continue;
                ++a3.e;
                a3.r = a5;
            }
            a3.i = a5;
        } while (a3.a(1));
        throw a3.a("Unterminated string");
    }

    private /* synthetic */ void z() throws IOException {
        JsonReader a2;
        do {
            int a3 = 0;
            while (a2.i + a3 < a2.n) {
                switch (a2.w[a2.i + a3]) {
                    case '#': 
                    case '/': 
                    case ';': 
                    case '=': 
                    case '\\': {
                        a2.o();
                    }
                    case '\t': 
                    case '\n': 
                    case '\f': 
                    case '\r': 
                    case ' ': 
                    case ',': 
                    case ':': 
                    case '[': 
                    case ']': 
                    case '{': 
                    case '}': {
                        a2.i += a3;
                        return;
                    }
                }
                ++a3;
            }
            a2.i += a3;
        } while (a2.a(1));
    }

    public int a() throws IOException {
        JsonReader a2;
        int a3 = a2.f;
        if (a3 == 0) {
            a3 = a2.y();
        }
        if (a3 == 15) {
            int a4 = (int)a2.h;
            if (a2.h != (long)a4) {
                throw new NumberFormatException("Expected an int but was " + a2.h + a2.p());
            }
            a2.f = 0;
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
            return a4;
        }
        if (a3 == 16) {
            a2.l = new String(a2.w, a2.i, a2.z);
            a2.i += a2.z;
        } else if (a3 == 8 || a3 == 9 || a3 == 10) {
            a2.l = a3 == 10 ? a2.o() : a2.a(a3 == 8 ? (char)'\'' : '\"');
            try {
                int a5 = Integer.parseInt(a2.l);
                a2.f = 0;
                int n3 = a2.c - 1;
                a2.d[n3] = a2.d[n3] + 1;
                return a5;
            }
            catch (NumberFormatException numberFormatException) {}
        } else {
            throw new IllegalStateException("Expected an int but was " + (Object)((Object)a2.a()) + a2.p());
        }
        a2.f = 11;
        double a6 = Double.parseDouble(a2.l);
        int a7 = (int)a6;
        if ((double)a7 != a6) {
            throw new NumberFormatException("Expected an int but was " + a2.l + a2.p());
        }
        a2.l = null;
        a2.f = 0;
        int n4 = a2.c - 1;
        a2.d[n4] = a2.d[n4] + 1;
        return a7;
    }

    @Override
    public void close() throws IOException {
        JsonReader a2;
        a2.f = 0;
        a2.b[0] = 8;
        a2.c = 1;
        a2.p.close();
    }

    public void y() throws IOException {
        JsonReader a2;
        int a3 = 0;
        do {
            int a4;
            if ((a4 = a2.f) == 0) {
                a4 = a2.y();
            }
            if (a4 == 3) {
                a2.a(1);
                ++a3;
            } else if (a4 == 1) {
                a2.a(3);
                ++a3;
            } else if (a4 == 4) {
                --a2.c;
                --a3;
            } else if (a4 == 2) {
                --a2.c;
                --a3;
            } else if (a4 == 14 || a4 == 10) {
                a2.z();
            } else if (a4 == 8 || a4 == 12) {
                a2.a('\'');
            } else if (a4 == 9 || a4 == 13) {
                a2.a('\"');
            } else if (a4 == 16) {
                a2.i += a2.z;
            }
            a2.f = 0;
        } while (a3 != 0);
        int n2 = a2.c - 1;
        a2.d[n2] = a2.d[n2] + 1;
        a2.v[a2.c - 1] = "null";
    }

    private /* synthetic */ void a(int a2) {
        JsonReader a3;
        if (a3.c == a3.b.length) {
            int a4 = a3.c * 2;
            a3.b = Arrays.copyOf(a3.b, a4);
            a3.d = Arrays.copyOf(a3.d, a4);
            a3.v = Arrays.copyOf(a3.v, a4);
        }
        a3.b[a3.c++] = a2;
    }

    private /* synthetic */ boolean a(int a2) throws IOException {
        int a3;
        JsonReader a4;
        char[] a5 = a4.w;
        a4.r -= a4.i;
        if (a4.n != a4.i) {
            a4.n -= a4.i;
            System.arraycopy(a5, a4.i, a5, 0, a4.n);
        } else {
            a4.n = 0;
        }
        a4.i = 0;
        while ((a3 = a4.p.read(a5, a4.n, a5.length - a4.n)) != -1) {
            a4.n += a3;
            if (a4.e == 0 && a4.r == 0 && a4.n > 0 && a5[0] == '\ufeff') {
                ++a4.i;
                ++a4.r;
                ++a2;
            }
            if (a4.n < a2) continue;
            return true;
        }
        return false;
    }

    private /* synthetic */ int a(boolean a2) throws IOException {
        JsonReader a3;
        block12: {
            char a4;
            char[] a5 = a3.w;
            int a6 = a3.i;
            int a7 = a3.n;
            block4: while (true) {
                if (a6 == a7) {
                    a3.i = a6;
                    if (!a3.a(1)) break block12;
                    a6 = a3.i;
                    a7 = a3.n;
                }
                if ((a4 = a5[a6++]) == '\n') {
                    ++a3.e;
                    a3.r = a6;
                    continue;
                }
                if (a4 == ' ' || a4 == '\r' || a4 == '\t') continue;
                if (a4 == '/') {
                    char a8;
                    a3.i = a6;
                    if (a6 == a7) {
                        --a3.i;
                        a8 = a3.a(2) ? '\u0001' : '\u0000';
                        ++a3.i;
                        if (a8 == '\u0000') {
                            return a4;
                        }
                    }
                    a3.o();
                    a8 = a5[a3.i];
                    switch (a8) {
                        case '*': {
                            ++a3.i;
                            if (!a3.a("*/")) {
                                throw a3.a("Unterminated comment");
                            }
                            a6 = a3.i + 2;
                            a7 = a3.n;
                            continue block4;
                        }
                        case '/': {
                            ++a3.i;
                            a3.p();
                            a6 = a3.i;
                            a7 = a3.n;
                            continue block4;
                        }
                    }
                    return a4;
                }
                if (a4 != '#') break;
                a3.i = a6;
                a3.o();
                a3.p();
                a6 = a3.i;
                a7 = a3.n;
            }
            a3.i = a6;
            return a4;
        }
        if (a2) {
            throw new EOFException("End of input" + a3.p());
        }
        return -1;
    }

    private /* synthetic */ void o() throws IOException {
        JsonReader a2;
        if (!a2.s) {
            throw a2.a("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    private /* synthetic */ void p() throws IOException {
        JsonReader a2;
        while (a2.i < a2.n || a2.a(1)) {
            char a3;
            if ((a3 = a2.w[a2.i++]) == '\n') {
                ++a2.e;
                a2.r = a2.i;
                break;
            }
            if (a3 != '\r') continue;
            break;
        }
    }

    private /* synthetic */ boolean a(String a2) throws IOException {
        JsonReader a3;
        int a4 = a2.length();
        while (a3.i + a4 <= a3.n || a3.a(a4)) {
            block5: {
                if (a3.w[a3.i] == '\n') {
                    ++a3.e;
                    a3.r = a3.i + 1;
                } else {
                    for (int a5 = 0; a5 < a4; ++a5) {
                        if (a3.w[a3.i + a5] == a2.charAt(a5)) {
                            continue;
                        }
                        break block5;
                    }
                    return true;
                }
            }
            ++a3.i;
        }
        return false;
    }

    public String toString() {
        JsonReader a2;
        return a2.getClass().getSimpleName() + a2.p();
    }

    String p() {
        JsonReader a2;
        int a3 = a2.e + 1;
        int a4 = a2.i - a2.r + 1;
        return " at line " + a3 + " column " + a4 + " path " + a2.a();
    }

    public String a() {
        JsonReader a2;
        StringBuilder a3 = new StringBuilder().append('$');
        int a4 = a2.c;
        block4: for (int a5 = 0; a5 < a4; ++a5) {
            switch (a2.b[a5]) {
                case 1: 
                case 2: {
                    a3.append('[').append(a2.d[a5]).append(']');
                    continue block4;
                }
                case 3: 
                case 4: 
                case 5: {
                    a3.append('.');
                    if (a2.v[a5] == null) continue block4;
                    a3.append(a2.v[a5]);
                    continue block4;
                }
            }
        }
        return a3.toString();
    }

    private /* synthetic */ char a() throws IOException {
        JsonReader a2;
        if (a2.i == a2.n && !a2.a(1)) {
            throw a2.a("Unterminated escape sequence");
        }
        char a3 = a2.w[a2.i++];
        switch (a3) {
            case 'u': {
                int a4;
                if (a2.i + 4 > a2.n && !a2.a(4)) {
                    throw a2.a("Unterminated escape sequence");
                }
                char a5 = '\u0000';
                int a6 = a4 + 4;
                for (a4 = a2.i; a4 < a6; ++a4) {
                    char a7 = a2.w[a4];
                    a5 = (char)(a5 << 4);
                    if (a7 >= '0' && a7 <= '9') {
                        a5 = (char)(a5 + (a7 - 48));
                        continue;
                    }
                    if (a7 >= 'a' && a7 <= 'f') {
                        a5 = (char)(a5 + (a7 - 97 + 10));
                        continue;
                    }
                    if (a7 >= 'A' && a7 <= 'F') {
                        a5 = (char)(a5 + (a7 - 65 + 10));
                        continue;
                    }
                    throw new NumberFormatException("\\u" + new String(a2.w, a2.i, 4));
                }
                a2.i += 4;
                return a5;
            }
            case 't': {
                return '\t';
            }
            case 'b': {
                return '\b';
            }
            case 'n': {
                return '\n';
            }
            case 'r': {
                return '\r';
            }
            case 'f': {
                return '\f';
            }
            case '\n': {
                ++a2.e;
                a2.r = a2.i;
            }
            case '\"': 
            case '\'': 
            case '/': 
            case '\\': {
                return a3;
            }
        }
        throw a2.a("Invalid escape sequence");
    }

    private /* synthetic */ IOException a(String a2) throws IOException {
        JsonReader a3;
        throw new MalformedJsonException(a2 + a3.p());
    }

    private /* synthetic */ void a() throws IOException {
        JsonReader a2;
        a2.a(true);
        --a2.i;
        if (a2.i + xa.length > a2.n && !a2.a(xa.length)) {
            return;
        }
        for (int a3 = 0; a3 < xa.length; ++a3) {
            if (a2.w[a2.i + a3] == xa[a3]) continue;
            return;
        }
        a2.i += xa.length;
    }

    static {
        JsonReaderInternalAccess.d = new JsonReaderInternalAccess(){
            {
                1 a2;
            }

            @Override
            public void a(JsonReader a2) throws IOException {
                if (a2 instanceof JsonTreeReader) {
                    ((JsonTreeReader)a2).a();
                    return;
                }
                int a3 = a2.f;
                if (a3 == 0) {
                    a3 = a2.y();
                }
                if (a3 == 13) {
                    a2.f = 9;
                } else if (a3 == 12) {
                    a2.f = 8;
                } else if (a3 == 14) {
                    a2.f = 10;
                } else {
                    throw new IllegalStateException("Expected a name but was " + (Object)((Object)a2.a()) + a2.p());
                }
            }
        };
    }
}

