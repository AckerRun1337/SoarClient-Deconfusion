/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.DefaultDateTypeAdapter;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonSerializer;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.bind.TreeTypeAdapter;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class GsonBuilder {
    private Excluder t;
    private LongSerializationPolicy p;
    private FieldNamingStrategy s;
    private final Map<Type, InstanceCreator<?>> w;
    private final List<TypeAdapterFactory> i;
    private final List<TypeAdapterFactory> n;
    private boolean e;
    private String r;
    private int f;
    private int h;
    private boolean z;
    private boolean l;
    private boolean b;
    private boolean c;
    private boolean v;
    private boolean d;

    public GsonBuilder() {
        GsonBuilder a2;
        a2.t = Excluder.h;
        a2.p = LongSerializationPolicy.c;
        a2.s = FieldNamingPolicy.h;
        a2.w = new HashMap();
        a2.i = new ArrayList<TypeAdapterFactory>();
        a2.n = new ArrayList<TypeAdapterFactory>();
        a2.e = false;
        a2.f = 2;
        a2.h = 2;
        a2.z = false;
        a2.l = false;
        a2.b = true;
        a2.c = false;
        a2.v = false;
        a2.d = false;
    }

    GsonBuilder(Gson a2) {
        GsonBuilder a3;
        a3.t = Excluder.h;
        a3.p = LongSerializationPolicy.c;
        a3.s = FieldNamingPolicy.h;
        a3.w = new HashMap();
        a3.i = new ArrayList<TypeAdapterFactory>();
        a3.n = new ArrayList<TypeAdapterFactory>();
        a3.e = false;
        a3.f = 2;
        a3.h = 2;
        a3.z = false;
        a3.l = false;
        a3.b = true;
        a3.c = false;
        a3.v = false;
        a3.d = false;
        a3.t = a2.t;
        a3.s = a2.p;
        a3.w.putAll(a2.s);
        a3.e = a2.w;
        a3.z = a2.i;
        a3.v = a2.n;
        a3.b = a2.e;
        a3.c = a2.r;
        a3.d = a2.f;
        a3.l = a2.h;
        a3.p = a2.c;
        a3.r = a2.z;
        a3.f = a2.l;
        a3.h = a2.b;
        a3.i.addAll(a2.v);
        a3.n.addAll(a2.d);
    }

    public GsonBuilder a(double a2) {
        GsonBuilder a3;
        a3.t = a3.t.a(a2);
        return a3;
    }

    public GsonBuilder a(int ... a2) {
        GsonBuilder a3;
        a3.t = a3.t.a(a2);
        return a3;
    }

    public GsonBuilder m() {
        GsonBuilder a2;
        a2.v = true;
        return a2;
    }

    public GsonBuilder h() {
        GsonBuilder a2;
        a2.t = a2.t.a();
        return a2;
    }

    public GsonBuilder x() {
        GsonBuilder a2;
        a2.e = true;
        return a2;
    }

    public GsonBuilder j() {
        GsonBuilder a2;
        a2.z = true;
        return a2;
    }

    public GsonBuilder z() {
        GsonBuilder a2;
        a2.t = a2.t.p();
        return a2;
    }

    public GsonBuilder a(LongSerializationPolicy a2) {
        GsonBuilder a3;
        a3.p = a2;
        return a3;
    }

    public GsonBuilder a(FieldNamingPolicy a2) {
        GsonBuilder a3;
        a3.s = a2;
        return a3;
    }

    public GsonBuilder a(FieldNamingStrategy a2) {
        GsonBuilder a3;
        a3.s = a2;
        return a3;
    }

    public GsonBuilder a(ExclusionStrategy ... a2) {
        GsonBuilder a3;
        for (ExclusionStrategy a4 : a2) {
            a3.t = a3.t.a(a4, true, true);
        }
        return a3;
    }

    public GsonBuilder p(ExclusionStrategy a2) {
        GsonBuilder a3;
        a3.t = a3.t.a(a2, true, false);
        return a3;
    }

    public GsonBuilder a(ExclusionStrategy a2) {
        GsonBuilder a3;
        a3.t = a3.t.a(a2, false, true);
        return a3;
    }

    public GsonBuilder y() {
        GsonBuilder a2;
        a2.c = true;
        return a2;
    }

    public GsonBuilder o() {
        GsonBuilder a2;
        a2.d = true;
        return a2;
    }

    public GsonBuilder p() {
        GsonBuilder a2;
        a2.b = false;
        return a2;
    }

    public GsonBuilder a(String a2) {
        GsonBuilder a3;
        a3.r = a2;
        return a3;
    }

    public GsonBuilder a(int a2) {
        GsonBuilder a3;
        a3.f = a2;
        a3.r = null;
        return a3;
    }

    public GsonBuilder a(int a2, int a3) {
        GsonBuilder a4;
        a4.f = a2;
        a4.h = a3;
        a4.r = null;
        return a4;
    }

    public GsonBuilder a(Type a2, Object a3) {
        GsonBuilder a4;
        $Gson$Preconditions.a(a3 instanceof JsonSerializer || a3 instanceof JsonDeserializer || a3 instanceof InstanceCreator || a3 instanceof TypeAdapter);
        if (a3 instanceof InstanceCreator) {
            a4.w.put(a2, (InstanceCreator)a3);
        }
        if (a3 instanceof JsonSerializer || a3 instanceof JsonDeserializer) {
            TypeToken<?> a5 = TypeToken.p(a2);
            a4.i.add(TreeTypeAdapter.a(a5, a3));
        }
        if (a3 instanceof TypeAdapter) {
            a4.i.add(TypeAdapters.a(TypeToken.p(a2), (TypeAdapter)a3));
        }
        return a4;
    }

    public GsonBuilder a(TypeAdapterFactory a2) {
        GsonBuilder a3;
        a3.i.add(a2);
        return a3;
    }

    public GsonBuilder a(Class<?> a2, Object a3) {
        GsonBuilder a4;
        $Gson$Preconditions.a(a3 instanceof JsonSerializer || a3 instanceof JsonDeserializer || a3 instanceof TypeAdapter);
        if (a3 instanceof JsonDeserializer || a3 instanceof JsonSerializer) {
            a4.n.add(TreeTypeAdapter.a(a2, a3));
        }
        if (a3 instanceof TypeAdapter) {
            a4.i.add(TypeAdapters.a(a2, (TypeAdapter)a3));
        }
        return a4;
    }

    public GsonBuilder a() {
        GsonBuilder a2;
        a2.l = true;
        return a2;
    }

    public Gson a() {
        GsonBuilder a2;
        ArrayList<TypeAdapterFactory> a3 = new ArrayList<TypeAdapterFactory>(a2.i.size() + a2.n.size() + 3);
        a3.addAll(a2.i);
        Collections.reverse(a3);
        ArrayList<TypeAdapterFactory> a4 = new ArrayList<TypeAdapterFactory>(a2.n);
        Collections.reverse(a4);
        a3.addAll(a4);
        a2.a(a2.r, a2.f, a2.h, a3);
        return new Gson(a2.t, a2.s, a2.w, a2.e, a2.z, a2.v, a2.b, a2.c, a2.d, a2.l, a2.p, a2.r, a2.f, a2.h, a2.i, a2.n, a3);
    }

    private /* synthetic */ void a(String a2, int a3, int a4, List<TypeAdapterFactory> a5) {
        DefaultDateTypeAdapter a6;
        DefaultDateTypeAdapter a7;
        DefaultDateTypeAdapter a8;
        if (a2 != null && !"".equals(a2.trim())) {
            a8 = new DefaultDateTypeAdapter(java.util.Date.class, a2);
            a7 = new DefaultDateTypeAdapter(Timestamp.class, a2);
            a6 = new DefaultDateTypeAdapter(Date.class, a2);
        } else if (a3 != 2 && a4 != 2) {
            a8 = new DefaultDateTypeAdapter(java.util.Date.class, a3, a4);
            a7 = new DefaultDateTypeAdapter(Timestamp.class, a3, a4);
            a6 = new DefaultDateTypeAdapter(Date.class, a3, a4);
        } else {
            return;
        }
        a5.add(TypeAdapters.p(java.util.Date.class, a8));
        a5.add(TypeAdapters.p(Timestamp.class, a7));
        a5.add(TypeAdapters.p(Date.class, a6));
    }
}

