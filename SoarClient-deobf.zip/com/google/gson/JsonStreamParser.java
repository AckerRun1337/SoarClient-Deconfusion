/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class JsonStreamParser
implements Iterator<JsonElement> {
    private final JsonReader v;
    private final Object d;

    public JsonStreamParser(String a2) {
        a3(new StringReader(a2));
        JsonStreamParser a3;
    }

    public JsonStreamParser(Reader a2) {
        JsonStreamParser a3;
        a3.v = new JsonReader(a2);
        a3.v.a(true);
        a3.d = new Object();
    }

    public JsonElement a() throws JsonParseException {
        JsonStreamParser a2;
        if (!a2.hasNext()) {
            throw new NoSuchElementException();
        }
        try {
            return Streams.a(a2.v);
        }
        catch (StackOverflowError a3) {
            throw new JsonParseException("Failed parsing JSON source to Json", a3);
        }
        catch (OutOfMemoryError a4) {
            throw new JsonParseException("Failed parsing JSON source to Json", a4);
        }
        catch (JsonParseException a5) {
            throw a5.getCause() instanceof EOFException ? new NoSuchElementException() : a5;
        }
    }

    @Override
    public boolean hasNext() {
        JsonStreamParser a2;
        Object object = a2.d;
        synchronized (object) {
            try {
                return a2.v.a() != JsonToken.v;
            }
            catch (MalformedJsonException a3) {
                throw new JsonSyntaxException(a3);
            }
            catch (IOException a4) {
                throw new JsonIOException(a4);
            }
        }
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}

