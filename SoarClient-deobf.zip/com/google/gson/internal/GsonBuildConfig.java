/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

public final class GsonBuildConfig {
    public static final String d = "2.8.6";

    private /* synthetic */ GsonBuildConfig() {
        GsonBuildConfig a2;
    }
}

