/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.reflect;

import com.google.gson.internal.reflect.ReflectionAccessor;
import java.lang.reflect.AccessibleObject;

final class PreJava9ReflectionAccessor
extends ReflectionAccessor {
    PreJava9ReflectionAccessor() {
        PreJava9ReflectionAccessor a2;
    }

    @Override
    public void a(AccessibleObject a2) {
        a2.setAccessible(true);
    }
}

