/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.reflect;

import com.google.gson.JsonIOException;
import com.google.gson.internal.reflect.ReflectionAccessor;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
final class UnsafeReflectionAccessor
extends ReflectionAccessor {
    private static Class c;
    private final Object v = UnsafeReflectionAccessor.a();
    private final Field d = UnsafeReflectionAccessor.a();

    UnsafeReflectionAccessor() {
        UnsafeReflectionAccessor a2;
    }

    @Override
    public void a(AccessibleObject a2) {
        UnsafeReflectionAccessor a3;
        boolean a4 = a3.a(a2);
        if (!a4) {
            try {
                a2.setAccessible(true);
            }
            catch (SecurityException a5) {
                throw new JsonIOException("Gson couldn't modify fields for " + a2 + "\nand sun.misc.Unsafe not found.\nEither write a custom type adapter, or make fields accessible, or include sun.misc.Unsafe.", a5);
            }
        }
    }

    boolean a(AccessibleObject a2) {
        UnsafeReflectionAccessor a3;
        if (a3.v != null && a3.d != null) {
            try {
                Method a4 = c.getMethod("objectFieldOffset", Field.class);
                long a5 = (Long)a4.invoke(a3.v, a3.d);
                Method a6 = c.getMethod("putBoolean", Object.class, Long.TYPE, Boolean.TYPE);
                a6.invoke(a3.v, a2, a5, true);
                return true;
            }
            catch (Exception a4) {
                // empty catch block
            }
        }
        return false;
    }

    private static /* synthetic */ Object a() {
        try {
            c = Class.forName("sun.misc.Unsafe");
            Field a2 = c.getDeclaredField("theUnsafe");
            a2.setAccessible(true);
            return a2.get(null);
        }
        catch (Exception a3) {
            return null;
        }
    }

    private static /* synthetic */ Field a() {
        try {
            return AccessibleObject.class.getDeclaredField("override");
        }
        catch (NoSuchFieldException a2) {
            return null;
        }
    }
}

