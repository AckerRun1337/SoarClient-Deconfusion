/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.reflect;

import com.google.gson.internal.JavaVersion;
import com.google.gson.internal.reflect.PreJava9ReflectionAccessor;
import com.google.gson.internal.reflect.UnsafeReflectionAccessor;
import java.lang.reflect.AccessibleObject;

public abstract class ReflectionAccessor {
    private static final ReflectionAccessor d = JavaVersion.a() < 9 ? new PreJava9ReflectionAccessor() : new UnsafeReflectionAccessor();

    public ReflectionAccessor() {
        ReflectionAccessor a2;
    }

    public abstract void a(AccessibleObject var1);

    public static ReflectionAccessor a() {
        return d;
    }
}

