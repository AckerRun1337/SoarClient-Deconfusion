/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public final class LinkedHashTreeMap<K, V>
extends AbstractMap<K, V>
implements Serializable {
    private static final Comparator<Comparable> e = new Comparator<Comparable>(){
        {
            1 a2;
        }

        public int a(Comparable a2, Comparable a3) {
            return a2.compareTo(a3);
        }
    };
    Comparator<? super K> r;
    Node<K, V>[] f;
    final Node<K, V> h;
    int z = 0;
    int l = 0;
    int b;
    private EntrySet c;
    private KeySet v;

    public LinkedHashTreeMap() {
        a2(e);
        LinkedHashTreeMap<Comparable, V> a2;
    }

    public LinkedHashTreeMap(Comparator<? super K> a2) {
        LinkedHashTreeMap a3;
        a3.r = a2 != null ? a2 : e;
        a3.h = new Node();
        a3.f = new Node[16];
        a3.b = a3.f.length / 2 + a3.f.length / 4;
    }

    @Override
    public int size() {
        LinkedHashTreeMap a2;
        return a2.z;
    }

    @Override
    public V get(Object a2) {
        LinkedHashTreeMap a3;
        Node<K, V> a4 = a3.p(a2);
        return a4 != null ? (V)a4.v : null;
    }

    @Override
    public boolean containsKey(Object a2) {
        LinkedHashTreeMap a3;
        return a3.p(a2) != null;
    }

    @Override
    public V put(K a2, V a3) {
        LinkedHashTreeMap a4;
        if (a2 == null) {
            throw new NullPointerException("key == null");
        }
        Node<K, V> a5 = a4.a(a2, true);
        Object a6 = a5.v;
        a5.v = a3;
        return a6;
    }

    @Override
    public void clear() {
        LinkedHashTreeMap a2;
        Arrays.fill(a2.f, null);
        a2.z = 0;
        ++a2.l;
        Node<K, V> a3 = a2.h;
        Node a4 = a3.z;
        while (a4 != a3) {
            Node a5 = a4.z;
            a4.l = null;
            a4.z = null;
            a4 = a5;
        }
        a3.l = a3;
        a3.z = a3.l;
    }

    @Override
    public V remove(Object a2) {
        LinkedHashTreeMap a3;
        Node<K, V> a4 = a3.a(a2);
        return a4 != null ? (V)a4.v : null;
    }

    Node<K, V> a(K a2, boolean a3) {
        Node<K, V> a4;
        Object a5;
        LinkedHashTreeMap a6;
        Comparator<K> a7 = a6.r;
        Node<K, V>[] a8 = a6.f;
        int a9 = LinkedHashTreeMap.a(a2.hashCode());
        int a10 = a9 & a8.length - 1;
        Node<K, V> a11 = a8[a10];
        int a12 = 0;
        if (a11 != null) {
            a5 = a7 == e ? (Comparable)a2 : null;
            while (true) {
                int n2 = a12 = a5 != null ? a5.compareTo(a11.b) : a7.compare(a2, a11.b);
                if (a12 == 0) {
                    return a11;
                }
                Node node = a4 = a12 < 0 ? a11.f : a11.h;
                if (a4 == null) break;
                a11 = a4;
            }
        }
        if (!a3) {
            return null;
        }
        a5 = a6.h;
        if (a11 == null) {
            if (a7 == e && !(a2 instanceof Comparable)) {
                throw new ClassCastException(a2.getClass().getName() + " is not Comparable");
            }
            a4 = new Node<K, V>(a11, a2, a9, a5, ((Node)a5).l);
            a8[a10] = a4;
        } else {
            a4 = new Node<K, V>(a11, a2, a9, a5, ((Node)a5).l);
            if (a12 < 0) {
                a11.f = a4;
            } else {
                a11.h = a4;
            }
            a6.a(a11, true);
        }
        if (a6.z++ > a6.b) {
            a6.a();
        }
        ++a6.l;
        return a4;
    }

    Node<K, V> p(Object a2) {
        try {
            LinkedHashTreeMap a3;
            return a2 != null ? a3.a(a2, false) : null;
        }
        catch (ClassCastException a4) {
            return null;
        }
    }

    Node<K, V> a(Map.Entry<?, ?> a2) {
        LinkedHashTreeMap a3;
        Node<K, V> a4 = a3.p(a2.getKey());
        boolean a5 = a4 != null && a3.a(a4.v, a2.getValue());
        return a5 ? a4 : null;
    }

    private /* synthetic */ boolean a(Object a2, Object a3) {
        return a2 == a3 || a2 != null && a2.equals(a3);
    }

    private static /* synthetic */ int a(int a2) {
        a2 ^= a2 >>> 20 ^ a2 >>> 12;
        return a2 ^ a2 >>> 7 ^ a2 >>> 4;
    }

    void p(Node<K, V> a2, boolean a3) {
        LinkedHashTreeMap a4;
        if (a3) {
            a2.l.z = a2.z;
            a2.z.l = a2.l;
            a2.l = null;
            a2.z = null;
        }
        Node a5 = a2.f;
        Node a6 = a2.h;
        Node a7 = a2.r;
        if (a5 != null && a6 != null) {
            Node a8 = a5.d > a6.d ? a5.a() : a6.p();
            a4.p(a8, false);
            int a9 = 0;
            a5 = a2.f;
            if (a5 != null) {
                a9 = a5.d;
                a8.f = a5;
                a5.r = a8;
                a2.f = null;
            }
            int a10 = 0;
            a6 = a2.h;
            if (a6 != null) {
                a10 = a6.d;
                a8.h = a6;
                a6.r = a8;
                a2.h = null;
            }
            a8.d = Math.max(a9, a10) + 1;
            a4.a(a2, a8);
            return;
        }
        if (a5 != null) {
            a4.a(a2, a5);
            a2.f = null;
        } else if (a6 != null) {
            a4.a(a2, a6);
            a2.h = null;
        } else {
            a4.a(a2, null);
        }
        a4.a(a7, false);
        --a4.z;
        ++a4.l;
    }

    Node<K, V> a(Object a2) {
        LinkedHashTreeMap a3;
        Node<K, V> a4 = a3.p(a2);
        if (a4 != null) {
            a3.p(a4, true);
        }
        return a4;
    }

    private /* synthetic */ void a(Node<K, V> a2, Node<K, V> a3) {
        Node a4 = a2.r;
        a2.r = null;
        if (a3 != null) {
            a3.r = a4;
        }
        if (a4 != null) {
            if (a4.f == a2) {
                a4.f = a3;
            } else {
                assert (a4.h == a2);
                a4.h = a3;
            }
        } else {
            LinkedHashTreeMap a5;
            int a6 = a2.c & a5.f.length - 1;
            a5.f[a6] = a3;
        }
    }

    private /* synthetic */ void a(Node<K, V> a2, boolean a3) {
        Node<K, V> a4 = a2;
        while (a4 != null) {
            LinkedHashTreeMap a5;
            int a6;
            Node a7;
            int a8;
            int a9;
            Node a10;
            Node a11;
            int a12;
            Node a13 = a4.f;
            int a14 = a13 != null ? a13.d : 0;
            int a15 = a14 - (a12 = (a11 = a4.h) != null ? a11.d : 0);
            if (a15 == -2) {
                a10 = a11.f;
                a9 = a10 != null ? a10.d : 0;
                a6 = a9 - (a8 = (a7 = a11.h) != null ? a7.d : 0);
                if (a6 == -1 || a6 == 0 && !a3) {
                    a5.p(a4);
                } else {
                    assert (a6 == 1);
                    a5.a(a11);
                    a5.p(a4);
                }
                if (a3) {
                    break;
                }
            } else if (a15 == 2) {
                a10 = a13.f;
                a9 = a10 != null ? a10.d : 0;
                a6 = a9 - (a8 = (a7 = a13.h) != null ? a7.d : 0);
                if (a6 == 1 || a6 == 0 && !a3) {
                    a5.a(a4);
                } else {
                    assert (a6 == -1);
                    a5.p(a13);
                    a5.a(a4);
                }
                if (a3) {
                    break;
                }
            } else if (a15 == 0) {
                a4.d = a14 + 1;
                if (a3) {
                    break;
                }
            } else {
                assert (a15 == -1 || a15 == 1);
                a4.d = Math.max(a14, a12) + 1;
                if (!a3) break;
            }
            a4 = a4.r;
        }
    }

    private /* synthetic */ void p(Node<K, V> a2) {
        LinkedHashTreeMap a3;
        Node a4 = a2.f;
        Node a5 = a2.h;
        Node a6 = a5.f;
        Node a7 = a5.h;
        a2.h = a6;
        if (a6 != null) {
            a6.r = a2;
        }
        a3.a(a2, a5);
        a5.f = a2;
        a2.r = a5;
        a2.d = Math.max(a4 != null ? a4.d : 0, a6 != null ? a6.d : 0) + 1;
        a5.d = Math.max(a2.d, a7 != null ? a7.d : 0) + 1;
    }

    private /* synthetic */ void a(Node<K, V> a2) {
        LinkedHashTreeMap a3;
        Node a4 = a2.f;
        Node a5 = a2.h;
        Node a6 = a4.f;
        Node a7 = a4.h;
        a2.f = a7;
        if (a7 != null) {
            a7.r = a2;
        }
        a3.a(a2, a4);
        a4.h = a2;
        a2.r = a4;
        a2.d = Math.max(a5 != null ? a5.d : 0, a7 != null ? a7.d : 0) + 1;
        a4.d = Math.max(a2.d, a6 != null ? a6.d : 0) + 1;
    }

    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        LinkedHashTreeMap a2;
        EntrySet a3 = a2.c;
        return a3 != null ? a3 : (a2.c = a2.new EntrySet());
    }

    @Override
    public Set<K> keySet() {
        LinkedHashTreeMap a2;
        KeySet a3 = a2.v;
        return a3 != null ? a3 : (a2.v = a2.new KeySet());
    }

    private /* synthetic */ void a() {
        LinkedHashTreeMap a2;
        a2.f = LinkedHashTreeMap.a(a2.f);
        a2.b = a2.f.length / 2 + a2.f.length / 4;
    }

    static <K, V> Node<K, V>[] a(Node<K, V>[] a2) {
        int a3 = a2.length;
        Node[] a4 = new Node[a3 * 2];
        AvlIterator<K, V> a5 = new AvlIterator<K, V>();
        AvlBuilder a6 = new AvlBuilder();
        AvlBuilder a7 = new AvlBuilder();
        for (int a8 = 0; a8 < a3; ++a8) {
            Node a9;
            Node<K, V> a10 = a2[a8];
            if (a10 == null) continue;
            a5.a(a10);
            int a11 = 0;
            int a12 = 0;
            while ((a9 = a5.a()) != null) {
                if ((a9.c & a3) == 0) {
                    ++a11;
                    continue;
                }
                ++a12;
            }
            a6.a(a11);
            a7.a(a12);
            a5.a(a10);
            while ((a9 = a5.a()) != null) {
                if ((a9.c & a3) == 0) {
                    a6.a(a9);
                    continue;
                }
                a7.a(a9);
            }
            a4[a8] = a11 > 0 ? a6.a() : null;
            a4[a8 + a3] = a12 > 0 ? a7.a() : null;
        }
        return a4;
    }

    private /* synthetic */ Object a() throws ObjectStreamException {
        LinkedHashTreeMap a2;
        return new LinkedHashMap(a2);
    }

    final class KeySet
    extends AbstractSet<K> {
        KeySet() {
            KeySet a3;
        }

        @Override
        public int size() {
            KeySet a2;
            return a2.LinkedHashTreeMap.this.z;
        }

        @Override
        public Iterator<K> iterator() {
            KeySet a2;
            return new LinkedTreeMapIterator<K>(){
                {
                    1 a3;
                }

                @Override
                public K next() {
                    1 a2;
                    return a2.a().b;
                }
            };
        }

        @Override
        public boolean contains(Object a2) {
            KeySet a3;
            return a3.LinkedHashTreeMap.this.containsKey(a2);
        }

        @Override
        public boolean remove(Object a2) {
            KeySet a3;
            return a3.LinkedHashTreeMap.this.a(a2) != null;
        }

        @Override
        public void clear() {
            KeySet a2;
            a2.LinkedHashTreeMap.this.clear();
        }
    }

    final class EntrySet
    extends AbstractSet<Map.Entry<K, V>> {
        EntrySet() {
            EntrySet a3;
        }

        @Override
        public int size() {
            EntrySet a2;
            return a2.LinkedHashTreeMap.this.z;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            EntrySet a2;
            return new LinkedTreeMapIterator<Map.Entry<K, V>>(){
                {
                    1 a3;
                }

                @Override
                public Map.Entry<K, V> a() {
                    1 a2;
                    return ((LinkedTreeMapIterator)a2).a();
                }
            };
        }

        @Override
        public boolean contains(Object a2) {
            EntrySet a3;
            return a2 instanceof Map.Entry && a3.LinkedHashTreeMap.this.a((Map.Entry)a2) != null;
        }

        @Override
        public boolean remove(Object a2) {
            EntrySet a3;
            if (!(a2 instanceof Map.Entry)) {
                return false;
            }
            Node a4 = a3.LinkedHashTreeMap.this.a((Map.Entry)a2);
            if (a4 == null) {
                return false;
            }
            a3.LinkedHashTreeMap.this.p(a4, true);
            return true;
        }

        @Override
        public void clear() {
            EntrySet a2;
            a2.LinkedHashTreeMap.this.clear();
        }
    }

    private abstract class LinkedTreeMapIterator<T>
    implements Iterator<T> {
        Node<K, V> b;
        Node<K, V> c;
        int v;

        LinkedTreeMapIterator() {
            LinkedTreeMapIterator a2;
            a2.b = a2.LinkedHashTreeMap.this.h.z;
            a2.c = null;
            a2.v = a2.LinkedHashTreeMap.this.l;
        }

        @Override
        public final boolean hasNext() {
            LinkedTreeMapIterator a2;
            return a2.b != a2.LinkedHashTreeMap.this.h;
        }

        final Node<K, V> a() {
            LinkedTreeMapIterator a2;
            Node a3 = a2.b;
            if (a3 == a2.LinkedHashTreeMap.this.h) {
                throw new NoSuchElementException();
            }
            if (a2.LinkedHashTreeMap.this.l != a2.v) {
                throw new ConcurrentModificationException();
            }
            a2.b = a3.z;
            a2.c = a3;
            return a2.c;
        }

        @Override
        public final void remove() {
            LinkedTreeMapIterator a2;
            if (a2.c == null) {
                throw new IllegalStateException();
            }
            a2.LinkedHashTreeMap.this.p(a2.c, true);
            a2.c = null;
            a2.v = a2.LinkedHashTreeMap.this.l;
        }
    }

    static final class AvlBuilder<K, V> {
        private Node<K, V> b;
        private int c;
        private int v;
        private int d;

        AvlBuilder() {
            AvlBuilder a2;
        }

        void a(int a2) {
            int a3 = Integer.highestOneBit(a2) * 2 - 1;
            a.c = a3 - a2;
            a.d = 0;
            a.v = 0;
            a.b = null;
        }

        void a(Node<K, V> a2) {
            AvlBuilder a3;
            a2.h = null;
            a2.r = null;
            a2.f = null;
            a2.d = 1;
            if (a3.c > 0 && (a3.d & 1) == 0) {
                ++a3.d;
                --a3.c;
                ++a3.v;
            }
            a2.r = a3.b;
            a3.b = a2;
            ++a3.d;
            if (a3.c > 0 && (a3.d & 1) == 0) {
                ++a3.d;
                --a3.c;
                ++a3.v;
            }
            int a4 = 4;
            while ((a3.d & a4 - 1) == a4 - 1) {
                Node a5;
                Node<K, V> a6;
                if (a3.v == 0) {
                    a6 = a3.b;
                    a5 = a6.r;
                    Node a7 = a5.r;
                    a5.r = a7.r;
                    a3.b = a5;
                    a5.f = a7;
                    a5.h = a6;
                    a5.d = a6.d + 1;
                    a7.r = a5;
                    a6.r = a5;
                } else if (a3.v == 1) {
                    a6 = a3.b;
                    a5 = a6.r;
                    a3.b = a5;
                    a5.h = a6;
                    a5.d = a6.d + 1;
                    a6.r = a5;
                    a3.v = 0;
                } else if (a3.v == 2) {
                    a3.v = 0;
                }
                a4 *= 2;
            }
        }

        Node<K, V> a() {
            AvlBuilder a2;
            Node<K, V> a3 = a2.b;
            if (a3.r != null) {
                throw new IllegalStateException();
            }
            return a3;
        }
    }

    static class AvlIterator<K, V> {
        private Node<K, V> d;

        AvlIterator() {
            AvlIterator a2;
        }

        void a(Node<K, V> a2) {
            Node<K, V> a3 = null;
            Node<K, V> a4 = a2;
            while (a4 != null) {
                a4.r = a3;
                a3 = a4;
                a4 = a4.f;
            }
            a.d = a3;
        }

        public Node<K, V> a() {
            AvlIterator a2;
            Node<K, V> a3 = a2.d;
            if (a3 == null) {
                return null;
            }
            Node<K, V> a4 = a3;
            a3 = a4.r;
            a4.r = null;
            Node a5 = a4.h;
            while (a5 != null) {
                a5.r = a3;
                a3 = a5;
                a5 = a5.f;
            }
            a2.d = a3;
            return a4;
        }
    }

    static final class Node<K, V>
    implements Map.Entry<K, V> {
        Node<K, V> r;
        Node<K, V> f;
        Node<K, V> h;
        Node<K, V> z;
        Node<K, V> l;
        final K b;
        final int c;
        V v;
        int d;

        Node() {
            Node a2;
            a2.b = null;
            a2.c = -1;
            a2.z = a2.l = a2;
        }

        Node(Node<K, V> a2, K a3, int a4, Node<K, V> a5, Node<K, V> a6) {
            Node a7;
            a7.r = a2;
            a7.b = a3;
            a7.c = a4;
            a7.d = 1;
            a7.z = a5;
            a7.l = a6;
            a6.z = a7;
            a5.l = a7;
        }

        @Override
        public K getKey() {
            Node a2;
            return a2.b;
        }

        @Override
        public V getValue() {
            Node a2;
            return a2.v;
        }

        @Override
        public V setValue(V a2) {
            Node a3;
            V a4 = a3.v;
            a3.v = a2;
            return a4;
        }

        @Override
        public boolean equals(Object a2) {
            if (a2 instanceof Map.Entry) {
                Node a3;
                Map.Entry a4 = (Map.Entry)a2;
                return (a3.b == null ? a4.getKey() == null : a3.b.equals(a4.getKey())) && (a3.v == null ? a4.getValue() == null : a3.v.equals(a4.getValue()));
            }
            return false;
        }

        @Override
        public int hashCode() {
            Node a2;
            return (a2.b == null ? 0 : a2.b.hashCode()) ^ (a2.v == null ? 0 : a2.v.hashCode());
        }

        public String toString() {
            Node a2;
            return a2.b + "=" + a2.v;
        }

        public Node<K, V> p() {
            Node<K, V> a2;
            Node<K, V> a3 = a2;
            Node<K, V> a4 = a3.f;
            while (a4 != null) {
                a3 = a4;
                a4 = a3.f;
            }
            return a3;
        }

        public Node<K, V> a() {
            Node<K, V> a2;
            Node<K, V> a3 = a2;
            Node<K, V> a4 = a3.h;
            while (a4 != null) {
                a3 = a4;
                a4 = a3.h;
            }
            return a3;
        }
    }
}

