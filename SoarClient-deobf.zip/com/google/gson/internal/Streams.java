/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;

public final class Streams {
    private /* synthetic */ Streams() {
        Streams a2;
        throw new UnsupportedOperationException();
    }

    public static JsonElement a(JsonReader a2) throws JsonParseException {
        boolean a3 = true;
        try {
            a2.a();
            a3 = false;
            return TypeAdapters.c.a(a2);
        }
        catch (EOFException a4) {
            if (a3) {
                return JsonNull.d;
            }
            throw new JsonSyntaxException(a4);
        }
        catch (MalformedJsonException a5) {
            throw new JsonSyntaxException(a5);
        }
        catch (IOException a6) {
            throw new JsonIOException(a6);
        }
        catch (NumberFormatException a7) {
            throw new JsonSyntaxException(a7);
        }
    }

    public static void a(JsonElement a2, JsonWriter a3) throws IOException {
        TypeAdapters.c.a(a3, a2);
    }

    public static Writer a(Appendable a2) {
        return a2 instanceof Writer ? (Writer)a2 : new AppendableWriter(a2);
    }

    private static final class AppendableWriter
    extends Writer {
        private final Appendable v;
        private final CurrentWrite d = new CurrentWrite();

        AppendableWriter(Appendable a2) {
            AppendableWriter a3;
            a3.v = a2;
        }

        @Override
        public void write(char[] a2, int a3, int a4) throws IOException {
            AppendableWriter a5;
            a5.d.d = a2;
            a5.v.append(a5.d, a3, a3 + a4);
        }

        @Override
        public void write(int a2) throws IOException {
            AppendableWriter a3;
            a3.v.append((char)a2);
        }

        @Override
        public void flush() {
        }

        @Override
        public void close() {
        }

        static class CurrentWrite
        implements CharSequence {
            char[] d;

            CurrentWrite() {
                CurrentWrite a2;
            }

            @Override
            public int length() {
                CurrentWrite a2;
                return a2.d.length;
            }

            @Override
            public char charAt(int a2) {
                CurrentWrite a3;
                return a3.d[a2];
            }

            @Override
            public CharSequence subSequence(int a2, int a3) {
                CurrentWrite a4;
                return new String(a4.d, a2, a3 - a2);
            }
        }
    }
}

