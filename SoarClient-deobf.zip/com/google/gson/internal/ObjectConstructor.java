/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

public interface ObjectConstructor<T> {
    public T a();
}

