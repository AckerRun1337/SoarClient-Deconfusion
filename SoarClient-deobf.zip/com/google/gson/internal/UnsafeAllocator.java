/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public abstract class UnsafeAllocator {
    public UnsafeAllocator() {
        UnsafeAllocator a2;
    }

    public abstract <T> T a(Class<T> var1) throws Exception;

    public static UnsafeAllocator a() {
        try {
            Class<?> a2 = Class.forName("sun.misc.Unsafe");
            Field a3 = a2.getDeclaredField("theUnsafe");
            a3.setAccessible(true);
            final Object a4 = a3.get(null);
            final Method a5 = a2.getMethod("allocateInstance", Class.class);
            return new UnsafeAllocator(){
                {
                    1 a2;
                }

                @Override
                public <T> T a(Class<T> a2) throws Exception {
                    1 a3;
                    1.a(a2);
                    return (T)a3.a5.invoke(a3.a4, a2);
                }
            };
        }
        catch (Exception a2) {
            try {
                Method a6 = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                a6.setAccessible(true);
                final int a7 = (Integer)a6.invoke(null, Object.class);
                final Method a8 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                a8.setAccessible(true);
                return new UnsafeAllocator(){
                    {
                        2 a2;
                    }

                    @Override
                    public <T> T a(Class<T> a2) throws Exception {
                        2 a3;
                        2.a(a2);
                        return (T)a3.a8.invoke(null, a2, a3.a7);
                    }
                };
            }
            catch (Exception a6) {
                try {
                    final Method a9 = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
                    a9.setAccessible(true);
                    return new UnsafeAllocator(){
                        {
                            3 a2;
                        }

                        @Override
                        public <T> T a(Class<T> a2) throws Exception {
                            3 a3;
                            3.a(a2);
                            return (T)a3.a9.invoke(null, a2, Object.class);
                        }
                    };
                }
                catch (Exception a9) {
                    return new UnsafeAllocator(){
                        {
                            4 a2;
                        }

                        @Override
                        public <T> T a(Class<T> a2) {
                            throw new UnsupportedOperationException("Cannot allocate " + a2);
                        }
                    };
                }
            }
        }
    }

    static void a(Class<?> a2) {
        int a3 = a2.getModifiers();
        if (Modifier.isInterface(a3)) {
            throw new UnsupportedOperationException("Interface can't be instantiated! Interface name: " + a2.getName());
        }
        if (Modifier.isAbstract(a3)) {
            throw new UnsupportedOperationException("Abstract class can't be instantiated! Class name: " + a2.getName());
        }
    }
}

