/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.internal.$Gson$Preconditions;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class $Gson$Types {
    static final Type[] d = new Type[0];

    private /* synthetic */ $Gson$Types() {
        $Gson$Types a2;
        throw new UnsupportedOperationException();
    }

    public static ParameterizedType a(Type a2, Type a3, Type ... a4) {
        return new ParameterizedTypeImpl(a2, a3, a4);
    }

    public static GenericArrayType a(Type a2) {
        return new GenericArrayTypeImpl(a2);
    }

    public static WildcardType p(Type a2) {
        Type[] a3 = a2 instanceof WildcardType ? ((WildcardType)a2).getUpperBounds() : new Type[]{a2};
        return new WildcardTypeImpl(a3, d);
    }

    public static WildcardType a(Type a2) {
        Type[] a3 = a2 instanceof WildcardType ? ((WildcardType)a2).getLowerBounds() : new Type[]{a2};
        return new WildcardTypeImpl(new Type[]{Object.class}, a3);
    }

    public static Type p(Type a2) {
        if (a2 instanceof Class) {
            Class a3 = (Class)a2;
            return a3.isArray() ? new GenericArrayTypeImpl($Gson$Types.p(a3.getComponentType())) : a3;
        }
        if (a2 instanceof ParameterizedType) {
            ParameterizedType a4 = (ParameterizedType)a2;
            return new ParameterizedTypeImpl(a4.getOwnerType(), a4.getRawType(), a4.getActualTypeArguments());
        }
        if (a2 instanceof GenericArrayType) {
            GenericArrayType a5 = (GenericArrayType)a2;
            return new GenericArrayTypeImpl(a5.getGenericComponentType());
        }
        if (a2 instanceof WildcardType) {
            WildcardType a6 = (WildcardType)a2;
            return new WildcardTypeImpl(a6.getUpperBounds(), a6.getLowerBounds());
        }
        return a2;
    }

    public static Class<?> a(Type a2) {
        if (a2 instanceof Class) {
            return (Class)a2;
        }
        if (a2 instanceof ParameterizedType) {
            ParameterizedType a3 = (ParameterizedType)a2;
            Type a4 = a3.getRawType();
            $Gson$Preconditions.a(a4 instanceof Class);
            return (Class)a4;
        }
        if (a2 instanceof GenericArrayType) {
            Type a5 = ((GenericArrayType)a2).getGenericComponentType();
            return Array.newInstance($Gson$Types.a(a5), 0).getClass();
        }
        if (a2 instanceof TypeVariable) {
            return Object.class;
        }
        if (a2 instanceof WildcardType) {
            return $Gson$Types.a(((WildcardType)a2).getUpperBounds()[0]);
        }
        String a6 = a2 == null ? "null" : a2.getClass().getName();
        throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + a2 + "> is of type " + a6);
    }

    static boolean a(Object a2, Object a3) {
        return a2 == a3 || a2 != null && a2.equals(a3);
    }

    public static boolean a(Type a2, Type a3) {
        if (a2 == a3) {
            return true;
        }
        if (a2 instanceof Class) {
            return a2.equals(a3);
        }
        if (a2 instanceof ParameterizedType) {
            if (!(a3 instanceof ParameterizedType)) {
                return false;
            }
            ParameterizedType a4 = (ParameterizedType)a2;
            ParameterizedType a5 = (ParameterizedType)a3;
            return $Gson$Types.a((Object)a4.getOwnerType(), (Object)a5.getOwnerType()) && a4.getRawType().equals(a5.getRawType()) && Arrays.equals(a4.getActualTypeArguments(), a5.getActualTypeArguments());
        }
        if (a2 instanceof GenericArrayType) {
            if (!(a3 instanceof GenericArrayType)) {
                return false;
            }
            GenericArrayType a6 = (GenericArrayType)a2;
            GenericArrayType a7 = (GenericArrayType)a3;
            return $Gson$Types.a(a6.getGenericComponentType(), a7.getGenericComponentType());
        }
        if (a2 instanceof WildcardType) {
            if (!(a3 instanceof WildcardType)) {
                return false;
            }
            WildcardType a8 = (WildcardType)a2;
            WildcardType a9 = (WildcardType)a3;
            return Arrays.equals(a8.getUpperBounds(), a9.getUpperBounds()) && Arrays.equals(a8.getLowerBounds(), a9.getLowerBounds());
        }
        if (a2 instanceof TypeVariable) {
            if (!(a3 instanceof TypeVariable)) {
                return false;
            }
            TypeVariable a10 = (TypeVariable)a2;
            TypeVariable a11 = (TypeVariable)a3;
            return a10.getGenericDeclaration() == a11.getGenericDeclaration() && a10.getName().equals(a11.getName());
        }
        return false;
    }

    static int a(Object a2) {
        return a2 != null ? a2.hashCode() : 0;
    }

    public static String a(Type a2) {
        return a2 instanceof Class ? ((Class)a2).getName() : a2.toString();
    }

    static Type p(Type a2, Class<?> a3, Class<?> a4) {
        Object a5;
        if (a4 == a3) {
            return a2;
        }
        if (a4.isInterface()) {
            a5 = ((Class)a3).getInterfaces();
            int a6 = ((Class<?>[])a5).length;
            for (int a7 = 0; a7 < a6; ++a7) {
                if (a5[a7] == a4) {
                    return ((Class)a3).getGenericInterfaces()[a7];
                }
                if (!a4.isAssignableFrom(a5[a7])) continue;
                return $Gson$Types.p(((Class)a3).getGenericInterfaces()[a7], a5[a7], a4);
            }
        }
        if (!((Class)a3).isInterface()) {
            while (a3 != Object.class) {
                a5 = ((Class)a3).getSuperclass();
                if (a5 == a4) {
                    return ((Class)a3).getGenericSuperclass();
                }
                if (a4.isAssignableFrom((Class<?>)a5)) {
                    return $Gson$Types.p(((Class)a3).getGenericSuperclass(), a5, a4);
                }
                a3 = a5;
            }
        }
        return a4;
    }

    static Type a(Type a2, Class<?> a3, Class<?> a4) {
        if (a2 instanceof WildcardType) {
            a2 = ((WildcardType)a2).getUpperBounds()[0];
        }
        $Gson$Preconditions.a(a4.isAssignableFrom(a3));
        return $Gson$Types.a(a2, a3, $Gson$Types.p(a2, a3, a4));
    }

    public static Type a(Type a2) {
        return a2 instanceof GenericArrayType ? ((GenericArrayType)a2).getGenericComponentType() : ((Class)a2).getComponentType();
    }

    public static Type a(Type a2, Class<?> a3) {
        Type a4 = $Gson$Types.a(a2, a3, Collection.class);
        if (a4 instanceof WildcardType) {
            a4 = ((WildcardType)a4).getUpperBounds()[0];
        }
        if (a4 instanceof ParameterizedType) {
            return ((ParameterizedType)a4).getActualTypeArguments()[0];
        }
        return Object.class;
    }

    public static Type[] a(Type a2, Class<?> a3) {
        if (a2 == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        Type a4 = $Gson$Types.a(a2, a3, Map.class);
        if (a4 instanceof ParameterizedType) {
            ParameterizedType a5 = (ParameterizedType)a4;
            return a5.getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    public static Type a(Type a2, Class<?> a3, Type a4) {
        return $Gson$Types.a(a2, a3, a4, new HashSet<TypeVariable>());
    }

    private static /* synthetic */ Type a(Type a2, Class<?> a3, Type a4, Collection<TypeVariable> a5) {
        Type a6;
        while (a4 instanceof TypeVariable) {
            a6 = (TypeVariable)a4;
            if (a5.contains(a6)) {
                return a4;
            }
            a5.add((TypeVariable)a6);
            a4 = $Gson$Types.a(a2, a3, a6);
            if (a4 != a6) continue;
            return a4;
        }
        if (a4 instanceof Class && ((Class)a4).isArray()) {
            Type a7;
            a6 = (Class)a4;
            Class<?> a8 = ((Class)a6).getComponentType();
            return a8 == (a7 = $Gson$Types.a(a2, a3, a8, a5)) ? a6 : $Gson$Types.a(a7);
        }
        if (a4 instanceof GenericArrayType) {
            Type a9;
            a6 = (GenericArrayType)a4;
            Type a10 = a6.getGenericComponentType();
            return a10 == (a9 = $Gson$Types.a(a2, a3, a10, a5)) ? a6 : $Gson$Types.a(a9);
        }
        if (a4 instanceof ParameterizedType) {
            a6 = (ParameterizedType)a4;
            Type a11 = a6.getOwnerType();
            Type a12 = $Gson$Types.a(a2, a3, a11, a5);
            boolean a13 = a12 != a11;
            Type[] a14 = a6.getActualTypeArguments();
            int a15 = a14.length;
            for (int a16 = 0; a16 < a15; ++a16) {
                Type a17 = $Gson$Types.a(a2, a3, a14[a16], a5);
                if (a17 == a14[a16]) continue;
                if (!a13) {
                    a14 = (Type[])a14.clone();
                    a13 = true;
                }
                a14[a16] = a17;
            }
            return a13 ? $Gson$Types.a(a12, a6.getRawType(), a14) : a6;
        }
        if (a4 instanceof WildcardType) {
            Type a18;
            a6 = (WildcardType)a4;
            Type[] a19 = a6.getLowerBounds();
            Type[] a20 = a6.getUpperBounds();
            if (a19.length == 1) {
                Type a21 = $Gson$Types.a(a2, a3, a19[0], a5);
                if (a21 != a19[0]) {
                    return $Gson$Types.a(a21);
                }
            } else if (a20.length == 1 && (a18 = $Gson$Types.a(a2, a3, a20[0], a5)) != a20[0]) {
                return $Gson$Types.p(a18);
            }
            return a6;
        }
        return a4;
    }

    static Type a(Type a2, Class<?> a3, TypeVariable<?> a4) {
        Class<?> a5 = $Gson$Types.a(a4);
        if (a5 == null) {
            return a4;
        }
        Type a6 = $Gson$Types.p(a2, a3, a5);
        if (a6 instanceof ParameterizedType) {
            int a7 = $Gson$Types.a(a5.getTypeParameters(), a4);
            return ((ParameterizedType)a6).getActualTypeArguments()[a7];
        }
        return a4;
    }

    private static /* synthetic */ int a(Object[] a2, Object a3) {
        int a4 = a2.length;
        for (int a5 = 0; a5 < a4; ++a5) {
            if (!a3.equals(a2[a5])) continue;
            return a5;
        }
        throw new NoSuchElementException();
    }

    private static /* synthetic */ Class<?> a(TypeVariable<?> a2) {
        Object a3 = a2.getGenericDeclaration();
        return a3 instanceof Class ? (Class)a3 : null;
    }

    static void a(Type a2) {
        $Gson$Preconditions.a(!(a2 instanceof Class) || !((Class)a2).isPrimitive());
    }

    private static final class WildcardTypeImpl
    implements WildcardType,
    Serializable {
        private final Type c;
        private final Type v;
        private static final long d = 0L;

        public WildcardTypeImpl(Type[] a2, Type[] a3) {
            WildcardTypeImpl a4;
            $Gson$Preconditions.a(a3.length <= 1);
            $Gson$Preconditions.a(a2.length == 1);
            if (a3.length == 1) {
                $Gson$Preconditions.a(a3[0]);
                $Gson$Types.a(a3[0]);
                $Gson$Preconditions.a(a2[0] == Object.class);
                a4.v = $Gson$Types.p(a3[0]);
                a4.c = Object.class;
            } else {
                $Gson$Preconditions.a(a2[0]);
                $Gson$Types.a(a2[0]);
                a4.v = null;
                a4.c = $Gson$Types.p(a2[0]);
            }
        }

        @Override
        public Type[] getUpperBounds() {
            WildcardTypeImpl a2;
            return new Type[]{a2.c};
        }

        @Override
        public Type[] getLowerBounds() {
            Type[] typeArray;
            WildcardTypeImpl a2;
            if (a2.v != null) {
                Type[] typeArray2 = new Type[1];
                typeArray = typeArray2;
                typeArray2[0] = a2.v;
            } else {
                typeArray = d;
            }
            return typeArray;
        }

        public boolean equals(Object a2) {
            WildcardTypeImpl a3;
            return a2 instanceof WildcardType && $Gson$Types.a((Type)a3, (WildcardType)a2);
        }

        public int hashCode() {
            WildcardTypeImpl a2;
            return (a2.v != null ? 31 + a2.v.hashCode() : 1) ^ 31 + a2.c.hashCode();
        }

        public String toString() {
            WildcardTypeImpl a2;
            if (a2.v != null) {
                return "? super " + $Gson$Types.a(a2.v);
            }
            if (a2.c == Object.class) {
                return "?";
            }
            return "? extends " + $Gson$Types.a(a2.c);
        }
    }

    private static final class GenericArrayTypeImpl
    implements GenericArrayType,
    Serializable {
        private final Type v;
        private static final long d = 0L;

        public GenericArrayTypeImpl(Type a2) {
            GenericArrayTypeImpl a3;
            a3.v = $Gson$Types.p(a2);
        }

        @Override
        public Type getGenericComponentType() {
            GenericArrayTypeImpl a2;
            return a2.v;
        }

        public boolean equals(Object a2) {
            GenericArrayTypeImpl a3;
            return a2 instanceof GenericArrayType && $Gson$Types.a((Type)a3, (GenericArrayType)a2);
        }

        public int hashCode() {
            GenericArrayTypeImpl a2;
            return a2.v.hashCode();
        }

        public String toString() {
            GenericArrayTypeImpl a2;
            return $Gson$Types.a(a2.v) + "[]";
        }
    }

    private static final class ParameterizedTypeImpl
    implements ParameterizedType,
    Serializable {
        private final Type b;
        private final Type c;
        private final Type[] v;
        private static final long d = 0L;

        public ParameterizedTypeImpl(Type a2, Type a3, Type ... a4) {
            int a5;
            ParameterizedTypeImpl a6;
            if (a3 instanceof Class) {
                Class a7 = (Class)a3;
                a5 = Modifier.isStatic(a7.getModifiers()) || a7.getEnclosingClass() == null ? 1 : 0;
                $Gson$Preconditions.a(a2 != null || a5 != 0);
            }
            a6.b = a2 == null ? null : $Gson$Types.p(a2);
            a6.c = $Gson$Types.p(a3);
            a6.v = (Type[])a4.clone();
            a5 = a6.v.length;
            for (int a8 = 0; a8 < a5; ++a8) {
                $Gson$Preconditions.a(a6.v[a8]);
                $Gson$Types.a(a6.v[a8]);
                a6.v[a8] = $Gson$Types.p(a6.v[a8]);
            }
        }

        @Override
        public Type[] getActualTypeArguments() {
            ParameterizedTypeImpl a2;
            return (Type[])a2.v.clone();
        }

        @Override
        public Type getRawType() {
            ParameterizedTypeImpl a2;
            return a2.c;
        }

        @Override
        public Type getOwnerType() {
            ParameterizedTypeImpl a2;
            return a2.b;
        }

        public boolean equals(Object a2) {
            ParameterizedTypeImpl a3;
            return a2 instanceof ParameterizedType && $Gson$Types.a((Type)a3, (ParameterizedType)a2);
        }

        public int hashCode() {
            ParameterizedTypeImpl a2;
            return Arrays.hashCode(a2.v) ^ a2.c.hashCode() ^ $Gson$Types.a((Object)a2.b);
        }

        public String toString() {
            ParameterizedTypeImpl a2;
            int a3 = a2.v.length;
            if (a3 == 0) {
                return $Gson$Types.a(a2.c);
            }
            StringBuilder a4 = new StringBuilder(30 * (a3 + 1));
            a4.append($Gson$Types.a(a2.c)).append("<").append($Gson$Types.a(a2.v[0]));
            for (int a5 = 1; a5 < a3; ++a5) {
                a4.append(", ").append($Gson$Types.a(a2.v[a5]));
            }
            return a4.append(">").toString();
        }
    }
}

