/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JavaVersion {
    private static final int d = JavaVersion.p();

    private static /* synthetic */ int p() {
        String a2 = System.getProperty("java.version");
        return JavaVersion.o(a2);
    }

    static int o(String a2) {
        int a3 = JavaVersion.p(a2);
        if (a3 == -1) {
            a3 = JavaVersion.a(a2);
        }
        if (a3 == -1) {
            return 6;
        }
        return a3;
    }

    private static /* synthetic */ int p(String a2) {
        try {
            String[] a3 = a2.split("[._]");
            int a4 = Integer.parseInt(a3[0]);
            if (a4 == 1 && a3.length > 1) {
                return Integer.parseInt(a3[1]);
            }
            return a4;
        }
        catch (NumberFormatException a5) {
            return -1;
        }
    }

    private static /* synthetic */ int a(String a2) {
        try {
            char a3;
            StringBuilder a4 = new StringBuilder();
            for (int a5 = 0; a5 < a2.length() && Character.isDigit(a3 = a2.charAt(a5)); ++a5) {
                a4.append(a3);
            }
            return Integer.parseInt(a4.toString());
        }
        catch (NumberFormatException a6) {
            return -1;
        }
    }

    public static int a() {
        return d;
    }

    public static boolean a() {
        return d >= 9;
    }

    private /* synthetic */ JavaVersion() {
        JavaVersion a2;
    }
}

