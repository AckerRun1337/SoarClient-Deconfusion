/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.UnsafeAllocator;
import com.google.gson.internal.reflect.ReflectionAccessor;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public final class ConstructorConstructor {
    private final Map<Type, InstanceCreator<?>> v;
    private final ReflectionAccessor d = ReflectionAccessor.a();

    public ConstructorConstructor(Map<Type, InstanceCreator<?>> a2) {
        ConstructorConstructor a3;
        a3.v = a2;
    }

    public <T> ObjectConstructor<T> a(TypeToken<T> a2) {
        ConstructorConstructor a3;
        final Type a4 = a2.a();
        Type a5 = a2.a();
        final InstanceCreator<?> a6 = a3.v.get(a4);
        if (a6 != null) {
            return new ObjectConstructor<T>(){
                {
                    1 a3;
                }

                @Override
                public T a() {
                    1 a2;
                    return a2.a6.a(a2.a4);
                }
            };
        }
        final InstanceCreator<?> a7 = a3.v.get(a5);
        if (a7 != null) {
            return new ObjectConstructor<T>(){
                {
                    2 a3;
                }

                @Override
                public T a() {
                    2 a2;
                    return a2.a7.a(a2.a4);
                }
            };
        }
        ObjectConstructor<T> a8 = a3.a((Class<? super T>)a5);
        if (a8 != null) {
            return a8;
        }
        ObjectConstructor<T> a9 = a3.p(a4, (Class<? super T>)a5);
        if (a9 != null) {
            return a9;
        }
        return a3.a(a4, (Class<? super T>)a5);
    }

    private /* synthetic */ <T> ObjectConstructor<T> a(Class<? super T> a2) {
        try {
            ConstructorConstructor a3;
            final Constructor<T> a4 = a2.getDeclaredConstructor(new Class[0]);
            if (!a4.isAccessible()) {
                a3.d.a(a4);
            }
            return new ObjectConstructor<T>(){
                {
                    3 a3;
                }

                @Override
                public T a() {
                    3 a2;
                    try {
                        Object[] a3 = null;
                        return a2.a4.newInstance(a3);
                    }
                    catch (InstantiationException a42) {
                        throw new RuntimeException("Failed to invoke " + a2.a4 + " with no args", a42);
                    }
                    catch (InvocationTargetException a5) {
                        throw new RuntimeException("Failed to invoke " + a2.a4 + " with no args", a5.getTargetException());
                    }
                    catch (IllegalAccessException a6) {
                        throw new AssertionError((Object)a6);
                    }
                }
            };
        }
        catch (NoSuchMethodException a5) {
            return null;
        }
    }

    private /* synthetic */ <T> ObjectConstructor<T> p(final Type a2, Class<? super T> a3) {
        ConstructorConstructor a4;
        if (Collection.class.isAssignableFrom(a3)) {
            if (SortedSet.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        4 a3;
                    }

                    @Override
                    public T a() {
                        return new TreeSet();
                    }
                };
            }
            if (EnumSet.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        5 a3;
                    }

                    @Override
                    public T a() {
                        5 a22;
                        if (a22.a2 instanceof ParameterizedType) {
                            Type a3 = ((ParameterizedType)a22.a2).getActualTypeArguments()[0];
                            if (a3 instanceof Class) {
                                return EnumSet.noneOf((Class)a3);
                            }
                            throw new JsonIOException("Invalid EnumSet type: " + a22.a2.toString());
                        }
                        throw new JsonIOException("Invalid EnumSet type: " + a22.a2.toString());
                    }
                };
            }
            if (Set.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        6 a3;
                    }

                    @Override
                    public T a() {
                        return new LinkedHashSet();
                    }
                };
            }
            if (Queue.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        7 a3;
                    }

                    @Override
                    public T a() {
                        return new ArrayDeque();
                    }
                };
            }
            return new ObjectConstructor<T>(){
                {
                    8 a3;
                }

                @Override
                public T a() {
                    return new ArrayList();
                }
            };
        }
        if (Map.class.isAssignableFrom(a3)) {
            if (ConcurrentNavigableMap.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        9 a3;
                    }

                    @Override
                    public T a() {
                        return new ConcurrentSkipListMap();
                    }
                };
            }
            if (ConcurrentMap.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        10 a3;
                    }

                    @Override
                    public T a() {
                        return new ConcurrentHashMap();
                    }
                };
            }
            if (SortedMap.class.isAssignableFrom(a3)) {
                return new ObjectConstructor<T>(){
                    {
                        11 a3;
                    }

                    @Override
                    public T a() {
                        return new TreeMap();
                    }
                };
            }
            if (a2 instanceof ParameterizedType && !String.class.isAssignableFrom((Class<?>)TypeToken.p(((ParameterizedType)a2).getActualTypeArguments()[0]).a())) {
                return new ObjectConstructor<T>(){
                    {
                        12 a3;
                    }

                    @Override
                    public T a() {
                        return new LinkedHashMap();
                    }
                };
            }
            return new ObjectConstructor<T>(){
                {
                    13 a3;
                }

                @Override
                public T a() {
                    return new LinkedTreeMap();
                }
            };
        }
        return null;
    }

    private /* synthetic */ <T> ObjectConstructor<T> a(final Type a2, final Class<? super T> a3) {
        ConstructorConstructor a4;
        return new ObjectConstructor<T>(){
            private final UnsafeAllocator b = UnsafeAllocator.a();
            {
                14 a32;
            }

            @Override
            public T a() {
                14 a22;
                try {
                    Object a32 = a22.b.a(a22.a3);
                    return a32;
                }
                catch (Exception a4) {
                    throw new RuntimeException("Unable to invoke no-args constructor for " + a22.a2 + ". Registering an InstanceCreator with Gson for this type may fix this problem.", a4);
                }
            }
        };
    }

    public String toString() {
        ConstructorConstructor a2;
        return a2.v.toString();
    }
}

