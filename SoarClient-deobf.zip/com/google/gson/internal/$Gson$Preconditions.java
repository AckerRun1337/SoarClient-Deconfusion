/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

public final class $Gson$Preconditions {
    private /* synthetic */ $Gson$Preconditions() {
        $Gson$Preconditions a2;
        throw new UnsupportedOperationException();
    }

    public static <T> T a(T a2) {
        if (a2 == null) {
            throw new NullPointerException();
        }
        return a2;
    }

    public static void a(boolean a2) {
        if (!a2) {
            throw new IllegalArgumentException();
        }
    }
}

