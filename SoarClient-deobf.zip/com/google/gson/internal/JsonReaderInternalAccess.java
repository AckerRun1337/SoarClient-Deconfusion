/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.stream.JsonReader;
import java.io.IOException;

public abstract class JsonReaderInternalAccess {
    public static JsonReaderInternalAccess d;

    public JsonReaderInternalAccess() {
        JsonReaderInternalAccess a2;
    }

    public abstract void a(JsonReader var1) throws IOException;
}

