/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;
import com.google.gson.annotations.Until;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class Excluder
implements TypeAdapterFactory,
Cloneable {
    private static final double f = -1.0;
    public static final Excluder h = new Excluder();
    private double z = -1.0;
    private int l = 136;
    private boolean b = true;
    private boolean c;
    private List<ExclusionStrategy> v = Collections.emptyList();
    private List<ExclusionStrategy> d = Collections.emptyList();

    public Excluder() {
        Excluder a2;
    }

    protected Excluder o() {
        try {
            Excluder a2;
            return (Excluder)super.clone();
        }
        catch (CloneNotSupportedException a3) {
            throw new AssertionError((Object)a3);
        }
    }

    public Excluder a(double a2) {
        Excluder a3;
        Excluder a4 = a3.o();
        a4.z = a2;
        return a4;
    }

    public Excluder a(int ... a2) {
        Excluder a3;
        Excluder a4 = a3.o();
        a4.l = 0;
        for (int a5 : a2) {
            a4.l |= a5;
        }
        return a4;
    }

    public Excluder p() {
        Excluder a2;
        Excluder a3 = a2.o();
        a3.b = false;
        return a3;
    }

    public Excluder a() {
        Excluder a2;
        Excluder a3 = a2.o();
        a3.c = true;
        return a3;
    }

    public Excluder a(ExclusionStrategy a2, boolean a3, boolean a4) {
        Excluder a5;
        Excluder a6 = a5.o();
        if (a3) {
            a6.v = new ArrayList<ExclusionStrategy>(a5.v);
            a6.v.add(a2);
        }
        if (a4) {
            a6.d = new ArrayList<ExclusionStrategy>(a5.d);
            a6.d.add(a2);
        }
        return a6;
    }

    @Override
    public <T> TypeAdapter<T> a(final Gson a2, final TypeToken<T> a3) {
        boolean a4;
        Excluder a5;
        Type a6 = a3.a();
        boolean a7 = a5.y((Class<?>)a6);
        final boolean a8 = a7 || a5.a((Class<?>)a6, true);
        boolean bl2 = a4 = a7 || a5.a((Class<?>)a6, false);
        if (!a8 && !a4) {
            return null;
        }
        return new TypeAdapter<T>(){
            private TypeAdapter<T> z;
            {
                1 a32;
            }

            @Override
            public T a(JsonReader a22) throws IOException {
                1 a32;
                if (a32.a4) {
                    a22.y();
                    return null;
                }
                return a32.p().a(a22);
            }

            @Override
            public void a(JsonWriter a22, T a32) throws IOException {
                1 a42;
                if (a42.a8) {
                    a22.a();
                    return;
                }
                a42.p().a(a22, a32);
            }

            private /* synthetic */ TypeAdapter<T> p() {
                1 a22;
                TypeAdapter a32 = a22.z;
                return a32 != null ? a32 : (a22.z = a22.a2.a(a22.Excluder.this, a22.a3));
            }
        };
    }

    public boolean a(Field a2, boolean a3) {
        Object a4;
        Excluder a5;
        if ((a5.l & a2.getModifiers()) != 0) {
            return true;
        }
        if (a5.z != -1.0 && !a5.a(a2.getAnnotation(Since.class), a2.getAnnotation(Until.class))) {
            return true;
        }
        if (a2.isSynthetic()) {
            return true;
        }
        if (a5.c && ((a4 = a2.getAnnotation(Expose.class)) == null || (a3 ? !a4.m() : !a4.h()))) {
            return true;
        }
        if (!a5.b && a5.p(a2.getType())) {
            return true;
        }
        if (a5.o(a2.getType())) {
            return true;
        }
        Object object = a4 = a3 ? a5.v : a5.d;
        if (!a4.isEmpty()) {
            FieldAttributes a6 = new FieldAttributes(a2);
            Iterator iterator = a4.iterator();
            while (iterator.hasNext()) {
                ExclusionStrategy a7 = (ExclusionStrategy)iterator.next();
                if (!a7.a(a6)) continue;
                return true;
            }
        }
        return false;
    }

    private /* synthetic */ boolean y(Class<?> a2) {
        Excluder a3;
        if (a3.z != -1.0 && !a3.a(a2.getAnnotation(Since.class), a2.getAnnotation(Until.class))) {
            return true;
        }
        if (!a3.b && a3.p(a2)) {
            return true;
        }
        return a3.o(a2);
    }

    public boolean p(Class<?> a2, boolean a3) {
        Excluder a4;
        return a4.y(a2) || a4.a(a2, a3);
    }

    private /* synthetic */ boolean a(Class<?> a2, boolean a3) {
        Excluder a4;
        List<ExclusionStrategy> a5 = a3 ? a4.v : a4.d;
        for (ExclusionStrategy a6 : a5) {
            if (!a6.a(a2)) continue;
            return true;
        }
        return false;
    }

    private /* synthetic */ boolean o(Class<?> a2) {
        return !Enum.class.isAssignableFrom(a2) && (a2.isAnonymousClass() || a2.isLocalClass());
    }

    private /* synthetic */ boolean p(Class<?> a2) {
        Excluder a3;
        return a2.isMemberClass() && !a3.a(a2);
    }

    private /* synthetic */ boolean a(Class<?> a2) {
        return (a2.getModifiers() & 8) != 0;
    }

    private /* synthetic */ boolean a(Since a2, Until a3) {
        Excluder a4;
        return a4.a(a2) && a4.a(a3);
    }

    private /* synthetic */ boolean a(Since a2) {
        Excluder a3;
        double a4;
        return a2 == null || !((a4 = a2.o()) > a3.z);
    }

    private /* synthetic */ boolean a(Until a2) {
        Excluder a3;
        double a4;
        return a2 == null || !((a4 = a2.p()) <= a3.z);
    }
}

