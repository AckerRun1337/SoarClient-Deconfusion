/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import java.lang.reflect.Type;

public final class Primitives {
    private /* synthetic */ Primitives() {
        Primitives a2;
    }

    public static boolean p(Type a2) {
        return a2 instanceof Class && ((Class)a2).isPrimitive();
    }

    public static boolean a(Type a2) {
        return a2 == Integer.class || a2 == Float.class || a2 == Byte.class || a2 == Double.class || a2 == Long.class || a2 == Character.class || a2 == Boolean.class || a2 == Short.class || a2 == Void.class;
    }

    public static <T> Class<T> p(Class<T> a2) {
        if (a2 == Integer.TYPE) {
            return Integer.class;
        }
        if (a2 == Float.TYPE) {
            return Float.class;
        }
        if (a2 == Byte.TYPE) {
            return Byte.class;
        }
        if (a2 == Double.TYPE) {
            return Double.class;
        }
        if (a2 == Long.TYPE) {
            return Long.class;
        }
        if (a2 == Character.TYPE) {
            return Character.class;
        }
        if (a2 == Boolean.TYPE) {
            return Boolean.class;
        }
        if (a2 == Short.TYPE) {
            return Short.class;
        }
        if (a2 == Void.TYPE) {
            return Void.class;
        }
        return a2;
    }

    public static <T> Class<T> a(Class<T> a2) {
        if (a2 == Integer.class) {
            return Integer.TYPE;
        }
        if (a2 == Float.class) {
            return Float.TYPE;
        }
        if (a2 == Byte.class) {
            return Byte.TYPE;
        }
        if (a2 == Double.class) {
            return Double.TYPE;
        }
        if (a2 == Long.class) {
            return Long.TYPE;
        }
        if (a2 == Character.class) {
            return Character.TYPE;
        }
        if (a2 == Boolean.class) {
            return Boolean.TYPE;
        }
        if (a2 == Short.class) {
            return Short.TYPE;
        }
        if (a2 == Void.class) {
            return Void.TYPE;
        }
        return a2;
    }
}

