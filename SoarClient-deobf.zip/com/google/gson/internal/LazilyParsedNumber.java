/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import java.io.ObjectStreamException;
import java.math.BigDecimal;

public final class LazilyParsedNumber
extends Number {
    private final String d;

    public LazilyParsedNumber(String a2) {
        LazilyParsedNumber a3;
        a3.d = a2;
    }

    @Override
    public int intValue() {
        LazilyParsedNumber a2;
        try {
            return Integer.parseInt(a2.d);
        }
        catch (NumberFormatException a3) {
            try {
                return (int)Long.parseLong(a2.d);
            }
            catch (NumberFormatException a4) {
                return new BigDecimal(a2.d).intValue();
            }
        }
    }

    @Override
    public long longValue() {
        LazilyParsedNumber a2;
        try {
            return Long.parseLong(a2.d);
        }
        catch (NumberFormatException a3) {
            return new BigDecimal(a2.d).longValue();
        }
    }

    @Override
    public float floatValue() {
        LazilyParsedNumber a2;
        return Float.parseFloat(a2.d);
    }

    @Override
    public double doubleValue() {
        LazilyParsedNumber a2;
        return Double.parseDouble(a2.d);
    }

    public String toString() {
        LazilyParsedNumber a2;
        return a2.d;
    }

    private /* synthetic */ Object a() throws ObjectStreamException {
        LazilyParsedNumber a2;
        return new BigDecimal(a2.d);
    }

    public int hashCode() {
        LazilyParsedNumber a2;
        return a2.d.hashCode();
    }

    public boolean equals(Object a2) {
        LazilyParsedNumber a3;
        if (a3 == a2) {
            return true;
        }
        if (a2 instanceof LazilyParsedNumber) {
            LazilyParsedNumber a4 = (LazilyParsedNumber)a2;
            return a3.d == a4.d || a3.d.equals(a4.d);
        }
        return false;
    }
}

