/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

final class TypeAdapterRuntimeTypeWrapper<T>
extends TypeAdapter<T> {
    private final Gson c;
    private final TypeAdapter<T> v;
    private final Type d;

    TypeAdapterRuntimeTypeWrapper(Gson a2, TypeAdapter<T> a3, Type a4) {
        TypeAdapterRuntimeTypeWrapper a5;
        a5.c = a2;
        a5.v = a3;
        a5.d = a4;
    }

    @Override
    public T a(JsonReader a2) throws IOException {
        TypeAdapterRuntimeTypeWrapper a3;
        return a3.v.a(a2);
    }

    @Override
    public void a(JsonWriter a2, T a3) throws IOException {
        TypeAdapterRuntimeTypeWrapper a4;
        TypeAdapter<Object> a5 = a4.v;
        Type a6 = a4.a(a4.d, a3);
        if (a6 != a4.d) {
            TypeAdapter<?> a7 = a4.c.a(TypeToken.p(a6));
            a5 = !(a7 instanceof ReflectiveTypeAdapterFactory.Adapter) ? a7 : (!(a4.v instanceof ReflectiveTypeAdapterFactory.Adapter) ? a4.v : a7);
        }
        a5.a(a2, a3);
    }

    private /* synthetic */ Type a(Type a2, Object a3) {
        if (a3 != null && (a2 == Object.class || a2 instanceof TypeVariable || a2 instanceof Class)) {
            a2 = a3.getClass();
        }
        return a2;
    }
}

