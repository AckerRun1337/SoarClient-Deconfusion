/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.internal.Streams;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;

public final class TreeTypeAdapter<T>
extends TypeAdapter<T> {
    private final JsonSerializer<T> h;
    private final JsonDeserializer<T> z;
    final Gson l;
    private final TypeToken<T> b;
    private final TypeAdapterFactory c;
    private final GsonContextImpl v;
    private TypeAdapter<T> d;

    public TreeTypeAdapter(JsonSerializer<T> a2, JsonDeserializer<T> a3, Gson a4, TypeToken<T> a5, TypeAdapterFactory a6) {
        TreeTypeAdapter a7;
        a7.v = a7.new GsonContextImpl();
        a7.h = a2;
        a7.z = a3;
        a7.l = a4;
        a7.b = a5;
        a7.c = a6;
    }

    @Override
    public T a(JsonReader a2) throws IOException {
        TreeTypeAdapter a3;
        if (a3.z == null) {
            return a3.p().a(a2);
        }
        JsonElement a4 = Streams.a(a2);
        if (a4.p()) {
            return null;
        }
        return a3.z.a(a4, a3.b.a(), a3.v);
    }

    @Override
    public void a(JsonWriter a2, T a3) throws IOException {
        TreeTypeAdapter a4;
        if (a4.h == null) {
            a4.p().a(a2, a3);
            return;
        }
        if (a3 == null) {
            a2.a();
            return;
        }
        JsonElement a5 = a4.h.a(a3, a4.b.a(), a4.v);
        Streams.a(a5, a2);
    }

    private /* synthetic */ TypeAdapter<T> p() {
        TreeTypeAdapter a2;
        TypeAdapter<T> a3 = a2.d;
        return a3 != null ? a3 : (a2.d = a2.l.a(a2.c, a2.b));
    }

    public static TypeAdapterFactory p(TypeToken<?> a2, Object a3) {
        return new SingleTypeFactory(a3, a2, false, null);
    }

    public static TypeAdapterFactory a(TypeToken<?> a2, Object a3) {
        boolean a4 = a2.a() == a2.a();
        return new SingleTypeFactory(a3, a2, a4, null);
    }

    public static TypeAdapterFactory a(Class<?> a2, Object a3) {
        return new SingleTypeFactory(a3, null, false, a2);
    }

    private final class GsonContextImpl
    implements JsonSerializationContext,
    JsonDeserializationContext {
        private /* synthetic */ GsonContextImpl() {
            GsonContextImpl a2;
        }

        @Override
        public JsonElement a(Object a2) {
            GsonContextImpl a3;
            return a3.TreeTypeAdapter.this.l.a(a2);
        }

        @Override
        public JsonElement a(Object a2, Type a3) {
            GsonContextImpl a4;
            return a4.TreeTypeAdapter.this.l.a(a2, a3);
        }

        public <R> R a(JsonElement a2, Type a3) throws JsonParseException {
            GsonContextImpl a4;
            return (R)a4.TreeTypeAdapter.this.l.a(a2, a3);
        }
    }

    private static final class SingleTypeFactory
    implements TypeAdapterFactory {
        private final TypeToken<?> l;
        private final boolean b;
        private final Class<?> c;
        private final JsonSerializer<?> v;
        private final JsonDeserializer<?> d;

        SingleTypeFactory(Object a2, TypeToken<?> a3, boolean a4, Class<?> a5) {
            SingleTypeFactory a6;
            a6.v = a2 instanceof JsonSerializer ? (JsonSerializer)a2 : null;
            a6.d = a2 instanceof JsonDeserializer ? (JsonDeserializer)a2 : null;
            $Gson$Preconditions.a(a6.v != null || a6.d != null);
            a6.l = a3;
            a6.b = a4;
            a6.c = a5;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            SingleTypeFactory a4;
            boolean a5 = a4.l != null ? a4.l.equals(a3) || a4.b && a4.l.a() == a3.a() : a4.c.isAssignableFrom((Class<?>)a3.a());
            return a5 ? new TreeTypeAdapter(a4.v, a4.d, a2, a3, a4) : null;
        }
    }
}

