/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.JavaVersion;
import com.google.gson.internal.PreJava9DateFormatProvider;
import com.google.gson.internal.bind.util.ISO8601Utils;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class DateTypeAdapter
extends TypeAdapter<Date> {
    public static final TypeAdapterFactory v = new TypeAdapterFactory(){
        {
            1 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            return a3.a() == Date.class ? new DateTypeAdapter() : null;
        }
    };
    private final List<DateFormat> d = new ArrayList<DateFormat>();

    public DateTypeAdapter() {
        DateTypeAdapter a2;
        a2.d.add(DateFormat.getDateTimeInstance(2, 2, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            a2.d.add(DateFormat.getDateTimeInstance(2, 2));
        }
        if (JavaVersion.a()) {
            a2.d.add(PreJava9DateFormatProvider.a(2, 2));
        }
    }

    @Override
    public Date a(JsonReader a2) throws IOException {
        DateTypeAdapter a3;
        if (a2.a() == JsonToken.c) {
            a2.j();
            return null;
        }
        return a3.a(a2.y());
    }

    @Override
    private synchronized /* synthetic */ Date a(String a2) {
        DateTypeAdapter a3;
        for (DateFormat a4 : a3.d) {
            try {
                return a4.parse(a2);
            }
            catch (ParseException parseException) {
            }
        }
        try {
            return ISO8601Utils.a(a2, new ParsePosition(0));
        }
        catch (ParseException a5) {
            throw new JsonSyntaxException(a2, a5);
        }
    }

    @Override
    public synchronized void a(JsonWriter a2, Date a3) throws IOException {
        DateTypeAdapter a4;
        if (a3 == null) {
            a2.a();
            return;
        }
        String a5 = a4.d.get(0).format(a3);
        a2.p(a5);
    }
}

