/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;

public final class CollectionTypeAdapterFactory
implements TypeAdapterFactory {
    private final ConstructorConstructor d;

    public CollectionTypeAdapterFactory(ConstructorConstructor a2) {
        CollectionTypeAdapterFactory a3;
        a3.d = a2;
    }

    @Override
    public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
        CollectionTypeAdapterFactory a4;
        Type a5 = a3.a();
        Type a6 = a3.a();
        if (!Collection.class.isAssignableFrom((Class<?>)a6)) {
            return null;
        }
        Type a7 = $Gson$Types.a(a5, a6);
        TypeAdapter<?> a8 = a2.a(TypeToken.p(a7));
        ObjectConstructor<T> a9 = a4.d.a(a3);
        Adapter a10 = new Adapter(a2, a7, a8, a9);
        return a10;
    }

    private static final class Adapter<E>
    extends TypeAdapter<Collection<E>> {
        private final TypeAdapter<E> v;
        private final ObjectConstructor<? extends Collection<E>> d;

        public Adapter(Gson a2, Type a3, TypeAdapter<E> a4, ObjectConstructor<? extends Collection<E>> a5) {
            Adapter a6;
            a6.v = new TypeAdapterRuntimeTypeWrapper<E>(a2, a4, a3);
            a6.d = a5;
        }

        @Override
        public Collection<E> a(JsonReader a2) throws IOException {
            Adapter a3;
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            Collection<E> a4 = a3.d.a();
            a2.d();
            while (a2.p()) {
                E a5 = a3.v.a(a2);
                a4.add(a5);
            }
            a2.m();
            return a4;
        }

        @Override
        public void a(JsonWriter a2, Collection<E> a3) throws IOException {
            if (a3 == null) {
                a2.a();
                return;
            }
            a2.z();
            for (E a4 : a3) {
                Adapter a5;
                a5.v.a(a2, a4);
            }
            a2.y();
        }
    }
}

