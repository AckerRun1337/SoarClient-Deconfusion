/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class TypeAdapters {
    public static final TypeAdapter<Class> ra = new TypeAdapter<Class>(){
        {
            1 a2;
        }

        @Override
        public void a(JsonWriter a2, Class a3) throws IOException {
            throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + a3.getName() + ". Forgot to register a type adapter?");
        }

        @Override
        public Class a(JsonReader a2) throws IOException {
            throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
        }
    }.a();
    public static final TypeAdapterFactory aa = TypeAdapters.p(Class.class, ra);
    public static final TypeAdapter<BitSet> za = new TypeAdapter<BitSet>(){
        {
            2 a2;
        }

        @Override
        public BitSet a(JsonReader a2) throws IOException {
            BitSet a3 = new BitSet();
            a2.d();
            int a4 = 0;
            JsonToken a5 = a2.a();
            while (a5 != JsonToken.e) {
                boolean a6;
                switch (a5) {
                    case l: {
                        a6 = a2.a() != 0;
                        break;
                    }
                    case b: {
                        a6 = a2.a();
                        break;
                    }
                    case z: {
                        String a7 = a2.y();
                        try {
                            a6 = Integer.parseInt(a7) != 0;
                            break;
                        }
                        catch (NumberFormatException a8) {
                            throw new JsonSyntaxException("Error: Expecting: bitset number value (1, 0), Found: " + a7);
                        }
                    }
                    default: {
                        throw new JsonSyntaxException("Invalid bitset value type: " + (Object)((Object)a5));
                    }
                }
                if (a6) {
                    a3.set(a4);
                }
                ++a4;
                a5 = a2.a();
            }
            a2.m();
            return a3;
        }

        @Override
        public void a(JsonWriter a2, BitSet a3) throws IOException {
            a2.z();
            int a4 = a3.length();
            for (int a5 = 0; a5 < a4; ++a5) {
                int a6 = a3.get(a5) ? 1 : 0;
                a2.a((long)a6);
            }
            a2.y();
        }
    }.a();
    public static final TypeAdapterFactory fa = TypeAdapters.p(BitSet.class, za);
    public static final TypeAdapter<Boolean> wa = new TypeAdapter<Boolean>(){
        {
            3 a2;
        }

        @Override
        public Boolean a(JsonReader a2) throws IOException {
            JsonToken a3 = a2.a();
            if (a3 == JsonToken.c) {
                a2.j();
                return null;
            }
            if (a3 == JsonToken.z) {
                return Boolean.parseBoolean(a2.y());
            }
            return a2.a();
        }

        @Override
        public void a(JsonWriter a2, Boolean a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapter<Boolean> va = new TypeAdapter<Boolean>(){
        {
            4 a2;
        }

        @Override
        public Boolean a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return Boolean.valueOf(a2.y());
        }

        @Override
        public void a(JsonWriter a2, Boolean a3) throws IOException {
            a2.p(a3 == null ? "null" : a3.toString());
        }
    };
    public static final TypeAdapterFactory sa = TypeAdapters.p(Boolean.TYPE, Boolean.class, wa);
    public static final TypeAdapter<Number> ea = new TypeAdapter<Number>(){
        {
            5 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                int a3 = a2.a();
                return (byte)a3;
            }
            catch (NumberFormatException a4) {
                throw new JsonSyntaxException(a4);
            }
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapterFactory qa = TypeAdapters.p(Byte.TYPE, Byte.class, ea);
    public static final TypeAdapter<Number> xa = new TypeAdapter<Number>(){
        {
            6 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                return (short)a2.a();
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapterFactory ua = TypeAdapters.p(Short.TYPE, Short.class, xa);
    public static final TypeAdapter<Number> da = new TypeAdapter<Number>(){
        {
            7 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                return a2.a();
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapterFactory ma = TypeAdapters.p(Integer.TYPE, Integer.class, da);
    public static final TypeAdapter<AtomicInteger> na = new TypeAdapter<AtomicInteger>(){
        {
            8 a2;
        }

        @Override
        public AtomicInteger a(JsonReader a2) throws IOException {
            try {
                return new AtomicInteger(a2.a());
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, AtomicInteger a3) throws IOException {
            a2.a((long)a3.get());
        }
    }.a();
    public static final TypeAdapterFactory ka = TypeAdapters.p(AtomicInteger.class, na);
    public static final TypeAdapter<AtomicBoolean> ha = new TypeAdapter<AtomicBoolean>(){
        {
            9 a2;
        }

        @Override
        public AtomicBoolean a(JsonReader a2) throws IOException {
            return new AtomicBoolean(a2.a());
        }

        @Override
        public void a(JsonWriter a2, AtomicBoolean a3) throws IOException {
            a2.a(a3.get());
        }
    }.a();
    public static final TypeAdapterFactory ya = TypeAdapters.p(AtomicBoolean.class, ha);
    public static final TypeAdapter<AtomicIntegerArray> ca = new TypeAdapter<AtomicIntegerArray>(){
        {
            10 a2;
        }

        @Override
        public AtomicIntegerArray a(JsonReader a2) throws IOException {
            int a3;
            ArrayList<Integer> a4 = new ArrayList<Integer>();
            a2.d();
            while (a2.p()) {
                try {
                    a3 = a2.a();
                    a4.add(a3);
                }
                catch (NumberFormatException a5) {
                    throw new JsonSyntaxException(a5);
                }
            }
            a2.m();
            a3 = a4.size();
            AtomicIntegerArray a6 = new AtomicIntegerArray(a3);
            for (int a7 = 0; a7 < a3; ++a7) {
                a6.set(a7, (Integer)a4.get(a7));
            }
            return a6;
        }

        @Override
        public void a(JsonWriter a2, AtomicIntegerArray a3) throws IOException {
            a2.z();
            int a4 = a3.length();
            for (int a5 = 0; a5 < a4; ++a5) {
                a2.a((long)a3.get(a5));
            }
            a2.y();
        }
    }.a();
    public static final TypeAdapterFactory ga = TypeAdapters.p(AtomicIntegerArray.class, ca);
    public static final TypeAdapter<Number> ja = new TypeAdapter<Number>(){
        {
            11 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                return a2.a();
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapter<Number> ia = new TypeAdapter<Number>(){
        {
            12 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return Float.valueOf((float)a2.a());
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapter<Number> ta = new TypeAdapter<Number>(){
        {
            13 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return a2.a();
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapter<Number> oa = new TypeAdapter<Number>(){
        {
            14 a2;
        }

        @Override
        public Number a(JsonReader a2) throws IOException {
            JsonToken a3 = a2.a();
            switch (a3) {
                case c: {
                    a2.j();
                    return null;
                }
                case l: 
                case z: {
                    return new LazilyParsedNumber(a2.y());
                }
            }
            throw new JsonSyntaxException("Expecting number, got: " + (Object)((Object)a3));
        }

        @Override
        public void a(JsonWriter a2, Number a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapterFactory pa = TypeAdapters.p(Number.class, oa);
    public static final TypeAdapter<Character> ba = new TypeAdapter<Character>(){
        {
            15 a2;
        }

        @Override
        public Character a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            String a3 = a2.y();
            if (a3.length() != 1) {
                throw new JsonSyntaxException("Expecting character, got: " + a3);
            }
            return Character.valueOf(a3.charAt(0));
        }

        @Override
        public void a(JsonWriter a2, Character a3) throws IOException {
            a2.p(a3 == null ? null : String.valueOf(a3));
        }
    };
    public static final TypeAdapterFactory la = TypeAdapters.p(Character.TYPE, Character.class, ba);
    public static final TypeAdapter<String> u = new TypeAdapter<String>(){
        {
            16 a2;
        }

        @Override
        public String a(JsonReader a2) throws IOException {
            JsonToken a3 = a2.a();
            if (a3 == JsonToken.c) {
                a2.j();
                return null;
            }
            if (a3 == JsonToken.b) {
                return Boolean.toString(a2.a());
            }
            return a2.y();
        }

        @Override
        public void a(JsonWriter a2, String a3) throws IOException {
            a2.p(a3);
        }
    };
    public static final TypeAdapter<BigDecimal> j = new TypeAdapter<BigDecimal>(){
        {
            17 a2;
        }

        @Override
        public BigDecimal a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                return new BigDecimal(a2.y());
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, BigDecimal a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapter<BigInteger> o = new TypeAdapter<BigInteger>(){
        {
            18 a2;
        }

        @Override
        public BigInteger a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                return new BigInteger(a2.y());
            }
            catch (NumberFormatException a3) {
                throw new JsonSyntaxException(a3);
            }
        }

        @Override
        public void a(JsonWriter a2, BigInteger a3) throws IOException {
            a2.a(a3);
        }
    };
    public static final TypeAdapterFactory m = TypeAdapters.p(String.class, u);
    public static final TypeAdapter<StringBuilder> y = new TypeAdapter<StringBuilder>(){
        {
            19 a2;
        }

        @Override
        public StringBuilder a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return new StringBuilder(a2.y());
        }

        @Override
        public void a(JsonWriter a2, StringBuilder a3) throws IOException {
            a2.p(a3 == null ? null : a3.toString());
        }
    };
    public static final TypeAdapterFactory a = TypeAdapters.p(StringBuilder.class, y);
    public static final TypeAdapter<StringBuffer> q = new TypeAdapter<StringBuffer>(){
        {
            20 a2;
        }

        @Override
        public StringBuffer a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return new StringBuffer(a2.y());
        }

        @Override
        public void a(JsonWriter a2, StringBuffer a3) throws IOException {
            a2.p(a3 == null ? null : a3.toString());
        }
    };
    public static final TypeAdapterFactory g = TypeAdapters.p(StringBuffer.class, q);
    public static final TypeAdapter<URL> k = new TypeAdapter<URL>(){
        {
            21 a2;
        }

        @Override
        public URL a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            String a3 = a2.y();
            return "null".equals(a3) ? null : new URL(a3);
        }

        @Override
        public void a(JsonWriter a2, URL a3) throws IOException {
            a2.p(a3 == null ? null : a3.toExternalForm());
        }
    };
    public static final TypeAdapterFactory x = TypeAdapters.p(URL.class, k);
    public static final TypeAdapter<URI> t = new TypeAdapter<URI>(){
        {
            22 a2;
        }

        @Override
        public URI a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            try {
                String a3 = a2.y();
                return "null".equals(a3) ? null : new URI(a3);
            }
            catch (URISyntaxException a4) {
                throw new JsonIOException(a4);
            }
        }

        @Override
        public void a(JsonWriter a2, URI a3) throws IOException {
            a2.p(a3 == null ? null : a3.toASCIIString());
        }
    };
    public static final TypeAdapterFactory p = TypeAdapters.p(URI.class, t);
    public static final TypeAdapter<InetAddress> s = new TypeAdapter<InetAddress>(){
        {
            23 a2;
        }

        @Override
        public InetAddress a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return InetAddress.getByName(a2.y());
        }

        @Override
        public void a(JsonWriter a2, InetAddress a3) throws IOException {
            a2.p(a3 == null ? null : a3.getHostAddress());
        }
    };
    public static final TypeAdapterFactory w = TypeAdapters.a(InetAddress.class, s);
    public static final TypeAdapter<UUID> i = new TypeAdapter<UUID>(){
        {
            24 a2;
        }

        @Override
        public UUID a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return UUID.fromString(a2.y());
        }

        @Override
        public void a(JsonWriter a2, UUID a3) throws IOException {
            a2.p(a3 == null ? null : a3.toString());
        }
    };
    public static final TypeAdapterFactory n = TypeAdapters.p(UUID.class, i);
    public static final TypeAdapter<Currency> e = new TypeAdapter<Currency>(){
        {
            25 a2;
        }

        @Override
        public Currency a(JsonReader a2) throws IOException {
            return Currency.getInstance(a2.y());
        }

        @Override
        public void a(JsonWriter a2, Currency a3) throws IOException {
            a2.p(a3.getCurrencyCode());
        }
    }.a();
    public static final TypeAdapterFactory r = TypeAdapters.p(Currency.class, e);
    public static final TypeAdapterFactory f = new TypeAdapterFactory(){
        {
            26 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            26 a4;
            if (a3.a() != Timestamp.class) {
                return null;
            }
            final TypeAdapter<Date> a5 = a2.a(Date.class);
            return new TypeAdapter<Timestamp>(){
                {
                    1 a3;
                }

                @Override
                public Timestamp a(JsonReader a2) throws IOException {
                    1 a3;
                    Date a4 = (Date)a3.a5.a(a2);
                    return a4 != null ? new Timestamp(a4.getTime()) : null;
                }

                @Override
                public void a(JsonWriter a2, Timestamp a3) throws IOException {
                    1 a4;
                    a4.a5.a(a2, a3);
                }
            };
        }
    };
    public static final TypeAdapter<Calendar> h = new TypeAdapter<Calendar>(){
        private static final String z = "year";
        private static final String l = "month";
        private static final String b = "dayOfMonth";
        private static final String c = "hourOfDay";
        private static final String v = "minute";
        private static final String d = "second";
        {
            27 a2;
        }

        @Override
        public Calendar a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            a2.h();
            int a3 = 0;
            int a4 = 0;
            int a5 = 0;
            int a6 = 0;
            int a7 = 0;
            int a8 = 0;
            while (a2.a() != JsonToken.f) {
                String a9 = a2.z();
                int a10 = a2.a();
                if (z.equals(a9)) {
                    a3 = a10;
                    continue;
                }
                if (l.equals(a9)) {
                    a4 = a10;
                    continue;
                }
                if (b.equals(a9)) {
                    a5 = a10;
                    continue;
                }
                if (c.equals(a9)) {
                    a6 = a10;
                    continue;
                }
                if (v.equals(a9)) {
                    a7 = a10;
                    continue;
                }
                if (!d.equals(a9)) continue;
                a8 = a10;
            }
            a2.x();
            return new GregorianCalendar(a3, a4, a5, a6, a7, a8);
        }

        @Override
        public void a(JsonWriter a2, Calendar a3) throws IOException {
            if (a3 == null) {
                a2.a();
                return;
            }
            a2.o();
            a2.o(z);
            a2.a((long)a3.get(1));
            a2.o(l);
            a2.a((long)a3.get(2));
            a2.o(b);
            a2.a((long)a3.get(5));
            a2.o(c);
            a2.a((long)a3.get(11));
            a2.o(v);
            a2.a((long)a3.get(12));
            a2.o(d);
            a2.a((long)a3.get(13));
            a2.p();
        }
    };
    public static final TypeAdapterFactory z = TypeAdapters.a(Calendar.class, GregorianCalendar.class, h);
    public static final TypeAdapter<Locale> l = new TypeAdapter<Locale>(){
        {
            28 a2;
        }

        @Override
        public Locale a(JsonReader a2) throws IOException {
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            String a3 = a2.y();
            StringTokenizer a4 = new StringTokenizer(a3, "_");
            String a5 = null;
            String a6 = null;
            String a7 = null;
            if (a4.hasMoreElements()) {
                a5 = a4.nextToken();
            }
            if (a4.hasMoreElements()) {
                a6 = a4.nextToken();
            }
            if (a4.hasMoreElements()) {
                a7 = a4.nextToken();
            }
            if (a6 == null && a7 == null) {
                return new Locale(a5);
            }
            if (a7 == null) {
                return new Locale(a5, a6);
            }
            return new Locale(a5, a6, a7);
        }

        @Override
        public void a(JsonWriter a2, Locale a3) throws IOException {
            a2.p(a3 == null ? null : a3.toString());
        }
    };
    public static final TypeAdapterFactory b = TypeAdapters.p(Locale.class, l);
    public static final TypeAdapter<JsonElement> c = new TypeAdapter<JsonElement>(){
        {
            29 a2;
        }

        @Override
        public JsonElement a(JsonReader a2) throws IOException {
            switch (a2.a()) {
                case z: {
                    return new JsonPrimitive(a2.y());
                }
                case l: {
                    String a3 = a2.y();
                    return new JsonPrimitive(new LazilyParsedNumber(a3));
                }
                case b: {
                    return new JsonPrimitive(a2.a());
                }
                case c: {
                    a2.j();
                    return JsonNull.d;
                }
                case n: {
                    29 a4;
                    JsonArray a5 = new JsonArray();
                    a2.d();
                    while (a2.p()) {
                        a5.a(a4.a(a2));
                    }
                    a2.m();
                    return a5;
                }
                case r: {
                    29 a4;
                    JsonObject a6 = new JsonObject();
                    a2.h();
                    while (a2.p()) {
                        a6.a(a2.z(), a4.a(a2));
                    }
                    a2.x();
                    return a6;
                }
            }
            throw new IllegalArgumentException();
        }

        @Override
        public void a(JsonWriter a2, JsonElement a3) throws IOException {
            29 a4;
            if (a3 == null || a3.p()) {
                a2.a();
            } else if (a3.o()) {
                JsonElement a5 = a3.a();
                if (((JsonPrimitive)a5).x()) {
                    a2.a(((JsonPrimitive)a5).a());
                } else if (((JsonPrimitive)a5).h()) {
                    a2.a(((JsonPrimitive)a5).a());
                } else {
                    a2.p(((JsonPrimitive)a5).a());
                }
            } else if (a3.z()) {
                a2.z();
                Iterator<JsonElement> iterator = ((JsonArray)a3.a()).iterator();
                while (iterator.hasNext()) {
                    JsonElement a6 = iterator.next();
                    a4.a(a2, a6);
                }
                a2.y();
            } else if (a3.y()) {
                a2.o();
                for (Map.Entry<String, JsonElement> a7 : ((JsonObject)a3.a()).p()) {
                    a2.o(a7.getKey());
                    a4.a(a2, a7.getValue());
                }
                a2.p();
            } else {
                throw new IllegalArgumentException("Couldn't write " + a3.getClass());
            }
        }
    };
    public static final TypeAdapterFactory v = TypeAdapters.a(JsonElement.class, c);
    public static final TypeAdapterFactory d = new TypeAdapterFactory(){
        {
            30 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            Class a4 = a3.a();
            if (!Enum.class.isAssignableFrom(a4) || a4 == Enum.class) {
                return null;
            }
            if (!a4.isEnum()) {
                a4 = a4.getSuperclass();
            }
            return new EnumTypeAdapter(a4);
        }
    };

    private /* synthetic */ TypeAdapters() {
        TypeAdapters a2;
        throw new UnsupportedOperationException();
    }

    public static <TT> TypeAdapterFactory a(final TypeToken<TT> a2, final TypeAdapter<TT> a3) {
        return new TypeAdapterFactory(){
            {
                31 a22;
            }

            @Override
            public <T> TypeAdapter<T> a(Gson a22, TypeToken<T> a32) {
                31 a4;
                return a32.equals(a4.a2) ? a4.a3 : null;
            }
        };
    }

    public static <TT> TypeAdapterFactory p(final Class<TT> a2, final TypeAdapter<TT> a3) {
        return new TypeAdapterFactory(){
            {
                32 a22;
            }

            @Override
            public <T> TypeAdapter<T> a(Gson a22, TypeToken<T> a32) {
                32 a4;
                return a32.a() == a4.a2 ? a4.a3 : null;
            }

            public String toString() {
                32 a22;
                return "Factory[type=" + a22.a2.getName() + ",adapter=" + a22.a3 + "]";
            }
        };
    }

    public static <TT> TypeAdapterFactory p(final Class<TT> a2, final Class<TT> a3, final TypeAdapter<? super TT> a4) {
        return new TypeAdapterFactory(){
            {
                33 a22;
            }

            @Override
            public <T> TypeAdapter<T> a(Gson a22, TypeToken<T> a32) {
                33 a42;
                Type a5 = a32.a();
                return a5 == a42.a2 || a5 == a42.a3 ? a42.a4 : null;
            }

            public String toString() {
                33 a22;
                return "Factory[type=" + a22.a3.getName() + "+" + a22.a2.getName() + ",adapter=" + a22.a4 + "]";
            }
        };
    }

    public static <TT> TypeAdapterFactory a(final Class<TT> a2, final Class<? extends TT> a3, final TypeAdapter<? super TT> a4) {
        return new TypeAdapterFactory(){
            {
                34 a22;
            }

            @Override
            public <T> TypeAdapter<T> a(Gson a22, TypeToken<T> a32) {
                34 a42;
                Type a5 = a32.a();
                return a5 == a42.a2 || a5 == a42.a3 ? a42.a4 : null;
            }

            public String toString() {
                34 a22;
                return "Factory[type=" + a22.a2.getName() + "+" + a22.a3.getName() + ",adapter=" + a22.a4 + "]";
            }
        };
    }

    public static <T1> TypeAdapterFactory a(final Class<T1> a2, final TypeAdapter<T1> a3) {
        return new TypeAdapterFactory(){
            {
                35 a22;
            }

            public <T2> TypeAdapter<T2> a(Gson a22, TypeToken<T2> a32) {
                35 a4;
                Type a5 = a32.a();
                if (!a4.a2.isAssignableFrom((Class<?>)a5)) {
                    return null;
                }
                return new TypeAdapter<T1>((Class)a5){
                    final /* synthetic */ Class v;
                    {
                        1 a3;
                        a3.v = clazz;
                    }

                    @Override
                    public void a(JsonWriter a2, T1 a3) throws IOException {
                        1 a4;
                        a4.a3.a(a2, a3);
                    }

                    @Override
                    public T1 a(JsonReader a2) throws IOException {
                        1 a3;
                        Object a4 = a3.a3.a(a2);
                        if (a4 != null && !a3.v.isInstance(a4)) {
                            throw new JsonSyntaxException("Expected a " + a3.v.getName() + " but was " + a4.getClass().getName());
                        }
                        return a4;
                    }
                };
            }

            public String toString() {
                35 a22;
                return "Factory[typeHierarchy=" + a22.a2.getName() + ",adapter=" + a22.a3 + "]";
            }
        };
    }

    private static final class EnumTypeAdapter<T extends Enum<T>>
    extends TypeAdapter<T> {
        private final Map<String, T> v = new HashMap<String, T>();
        private final Map<T, String> d = new HashMap<T, String>();

        public EnumTypeAdapter(Class<T> a2) {
            EnumTypeAdapter a3;
            try {
                for (Enum a4 : (Enum[])a2.getEnumConstants()) {
                    String a5 = a4.name();
                    SerializedName a6 = a2.getField(a5).getAnnotation(SerializedName.class);
                    if (a6 != null) {
                        a5 = a6.z();
                        for (String a7 : a6.y()) {
                            a3.v.put(a7, a4);
                        }
                    }
                    a3.v.put(a5, a4);
                    a3.d.put(a4, a5);
                }
            }
            catch (NoSuchFieldException a8) {
                throw new AssertionError((Object)a8);
            }
        }

        @Override
        public T a(JsonReader a2) throws IOException {
            EnumTypeAdapter a3;
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            return (T)((Enum)a3.v.get(a2.y()));
        }

        @Override
        public void a(JsonWriter a2, T a3) throws IOException {
            EnumTypeAdapter a4;
            a2.p(a3 == null ? null : a4.d.get(a3));
        }
    }
}

