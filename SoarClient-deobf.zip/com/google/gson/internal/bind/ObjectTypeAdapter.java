/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.ArrayList;

public final class ObjectTypeAdapter
extends TypeAdapter<Object> {
    public static final TypeAdapterFactory v = new TypeAdapterFactory(){
        {
            1 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            if (a3.a() == Object.class) {
                return new ObjectTypeAdapter(a2);
            }
            return null;
        }
    };
    private final Gson d;

    ObjectTypeAdapter(Gson a2) {
        ObjectTypeAdapter a3;
        a3.d = a2;
    }

    @Override
    public Object a(JsonReader a2) throws IOException {
        JsonToken a3 = a2.a();
        switch (a3) {
            case n: {
                ObjectTypeAdapter a4;
                ArrayList<Object> a5 = new ArrayList<Object>();
                a2.d();
                while (a2.p()) {
                    a5.add(a4.a(a2));
                }
                a2.m();
                return a5;
            }
            case r: {
                ObjectTypeAdapter a4;
                LinkedTreeMap<String, Object> a6 = new LinkedTreeMap<String, Object>();
                a2.h();
                while (a2.p()) {
                    a6.put(a2.z(), a4.a(a2));
                }
                a2.x();
                return a6;
            }
            case z: {
                return a2.y();
            }
            case l: {
                return a2.a();
            }
            case b: {
                return a2.a();
            }
            case c: {
                a2.j();
                return null;
            }
        }
        throw new IllegalStateException();
    }

    @Override
    public void a(JsonWriter a2, Object a3) throws IOException {
        ObjectTypeAdapter a4;
        if (a3 == null) {
            a2.a();
            return;
        }
        TypeAdapter<?> a5 = a4.d.a(a3.getClass());
        if (a5 instanceof ObjectTypeAdapter) {
            a2.o();
            a2.p();
            return;
        }
        a5.a(a2, a3);
    }
}

