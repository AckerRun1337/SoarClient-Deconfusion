/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JsonTreeWriter
extends JsonWriter {
    private static final Writer l = new Writer(){
        {
            1 a2;
        }

        @Override
        public void write(char[] a2, int a3, int a4) {
            throw new AssertionError();
        }

        @Override
        public void flush() throws IOException {
            throw new AssertionError();
        }

        @Override
        public void close() throws IOException {
            throw new AssertionError();
        }
    };
    private static final JsonPrimitive b = new JsonPrimitive("closed");
    private final List<JsonElement> c = new ArrayList<JsonElement>();
    private String v;
    private JsonElement d = JsonNull.d;

    public JsonTreeWriter() {
        super(l);
        JsonTreeWriter a2;
    }

    public JsonElement p() {
        JsonTreeWriter a2;
        if (!a2.c.isEmpty()) {
            throw new IllegalStateException("Expected one JSON element but was " + a2.c);
        }
        return a2.d;
    }

    private /* synthetic */ JsonElement a() {
        JsonTreeWriter a2;
        return a2.c.get(a2.c.size() - 1);
    }

    private /* synthetic */ void a(JsonElement a2) {
        JsonTreeWriter a3;
        if (a3.v != null) {
            if (!a2.p() || a3.a()) {
                JsonObject a4 = (JsonObject)a3.a();
                a4.a(a3.v, a2);
            }
            a3.v = null;
        } else if (a3.c.isEmpty()) {
            a3.d = a2;
        } else {
            JsonElement a5 = a3.a();
            if (a5 instanceof JsonArray) {
                ((JsonArray)a5).a(a2);
            } else {
                throw new IllegalStateException();
            }
        }
    }

    @Override
    public JsonWriter z() throws IOException {
        JsonTreeWriter a2;
        JsonArray a3 = new JsonArray();
        a2.a(a3);
        a2.c.add(a3);
        return a2;
    }

    @Override
    public JsonWriter y() throws IOException {
        JsonTreeWriter a2;
        if (a2.c.isEmpty() || a2.v != null) {
            throw new IllegalStateException();
        }
        JsonElement a3 = a2.a();
        if (a3 instanceof JsonArray) {
            a2.c.remove(a2.c.size() - 1);
            return a2;
        }
        throw new IllegalStateException();
    }

    @Override
    public JsonWriter o() throws IOException {
        JsonTreeWriter a2;
        JsonObject a3 = new JsonObject();
        a2.a(a3);
        a2.c.add(a3);
        return a2;
    }

    @Override
    public JsonWriter p() throws IOException {
        JsonTreeWriter a2;
        if (a2.c.isEmpty() || a2.v != null) {
            throw new IllegalStateException();
        }
        JsonElement a3 = a2.a();
        if (a3 instanceof JsonObject) {
            a2.c.remove(a2.c.size() - 1);
            return a2;
        }
        throw new IllegalStateException();
    }

    @Override
    public JsonWriter o(String a2) throws IOException {
        JsonTreeWriter a3;
        if (a3.c.isEmpty() || a3.v != null) {
            throw new IllegalStateException();
        }
        JsonElement a4 = a3.a();
        if (a4 instanceof JsonObject) {
            a3.v = a2;
            return a3;
        }
        throw new IllegalStateException();
    }

    @Override
    public JsonWriter p(String a2) throws IOException {
        JsonTreeWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.a(new JsonPrimitive(a2));
        return a3;
    }

    @Override
    public JsonWriter a() throws IOException {
        JsonTreeWriter a2;
        a2.a(JsonNull.d);
        return a2;
    }

    @Override
    public JsonWriter a(boolean a2) throws IOException {
        JsonTreeWriter a3;
        a3.a(new JsonPrimitive(a2));
        return a3;
    }

    @Override
    public JsonWriter a(Boolean a2) throws IOException {
        JsonTreeWriter a3;
        if (a2 == null) {
            return a3.a();
        }
        a3.a(new JsonPrimitive(a2));
        return a3;
    }

    @Override
    public JsonWriter a(double a2) throws IOException {
        JsonTreeWriter a3;
        if (!a3.o() && (Double.isNaN(a2) || Double.isInfinite(a2))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: " + a2);
        }
        a3.a(new JsonPrimitive(a2));
        return a3;
    }

    @Override
    public JsonWriter a(long a2) throws IOException {
        JsonTreeWriter a3;
        a3.a(new JsonPrimitive(a2));
        return a3;
    }

    @Override
    public JsonWriter a(Number a2) throws IOException {
        double a3;
        JsonTreeWriter a4;
        if (a2 == null) {
            return a4.a();
        }
        if (!a4.o() && (Double.isNaN(a3 = a2.doubleValue()) || Double.isInfinite(a3))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: " + a2);
        }
        a4.a(new JsonPrimitive(a2));
        return a4;
    }

    @Override
    public void flush() throws IOException {
    }

    @Override
    public void close() throws IOException {
        JsonTreeWriter a2;
        if (!a2.c.isEmpty()) {
            throw new IOException("Incomplete document");
        }
        a2.c.add(b);
    }
}

