/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class ISO8601Utils {
    private static final String v = "UTC";
    private static final TimeZone d = TimeZone.getTimeZone("UTC");

    public ISO8601Utils() {
        ISO8601Utils a2;
    }

    public static String a(Date a2) {
        return ISO8601Utils.a(a2, false, d);
    }

    public static String a(Date a2, boolean a3) {
        return ISO8601Utils.a(a2, a3, d);
    }

    public static String a(Date a2, boolean a3, TimeZone a4) {
        int a5;
        GregorianCalendar a6 = new GregorianCalendar(a4, Locale.US);
        a6.setTime(a2);
        int a7 = "yyyy-MM-ddThh:mm:ss".length();
        a7 += a3 ? ".sss".length() : 0;
        StringBuilder a8 = new StringBuilder(a7 += a4.getRawOffset() == 0 ? "Z".length() : "+hh:mm".length());
        ISO8601Utils.a(a8, a6.get(1), "yyyy".length());
        a8.append('-');
        ISO8601Utils.a(a8, a6.get(2) + 1, "MM".length());
        a8.append('-');
        ISO8601Utils.a(a8, a6.get(5), "dd".length());
        a8.append('T');
        ISO8601Utils.a(a8, a6.get(11), "hh".length());
        a8.append(':');
        ISO8601Utils.a(a8, a6.get(12), "mm".length());
        a8.append(':');
        ISO8601Utils.a(a8, a6.get(13), "ss".length());
        if (a3) {
            a8.append('.');
            ISO8601Utils.a(a8, a6.get(14), "sss".length());
        }
        if ((a5 = a4.getOffset(a6.getTimeInMillis())) != 0) {
            int a9 = Math.abs(a5 / 60000 / 60);
            int a10 = Math.abs(a5 / 60000 % 60);
            a8.append(a5 < 0 ? (char)'-' : '+');
            ISO8601Utils.a(a8, a9, "hh".length());
            a8.append(':');
            ISO8601Utils.a(a8, a10, "mm".length());
        } else {
            a8.append('Z');
        }
        return a8.toString();
    }

    public static Date a(String a2, ParsePosition a3) throws ParseException {
        RuntimeException a4 = null;
        try {
            int a5;
            int a6 = a3.getIndex();
            int a7 = ISO8601Utils.a(a2, a6, a6 += 4);
            if (ISO8601Utils.a(a2, a6, '-')) {
                // empty if block
            }
            int a8 = ISO8601Utils.a(a2, ++a6, a6 += 2);
            if (ISO8601Utils.a(a2, a6, '-')) {
                // empty if block
            }
            int a9 = ISO8601Utils.a(a2, ++a6, a6 += 2);
            int a10 = 0;
            int a11 = 0;
            int a12 = 0;
            int a13 = 0;
            boolean a14 = ISO8601Utils.a(a2, a6, 'T');
            if (!a14 && a2.length() <= a6) {
                GregorianCalendar a15 = new GregorianCalendar(a7, a8 - 1, a9);
                a3.setIndex(a6);
                return a15.getTime();
            }
            if (a14) {
                char a16;
                a10 = ISO8601Utils.a(a2, ++a6, a6 += 2);
                if (ISO8601Utils.a(a2, a6, ':')) {
                    // empty if block
                }
                a11 = ISO8601Utils.a(a2, ++a6, a6 += 2);
                if (ISO8601Utils.a(a2, a6, ':')) {
                    ++a6;
                }
                if (a2.length() > a6 && (a16 = a2.charAt(a6)) != 'Z' && a16 != '+' && a16 != '-') {
                    if ((a12 = ISO8601Utils.a(a2, a6, a6 += 2)) > 59 && a12 < 63) {
                        a12 = 59;
                    }
                    if (ISO8601Utils.a(a2, a6, '.')) {
                        a5 = ISO8601Utils.a(a2, ++a6 + 1);
                        int a17 = Math.min(a5, a6 + 3);
                        int a18 = ISO8601Utils.a(a2, a6, a17);
                        switch (a17 - a6) {
                            case 2: {
                                a13 = a18 * 10;
                                break;
                            }
                            case 1: {
                                a13 = a18 * 100;
                                break;
                            }
                            default: {
                                a13 = a18;
                            }
                        }
                        a6 = a5;
                    }
                }
            }
            if (a2.length() <= a6) {
                throw new IllegalArgumentException("No time zone indicator");
            }
            TimeZone a19 = null;
            a5 = a2.charAt(a6);
            if (a5 == 90) {
                a19 = d;
                ++a6;
            } else if (a5 == 43 || a5 == 45) {
                String a20 = a2.substring(a6);
                a20 = a20.length() >= 5 ? a20 : a20 + "00";
                a6 += a20.length();
                if ("+0000".equals(a20) || "+00:00".equals(a20)) {
                    a19 = d;
                } else {
                    String a21;
                    String a22 = "GMT" + a20;
                    a19 = TimeZone.getTimeZone(a22);
                    String a23 = a19.getID();
                    if (!a23.equals(a22) && !(a21 = a23.replace(":", "")).equals(a22)) {
                        throw new IndexOutOfBoundsException("Mismatching time zone indicator: " + a22 + " given, resolves to " + a19.getID());
                    }
                }
            } else {
                throw new IndexOutOfBoundsException("Invalid time zone indicator '" + (char)a5 + "'");
            }
            GregorianCalendar a24 = new GregorianCalendar(a19);
            a24.setLenient(false);
            a24.set(1, a7);
            a24.set(2, a8 - 1);
            a24.set(5, a9);
            a24.set(11, a10);
            a24.set(12, a11);
            a24.set(13, a12);
            a24.set(14, a13);
            a3.setIndex(a6);
            return a24.getTime();
        }
        catch (IndexOutOfBoundsException a25) {
            a4 = a25;
        }
        catch (NumberFormatException a26) {
            a4 = a26;
        }
        catch (IllegalArgumentException a27) {
            a4 = a27;
        }
        String a28 = a2 == null ? null : '\"' + a2 + '\"';
        String a29 = a4.getMessage();
        if (a29 == null || a29.isEmpty()) {
            a29 = "(" + a4.getClass().getName() + ")";
        }
        ParseException a30 = new ParseException("Failed to parse date [" + a28 + "]: " + a29, a3.getIndex());
        a30.initCause(a4);
        throw a30;
    }

    private static /* synthetic */ boolean a(String a2, int a3, char a4) {
        return a3 < a2.length() && a2.charAt(a3) == a4;
    }

    private static /* synthetic */ int a(String a2, int a3, int a4) throws NumberFormatException {
        int a5;
        if (a3 < 0 || a4 > a2.length() || a3 > a4) {
            throw new NumberFormatException(a2);
        }
        int a6 = a3;
        int a7 = 0;
        if (a6 < a4) {
            if ((a5 = Character.digit(a2.charAt(a6++), 10)) < 0) {
                throw new NumberFormatException("Invalid number: " + a2.substring(a3, a4));
            }
            a7 = -a5;
        }
        while (a6 < a4) {
            if ((a5 = Character.digit(a2.charAt(a6++), 10)) < 0) {
                throw new NumberFormatException("Invalid number: " + a2.substring(a3, a4));
            }
            a7 *= 10;
            a7 -= a5;
        }
        return -a7;
    }

    private static /* synthetic */ void a(StringBuilder a2, int a3, int a4) {
        String a5 = Integer.toString(a3);
        for (int a6 = a4 - a5.length(); a6 > 0; --a6) {
            a2.append('0');
        }
        a2.append(a5);
    }

    private static /* synthetic */ int a(String a2, int a3) {
        for (int a4 = a3; a4 < a2.length(); ++a4) {
            char a5 = a2.charAt(a4);
            if (a5 >= '0' && a5 <= '9') continue;
            return a4;
        }
        return a2.length();
    }
}

