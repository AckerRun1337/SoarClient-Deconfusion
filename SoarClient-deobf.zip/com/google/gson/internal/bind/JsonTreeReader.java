/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JsonTreeReader
extends JsonReader {
    private static final Reader z = new Reader(){
        {
            1 a2;
        }

        @Override
        public int read(char[] a2, int a3, int a4) throws IOException {
            throw new AssertionError();
        }

        @Override
        public void close() throws IOException {
            throw new AssertionError();
        }
    };
    private static final Object l = new Object();
    private Object[] b = new Object[32];
    private int c = 0;
    private String[] v = new String[32];
    private int[] d = new int[32];

    public JsonTreeReader(JsonElement a2) {
        super(z);
        JsonTreeReader a3;
        a3.a(a2);
    }

    @Override
    public void d() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.n);
        JsonArray a3 = (JsonArray)a2.p();
        a2.a(a3.iterator());
        a2.d[a2.c - 1] = 0;
    }

    @Override
    public void m() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.e);
        a2.a();
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
    }

    @Override
    public void h() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.r);
        JsonObject a3 = (JsonObject)a2.p();
        a2.a(a3.p().iterator());
    }

    @Override
    public void x() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.f);
        a2.a();
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
    }

    @Override
    public boolean p() throws IOException {
        JsonTreeReader a2;
        JsonToken a3 = a2.a();
        return a3 != JsonToken.f && a3 != JsonToken.e;
    }

    @Override
    public JsonToken a() throws IOException {
        JsonTreeReader a2;
        if (a2.c == 0) {
            return JsonToken.v;
        }
        Object a3 = a2.p();
        if (a3 instanceof Iterator) {
            boolean a4 = a2.b[a2.c - 2] instanceof JsonObject;
            Iterator a5 = (Iterator)a3;
            if (a5.hasNext()) {
                if (a4) {
                    return JsonToken.h;
                }
                a2.a(a5.next());
                return a2.a();
            }
            return a4 ? JsonToken.f : JsonToken.e;
        }
        if (a3 instanceof JsonObject) {
            return JsonToken.r;
        }
        if (a3 instanceof JsonArray) {
            return JsonToken.n;
        }
        if (a3 instanceof JsonPrimitive) {
            JsonPrimitive a6 = (JsonPrimitive)a3;
            if (a6.j()) {
                return JsonToken.z;
            }
            if (a6.h()) {
                return JsonToken.b;
            }
            if (a6.x()) {
                return JsonToken.l;
            }
            throw new AssertionError();
        }
        if (a3 instanceof JsonNull) {
            return JsonToken.c;
        }
        if (a3 == l) {
            throw new IllegalStateException("JsonReader is closed");
        }
        throw new AssertionError();
    }

    private /* synthetic */ Object p() {
        JsonTreeReader a2;
        return a2.b[a2.c - 1];
    }

    private /* synthetic */ Object a() {
        JsonTreeReader a2;
        Object a3 = a2.b[--a2.c];
        a2.b[a2.c] = null;
        return a3;
    }

    private /* synthetic */ void a(JsonToken a2) throws IOException {
        JsonTreeReader a3;
        if (a3.a() != a2) {
            throw new IllegalStateException("Expected " + (Object)((Object)a2) + " but was " + (Object)((Object)a3.a()) + a3.o());
        }
    }

    @Override
    public String z() throws IOException {
        String a2;
        JsonTreeReader a3;
        a3.a(JsonToken.h);
        Iterator a4 = (Iterator)a3.p();
        Map.Entry a5 = (Map.Entry)a4.next();
        a3.v[a3.c - 1] = a2 = (String)a5.getKey();
        a3.a(a5.getValue());
        return a2;
    }

    @Override
    public String y() throws IOException {
        JsonTreeReader a2;
        JsonToken a3 = a2.a();
        if (a3 != JsonToken.z && a3 != JsonToken.l) {
            throw new IllegalStateException("Expected " + (Object)((Object)JsonToken.z) + " but was " + (Object)((Object)a3) + a2.o());
        }
        String a4 = ((JsonPrimitive)a2.a()).a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
        return a4;
    }

    @Override
    public boolean a() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.b);
        boolean a3 = ((JsonPrimitive)a2.a()).a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
        return a3;
    }

    @Override
    public void j() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.c);
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
    }

    @Override
    public double a() throws IOException {
        JsonTreeReader a2;
        JsonToken a3 = a2.a();
        if (a3 != JsonToken.l && a3 != JsonToken.z) {
            throw new IllegalStateException("Expected " + (Object)((Object)JsonToken.l) + " but was " + (Object)((Object)a3) + a2.o());
        }
        double a4 = ((JsonPrimitive)a2.p()).a();
        if (!a2.o() && (Double.isNaN(a4) || Double.isInfinite(a4))) {
            throw new NumberFormatException("JSON forbids NaN and infinities: " + a4);
        }
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
        return a4;
    }

    @Override
    public long a() throws IOException {
        JsonTreeReader a2;
        JsonToken a3 = a2.a();
        if (a3 != JsonToken.l && a3 != JsonToken.z) {
            throw new IllegalStateException("Expected " + (Object)((Object)JsonToken.l) + " but was " + (Object)((Object)a3) + a2.o());
        }
        long a4 = ((JsonPrimitive)a2.p()).a();
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
        return a4;
    }

    @Override
    public int a() throws IOException {
        JsonTreeReader a2;
        JsonToken a3 = a2.a();
        if (a3 != JsonToken.l && a3 != JsonToken.z) {
            throw new IllegalStateException("Expected " + (Object)((Object)JsonToken.l) + " but was " + (Object)((Object)a3) + a2.o());
        }
        int a4 = ((JsonPrimitive)a2.p()).a();
        a2.a();
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
        return a4;
    }

    @Override
    public void close() throws IOException {
        a.b = new Object[]{l};
        a.c = 1;
    }

    @Override
    public void y() throws IOException {
        JsonTreeReader a2;
        if (a2.a() == JsonToken.h) {
            a2.z();
            a2.v[a2.c - 2] = "null";
        } else {
            a2.a();
            if (a2.c > 0) {
                a2.v[a2.c - 1] = "null";
            }
        }
        if (a2.c > 0) {
            int n2 = a2.c - 1;
            a2.d[n2] = a2.d[n2] + 1;
        }
    }

    @Override
    public String toString() {
        JsonTreeReader a2;
        return a2.getClass().getSimpleName();
    }

    public void a() throws IOException {
        JsonTreeReader a2;
        a2.a(JsonToken.h);
        Iterator a3 = (Iterator)a2.p();
        Map.Entry a4 = (Map.Entry)a3.next();
        a2.a(a4.getValue());
        a2.a(new JsonPrimitive((String)a4.getKey()));
    }

    private /* synthetic */ void a(Object a2) {
        JsonTreeReader a3;
        if (a3.c == a3.b.length) {
            int a4 = a3.c * 2;
            a3.b = Arrays.copyOf(a3.b, a4);
            a3.d = Arrays.copyOf(a3.d, a4);
            a3.v = Arrays.copyOf(a3.v, a4);
        }
        a3.b[a3.c++] = a2;
    }

    @Override
    public String a() {
        JsonTreeReader a2;
        StringBuilder a3 = new StringBuilder().append('$');
        for (int a4 = 0; a4 < a2.c; ++a4) {
            if (a2.b[a4] instanceof JsonArray) {
                if (!(a2.b[++a4] instanceof Iterator)) continue;
                a3.append('[').append(a2.d[a4]).append(']');
                continue;
            }
            if (!(a2.b[a4] instanceof JsonObject) || !(a2.b[++a4] instanceof Iterator)) continue;
            a3.append('.');
            if (a2.v[a4] == null) continue;
            a3.append(a2.v[a4]);
        }
        return a3.toString();
    }

    private /* synthetic */ String o() {
        JsonTreeReader a2;
        return " at path " + (String)a2.a();
    }
}

