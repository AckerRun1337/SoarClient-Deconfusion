/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;

public final class ArrayTypeAdapter<E>
extends TypeAdapter<Object> {
    public static final TypeAdapterFactory c = new TypeAdapterFactory(){
        {
            1 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            Type a4 = a3.a();
            if (!(a4 instanceof GenericArrayType || a4 instanceof Class && ((Class)a4).isArray())) {
                return null;
            }
            Type a5 = $Gson$Types.a(a4);
            TypeAdapter<?> a6 = a2.a(TypeToken.p(a5));
            return new ArrayTypeAdapter(a2, a6, (Class<?>)$Gson$Types.a(a5));
        }
    };
    private final Class<E> v;
    private final TypeAdapter<E> d;

    public ArrayTypeAdapter(Gson a2, TypeAdapter<E> a3, Class<E> a4) {
        ArrayTypeAdapter a5;
        a5.d = new TypeAdapterRuntimeTypeWrapper<E>(a2, a3, a4);
        a5.v = a4;
    }

    @Override
    public Object a(JsonReader a2) throws IOException {
        ArrayTypeAdapter a3;
        if (a2.a() == JsonToken.c) {
            a2.j();
            return null;
        }
        ArrayList<E> a4 = new ArrayList<E>();
        a2.d();
        while (a2.p()) {
            E a5 = a3.d.a(a2);
            a4.add(a5);
        }
        a2.m();
        int a6 = a4.size();
        Object a7 = Array.newInstance(a3.v, a6);
        for (int a8 = 0; a8 < a6; ++a8) {
            Array.set(a7, a8, a4.get(a8));
        }
        return a7;
    }

    @Override
    public void a(JsonWriter a2, Object a3) throws IOException {
        if (a3 == null) {
            a2.a();
            return;
        }
        a2.z();
        int a4 = Array.getLength(a3);
        for (int a5 = 0; a5 < a4; ++a5) {
            ArrayTypeAdapter a6;
            Object a7 = Array.get(a3, a5);
            a6.d.a(a2, a7);
        }
        a2.y();
    }
}

