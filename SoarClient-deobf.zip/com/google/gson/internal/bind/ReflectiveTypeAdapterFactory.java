/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;
import com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory;
import com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper;
import com.google.gson.internal.reflect.ReflectionAccessor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ReflectiveTypeAdapterFactory
implements TypeAdapterFactory {
    private final ConstructorConstructor l;
    private final FieldNamingStrategy b;
    private final Excluder c;
    private final JsonAdapterAnnotationTypeAdapterFactory v;
    private final ReflectionAccessor d = ReflectionAccessor.a();

    public ReflectiveTypeAdapterFactory(ConstructorConstructor a2, FieldNamingStrategy a3, Excluder a4, JsonAdapterAnnotationTypeAdapterFactory a5) {
        ReflectiveTypeAdapterFactory a6;
        a6.l = a2;
        a6.b = a3;
        a6.c = a4;
        a6.v = a5;
    }

    public boolean a(Field a2, boolean a3) {
        ReflectiveTypeAdapterFactory a4;
        return ReflectiveTypeAdapterFactory.a(a2, a3, a4.c);
    }

    static boolean a(Field a2, boolean a3, Excluder a4) {
        return !a4.p(a2.getType(), a3) && !a4.a(a2, a3);
    }

    private /* synthetic */ List<String> a(Field a2) {
        SerializedName a3 = a2.getAnnotation(SerializedName.class);
        if (a3 == null) {
            ReflectiveTypeAdapterFactory a4;
            String a5 = a4.b.a(a2);
            return Collections.singletonList(a5);
        }
        String a6 = a3.z();
        String[] a7 = a3.y();
        if (a7.length == 0) {
            return Collections.singletonList(a6);
        }
        ArrayList<String> a8 = new ArrayList<String>(a7.length + 1);
        a8.add(a6);
        for (String a9 : a7) {
            a8.add(a9);
        }
        return a8;
    }

    @Override
    public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
        ReflectiveTypeAdapterFactory a4;
        Type a5 = a3.a();
        if (!Object.class.isAssignableFrom((Class<?>)a5)) {
            return null;
        }
        ObjectConstructor<T> a6 = a4.l.a(a3);
        return new Adapter<T>(a6, a4.a(a2, a3, (Class<?>)a5));
    }

    private /* synthetic */ BoundField a(final Gson a2, final Field a3, String a4, final TypeToken<?> a5, boolean a6, boolean a7) {
        boolean a8;
        ReflectiveTypeAdapterFactory a9;
        final boolean a10 = Primitives.p(a5.a());
        JsonAdapter a11 = a3.getAnnotation(JsonAdapter.class);
        TypeAdapter<?> a12 = null;
        if (a11 != null) {
            a12 = a9.v.a(a9.l, a2, a5, a11);
        }
        boolean bl2 = a8 = a12 != null;
        if (a12 == null) {
            a12 = a2.a(a5);
        }
        final TypeAdapter<?> a13 = a12;
        return new BoundField(a4, a6, a7){
            {
                1 a6;
                super(a32, a4, a52);
            }

            @Override
            void a(JsonWriter a22, Object a32) throws IOException, IllegalAccessException {
                1 a4;
                Object a52 = a4.a3.get(a32);
                TypeAdapter a6 = a4.a8 ? a4.a13 : new TypeAdapterRuntimeTypeWrapper(a4.a2, a4.a13, a4.a5.a());
                a6.a(a22, a52);
            }

            @Override
            void a(JsonReader a22, Object a32) throws IOException, IllegalAccessException {
                1 a4;
                Object a52 = a4.a13.a(a22);
                if (a52 != null || !a4.a10) {
                    a4.a3.set(a32, a52);
                }
            }

            @Override
            public boolean a(Object a22) throws IOException, IllegalAccessException {
                1 a32;
                if (!a32.v) {
                    return false;
                }
                Object a4 = a32.a3.get(a22);
                return a4 != a22;
            }
        };
    }

    private /* synthetic */ Map<String, BoundField> a(Gson a2, TypeToken<?> a3, Class<?> a4) {
        LinkedHashMap<String, BoundField> a5 = new LinkedHashMap<String, BoundField>();
        if (a4.isInterface()) {
            return a5;
        }
        Type a6 = a3.a();
        while (a4 != Object.class) {
            Field[] a7;
            for (Field a8 : a7 = a4.getDeclaredFields()) {
                ReflectiveTypeAdapterFactory a9;
                boolean a10 = a9.a(a8, true);
                boolean a11 = a9.a(a8, false);
                if (!a10 && !a11) continue;
                a9.d.a(a8);
                Type a12 = $Gson$Types.a(a3.a(), a4, a8.getGenericType());
                List<String> a13 = a9.a(a8);
                BoundField a14 = null;
                int a15 = a13.size();
                for (int a16 = 0; a16 < a15; ++a16) {
                    String a17 = a13.get(a16);
                    if (a16 != 0) {
                        a10 = false;
                    }
                    BoundField a18 = a9.a(a2, a8, a17, TypeToken.p(a12), a10, a11);
                    BoundField a19 = a5.put(a17, a18);
                    if (a14 != null) continue;
                    a14 = a19;
                }
                if (a14 == null) continue;
                throw new IllegalArgumentException(a6 + " declares multiple JSON fields named " + a14.c);
            }
            a3 = TypeToken.p($Gson$Types.a(a3.a(), a4, a4.getGenericSuperclass()));
            a4 = a3.a();
        }
        return a5;
    }

    public static final class Adapter<T>
    extends TypeAdapter<T> {
        private final ObjectConstructor<T> v;
        private final Map<String, BoundField> d;

        Adapter(ObjectConstructor<T> a2, Map<String, BoundField> a3) {
            Adapter a4;
            a4.v = a2;
            a4.d = a3;
        }

        @Override
        public T a(JsonReader a2) throws IOException {
            Adapter a3;
            if (a2.a() == JsonToken.c) {
                a2.j();
                return null;
            }
            T a4 = a3.v.a();
            try {
                a2.h();
                while (a2.p()) {
                    String a5 = a2.z();
                    BoundField a6 = a3.d.get(a5);
                    if (a6 == null || !a6.d) {
                        a2.y();
                        continue;
                    }
                    a6.a(a2, a4);
                }
            }
            catch (IllegalStateException a7) {
                throw new JsonSyntaxException(a7);
            }
            catch (IllegalAccessException a8) {
                throw new AssertionError((Object)a8);
            }
            a2.x();
            return a4;
        }

        @Override
        public void a(JsonWriter a2, T a3) throws IOException {
            if (a3 == null) {
                a2.a();
                return;
            }
            a2.o();
            try {
                Adapter a4;
                for (BoundField a5 : a4.d.values()) {
                    if (!a5.a(a3)) continue;
                    a2.o(a5.c);
                    a5.a(a2, a3);
                }
            }
            catch (IllegalAccessException a6) {
                throw new AssertionError((Object)a6);
            }
            a2.p();
        }
    }

    static abstract class BoundField {
        final String c;
        final boolean v;
        final boolean d;

        protected BoundField(String a2, boolean a3, boolean a4) {
            BoundField a5;
            a5.c = a2;
            a5.v = a3;
            a5.d = a4;
        }

        abstract boolean a(Object var1) throws IOException, IllegalAccessException;

        abstract void a(JsonWriter var1, Object var2) throws IOException, IllegalAccessException;

        abstract void a(JsonReader var1, Object var2) throws IOException, IllegalAccessException;
    }
}

