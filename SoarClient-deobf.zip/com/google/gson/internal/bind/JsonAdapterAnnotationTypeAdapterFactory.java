/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.bind.TreeTypeAdapter;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public final class JsonAdapterAnnotationTypeAdapterFactory
implements TypeAdapterFactory {
    private final ConstructorConstructor d;

    public JsonAdapterAnnotationTypeAdapterFactory(ConstructorConstructor a2) {
        JsonAdapterAnnotationTypeAdapterFactory a3;
        a3.d = a2;
    }

    @Override
    public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
        JsonAdapterAnnotationTypeAdapterFactory a4;
        Type a5 = a3.a();
        JsonAdapter a6 = ((Class)a5).getAnnotation(JsonAdapter.class);
        if (a6 == null) {
            return null;
        }
        return a4.a(a4.d, a2, a3, a6);
    }

    TypeAdapter<?> a(ConstructorConstructor a2, Gson a3, TypeToken<?> a4, JsonAdapter a5) {
        TypeAdapter<?> a6;
        Object a7 = a2.a(TypeToken.a(a5.x())).a();
        if (a7 instanceof TypeAdapter) {
            a6 = (TypeAdapter<?>)a7;
        } else if (a7 instanceof TypeAdapterFactory) {
            a6 = ((TypeAdapterFactory)a7).a(a3, a4);
        } else if (a7 instanceof JsonSerializer || a7 instanceof JsonDeserializer) {
            JsonSerializer a8 = a7 instanceof JsonSerializer ? (JsonSerializer)a7 : null;
            JsonDeserializer a9 = a7 instanceof JsonDeserializer ? (JsonDeserializer)a7 : null;
            a6 = new TreeTypeAdapter(a8, a9, a3, a4, null);
        } else {
            throw new IllegalArgumentException("Invalid attempt to bind an instance of " + a7.getClass().getName() + " as a @JsonAdapter for " + a4.toString() + ". @JsonAdapter value must be a TypeAdapter, TypeAdapterFactory, JsonSerializer or JsonDeserializer.");
        }
        if (a6 != null && a5.j()) {
            a6 = a6.a();
        }
        return a6;
    }
}

