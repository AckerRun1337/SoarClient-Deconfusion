/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Streams;
import com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

public final class MapTypeAdapterFactory
implements TypeAdapterFactory {
    private final ConstructorConstructor v;
    final boolean d;

    public MapTypeAdapterFactory(ConstructorConstructor a2, boolean a3) {
        MapTypeAdapterFactory a4;
        a4.v = a2;
        a4.d = a3;
    }

    @Override
    public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
        MapTypeAdapterFactory a4;
        Type a5 = a3.a();
        Type a6 = a3.a();
        if (!Map.class.isAssignableFrom((Class<?>)a6)) {
            return null;
        }
        Type a7 = $Gson$Types.a(a5);
        Type[] a8 = $Gson$Types.a(a5, a7);
        TypeAdapter<?> a9 = a4.a(a2, a8[0]);
        TypeAdapter<?> a10 = a2.a(TypeToken.p(a8[1]));
        ObjectConstructor<T> a11 = a4.v.a(a3);
        Adapter a12 = a4.new Adapter(a2, a8[0], a9, a8[1], a10, a11);
        return a12;
    }

    private /* synthetic */ TypeAdapter<?> a(Gson a2, Type a3) {
        return a3 == Boolean.TYPE || a3 == Boolean.class ? TypeAdapters.va : a2.a(TypeToken.p(a3));
    }

    private final class Adapter<K, V>
    extends TypeAdapter<Map<K, V>> {
        private final TypeAdapter<K> b;
        private final TypeAdapter<V> c;
        private final ObjectConstructor<? extends Map<K, V>> v;

        public Adapter(Gson a2, Type a3, TypeAdapter<K> a4, Type a5, TypeAdapter<V> a6, ObjectConstructor<? extends Map<K, V>> a7) {
            Adapter a8;
            a8.b = new TypeAdapterRuntimeTypeWrapper<K>(a2, a4, a3);
            a8.c = new TypeAdapterRuntimeTypeWrapper<V>(a2, a6, a5);
            a8.v = a7;
        }

        @Override
        public Map<K, V> a(JsonReader a2) throws IOException {
            Adapter a3;
            JsonToken a4 = a2.a();
            if (a4 == JsonToken.c) {
                a2.j();
                return null;
            }
            Map<K, V> a5 = a3.v.a();
            if (a4 == JsonToken.n) {
                a2.d();
                while (a2.p()) {
                    a2.d();
                    K a6 = a3.b.a(a2);
                    V a7 = a3.c.a(a2);
                    V a8 = a5.put(a6, a7);
                    if (a8 != null) {
                        throw new JsonSyntaxException("duplicate key: " + a6);
                    }
                    a2.m();
                }
                a2.m();
            } else {
                a2.h();
                while (a2.p()) {
                    V a9;
                    JsonReaderInternalAccess.d.a(a2);
                    K a10 = a3.b.a(a2);
                    V a11 = a5.put(a10, a9 = a3.c.a(a2));
                    if (a11 == null) continue;
                    throw new JsonSyntaxException("duplicate key: " + a10);
                }
                a2.x();
            }
            return a5;
        }

        @Override
        public void a(JsonWriter a2, Map<K, V> a3) throws IOException {
            JsonElement a4;
            Adapter a5;
            if (a3 == null) {
                a2.a();
                return;
            }
            if (!a5.MapTypeAdapterFactory.this.d) {
                a2.o();
                for (Map.Entry<K, V> a6 : a3.entrySet()) {
                    a2.o(String.valueOf(a6.getKey()));
                    a5.c.a(a2, a6.getValue());
                }
                a2.p();
                return;
            }
            boolean a7 = false;
            ArrayList<JsonElement> a8 = new ArrayList<JsonElement>(a3.size());
            ArrayList<V> a9 = new ArrayList<V>(a3.size());
            for (Map.Entry<K, V> a10 : a3.entrySet()) {
                a4 = a5.b.a(a10.getKey());
                a8.add(a4);
                a9.add(a10.getValue());
                a7 |= a4.z() || a4.y();
            }
            if (a7) {
                a2.z();
                int a11 = a8.size();
                for (int a12 = 0; a12 < a11; ++a12) {
                    a2.z();
                    Streams.a((JsonElement)a8.get(a12), a2);
                    a5.c.a(a2, a9.get(a12));
                    a2.y();
                }
                a2.y();
            } else {
                a2.o();
                int a13 = a8.size();
                for (int a14 = 0; a14 < a13; ++a14) {
                    a4 = (JsonElement)a8.get(a14);
                    a2.o(a5.a(a4));
                    a5.c.a(a2, a9.get(a14));
                }
                a2.p();
            }
        }

        @Override
        private /* synthetic */ String a(JsonElement a2) {
            if (a2.o()) {
                JsonElement a3 = a2.a();
                if (((JsonPrimitive)a3).x()) {
                    return String.valueOf(((JsonPrimitive)a3).a());
                }
                if (((JsonPrimitive)a3).h()) {
                    return Boolean.toString(((JsonPrimitive)a3).a());
                }
                if (((JsonPrimitive)a3).j()) {
                    return ((JsonPrimitive)a3).a();
                }
                throw new AssertionError();
            }
            if (a2.p()) {
                return "null";
            }
            throw new AssertionError();
        }
    }
}

