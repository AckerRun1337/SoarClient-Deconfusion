/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public final class SqlDateTypeAdapter
extends TypeAdapter<Date> {
    public static final TypeAdapterFactory v = new TypeAdapterFactory(){
        {
            1 a2;
        }

        @Override
        public <T> TypeAdapter<T> a(Gson a2, TypeToken<T> a3) {
            return a3.a() == Date.class ? new SqlDateTypeAdapter() : null;
        }
    };
    private final DateFormat d = new SimpleDateFormat("MMM d, yyyy");

    public SqlDateTypeAdapter() {
        SqlDateTypeAdapter a2;
    }

    @Override
    public synchronized Date a(JsonReader a2) throws IOException {
        if (a2.a() == JsonToken.c) {
            a2.j();
            return null;
        }
        try {
            SqlDateTypeAdapter a3;
            long a4 = a3.d.parse(a2.y()).getTime();
            return new Date(a4);
        }
        catch (ParseException a5) {
            throw new JsonSyntaxException(a5);
        }
    }

    @Override
    public synchronized void a(JsonWriter a2, Date a3) throws IOException {
        SqlDateTypeAdapter a4;
        a2.p(a3 == null ? null : a4.d.format(a3));
    }
}

