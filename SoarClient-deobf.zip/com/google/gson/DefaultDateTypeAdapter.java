/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.internal.JavaVersion;
import com.google.gson.internal.PreJava9DateFormatProvider;
import com.google.gson.internal.bind.util.ISO8601Utils;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class DefaultDateTypeAdapter
extends TypeAdapter<java.util.Date> {
    private static final String c = "DefaultDateTypeAdapter";
    private final Class<? extends java.util.Date> v;
    private final List<DateFormat> d;

    DefaultDateTypeAdapter(Class<? extends java.util.Date> a2) {
        DefaultDateTypeAdapter a3;
        a3.d = new ArrayList<DateFormat>();
        a3.v = DefaultDateTypeAdapter.a(a2);
        a3.d.add(DateFormat.getDateTimeInstance(2, 2, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            a3.d.add(DateFormat.getDateTimeInstance(2, 2));
        }
        if (JavaVersion.a()) {
            a3.d.add(PreJava9DateFormatProvider.a(2, 2));
        }
    }

    DefaultDateTypeAdapter(Class<? extends java.util.Date> a2, String a3) {
        DefaultDateTypeAdapter a4;
        a4.d = new ArrayList<DateFormat>();
        a4.v = DefaultDateTypeAdapter.a(a2);
        a4.d.add(new SimpleDateFormat(a3, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            a4.d.add(new SimpleDateFormat(a3));
        }
    }

    DefaultDateTypeAdapter(Class<? extends java.util.Date> a2, int a3) {
        DefaultDateTypeAdapter a4;
        a4.d = new ArrayList<DateFormat>();
        a4.v = DefaultDateTypeAdapter.a(a2);
        a4.d.add(DateFormat.getDateInstance(a3, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            a4.d.add(DateFormat.getDateInstance(a3));
        }
        if (JavaVersion.a()) {
            a4.d.add(PreJava9DateFormatProvider.a(a3));
        }
    }

    public DefaultDateTypeAdapter(int a2, int a3) {
        a4(java.util.Date.class, a2, a3);
        DefaultDateTypeAdapter a4;
    }

    public DefaultDateTypeAdapter(Class<? extends java.util.Date> a2, int a3, int a4) {
        DefaultDateTypeAdapter a5;
        a5.d = new ArrayList<DateFormat>();
        a5.v = DefaultDateTypeAdapter.a(a2);
        a5.d.add(DateFormat.getDateTimeInstance(a3, a4, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            a5.d.add(DateFormat.getDateTimeInstance(a3, a4));
        }
        if (JavaVersion.a()) {
            a5.d.add(PreJava9DateFormatProvider.a(a3, a4));
        }
    }

    private static /* synthetic */ Class<? extends java.util.Date> a(Class<? extends java.util.Date> a2) {
        if (a2 != java.util.Date.class && a2 != Date.class && a2 != Timestamp.class) {
            throw new IllegalArgumentException("Date type must be one of " + java.util.Date.class + ", " + Timestamp.class + ", or " + Date.class + " but was " + a2);
        }
        return a2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(JsonWriter a2, java.util.Date a3) throws IOException {
        DefaultDateTypeAdapter a4;
        if (a3 == null) {
            a2.a();
            return;
        }
        List<DateFormat> list = a4.d;
        synchronized (list) {
            String a5 = a4.d.get(0).format(a3);
            a2.p(a5);
        }
    }

    @Override
    public java.util.Date a(JsonReader a2) throws IOException {
        DefaultDateTypeAdapter a3;
        if (a2.a() == JsonToken.c) {
            a2.j();
            return null;
        }
        java.util.Date a4 = a3.a(a2.y());
        if (a3.v == java.util.Date.class) {
            return a4;
        }
        if (a3.v == Timestamp.class) {
            return new Timestamp(a4.getTime());
        }
        if (a3.v == Date.class) {
            return new Date(a4.getTime());
        }
        throw new AssertionError();
    }

    @Override
    private /* synthetic */ java.util.Date a(String a2) {
        DefaultDateTypeAdapter a3;
        List<DateFormat> list = a3.d;
        synchronized (list) {
            for (DateFormat a4 : a3.d) {
                try {
                    return a4.parse(a2);
                }
                catch (ParseException parseException) {
                }
            }
            try {
                return ISO8601Utils.a(a2, new ParsePosition(0));
            }
            catch (ParseException a5) {
                throw new JsonSyntaxException(a2, a5);
            }
        }
    }

    public String toString() {
        DefaultDateTypeAdapter a2;
        DateFormat a3 = a2.d.get(0);
        if (a3 instanceof SimpleDateFormat) {
            return "DefaultDateTypeAdapter(" + ((SimpleDateFormat)a3).toPattern() + ')';
        }
        return "DefaultDateTypeAdapter(" + a3.getClass().getSimpleName() + ')';
    }
}

