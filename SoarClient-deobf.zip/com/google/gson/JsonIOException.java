/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonParseException;

public final class JsonIOException
extends JsonParseException {
    private static final long d = 1L;

    public JsonIOException(String a2) {
        super(a2);
        JsonIOException a3;
    }

    public JsonIOException(String a2, Throwable a3) {
        super(a2, a3);
        JsonIOException a4;
    }

    public JsonIOException(Throwable a2) {
        super(a2);
        JsonIOException a3;
    }
}

