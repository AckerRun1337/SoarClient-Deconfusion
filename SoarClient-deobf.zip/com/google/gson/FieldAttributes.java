/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.internal.$Gson$Preconditions;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class FieldAttributes {
    private final Field d;

    public FieldAttributes(Field a2) {
        FieldAttributes a3;
        $Gson$Preconditions.a(a2);
        a3.d = a2;
    }

    public Class<?> p() {
        FieldAttributes a2;
        return a2.d.getDeclaringClass();
    }

    public String a() {
        FieldAttributes a2;
        return a2.d.getName();
    }

    public Type a() {
        FieldAttributes a2;
        return a2.d.getGenericType();
    }

    public Class<?> a() {
        FieldAttributes a2;
        return a2.d.getType();
    }

    public <T extends Annotation> T a(Class<T> a2) {
        FieldAttributes a3;
        return a3.d.getAnnotation(a2);
    }

    public Collection<Annotation> a() {
        FieldAttributes a2;
        return Arrays.asList(a2.d.getAnnotations());
    }

    public boolean a(int a2) {
        FieldAttributes a3;
        return (a3.d.getModifiers() & a2) != 0;
    }

    Object a(Object a2) throws IllegalAccessException {
        FieldAttributes a3;
        return a3.d.get(a2);
    }

    boolean a() {
        FieldAttributes a2;
        return a2.d.isSynthetic();
    }
}

