/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonParseException;

public final class JsonSyntaxException
extends JsonParseException {
    private static final long d = 1L;

    public JsonSyntaxException(String a2) {
        super(a2);
        JsonSyntaxException a3;
    }

    public JsonSyntaxException(String a2, Throwable a3) {
        super(a2, a3);
        JsonSyntaxException a4;
    }

    public JsonSyntaxException(Throwable a2) {
        super(a2);
        JsonSyntaxException a3;
    }
}

