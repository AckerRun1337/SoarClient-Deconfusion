/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import java.lang.reflect.Field;

public interface FieldNamingStrategy {
    public String a(Field var1);
}

