/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JsonArray
extends JsonElement
implements Iterable<JsonElement> {
    private final List<JsonElement> d;

    public JsonArray() {
        JsonArray a2;
        a2.d = new ArrayList<JsonElement>();
    }

    public JsonArray(int a2) {
        JsonArray a3;
        a3.d = new ArrayList<JsonElement>(a2);
    }

    public JsonArray p() {
        JsonArray a2;
        if (!a2.d.isEmpty()) {
            JsonArray a3 = new JsonArray(a2.d.size());
            for (JsonElement a4 : a2.d) {
                a3.a(a4.a());
            }
            return a3;
        }
        return new JsonArray();
    }

    public void a(Boolean a2) {
        JsonArray a3;
        a3.d.add(a2 == null ? JsonNull.d : new JsonPrimitive(a2));
    }

    public void a(Character a2) {
        JsonArray a3;
        a3.d.add(a2 == null ? JsonNull.d : new JsonPrimitive(a2));
    }

    public void a(Number a2) {
        JsonArray a3;
        a3.d.add(a2 == null ? JsonNull.d : new JsonPrimitive(a2));
    }

    public void a(String a2) {
        JsonArray a3;
        a3.d.add(a2 == null ? JsonNull.d : new JsonPrimitive(a2));
    }

    public void a(JsonElement a2) {
        JsonArray a3;
        if (a2 == null) {
            a2 = JsonNull.d;
        }
        a3.d.add(a2);
    }

    public void a(JsonArray a2) {
        JsonArray a3;
        a3.d.addAll(a2.d);
    }

    public JsonElement a(int a2, JsonElement a3) {
        JsonArray a4;
        return a4.d.set(a2, a3);
    }

    public boolean p(JsonElement a2) {
        JsonArray a3;
        return a3.d.remove(a2);
    }

    public JsonElement p(int a2) {
        JsonArray a3;
        return a3.d.remove(a2);
    }

    public boolean a(JsonElement a2) {
        JsonArray a3;
        return a3.d.contains(a2);
    }

    public int p() {
        JsonArray a2;
        return a2.d.size();
    }

    @Override
    public Iterator<JsonElement> iterator() {
        JsonArray a2;
        return a2.d.iterator();
    }

    public JsonElement a(int a2) {
        JsonArray a3;
        return a3.d.get(a2);
    }

    @Override
    public Number a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public String a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public double a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public BigDecimal a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public BigInteger a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public float a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public long a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public int a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public byte a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public char a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public short a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    @Override
    public boolean a() {
        JsonArray a2;
        if (a2.d.size() == 1) {
            return a2.d.get(0).a();
        }
        throw new IllegalStateException();
    }

    public boolean equals(Object a2) {
        JsonArray a3;
        return a2 == a3 || a2 instanceof JsonArray && ((JsonArray)a2).d.equals(a3.d);
    }

    public int hashCode() {
        JsonArray a2;
        return a2.d.hashCode();
    }
}

