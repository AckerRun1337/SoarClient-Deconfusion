/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;

public final class JsonNull
extends JsonElement {
    public static final JsonNull d = new JsonNull();

    @Deprecated
    public JsonNull() {
        JsonNull a2;
    }

    public JsonNull p() {
        return d;
    }

    public int hashCode() {
        return JsonNull.class.hashCode();
    }

    public boolean equals(Object a2) {
        JsonNull a3;
        return a3 == a2 || a2 instanceof JsonNull;
    }
}

