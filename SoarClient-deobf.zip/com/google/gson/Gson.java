/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.FieldNamingStrategy;
import com.google.gson.GsonBuilder;
import com.google.gson.InstanceCreator;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonSyntaxException;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.Primitives;
import com.google.gson.internal.Streams;
import com.google.gson.internal.bind.ArrayTypeAdapter;
import com.google.gson.internal.bind.CollectionTypeAdapterFactory;
import com.google.gson.internal.bind.DateTypeAdapter;
import com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory;
import com.google.gson.internal.bind.JsonTreeReader;
import com.google.gson.internal.bind.JsonTreeWriter;
import com.google.gson.internal.bind.MapTypeAdapterFactory;
import com.google.gson.internal.bind.ObjectTypeAdapter;
import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory;
import com.google.gson.internal.bind.SqlDateTypeAdapter;
import com.google.gson.internal.bind.TimeTypeAdapter;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Gson {
    static final boolean oa = false;
    static final boolean pa = false;
    static final boolean ba = false;
    static final boolean la = true;
    static final boolean u = false;
    static final boolean j = false;
    static final boolean o = false;
    private static final TypeToken<?> m = TypeToken.a(Object.class);
    private static final String y = ")]}'\n";
    private final ThreadLocal<Map<TypeToken<?>, FutureTypeAdapter<?>>> a = new ThreadLocal();
    private final Map<TypeToken<?>, TypeAdapter<?>> q = new ConcurrentHashMap();
    private final ConstructorConstructor g;
    private final JsonAdapterAnnotationTypeAdapterFactory k;
    final List<TypeAdapterFactory> x;
    final Excluder t;
    final FieldNamingStrategy p;
    final Map<Type, InstanceCreator<?>> s;
    final boolean w;
    final boolean i;
    final boolean n;
    final boolean e;
    final boolean r;
    final boolean f;
    final boolean h;
    final String z;
    final int l;
    final int b;
    final LongSerializationPolicy c;
    final List<TypeAdapterFactory> v;
    final List<TypeAdapterFactory> d;

    public Gson() {
        a2(Excluder.h, FieldNamingPolicy.h, Collections.emptyMap(), false, false, false, true, false, false, false, LongSerializationPolicy.c, null, 2, 2, Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
        Gson a2;
    }

    Gson(Excluder a2, FieldNamingStrategy a3, Map<Type, InstanceCreator<?>> a4, boolean a5, boolean a6, boolean a7, boolean a8, boolean a9, boolean a10, boolean a11, LongSerializationPolicy a12, String a13, int a14, int a15, List<TypeAdapterFactory> a16, List<TypeAdapterFactory> a17, List<TypeAdapterFactory> a18) {
        Gson a19;
        a19.t = a2;
        a19.p = a3;
        a19.s = a4;
        a19.g = new ConstructorConstructor(a4);
        a19.w = a5;
        a19.i = a6;
        a19.n = a7;
        a19.e = a8;
        a19.r = a9;
        a19.f = a10;
        a19.h = a11;
        a19.c = a12;
        a19.z = a13;
        a19.l = a14;
        a19.b = a15;
        a19.v = a16;
        a19.d = a17;
        ArrayList<TypeAdapterFactory> a20 = new ArrayList<TypeAdapterFactory>();
        a20.add(TypeAdapters.v);
        a20.add(ObjectTypeAdapter.v);
        a20.add(a2);
        a20.addAll(a18);
        a20.add(TypeAdapters.m);
        a20.add(TypeAdapters.ma);
        a20.add(TypeAdapters.sa);
        a20.add(TypeAdapters.qa);
        a20.add(TypeAdapters.ua);
        TypeAdapter<Number> a21 = Gson.a(a12);
        a20.add(TypeAdapters.p(Long.TYPE, Long.class, a21));
        a20.add(TypeAdapters.p(Double.TYPE, Double.class, a19.p(a11)));
        a20.add(TypeAdapters.p(Float.TYPE, Float.class, a19.a(a11)));
        a20.add(TypeAdapters.pa);
        a20.add(TypeAdapters.ka);
        a20.add(TypeAdapters.ya);
        a20.add(TypeAdapters.p(AtomicLong.class, Gson.p(a21)));
        a20.add(TypeAdapters.p(AtomicLongArray.class, Gson.a(a21)));
        a20.add(TypeAdapters.ga);
        a20.add(TypeAdapters.la);
        a20.add(TypeAdapters.a);
        a20.add(TypeAdapters.g);
        a20.add(TypeAdapters.p(BigDecimal.class, TypeAdapters.j));
        a20.add(TypeAdapters.p(BigInteger.class, TypeAdapters.o));
        a20.add(TypeAdapters.x);
        a20.add(TypeAdapters.p);
        a20.add(TypeAdapters.n);
        a20.add(TypeAdapters.r);
        a20.add(TypeAdapters.b);
        a20.add(TypeAdapters.w);
        a20.add(TypeAdapters.fa);
        a20.add(DateTypeAdapter.v);
        a20.add(TypeAdapters.z);
        a20.add(TimeTypeAdapter.v);
        a20.add(SqlDateTypeAdapter.v);
        a20.add(TypeAdapters.f);
        a20.add(ArrayTypeAdapter.c);
        a20.add(TypeAdapters.aa);
        a20.add(new CollectionTypeAdapterFactory(a19.g));
        a20.add(new MapTypeAdapterFactory(a19.g, a6));
        a19.k = new JsonAdapterAnnotationTypeAdapterFactory(a19.g);
        a20.add(a19.k);
        a20.add(TypeAdapters.d);
        a20.add(new ReflectiveTypeAdapterFactory(a19.g, a3, a2, a19.k));
        a19.x = Collections.unmodifiableList(a20);
    }

    public GsonBuilder a() {
        Gson a2;
        return new GsonBuilder(a2);
    }

    public Excluder a() {
        Gson a2;
        return a2.t;
    }

    public FieldNamingStrategy a() {
        Gson a2;
        return a2.p;
    }

    public boolean p() {
        Gson a2;
        return a2.w;
    }

    public boolean a() {
        Gson a2;
        return a2.e;
    }

    private /* synthetic */ TypeAdapter<Number> p(boolean a2) {
        Gson a3;
        if (a2) {
            return TypeAdapters.ta;
        }
        return new TypeAdapter<Number>(){
            {
                1 a3;
            }

            @Override
            public Double a(JsonReader a2) throws IOException {
                if (a2.a() == JsonToken.c) {
                    a2.j();
                    return null;
                }
                return a2.a();
            }

            @Override
            public void a(JsonWriter a2, Number a3) throws IOException {
                if (a3 == null) {
                    a2.a();
                    return;
                }
                double a4 = a3.doubleValue();
                Gson.a(a4);
                a2.a(a3);
            }
        };
    }

    private /* synthetic */ TypeAdapter<Number> a(boolean a2) {
        Gson a3;
        if (a2) {
            return TypeAdapters.ia;
        }
        return new TypeAdapter<Number>(){
            {
                2 a3;
            }

            @Override
            public Float a(JsonReader a2) throws IOException {
                if (a2.a() == JsonToken.c) {
                    a2.j();
                    return null;
                }
                return Float.valueOf((float)a2.a());
            }

            @Override
            public void a(JsonWriter a2, Number a3) throws IOException {
                if (a3 == null) {
                    a2.a();
                    return;
                }
                float a4 = a3.floatValue();
                Gson.a(a4);
                a2.a(a3);
            }
        };
    }

    static void a(double a2) {
        if (Double.isNaN(a2) || Double.isInfinite(a2)) {
            throw new IllegalArgumentException(a2 + " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    private static /* synthetic */ TypeAdapter<Number> a(LongSerializationPolicy a2) {
        if (a2 == LongSerializationPolicy.c) {
            return TypeAdapters.ja;
        }
        return new TypeAdapter<Number>(){
            {
                3 a2;
            }

            @Override
            public Number a(JsonReader a2) throws IOException {
                if (a2.a() == JsonToken.c) {
                    a2.j();
                    return null;
                }
                return a2.a();
            }

            @Override
            public void a(JsonWriter a2, Number a3) throws IOException {
                if (a3 == null) {
                    a2.a();
                    return;
                }
                a2.p(a3.toString());
            }
        };
    }

    private static /* synthetic */ TypeAdapter<AtomicLong> p(final TypeAdapter<Number> a2) {
        return new TypeAdapter<AtomicLong>(){
            {
                4 a22;
            }

            @Override
            public void a(JsonWriter a22, AtomicLong a3) throws IOException {
                4 a4;
                a4.a2.a(a22, Long.valueOf(a3.get()));
            }

            @Override
            public AtomicLong a(JsonReader a22) throws IOException {
                4 a3;
                Number a4 = (Number)a3.a2.a(a22);
                return new AtomicLong(a4.longValue());
            }
        }.a();
    }

    private static /* synthetic */ TypeAdapter<AtomicLongArray> a(final TypeAdapter<Number> a2) {
        return new TypeAdapter<AtomicLongArray>(){
            {
                5 a22;
            }

            @Override
            public void a(JsonWriter a22, AtomicLongArray a3) throws IOException {
                a22.z();
                int a4 = a3.length();
                for (int a5 = 0; a5 < a4; ++a5) {
                    5 a6;
                    a6.a2.a(a22, Long.valueOf(a3.get(a5)));
                }
                a22.y();
            }

            @Override
            public AtomicLongArray a(JsonReader a22) throws IOException {
                ArrayList<Long> a3 = new ArrayList<Long>();
                a22.d();
                while (a22.p()) {
                    5 a4;
                    long a5 = ((Number)a4.a2.a(a22)).longValue();
                    a3.add(a5);
                }
                a22.m();
                int a6 = a3.size();
                AtomicLongArray a7 = new AtomicLongArray(a6);
                for (int a8 = 0; a8 < a6; ++a8) {
                    a7.set(a8, (Long)a3.get(a8));
                }
                return a7;
            }
        }.a();
    }

    public <T> TypeAdapter<T> a(TypeToken<T> a2) {
        FutureTypeAdapter<?> a3;
        Gson a4;
        TypeAdapter<?> a5 = a4.q.get(a2 == null ? m : a2);
        if (a5 != null) {
            return a5;
        }
        Map<TypeToken<?>, FutureTypeAdapter<?>> a6 = a4.a.get();
        boolean a7 = false;
        if (a6 == null) {
            a6 = new HashMap();
            a4.a.set(a6);
            a7 = true;
        }
        if ((a3 = a6.get(a2)) != null) {
            return a3;
        }
        try {
            FutureTypeAdapter<T> a8 = new FutureTypeAdapter<T>();
            a6.put(a2, a8);
            for (TypeAdapterFactory a9 : a4.x) {
                TypeAdapter<T> a10 = a9.a(a4, a2);
                if (a10 == null) continue;
                a8.a(a10);
                a4.q.put(a2, a10);
                TypeAdapter<T> typeAdapter = a10;
                return typeAdapter;
            }
            throw new IllegalArgumentException("GSON (2.8.6) cannot handle " + a2);
        }
        finally {
            a6.remove(a2);
            if (a7) {
                a4.a.remove();
            }
        }
    }

    public <T> TypeAdapter<T> a(TypeAdapterFactory a2, TypeToken<T> a3) {
        Gson a4;
        if (!a4.x.contains(a2)) {
            a2 = a4.k;
        }
        boolean a5 = false;
        for (TypeAdapterFactory a6 : a4.x) {
            if (!a5) {
                if (a6 != a2) continue;
                a5 = true;
                continue;
            }
            TypeAdapter<T> a7 = a6.a(a4, a3);
            if (a7 == null) continue;
            return a7;
        }
        throw new IllegalArgumentException("GSON cannot serialize " + a3);
    }

    public <T> TypeAdapter<T> a(Class<T> a2) {
        Gson a3;
        return a3.a(TypeToken.a(a2));
    }

    public JsonElement a(Object a2) {
        Gson a3;
        if (a2 == null) {
            return JsonNull.d;
        }
        return a3.a(a2, a2.getClass());
    }

    public JsonElement a(Object a2, Type a3) {
        Gson a4;
        JsonTreeWriter a5 = new JsonTreeWriter();
        a4.a(a2, a3, a5);
        return a5.p();
    }

    public String a(Object a2) {
        Gson a3;
        if (a2 == null) {
            return a3.a(JsonNull.d);
        }
        return a3.a(a2, a2.getClass());
    }

    public String a(Object a2, Type a3) {
        Gson a4;
        StringWriter a5 = new StringWriter();
        a4.a(a2, a3, a5);
        return a5.toString();
    }

    public void a(Object a2, Appendable a3) throws JsonIOException {
        Gson a4;
        if (a2 != null) {
            a4.a(a2, a2.getClass(), a3);
        } else {
            a4.a((JsonElement)JsonNull.d, a3);
        }
    }

    public void a(Object a2, Type a3, Appendable a4) throws JsonIOException {
        try {
            Gson a5;
            JsonWriter a6 = a5.a(Streams.a(a4));
            a5.a(a2, a3, a6);
        }
        catch (IOException a7) {
            throw new JsonIOException(a7);
        }
    }

    public void a(Object a2, Type a3, JsonWriter a4) throws JsonIOException {
        Gson a5;
        TypeAdapter<?> a6 = a5.a(TypeToken.p(a3));
        boolean a7 = a4.o();
        a4.o(true);
        boolean a8 = a4.p();
        a4.p(a5.e);
        boolean a9 = a4.a();
        a4.a(a5.w);
        try {
            a6.a(a4, a2);
        }
        catch (IOException a10) {
            throw new JsonIOException(a10);
        }
        catch (AssertionError a11) {
            AssertionError a12 = new AssertionError((Object)("AssertionError (GSON 2.8.6): " + ((Throwable)((Object)a11)).getMessage()));
            ((Throwable)((Object)a12)).initCause((Throwable)((Object)a11));
            throw a12;
        }
        finally {
            a4.o(a7);
            a4.p(a8);
            a4.a(a9);
        }
    }

    public String a(JsonElement a2) {
        Gson a3;
        StringWriter a4 = new StringWriter();
        a3.a(a2, (Appendable)a4);
        return a4.toString();
    }

    public void a(JsonElement a2, Appendable a3) throws JsonIOException {
        try {
            Gson a4;
            JsonWriter a5 = a4.a(Streams.a(a3));
            a4.a(a2, a5);
        }
        catch (IOException a6) {
            throw new JsonIOException(a6);
        }
    }

    public JsonWriter a(Writer a2) throws IOException {
        Gson a3;
        if (a3.n) {
            a2.write(y);
        }
        JsonWriter a4 = new JsonWriter(a2);
        if (a3.r) {
            a4.p("  ");
        }
        a4.a(a3.w);
        return a4;
    }

    public JsonReader a(Reader a2) {
        Gson a3;
        JsonReader a4 = new JsonReader(a2);
        a4.a(a3.f);
        return a4;
    }

    public void a(JsonElement a2, JsonWriter a3) throws JsonIOException {
        Gson a4;
        boolean a5 = a3.o();
        a3.o(true);
        boolean a6 = a3.p();
        a3.p(a4.e);
        boolean a7 = a3.a();
        a3.a(a4.w);
        try {
            Streams.a(a2, a3);
        }
        catch (IOException a8) {
            throw new JsonIOException(a8);
        }
        catch (AssertionError a9) {
            AssertionError a10 = new AssertionError((Object)("AssertionError (GSON 2.8.6): " + ((Throwable)((Object)a9)).getMessage()));
            ((Throwable)((Object)a10)).initCause((Throwable)((Object)a9));
            throw a10;
        }
        finally {
            a3.o(a5);
            a3.p(a6);
            a3.a(a7);
        }
    }

    public <T> T a(String a2, Class<T> a3) throws JsonSyntaxException {
        Gson a4;
        T a5 = a4.a(a2, (Type)a3);
        return Primitives.p(a3).cast(a5);
    }

    public <T> T a(String a2, Type a3) throws JsonSyntaxException {
        Gson a4;
        if (a2 == null) {
            return null;
        }
        StringReader a5 = new StringReader(a2);
        T a6 = a4.a((Reader)a5, a3);
        return a6;
    }

    public <T> T a(Reader a2, Class<T> a3) throws JsonSyntaxException, JsonIOException {
        Gson a4;
        JsonReader a5 = a4.a(a2);
        T a6 = a4.a(a5, a3);
        Gson.a(a6, a5);
        return Primitives.p(a3).cast(a6);
    }

    public <T> T a(Reader a2, Type a3) throws JsonIOException, JsonSyntaxException {
        Gson a4;
        JsonReader a5 = a4.a(a2);
        T a6 = a4.a(a5, a3);
        Gson.a(a6, a5);
        return a6;
    }

    private static /* synthetic */ void a(Object a2, JsonReader a3) {
        try {
            if (a2 != null && a3.a() != JsonToken.v) {
                throw new JsonIOException("JSON document was not fully consumed.");
            }
        }
        catch (MalformedJsonException a4) {
            throw new JsonSyntaxException(a4);
        }
        catch (IOException a5) {
            throw new JsonIOException(a5);
        }
    }

    public <T> T a(JsonReader a2, Type a3) throws JsonIOException, JsonSyntaxException {
        boolean a4 = true;
        boolean a5 = a2.o();
        a2.a(true);
        try {
            Object a6;
            Gson a7;
            a2.a();
            a4 = false;
            TypeToken<?> a8 = TypeToken.p(a3);
            TypeAdapter<?> a9 = a7.a(a8);
            Object obj = a6 = a9.a(a2);
            return (T)obj;
        }
        catch (EOFException a10) {
            if (a4) {
                T a9 = null;
                return a9;
            }
            throw new JsonSyntaxException(a10);
        }
        catch (IllegalStateException a11) {
            throw new JsonSyntaxException(a11);
        }
        catch (IOException a12) {
            throw new JsonSyntaxException(a12);
        }
        catch (AssertionError a13) {
            AssertionError a14 = new AssertionError((Object)("AssertionError (GSON 2.8.6): " + ((Throwable)((Object)a13)).getMessage()));
            ((Throwable)((Object)a14)).initCause((Throwable)((Object)a13));
            throw a14;
        }
        finally {
            a2.a(a5);
        }
    }

    public <T> T a(JsonElement a2, Class<T> a3) throws JsonSyntaxException {
        Gson a4;
        T a5 = a4.a(a2, (Type)a3);
        return Primitives.p(a3).cast(a5);
    }

    public <T> T a(JsonElement a2, Type a3) throws JsonSyntaxException {
        Gson a4;
        if (a2 == null) {
            return null;
        }
        return a4.a(new JsonTreeReader(a2), a3);
    }

    public String toString() {
        Gson a2;
        return "{serializeNulls:" + a2.w + ",factories:" + a2.x + ",instanceCreators:" + a2.g + "}";
    }

    static class FutureTypeAdapter<T>
    extends TypeAdapter<T> {
        private TypeAdapter<T> d;

        FutureTypeAdapter() {
            FutureTypeAdapter a2;
        }

        public void a(TypeAdapter<T> a2) {
            FutureTypeAdapter a3;
            if (a3.d != null) {
                throw new AssertionError();
            }
            a3.d = a2;
        }

        @Override
        public T a(JsonReader a2) throws IOException {
            FutureTypeAdapter a3;
            if (a3.d == null) {
                throw new IllegalStateException();
            }
            return a3.d.a(a2);
        }

        @Override
        public void a(JsonWriter a2, T a3) throws IOException {
            FutureTypeAdapter a4;
            if (a4.d == null) {
                throw new IllegalStateException();
            }
            a4.d.a(a2, a3);
        }
    }
}

