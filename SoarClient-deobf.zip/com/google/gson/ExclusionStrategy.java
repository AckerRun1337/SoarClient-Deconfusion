/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.FieldAttributes;

public interface ExclusionStrategy {
    public boolean a(FieldAttributes var1);

    public boolean a(Class<?> var1);
}

