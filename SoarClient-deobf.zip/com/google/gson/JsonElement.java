/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class JsonElement {
    public JsonElement() {
        JsonElement a2;
    }

    public abstract JsonElement a();

    public boolean z() {
        JsonElement a2;
        return a2 instanceof JsonArray;
    }

    public boolean y() {
        JsonElement a2;
        return a2 instanceof JsonObject;
    }

    public boolean o() {
        JsonElement a2;
        return a2 instanceof JsonPrimitive;
    }

    public boolean p() {
        JsonElement a2;
        return a2 instanceof JsonNull;
    }

    public JsonObject a() {
        JsonElement a2;
        if (a2.y()) {
            return (JsonObject)a2;
        }
        throw new IllegalStateException("Not a JSON Object: " + a2);
    }

    public JsonArray a() {
        JsonElement a2;
        if (a2.z()) {
            return (JsonArray)a2;
        }
        throw new IllegalStateException("Not a JSON Array: " + a2);
    }

    public JsonPrimitive a() {
        JsonElement a2;
        if (a2.o()) {
            return (JsonPrimitive)a2;
        }
        throw new IllegalStateException("Not a JSON Primitive: " + a2);
    }

    public JsonNull a() {
        JsonElement a2;
        if (a2.p()) {
            return (JsonNull)a2;
        }
        throw new IllegalStateException("Not a JSON Null: " + a2);
    }

    public boolean a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public Number a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public String a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public double a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public float a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public long a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public int a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public byte a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    @Deprecated
    public char a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public BigDecimal a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public BigInteger a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public short a() {
        JsonElement a2;
        throw new UnsupportedOperationException(a2.getClass().getSimpleName());
    }

    public String toString() {
        try {
            JsonElement a2;
            StringWriter a3 = new StringWriter();
            JsonWriter a4 = new JsonWriter(a3);
            a4.o(true);
            Streams.a(a2, a4);
            return a3.toString();
        }
        catch (IOException a5) {
            throw new AssertionError((Object)a5);
        }
    }
}

