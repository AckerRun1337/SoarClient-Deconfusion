/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public enum LongSerializationPolicy {
    c{
        {
            1 a2;
        }

        @Override
        public JsonElement a(Long a2) {
            return new JsonPrimitive(a2);
        }
    }
    ,
    v{
        {
            2 a2;
        }

        @Override
        public JsonElement a(Long a2) {
            return new JsonPrimitive(String.valueOf(a2));
        }
    };


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private /* synthetic */ LongSerializationPolicy() {
        LongSerializationPolicy a2;
    }

    public abstract JsonElement a(Long var1);
}

