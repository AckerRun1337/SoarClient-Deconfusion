/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.internal.bind.JsonTreeReader;
import com.google.gson.internal.bind.JsonTreeWriter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class TypeAdapter<T> {
    public TypeAdapter() {
        TypeAdapter a2;
    }

    public abstract void a(JsonWriter var1, T var2) throws IOException;

    public final void a(Writer a2, T a3) throws IOException {
        TypeAdapter a4;
        JsonWriter a5 = new JsonWriter(a2);
        a4.a(a5, a3);
    }

    public final TypeAdapter<T> a() {
        TypeAdapter a2;
        return new TypeAdapter<T>(){
            {
                1 a3;
            }

            @Override
            public void a(JsonWriter a2, T a3) throws IOException {
                if (a3 == null) {
                    a2.a();
                } else {
                    1 a4;
                    a4.TypeAdapter.this.a(a2, a3);
                }
            }

            @Override
            public T a(JsonReader a2) throws IOException {
                1 a3;
                if (a2.a() == JsonToken.c) {
                    a2.j();
                    return null;
                }
                return a3.TypeAdapter.this.a(a2);
            }
        };
    }

    public final String a(T a2) {
        StringWriter a3 = new StringWriter();
        try {
            TypeAdapter a4;
            a4.a(a3, a2);
        }
        catch (IOException a5) {
            throw new AssertionError((Object)a5);
        }
        return a3.toString();
    }

    public final JsonElement a(T a2) {
        try {
            TypeAdapter a3;
            JsonTreeWriter a4 = new JsonTreeWriter();
            a3.a(a4, a2);
            return a4.p();
        }
        catch (IOException a5) {
            throw new JsonIOException(a5);
        }
    }

    public abstract T a(JsonReader var1) throws IOException;

    public final T a(Reader a2) throws IOException {
        TypeAdapter a3;
        JsonReader a4 = new JsonReader(a2);
        return a3.a(a4);
    }

    public final T a(String a2) throws IOException {
        TypeAdapter a3;
        return a3.a(new StringReader(a2));
    }

    public final T a(JsonElement a2) {
        try {
            TypeAdapter a3;
            JsonTreeReader a4 = new JsonTreeReader(a2);
            return a3.a(a4);
        }
        catch (IOException a5) {
            throw new JsonIOException(a5);
        }
    }
}

