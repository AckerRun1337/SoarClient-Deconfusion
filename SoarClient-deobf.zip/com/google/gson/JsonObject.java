/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.google.gson.internal.LinkedTreeMap;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class JsonObject
extends JsonElement {
    private final LinkedTreeMap<String, JsonElement> d = new LinkedTreeMap();

    public JsonObject() {
        JsonObject a2;
    }

    public JsonObject p() {
        JsonObject a2;
        JsonObject a3 = new JsonObject();
        for (Map.Entry<String, JsonElement> a4 : a2.d.entrySet()) {
            a3.a(a4.getKey(), a4.getValue().a());
        }
        return a3;
    }

    public void a(String a2, JsonElement a3) {
        JsonObject a4;
        a4.d.put(a2, a3 == null ? JsonNull.d : a3);
    }

    public JsonElement p(String a2) {
        JsonObject a3;
        return a3.d.remove(a2);
    }

    public void a(String a2, String a3) {
        JsonObject a4;
        a4.a(a2, a3 == null ? JsonNull.d : new JsonPrimitive(a3));
    }

    public void a(String a2, Number a3) {
        JsonObject a4;
        a4.a(a2, a3 == null ? JsonNull.d : new JsonPrimitive(a3));
    }

    public void a(String a2, Boolean a3) {
        JsonObject a4;
        a4.a(a2, a3 == null ? JsonNull.d : new JsonPrimitive(a3));
    }

    public void a(String a2, Character a3) {
        JsonObject a4;
        a4.a(a2, a3 == null ? JsonNull.d : new JsonPrimitive(a3));
    }

    public Set<Map.Entry<String, JsonElement>> p() {
        JsonObject a2;
        return a2.d.entrySet();
    }

    public Set<String> a() {
        JsonObject a2;
        return a2.d.keySet();
    }

    public int p() {
        JsonObject a2;
        return a2.d.size();
    }

    public boolean a(String a2) {
        JsonObject a3;
        return a3.d.containsKey(a2);
    }

    public JsonElement a(String a2) {
        JsonObject a3;
        return a3.d.get(a2);
    }

    public JsonPrimitive a(String a2) {
        JsonObject a3;
        return (JsonPrimitive)a3.d.get(a2);
    }

    public JsonArray a(String a2) {
        JsonObject a3;
        return (JsonArray)a3.d.get(a2);
    }

    public JsonObject a(String a2) {
        JsonObject a3;
        return (JsonObject)a3.d.get(a2);
    }

    public boolean equals(Object a2) {
        JsonObject a3;
        return a2 == a3 || a2 instanceof JsonObject && ((JsonObject)a2).d.equals(a3.d);
    }

    public int hashCode() {
        JsonObject a2;
        return a2.d.hashCode();
    }
}

