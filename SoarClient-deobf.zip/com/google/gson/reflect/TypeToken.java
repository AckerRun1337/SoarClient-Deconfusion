/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.reflect;

import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.internal.$Gson$Types;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.HashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class TypeToken<T> {
    final Class<? super T> c;
    final Type v;
    final int d;

    protected TypeToken() {
        TypeToken a2;
        a2.v = TypeToken.a(a2.getClass());
        a2.c = $Gson$Types.a(a2.v);
        a2.d = a2.v.hashCode();
    }

    TypeToken(Type a2) {
        TypeToken a3;
        a3.v = $Gson$Types.p($Gson$Preconditions.a(a2));
        a3.c = $Gson$Types.a(a3.v);
        a3.d = a3.v.hashCode();
    }

    static Type a(Class<?> a2) {
        Type a3 = a2.getGenericSuperclass();
        if (a3 instanceof Class) {
            throw new RuntimeException("Missing type parameter.");
        }
        ParameterizedType a4 = (ParameterizedType)a3;
        return $Gson$Types.p(a4.getActualTypeArguments()[0]);
    }

    public final Class<? super T> a() {
        TypeToken a2;
        return a2.c;
    }

    public final Type a() {
        TypeToken a2;
        return a2.v;
    }

    @Deprecated
    public boolean a(Class<?> a2) {
        TypeToken a3;
        return a3.a((Type)a2);
    }

    @Deprecated
    public boolean a(Type a2) {
        TypeToken a3;
        if (a2 == null) {
            return false;
        }
        if (a3.v.equals(a2)) {
            return true;
        }
        if (a3.v instanceof Class) {
            return a3.c.isAssignableFrom((Class<?>)$Gson$Types.a(a2));
        }
        if (a3.v instanceof ParameterizedType) {
            return TypeToken.a(a2, (ParameterizedType)a3.v, new HashMap<String, Type>());
        }
        if (a3.v instanceof GenericArrayType) {
            return a3.c.isAssignableFrom((Class<?>)$Gson$Types.a(a2)) && TypeToken.a(a2, (GenericArrayType)a3.v);
        }
        throw TypeToken.a(a3.v, Class.class, ParameterizedType.class, GenericArrayType.class);
    }

    @Deprecated
    public boolean a(TypeToken<?> a2) {
        TypeToken a3;
        return a3.a(a2.a());
    }

    private static /* synthetic */ boolean a(Type a2, GenericArrayType a3) {
        Type a4 = a3.getGenericComponentType();
        if (a4 instanceof ParameterizedType) {
            Type a5 = a2;
            if (a2 instanceof GenericArrayType) {
                a5 = ((GenericArrayType)a2).getGenericComponentType();
            } else if (a2 instanceof Class) {
                Class<?> a6 = (Class<?>)a2;
                while (a6.isArray()) {
                    a6 = a6.getComponentType();
                }
                a5 = a6;
            }
            return TypeToken.a(a5, (ParameterizedType)a4, new HashMap<String, Type>());
        }
        return true;
    }

    private static /* synthetic */ boolean a(Type a2, ParameterizedType a3, Map<String, Type> a4) {
        if (a2 == null) {
            return false;
        }
        if (a3.equals(a2)) {
            return true;
        }
        Type a6 = $Gson$Types.a(a2);
        ParameterizedType a7 = null;
        if (a2 instanceof ParameterizedType) {
            a7 = (ParameterizedType)a2;
        }
        if (a7 != null) {
            Type[] typeArray = a7.getActualTypeArguments();
            TypeVariable<Class<T>>[] a8 = ((Class)a6).getTypeParameters();
            for (int a9 = 0; a9 < typeArray.length; ++a9) {
                Type a5 = typeArray[a9];
                TypeVariable a11 = a8[a9];
                while (a5 instanceof TypeVariable) {
                    TypeVariable a12 = (TypeVariable)a5;
                    a5 = a4.get(a12.getName());
                }
                a4.put(a11.getName(), a5);
            }
            if (TypeToken.a(a7, a3, a4)) {
                return true;
            }
        }
        for (Type a10 : ((Class)a6).getGenericInterfaces()) {
            if (!TypeToken.a(a10, a3, new HashMap<String, Type>(a4))) continue;
            return true;
        }
        Type type = ((Class)a6).getGenericSuperclass();
        return TypeToken.a(type, a3, new HashMap<String, Type>(a4));
    }

    private static /* synthetic */ boolean a(ParameterizedType a2, ParameterizedType a3, Map<String, Type> a4) {
        if (a2.getRawType().equals(a3.getRawType())) {
            Type[] a5 = a2.getActualTypeArguments();
            Type[] a6 = a3.getActualTypeArguments();
            for (int a7 = 0; a7 < a5.length; ++a7) {
                if (TypeToken.a(a5[a7], a6[a7], a4)) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    private static /* synthetic */ AssertionError a(Type a2, Class<?> ... a3) {
        StringBuilder a4 = new StringBuilder("Unexpected type. Expected one of: ");
        for (Class<?> a5 : a3) {
            a4.append(a5.getName()).append(", ");
        }
        a4.append("but got: ").append(a2.getClass().getName()).append(", for type token: ").append(a2.toString()).append('.');
        return new AssertionError((Object)a4.toString());
    }

    private static /* synthetic */ boolean a(Type a2, Type a3, Map<String, Type> a4) {
        return a3.equals(a2) || a2 instanceof TypeVariable && a3.equals(a4.get(((TypeVariable)a2).getName()));
    }

    public final int hashCode() {
        TypeToken a2;
        return a2.d;
    }

    public final boolean equals(Object a2) {
        TypeToken a3;
        return a2 instanceof TypeToken && $Gson$Types.a(a3.v, ((TypeToken)a2).v);
    }

    public final String toString() {
        TypeToken a2;
        return $Gson$Types.a(a2.v);
    }

    public static TypeToken<?> p(Type a2) {
        return new TypeToken(a2);
    }

    public static <T> TypeToken<T> a(Class<T> a2) {
        return new TypeToken<T>(a2);
    }

    public static TypeToken<?> a(Type a2, Type ... a3) {
        return new TypeToken($Gson$Types.a(null, a2, a3));
    }

    public static TypeToken<?> a(Type a2) {
        return new TypeToken($Gson$Types.a(a2));
    }
}

