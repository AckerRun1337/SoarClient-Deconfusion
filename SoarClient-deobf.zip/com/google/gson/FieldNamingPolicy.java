/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.FieldNamingStrategy;
import java.lang.reflect.Field;
import java.util.Locale;

public enum FieldNamingPolicy implements FieldNamingStrategy
{
    h{
        {
            1 a2;
        }

        @Override
        public String a(Field a2) {
            return a2.getName();
        }
    }
    ,
    z{
        {
            2 a2;
        }

        @Override
        public String a(Field a2) {
            return 2.a(a2.getName());
        }
    }
    ,
    l{
        {
            3 a2;
        }

        @Override
        public String a(Field a2) {
            return 3.a(3.a(a2.getName(), " "));
        }
    }
    ,
    b{
        {
            4 a2;
        }

        @Override
        public String a(Field a2) {
            return 4.a(a2.getName(), "_").toLowerCase(Locale.ENGLISH);
        }
    }
    ,
    c{
        {
            5 a2;
        }

        @Override
        public String a(Field a2) {
            return 5.a(a2.getName(), "-").toLowerCase(Locale.ENGLISH);
        }
    }
    ,
    v{
        {
            6 a2;
        }

        @Override
        public String a(Field a2) {
            return 6.a(a2.getName(), ".").toLowerCase(Locale.ENGLISH);
        }
    };


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private /* synthetic */ FieldNamingPolicy() {
        FieldNamingPolicy a2;
    }

    static String a(String a2, String a3) {
        StringBuilder a4 = new StringBuilder();
        int a5 = a2.length();
        for (int a6 = 0; a6 < a5; ++a6) {
            char a7 = a2.charAt(a6);
            if (Character.isUpperCase(a7) && a4.length() != 0) {
                a4.append(a3);
            }
            a4.append(a7);
        }
        return a4.toString();
    }

    static String a(String a2) {
        int a3;
        int a4 = a2.length() - 1;
        for (a3 = 0; !Character.isLetter(a2.charAt(a3)) && a3 < a4; ++a3) {
        }
        char a5 = a2.charAt(a3);
        if (Character.isUpperCase(a5)) {
            return a2;
        }
        char a6 = Character.toUpperCase(a5);
        if (a3 == 0) {
            return a6 + a2.substring(1);
        }
        return a2.substring(0, a3) + a6 + a2.substring(a3 + 1);
    }
}

