/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

public class JsonParseException
extends RuntimeException {
    static final long d = -4086729973971783390L;

    public JsonParseException(String a2) {
        super(a2);
        JsonParseException a3;
    }

    public JsonParseException(String a2, Throwable a3) {
        super(a2, a3);
        JsonParseException a4;
    }

    public JsonParseException(Throwable a2) {
        super(a2);
        JsonParseException a3;
    }
}

