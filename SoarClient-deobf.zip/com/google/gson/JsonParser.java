/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public final class JsonParser {
    @Deprecated
    public JsonParser() {
        JsonParser a2;
    }

    public static JsonElement p(String a2) throws JsonSyntaxException {
        return JsonParser.p(new StringReader(a2));
    }

    public static JsonElement p(Reader a2) throws JsonIOException, JsonSyntaxException {
        try {
            JsonReader a3 = new JsonReader(a2);
            JsonElement a4 = JsonParser.p(a3);
            if (!a4.p() && a3.a() != JsonToken.v) {
                throw new JsonSyntaxException("Did not consume the entire document.");
            }
            return a4;
        }
        catch (MalformedJsonException a5) {
            throw new JsonSyntaxException(a5);
        }
        catch (IOException a6) {
            throw new JsonIOException(a6);
        }
        catch (NumberFormatException a7) {
            throw new JsonSyntaxException(a7);
        }
    }

    public static JsonElement p(JsonReader a2) throws JsonIOException, JsonSyntaxException {
        boolean a3 = a2.o();
        a2.a(true);
        try {
            JsonElement jsonElement = Streams.a(a2);
            return jsonElement;
        }
        catch (StackOverflowError a4) {
            throw new JsonParseException("Failed parsing JSON source: " + a2 + " to Json", a4);
        }
        catch (OutOfMemoryError a5) {
            throw new JsonParseException("Failed parsing JSON source: " + a2 + " to Json", a5);
        }
        finally {
            a2.a(a3);
        }
    }

    @Deprecated
    public JsonElement a(String a2) throws JsonSyntaxException {
        return JsonParser.p(a2);
    }

    @Deprecated
    public JsonElement a(Reader a2) throws JsonIOException, JsonSyntaxException {
        return JsonParser.p(a2);
    }

    @Deprecated
    public JsonElement a(JsonReader a2) throws JsonIOException, JsonSyntaxException {
        return JsonParser.p(a2);
    }
}

