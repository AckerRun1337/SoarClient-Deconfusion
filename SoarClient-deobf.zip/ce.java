/*
 * Decompiled with CFR 0.152.
 */
public interface ce {
    public xga o();

    public boolean a(xub var1, sy var2, float var3);
}

