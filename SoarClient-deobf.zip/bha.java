/*
 * Decompiled with CFR 0.152.
 */
public class bha
extends bh {
    private /* synthetic */ boolean d;

    public bha() {
        super("Sneak", 0, gk.c);
        bha a2;
    }

    @Override
    public void y() {
        a.d = false;
    }

    @fo
    public void a(ghb a2) {
        bha a3;
        if (a2.a() == a3.g.jb.hk.a()) {
            a3.d = !a3.d;
        }
    }

    @fo
    public void a(zgd a2) {
        bha a3;
        if (a3.d) {
            bcd.a(a3.g.jb.hk.a(), true);
        } else {
            bcd.a(a3.g.jb.hk.a(), false);
        }
        if (a3.g.sb instanceof xf) {
            bcd.a(a3.g.jb.hk.a(), false);
        }
    }

    @Override
    public void p() {
        bha a2;
        super.p();
        a2.d = false;
    }
}

