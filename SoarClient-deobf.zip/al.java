/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class al
extends jn {
    private final ke b;
    private final float c;
    private final float v;
    private final float d;

    public al(int a2, String a3, boolean a4, ke a5, float a6, float a7, float a8) {
        super(a2, a3, a4);
        al a9;
        a9.b = a5;
        a9.c = a6;
        a9.v = a7;
        a9.d = a8;
    }

    public ke a() {
        al a2;
        return a2.b;
    }

    public float o() {
        al a2;
        return a2.c;
    }

    public float p() {
        al a2;
        return a2.v;
    }

    public float a() {
        al a2;
        return a2.d;
    }
}

