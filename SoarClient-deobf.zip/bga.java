/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;

class bga
extends ch {
    private final List<String> c;
    private final Map<String, iqa> v;
    final /* synthetic */ dld d;

    public bga(dld a2, oj a3) {
        bga a4;
        a4.d = a2;
        super(a3, dld.n, dld.e, 32, dld.e - 65 + 4, 18);
        a4.c = Lists.newArrayList();
        a4.v = Maps.newHashMap();
        for (iqa iqa2 : dld.a(a2).a()) {
            a4.v.put(iqa2.a(), iqa2);
            a4.c.add(iqa2.a());
        }
    }

    @Override
    protected int x() {
        bga a2;
        return a2.c.size();
    }

    @Override
    protected void a(int a2, boolean a3, int a4, int a5) {
    }

    @Override
    protected boolean p(int a2) {
        bga a3;
        return a3.c.get(a2).equals(dld.a(a3.d).a().a());
    }

    @Override
    protected int j() {
        bga a2;
        return a2.x() * 18;
    }

    @Override
    protected void o() {
        bga a2;
        a2.d.o();
    }

    @Override
    protected void a(int a2, int a3, int a4, int a5, int a6, int a7) {
        bga a8;
        ((gic)((Object)a8.d.z)).a(true);
        a8.d.p((gic)((Object)a8.d.z), a8.v.get(a8.c.get(a2)).toString(), a8.m / 2, a4 + 1, 0xFFFFFF);
        ((gic)((Object)a8.d.z)).a(dld.a(a8.d).a().a());
    }
}

