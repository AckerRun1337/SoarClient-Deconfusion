/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cv
extends mi {
    private efb r;
    private xi f;
    xga h;
    private double z;
    private qta l;
    private int b;
    float c;
    float v;
    private boolean d;

    public cv(efb a2, double a3, float a4, float a5) {
        cv a6;
        a6.r = a2;
        a6.h = a2.ib;
        a6.z = a3;
        a6.l = a2.a();
        a6.v = a4;
        a6.c = a5;
        a6.a(3);
        if (!(a2.a() instanceof hsa)) {
            throw new IllegalArgumentException("Unsupported mob type for FollowOwnerGoal");
        }
    }

    @Override
    public boolean o() {
        cv a2;
        xi xi2 = a2.r.z();
        if (xi2 == null) {
            return false;
        }
        if (xi2 instanceof pm && ((pm)xi2).wa()) {
            return false;
        }
        if (a2.r.la()) {
            return false;
        }
        if (a2.r.a((rj)xi2) < (double)(a2.v * a2.v)) {
            return false;
        }
        a2.f = xi2;
        return true;
    }

    @Override
    public boolean p() {
        cv a2;
        return !a2.l.o() && a2.r.a((rj)a2.f) > (double)(a2.c * a2.c) && !a2.r.la();
    }

    @Override
    public void o() {
        cv a2;
        a2.b = 0;
        a2.d = ((hsa)a2.r.a()).j();
        ((hsa)a2.r.a()).z(false);
    }

    @Override
    public void p() {
        cv a2;
        a2.f = null;
        a2.l.p();
        ((hsa)a2.r.a()).z(true);
    }

    private /* synthetic */ boolean a(tp a2) {
        cv a3;
        ba ba2 = a3.h.a(a2);
        yd yd2 = ba2.a();
        return yd2 == cl.cd ? true : !yd2.r();
    }

    @Override
    public void a() {
        cv a2;
        a2.r.a().a(a2.f, 10.0f, (float)a2.r.l());
        if (!a2.r.la() && --a2.b <= 0) {
            a2.b = 10;
            if (!a2.l.a(a2.f, a2.z) && !a2.r.pa() && a2.r.a((rj)a2.f) >= 144.0) {
                int n2 = smb.o((double)a2.f.fb) - 2;
                int n3 = smb.o((double)a2.f.db) - 2;
                int n4 = smb.o(a2.f.a().l);
                int n5 = 0;
                while (n5 <= 4) {
                    int n6 = 0;
                    while (n6 <= 4) {
                        if ((n5 < 1 || n6 < 1 || n5 > 3 || n6 > 3) && xga.a(a2.h, new tp(n2 + n5, n4 - 1, n3 + n6)) && a2.a(new tp(n2 + n5, n4, n3 + n6)) && a2.a(new tp(n2 + n5, n4 + 1, n3 + n6))) {
                            a2.r.p((float)(n2 + n5) + 0.5f, n4, (float)(n3 + n6) + 0.5f, a2.r.nb, a2.r.rb);
                            a2.l.p();
                            return;
                        }
                        ++n6;
                    }
                    ++n5;
                }
            }
        }
    }
}

