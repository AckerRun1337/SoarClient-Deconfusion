/*
 * Decompiled with CFR 0.152.
 */
/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cu {
    private aib d;

    public cu(aib a2) {
        cu a3;
        a3.d = a2;
    }

    public aib a() {
        cu a2;
        return a2.d;
    }

    public boolean a() {
        cu a2;
        return a2.d.a();
    }

    public int o() {
        cu a2;
        return a2.d.p();
    }

    public int p() {
        cu a2;
        return a2.d.a();
    }

    public int a() {
        cu a2;
        return a2.d.o();
    }

    public int hashCode() {
        cu a2;
        return a2.d.hashCode();
    }

    public boolean equals(Object a2) {
        cu a3;
        return a3.d.equals(a2);
    }

    public String toString() {
        cu a2;
        return a2.d.toString();
    }
}

