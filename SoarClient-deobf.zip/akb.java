/*
 * Decompiled with CFR 0.152.
 */
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import net.optifine.util.\u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class akb {
    private static String e = null;
    private static String r = null;
    private static boolean f = false;
    private static boolean h = false;
    private static boolean z = false;
    private static boolean l = false;
    private static float b;
    private static float c;
    private static final String v = ".png";
    private static final wmc d;

    static {
        d = new wmc("mcpatcher/ctm/default/empty.png");
    }

    public akb() {
        akb a2;
    }

    public static boolean p() {
        return f;
    }

    public static String a() {
        return e;
    }

    public static void z() {
        h = true;
        z = false;
    }

    public static dc a(dc a2, Map<wmc, dc> a3) {
        dc dc2;
        if (!h) {
            return a2;
        }
        if (!(a2 instanceof mnd)) {
            return a2;
        }
        mnd mnd2 = (mnd)a2;
        wmc wmc2 = mnd2.v;
        if (!l) {
            if (wmc2 != null) {
                z = true;
            }
            return a2;
        }
        if (wmc2 == null) {
            wmc2 = d;
        }
        if ((dc2 = a3.get(wmc2)) == null) {
            dc2 = new mnd(wmc2);
            ov ov2 = xfc.a();
            ov2.a(wmc2, dc2);
        }
        return dc2;
    }

    public static boolean a() {
        return z;
    }

    public static void y() {
        b = nla.f;
        c = nla.h;
        nla.a(nla.da, 240.0f, c);
        l = true;
    }

    public static void o() {
        l = false;
        nla.a(nla.da, b, c);
    }

    public static void p() {
        h = false;
        z = false;
    }

    public static void a() {
        f = false;
        e = null;
        r = null;
        if (xfc.u()) {
            try {
                String string = "optifine/emissive.properties";
                wmc wmc2 = new wmc(string);
                InputStream inputStream = xfc.a(wmc2);
                if (inputStream == null) {
                    return;
                }
                akb.p("Loading " + string);
                \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2 = new \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a();
                \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2.load(inputStream);
                inputStream.close();
                e = \u9318\u90aa\u7a84\u5e45\u5208\u69cd\u6b63\u8ed2\u8f5f\u8a51\u62b5\u5165\u8e5f\u554f\u637b\u9091\u59ff\u9583\u76e4\u5957\u6c7a\u4ea8\u53f3\u5fb3\u981a\u5165\u8377\u8aac\u77db\u9f13\u4f55\u8a9e\u53f3\u8377\u5949\u5f71\u4f7c\u847a\u64ae\u682a2.getProperty("suffix.emissive");
                if (e != null) {
                    r = String.valueOf(e) + v;
                }
                f = e != null;
            }
            catch (FileNotFoundException fileNotFoundException) {
                return;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    private static /* synthetic */ void p(String a2) {
        xfc.j("EmissiveTextures: " + a2);
    }

    private static /* synthetic */ void a(String a2) {
        xfc.z("EmissiveTextures: " + a2);
    }

    public static boolean a(wmc a2) {
        return r == null ? false : a2.p().endsWith(r);
    }

    public static void a(wmc a2, mnd a3) {
        if (a2 != null && a3 != null) {
            String string;
            a3.d = false;
            a3.v = null;
            if (r != null && (string = a2.p()).endsWith(v)) {
                if (string.endsWith(r)) {
                    a3.d = true;
                } else {
                    String string2 = String.valueOf(string.substring(0, string.length() - v.length())) + r;
                    wmc wmc2 = new wmc(a2.a(), string2);
                    if (xfc.p(wmc2)) {
                        a3.v = wmc2;
                    }
                }
            }
        }
    }
}

