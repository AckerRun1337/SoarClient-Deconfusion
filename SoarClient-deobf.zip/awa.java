/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class awa {
    private final int z;
    private final int l;
    private final int b;
    private final int c;
    private List<awa> v;
    private gma d;

    public awa(int a2, int a3, int a4, int a5) {
        awa a6;
        a6.z = a2;
        a6.l = a3;
        a6.b = a4;
        a6.c = a5;
    }

    public gma a() {
        awa a2;
        return a2.d;
    }

    public int p() {
        awa a2;
        return a2.z;
    }

    public int a() {
        awa a2;
        return a2.l;
    }

    public boolean a(gma a2) {
        awa a3;
        if (a3.d != null) {
            return false;
        }
        int n2 = a2.p();
        int n3 = a2.a();
        if (n2 <= a3.b && n3 <= a3.c) {
            if (n2 == a3.b && n3 == a3.c) {
                a3.d = a2;
                return true;
            }
            if (a3.v == null) {
                a3.v = Lists.newArrayListWithCapacity((int)1);
                a3.v.add(new awa(a3.z, a3.l, n2, n3));
                int n4 = a3.b - n2;
                int n5 = a3.c - n3;
                if (n5 > 0 && n4 > 0) {
                    int n6;
                    int n7 = Math.max(a3.c, n4);
                    if (n7 >= (n6 = Math.max(a3.b, n5))) {
                        a3.v.add(new awa(a3.z, a3.l + n3, n2, n5));
                        a3.v.add(new awa(a3.z + n2, a3.l, n4, a3.c));
                    } else {
                        a3.v.add(new awa(a3.z + n2, a3.l, n4, n3));
                        a3.v.add(new awa(a3.z, a3.l + n3, a3.b, n5));
                    }
                } else if (n4 == 0) {
                    a3.v.add(new awa(a3.z, a3.l + n3, n2, n5));
                } else if (n5 == 0) {
                    a3.v.add(new awa(a3.z + n2, a3.l, n4, n3));
                }
            }
            for (awa awa2 : a3.v) {
                if (!awa2.a(a2)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public void a(List<awa> a2) {
        awa a3;
        if (a3.d != null) {
            a2.add(a3);
        } else if (a3.v != null) {
            for (awa awa2 : a3.v) {
                awa2.a(a2);
            }
        }
    }

    public String toString() {
        awa a2;
        return "Slot{originX=" + a2.z + ", originY=" + a2.l + ", width=" + a2.b + ", height=" + a2.c + ", texture=" + a2.d + ", subSlots=" + a2.v + '}';
    }
}

