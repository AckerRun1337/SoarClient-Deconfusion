/*
 * Decompiled with CFR 0.152.
 */
import java.net.Proxy;
import java.util.LinkedHashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class dcc {
    private String s = null;
    private int w = 0;
    private Proxy i = Proxy.NO_PROXY;
    private String n = null;
    private String e = null;
    private String r = null;
    private Map<String, String> f = new LinkedHashMap<String, String>();
    private byte[] h = null;
    private int z = 0;
    public static final String l = "GET";
    public static final String b = "HEAD";
    public static final String c = "POST";
    public static final String v = "HTTP/1.0";
    public static final String d = "HTTP/1.1";

    public dcc(String a2, int a3, Proxy a4, String a5, String a6, String a7, Map<String, String> a8, byte[] a9) {
        dcc a10;
        a10.s = a2;
        a10.w = a3;
        a10.i = a4;
        a10.n = a5;
        a10.e = a6;
        a10.r = a7;
        a10.f = a8;
        a10.h = a9;
    }

    public String y() {
        dcc a2;
        return a2.s;
    }

    public int p() {
        dcc a2;
        return a2.w;
    }

    public String o() {
        dcc a2;
        return a2.n;
    }

    public String p() {
        dcc a2;
        return a2.e;
    }

    public String a() {
        dcc a2;
        return a2.r;
    }

    public Map<String, String> a() {
        dcc a2;
        return a2.f;
    }

    public byte[] a() {
        dcc a2;
        return a2.h;
    }

    public int a() {
        dcc a2;
        return a2.z;
    }

    public void a(int a2) {
        a.z = a2;
    }

    public Proxy a() {
        dcc a2;
        return a2.i;
    }
}

